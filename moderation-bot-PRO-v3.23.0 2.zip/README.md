# Moderation & Tickets Bot — v3.23.0

بوت ديسكورد عربي متكامل بهوية زرقاء غامقة: تذاكر احترافية، منع سبام، ذكاء اصطناعي مع تشغيل يوتيوب والقرآن، قيف اوي، فضفضة، جدولة التوب، ترحيب، مستويات، دوام، راديو وغيرها. **كل نظام له أمر واحد وقائمة تحكم خاصة.**

> الدليل الكامل خطوة بخطوة من الصفر: [`docs/GUIDE-AR.md`](docs/GUIDE-AR.md)
> شرح كل ميزة وأوامرها: [`docs/FEATURES.md`](docs/FEATURES.md)

## تشغيل سريع

```bash
cp .env.example .env        # ضع DISCORD_TOKEN داخله
npm install
npm start
```

## Docker (موصى به على VPS)

```bash
docker compose up -d --build
docker compose logs -f
```

## PM2

```bash
npm install && npm i -g pm2
pm2 start ecosystem.config.js && pm2 save && pm2 startup
```

## متغيرات البيئة

| المتغير | الوصف |
|---|---|
| `DISCORD_TOKEN` | توكن البوت (إجباري، لا يوضع في الملفات) |
| `ANTHROPIC_API_KEY` | مفتاح الذكاء الاصطناعي (اختياري، لنظام `/ai`) |
| `AI_MODEL` | نموذج الذكاء الاصطناعي (افتراضي `claude-haiku-5-5`) |
| `DATA_DIR` | مجلد البيانات (اختياري) |
| `CONFIG_PATH` | مسار `config.json` الحي (اختياري) |
| `BACKUP_DIR` | مجلد النسخ الاحتياطي (اختياري) |

## الأمان

- لا ترفع `.env` ولا التوكن إلى GitHub. المستودع يجب أن يكون **Private**.
- فحص `CI` يفشل تلقائياً إذا وُجد توكن داخل الملفات.
- شغّل نسخة **واحدة** فقط من البوت.
