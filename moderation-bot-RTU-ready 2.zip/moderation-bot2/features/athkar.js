'use strict';
/**
 * نظام الأذكار /athkar
 * إرسال ذكر أو دعاء عشوائي كل مدة محددة في روم تحدده الإدارة، مع صورة الأذكار.
 */
module.exports = (H) => {
const { D, client, BLUE, SERVER_ID, save, EPH, row, btn, chSel, strSel, embed, adminOnly, update, onOff, chTxt, path, fs } = H;
const { ButtonStyle, AttachmentBuilder } = D;
const DATA = require('./athkar-data');
const ASSETS_DIR = path.join(__dirname, '..', 'assets');
// صور الأذكار المتعددة (الآيات القرآنية الاحترافية)
const ATHKAR_IMAGES = [
    'athkar1.jpg', 'athkar2.jpg', 'athkar3.jpg', 'athkar4.jpg', 'athkar5.jpg',
    'athkar6.jpg', 'athkar7.jpg', 'athkar8.jpg', 'athkar10.jpg', 'athkar11.jpg',
    'athkar.jpg'
].filter(name => {
    try { return fs.existsSync(path.join(ASSETS_DIR, name)); } catch { return false; }
});
const INTERVALS = [
    { label: 'كل 15 دقيقة', value: '15' }, { label: 'كل 30 دقيقة', value: '30' }, { label: 'كل ساعة', value: '60' },
    { label: 'كل ساعتين', value: '120' }, { label: 'كل 3 ساعات', value: '180' }, { label: 'كل 6 ساعات', value: '360' },
    { label: 'كل 12 ساعة', value: '720' }, { label: 'كل يوم', value: '1440' }
];
const intervalName = m => (INTERVALS.find(x => x.value === String(m)) || { label: 'كل ' + m + ' دقيقة' }).label;

const cfg = () => {
    const s = (H.db.athkar = H.db.athkar || {});
    s.enabled = !!s.enabled;
    s.channelId = s.channelId || '';
    s.intervalMin = Number(s.intervalMin) >= 15 ? Number(s.intervalMin) : 60;
    if (!Array.isArray(s.categories) || !s.categories.length) s.categories = Object.keys(DATA);
    s.categories = s.categories.filter(k => DATA[k]);
    if (!s.categories.length) s.categories = Object.keys(DATA);
    s.lastSentAt = s.lastSentAt || 0;
    s.lastText = s.lastText || '';
    return s;
};

function pickRandom(s) {
    const pool = [];
    for (const k of s.categories) for (const t of DATA[k].items) pool.push({ k, t });
    let c = pool[Math.floor(Math.random() * pool.length)];
    // تجنب تكرار نفس الذكر مرتين متتاليتين
    for (let n = 0; n < 5 && pool.length > 1 && c.t === s.lastText; n++) c = pool[Math.floor(Math.random() * pool.length)];
    return c;
}

function buildMessage(c, guild) {
    const cat = DATA[c.k];
    const e = embed()
        .setAuthor({ name: '📿 ' + cat.name })
        .setDescription('# ' + c.t + '\n\n**النوع:** ' + cat.name + (c.t.match(/\d+\s*مرة/) ? '  •  **العدد:** ' + c.t.match(/\d+\s*مرة/)[0] : ''))
        .setFooter({ text: 'اذكروا الله يذكركم', ...(guild && guild.iconURL && guild.iconURL() ? { iconURL: guild.iconURL() } : {}) });
    const payload = { embeds: [e] };
    try {
        // اختيار صورة عشوائية من صور الآيات القرآنية
        if (ATHKAR_IMAGES.length > 0) {
            const randomImg = ATHKAR_IMAGES[Math.floor(Math.random() * ATHKAR_IMAGES.length)];
            const imgPath = path.join(ASSETS_DIR, randomImg);
            payload.files = [new AttachmentBuilder(imgPath, { name: 'athkar.jpg' })];
            e.setImage('attachment://athkar.jpg');
        }
    } catch {}
    return payload;
}

async function sendOne(force) {
    const s = cfg();
    if (!s.channelId) throw new Error('لم يتم تحديد روم الأذكار.');
    const guild = client.guilds.cache.get(SERVER_ID) || client.guilds.cache.first();
    const ch = guild && (guild.channels.cache.get(s.channelId) || await guild.channels.fetch(s.channelId).catch(() => null));
    if (!ch || !ch.isTextBased || !ch.isTextBased()) throw new Error('الروم المحدد غير موجود أو لا أستطيع الكتابة فيه.');
    const c = pickRandom(s);
    await ch.send(buildMessage(c, guild));
    s.lastText = c.t;
    s.lastSentAt = Date.now();
    save();
}

let timer = null;
function startScheduler() {
    if (timer) return;
    console.log('[athkar] ✅ نظام الأذكار جاهز — استخدم /athkar');
    timer = setInterval(async () => {
        try {
            const s = cfg();
            if (!s.enabled || !s.channelId) return;
            if (Date.now() - s.lastSentAt < s.intervalMin * 60000) return;
            s.lastSentAt = Date.now(); // نحجز الموعد أولاً حتى لا يتكرر الإرسال عند التأخر
            await sendOne();
        } catch (e) { console.error('[athkar]', e.message); }
    }, 30000);
    if (timer.unref) timer.unref();
}

function buildPanel() {
    const s = cfg();
    const e = embed()
        .setTitle('📿 نظام الأذكار')
        .setDescription('يرسل ذكراً أو دعاءً عشوائياً في الروم الذي تحدده، مع صورة الأذكار.')
        .addFields(
            { name: 'الحالة', value: onOff(s.enabled), inline: true },
            { name: 'الروم', value: chTxt(s.channelId), inline: true },
            { name: 'التكرار', value: intervalName(s.intervalMin), inline: true },
            { name: 'الأقسام المفعلة', value: s.categories.map(k => DATA[k].emoji + ' ' + DATA[k].name).join('\n') }
        );
    return {
        embeds: [e],
        components: [
            row(
                btn('ath:toggle', s.enabled ? 'إيقاف' : 'تشغيل', s.enabled ? '⏹️' : '▶️', s.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
                btn('ath:now', 'أرسل الآن', '📨', ButtonStyle.Primary)
            ),
            row(chSel('ath:setch', 'اختر روم الأذكار', { selected: s.channelId ? [s.channelId] : [] })),
            row(strSel('ath:int', 'كل كم يُرسل ذكر؟', INTERVALS.map(x => ({ ...x, default: x.value === String(s.intervalMin) })))),
            row(strSel('ath:cats', 'الأقسام التي تُرسل', Object.keys(DATA).map(k => ({ label: DATA[k].name, value: k, emoji: DATA[k].emoji, default: s.categories.includes(k) })), { min: 1, max: Object.keys(DATA).length }))
        ]
    };
}

async function component(i) {
    if (!(await adminOnly(i))) return;
    const s = cfg();
    const a = i.customId.split(':')[1];
    if (a === 'toggle') {
        if (!s.enabled && !s.channelId) return i.reply({ content: '⚠️ حدد روم الأذكار أولاً.', flags: EPH });
        s.enabled = !s.enabled;
        if (s.enabled) s.lastSentAt = 0; // يرسل أول ذكر خلال نصف دقيقة
        save();
        return update(i, buildPanel());
    }
    if (a === 'now') {
        await i.deferReply({ flags: EPH });
        try { await sendOne(true); return i.editReply({ content: '✅ تم إرسال ذكر في <#' + s.channelId + '>' }); }
        catch (e) { return i.editReply({ content: '❌ ' + e.message }); }
    }
    if (a === 'setch') { s.channelId = i.values[0]; save(); return update(i, buildPanel()); }
    if (a === 'int') { s.intervalMin = Number(i.values[0]); save(); return update(i, buildPanel()); }
    if (a === 'cats') { s.categories = i.values.filter(k => DATA[k]); save(); return update(i, buildPanel()); }
}

async function slash(i) {
    if (!(await adminOnly(i))) return;
    return i.reply({ ...buildPanel(), flags: EPH });
}

return {
    prefix: 'ath',
    commands: [{ name: 'athkar', description: 'نظام الأذكار: ذكر عشوائي في روم تحدده' }],
    ephemeral: ['athkar'],
    slash: { athkar: slash },
    component,
    onReady: startScheduler
};
};
