import asyncio
import json
import logging
import os
import random
import shutil
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

import aiohttp
import discord
from discord import app_commands
from discord.ext import commands, tasks
from dotenv import load_dotenv


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
SETTINGS_FILE = DATA_DIR / "settings.json"
ALQURAN_API = "https://api.alquran.cloud/v1"
ALADHAN_API = "https://api.aladhan.com/v1"
DEFAULT_EDITION = "ar.alafasy"
HTTP_TIMEOUT = aiohttp.ClientTimeout(total=35)
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("quran-bot")


RECITERS = {
    "مشاري العفاسي": "ar.alafasy",
    "محمود خليل الحصري": "ar.husary",
    "عبدالرحمن السديس": "ar.abdurrahmaansudais",
    "عبدالباسط عبدالصمد": "ar.abdulsamad",
    "أبو بكر الشاطري": "ar.shaatree",
    "أحمد العجمي": "ar.ahmedajamy",
    "هاني الرفاعي": "ar.hanirifai",
    "عبدالله بصفر": "ar.abdullahbasfar",
}
RECITER_CHOICES = [
    app_commands.Choice(name=name, value=edition)
    for name, edition in RECITERS.items()
]

SURAHS = [
    "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام",
    "الأعراف", "الأنفال", "التوبة", "يونس", "هود", "يوسف", "الرعد",
    "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
    "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء",
    "النمل", "القصص", "العنكبوت", "الروم", "لقمان", "السجدة", "الأحزاب",
    "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر", "فصلت",
    "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح",
    "الحجرات", "ق", "الذاريات", "الطور", "النجم", "القمر", "الرحمن",
    "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة", "الصف",
    "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك",
    "القلم", "الحاقة", "المعارج", "نوح", "الجن", "المزمل", "المدثر",
    "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
    "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق",
    "الأعلى", "الغاشية", "الفجر", "البلد", "الشمس", "الليل", "الضحى",
    "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
    "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون",
    "الكوثر", "الكافرون", "النصر", "المسد", "الإخلاص", "الفلق", "الناس",
]

QURANIC_DUAS = [
    ("رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", "البقرة 2:201"),
    ("رَبِّ زِدْنِي عِلْمًا", "طه 20:114"),
    ("رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِنْ لَدُنْكَ رَحْمَةً", "آل عمران 3:8"),
    ("رَبِّ اشْرَحْ لِي صَدْرِي ۝ وَيَسِّرْ لِي أَمْرِي", "طه 20:25–26"),
    ("رَبَّنَا ظَلَمْنَا أَنْفُسَنَا وَإِنْ لَمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ", "الأعراف 7:23"),
    ("رَبِّ اغْفِرْ وَارْحَمْ وَأَنْتَ خَيْرُ الرَّاحِمِينَ", "المؤمنون 23:118"),
]
RAMADAN_DUAS = [
    ("رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", "البقرة 2:201"),
    ("رَبَّنَا تَقَبَّلْ مِنَّا إِنَّكَ أَنْتَ السَّمِيعُ الْعَلِيمُ", "البقرة 2:127"),
    ("رَبَّنَا أَفْرِغْ عَلَيْنَا صَبْرًا وَتَوَفَّنَا مُسْلِمِينَ", "الأعراف 7:126"),
]
HADITHS = [
    ("إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى.", "صحيح البخاري، حديث 1؛ وصحيح مسلم، حديث 1907"),
    ("خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ.", "صحيح البخاري، حديث 5027"),
    ("لا يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ.", "صحيح البخاري، حديث 13؛ وصحيح مسلم، حديث 45"),
]
ASMA = [
    ("الرَّحْمَن", "واسع الرحمة"), ("الرَّحِيم", "الذي يرحم عباده"),
    ("الْمَلِك", "المالك المتصرف"), ("الْقُدُّوس", "المنزّه عن النقص"),
    ("السَّلَام", "السالم من كل نقص"), ("الْمُؤْمِن", "واهب الأمن"),
    ("الْعَزِيز", "الغالب الذي لا يُغلب"), ("الْغَفَّار", "كثير المغفرة"),
    ("الْوَهَّاب", "كثير العطاء"), ("الرَّزَّاق", "الذي يرزق خلقه"),
    ("الْعَلِيم", "المحيط علمه بكل شيء"), ("السَّمِيع", "الذي يسمع كل شيء"),
    ("الْبَصِير", "الذي يرى كل شيء"), ("الْحَكِيم", "المتقن لأمره"),
    ("الْكَرِيم", "كثير الخير والعطاء"), ("اللَّطِيف", "الرفيق بعباده"),
    ("الْحَفِيظ", "الحافظ لكل شيء"), ("التَّوَّاب", "القابل توبة عباده"),
    ("الْحَيّ", "كامل الحياة"), ("الْقَيُّوم", "القائم بنفسه ومدبّر خلقه"),
]
PROPHETS = {
    "آدم": "ورد ذكره في القرآن، ومنها البقرة 2:31–37.",
    "إدريس": "ورد ذكره في مريم 19:56–57.",
    "نوح": "وردت قصته في سورة نوح وسور أخرى.",
    "هود": "وردت قصته في سورة هود 11:50–60.",
    "صالح": "وردت قصته في سورة هود 11:61–68.",
    "إبراهيم": "وردت قصته في سور متعددة، ومنها إبراهيم 14.",
    "لوط": "وردت قصته في سور متعددة، ومنها هود 11:77–83.",
    "إسماعيل": "ورد ذكره في مريم 19:54–55.",
    "إسحاق": "ورد ذكره في هود 11:71–73.",
    "يعقوب": "ورد ذكره في سور متعددة، ومنها يوسف 12.",
    "يوسف": "قصته في سورة يوسف 12.",
    "أيوب": "ورد ذكره في الأنبياء 21:83–84.",
    "شعيب": "وردت قصته في سورة هود 11:84–95.",
    "موسى": "ورد ذكره في مواضع كثيرة، ومنها القصص 28.",
    "هارون": "ورد ذكره في طه 20:29–36.",
    "ذو الكفل": "ورد ذكره في الأنبياء 21:85.",
    "داود": "ورد ذكره في ص 38:17–26.",
    "سليمان": "ورد ذكره في النمل 27:15–44.",
    "إلياس": "ورد ذكره في الصافات 37:123–132.",
    "اليسع": "ورد ذكره في الأنعام 6:86.",
    "يونس": "ورد ذكره في سورة يونس 10 والأنبياء 21:87.",
    "زكريا": "وردت قصته في آل عمران 3:37–41.",
    "يحيى": "ورد ذكره في مريم 19:7–15.",
    "عيسى": "ورد ذكره في سور متعددة، ومنها آل عمران 3:45–55.",
    "محمد": "خاتم النبيين؛ ورد ذكره في مواضع كثيرة، ومنها الأحزاب 33:40.",
}
QURAN_WORDS = [
    ("الصَّمَد", "المقصود في الحوائج", "الإخلاص 112:2"),
    ("الْفَلَق", "الصبح", "الفلق 113:1"),
    ("الْكَوْثَر", "الخير الكثير", "الكوثر 108:1"),
    ("الْفُرْقَان", "ما يفرّق بين الحق والباطل", "الفرقان 25:1"),
    ("السَّكِينَة", "الطمأنينة", "الفتح 48:4"),
    ("الْبُرْهَان", "الحجة الواضحة", "النساء 4:174"),
]
CHALLENGES = [
    "اقرأ صفحتين من القرآن بتدبر اليوم.",
    "احفظ آية قصيرة وراجع معناها من تفسير موثوق.",
    "أرسل ذكرًا طيبًا لشخص تحبه.",
    "خصّص خمس دقائق للدعاء لشخص آخر.",
    "اقرأ سورة قصيرة وحاول تطبيق معنى واحد منها.",
]
AZKAR = [
    "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
    "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ",
    "لَا إِلَهَ إِلَّا اللَّهُ",
    "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ",
]
QUIZZES = [
    ("كم عدد سور القرآن الكريم؟", ["114", "110", "120", "99"], "114"),
    ("ما السورة التي لا تبدأ بالبسملة؟", ["التوبة", "الأنفال", "يونس", "النمل"], "التوبة"),
    ("ما أطول سورة في القرآن؟", ["البقرة", "آل عمران", "النساء", "المائدة"], "البقرة"),
    ("ما أقصر سورة في القرآن؟", ["الكوثر", "العصر", "الإخلاص", "النصر"], "الكوثر"),
]


def load_settings():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    try:
        return json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"azkar": {}}


def save_settings():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp_file = SETTINGS_FILE.with_suffix(".tmp")
    temp_file.write_text(
        json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    temp_file.replace(SETTINGS_FILE)


settings = load_settings()
user_counts = {}
tasbih_counts = {}
started_at = time.monotonic()
quran_cache = {}
http_session = None
synced = False


async def api_json(url):
    global http_session
    if http_session is None or http_session.closed:
        http_session = aiohttp.ClientSession(timeout=HTTP_TIMEOUT)
    async with http_session.get(url) as response:
        response.raise_for_status()
        result = await response.json(content_type=None)
    if result.get("code", 200) != 200 or result.get("status", "OK") != "OK":
        raise RuntimeError("تعذّر الحصول على البيانات من الخدمة.")
    return result.get("data")


@dataclass
class AyahTrack:
    surah_number: int
    ayah_number: int
    text: str
    audio_url: str


async def load_audio_edition(edition):
    if edition in quran_cache:
        return quran_cache[edition]
    data = await api_json(f"{ALQURAN_API}/quran/{quote(edition, safe='.')}")
    tracks = []
    for surah in data.get("surahs", []):
        for ayah in surah.get("ayahs", []):
            audio_url = ayah.get("audio")
            if audio_url:
                tracks.append(
                    AyahTrack(
                        surah_number=surah["number"],
                        ayah_number=ayah["numberInSurah"],
                        text=ayah.get("text", ""),
                        audio_url=audio_url,
                    )
                )
    if not tracks:
        raise RuntimeError("لم تُرجع الخدمة ملفات صوتية لهذا القارئ.")
    quran_cache[edition] = tracks
    return tracks


async def get_surah_text(surah_number, edition="quran-uthmani"):
    data = await api_json(f"{ALQURAN_API}/surah/{surah_number}/{quote(edition, safe='.')}")
    return data


async def fetch_tafsir(surah_number, ayah_number):
    data = await api_json(
        f"{ALQURAN_API}/ayah/{surah_number}:{ayah_number}/ar.muyassar"
    )
    return data.get("text", "")


def surah_start_index(tracks, surah_number):
    for index, track in enumerate(tracks):
        if track.surah_number == surah_number:
            return index
    return 0


class QuranPlayer:
    def __init__(self, bot, guild):
        self.bot = bot
        self.guild = guild
        self.voice_channel_id = None
        self.edition = DEFAULT_EDITION
        self.tracks = []
        self.index = 0
        self.volume = 0.7
        self.task = None
        self.stop_requested = False
        self.current_track = None
        self.last_error = None

    def begin(self):
        self.stop_requested = False
        if self.task is None or self.task.done():
            self.task = asyncio.create_task(self._play_forever())

    async def stop_audio(self):
        self.stop_requested = True
        voice = self.guild.voice_client
        if voice and voice.is_playing():
            voice.stop()
        if self.task and not self.task.done():
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
        self.task = None
        self.current_track = None

    async def _ensure_voice(self):
        channel = self.bot.get_channel(self.voice_channel_id)
        if channel is None:
            raise RuntimeError("لم أعد أستطيع العثور على القناة الصوتية.")
        voice = self.guild.voice_client
        if voice and voice.is_connected():
            if voice.channel and voice.channel.id != channel.id:
                await voice.move_to(channel)
            return voice
        if voice:
            try:
                await voice.disconnect(force=True)
            except Exception:
                pass
        return await channel.connect(
            timeout=25, reconnect=True, self_deaf=True
        )

    async def _play_one(self, voice, track):
        loop = asyncio.get_running_loop()
        finished = loop.create_future()

        def after(error):
            def finish():
                if not finished.done():
                    finished.set_result(error)
            loop.call_soon_threadsafe(finish)

        before = (
            "-nostdin -reconnect 1 -reconnect_streamed 1 "
            "-reconnect_delay_max 5 -rw_timeout 15000000"
        )
        source = discord.PCMVolumeTransformer(
            discord.FFmpegPCMAudio(
                track.audio_url,
                before_options=before,
                options="-vn",
            ),
            volume=self.volume,
        )
        voice.play(source, after=after)
        error = await asyncio.wait_for(finished, timeout=600)
        if error:
            raise error

    async def _play_forever(self):
        while not self.stop_requested:
            try:
                if not shutil.which("ffmpeg"):
                    raise RuntimeError("FFmpeg غير مثبت على الجهاز.")
                if not self.tracks:
                    self.tracks = await load_audio_edition(self.edition)
                if self.index >= len(self.tracks):
                    self.index = 0
                voice = await self._ensure_voice()
                track = self.tracks[self.index]
                self.current_track = track
                await self._play_one(voice, track)
                self.last_error = None
                self.index = (self.index + 1) % len(self.tracks)
            except asyncio.CancelledError:
                break
            except Exception as exc:
                self.last_error = str(exc)
                log.warning("Playback/reconnect error in guild %s: %s", self.guild.id, exc)
                await asyncio.sleep(5)


players = {}


def get_player(guild):
    player = players.get(guild.id)
    if player is None:
        player = players[guild.id] = QuranPlayer(bot, guild)
    return player


intents = discord.Intents.default()
intents.voice_states = True
bot = commands.Bot(command_prefix="!", intents=intents)


async def send(interaction, content=None, *, embed=None, ephemeral=False, view=None):
    if interaction.response.is_done():
        await interaction.followup.send(
            content=content, embed=embed, ephemeral=ephemeral, view=view
        )
    else:
        await interaction.response.send_message(
            content=content, embed=embed, ephemeral=ephemeral, view=view
        )


def require_guild(interaction):
    return interaction.guild is not None


class QuizView(discord.ui.View):
    def __init__(self, owner_id, question, choices, answer):
        super().__init__(timeout=90)
        self.owner_id = owner_id
        self.answer = answer
        for choice in choices:
            button = discord.ui.Button(label=choice, style=discord.ButtonStyle.primary)
            button.callback = self.make_callback(choice)
            self.add_item(button)

    def make_callback(self, choice):
        async def callback(interaction):
            if interaction.user.id != self.owner_id:
                await interaction.response.send_message(
                    "هذا الاختبار بدأه مستخدم آخر.", ephemeral=True
                )
                return
            result = "إجابة صحيحة، أحسنت." if choice == self.answer else f"الإجابة الصحيحة: **{self.answer}**"
            await interaction.response.edit_message(content=result, view=None)
            self.stop()
        return callback


@bot.event
async def on_ready():
    global synced
    if not synced:
        try:
            await bot.tree.sync()
            synced = True
        except Exception:
            log.exception("Could not sync slash commands")
    if not azkar_reminder.is_running():
        azkar_reminder.start()
    log.info("Logged in as %s (%s)", bot.user, bot.user.id if bot.user else "?")


@bot.event
async def on_voice_state_update(member, before, after):
    if bot.user and member.id == bot.user.id:
        player = players.get(member.guild.id)
        if player and after.channel:
            player.voice_channel_id = after.channel.id


@bot.event
async def on_disconnect():
    log.warning("Disconnected from Discord gateway; library will reconnect.")


@tasks.loop(hours=6)
async def azkar_reminder():
    for guild_id, cfg in list(settings.get("azkar", {}).items()):
        if not cfg.get("enabled") or not cfg.get("channel_id"):
            continue
        channel = bot.get_channel(int(cfg["channel_id"]))
        if channel:
            try:
                text = random.choice(AZKAR)
                await channel.send(f"🌿 تذكير بالذكر: **{text}**")
            except (discord.Forbidden, discord.HTTPException):
                log.info("Could not send azkar reminder in guild %s", guild_id)


@azkar_reminder.before_loop
async def before_azkar_reminder():
    await bot.wait_until_ready()


@bot.tree.command(name="help", description="عرض أوامر بوت القرآن")
async def help_command(interaction: discord.Interaction):
    text = (
        "**🎙️ الصوت**\n"
        "`/play` `/stop` `/reciter` `/surah` `/volume` `/now-playing`\n"
        "**📖 القرآن**\n"
        "`/ayah` `/tafsir` `/daily-verse`\n"
        "**🕌 أوامر إسلامية**\n"
        "`/dua` `/hadith` `/names` `/prophet` `/prayer-times` `/hijri` "
        "`/quiz` `/tasbih` `/zakat` `/quranic-word` `/athkar-counter` `/daily-challenge`\n"
        "**🌙 رمضان**\n"
        "`/ramadan` `/iftar` `/ramadan-dua` `/khatma` `/ramadan-schedule` `/last-ten`\n"
        "**⚙️ معلومات وإعدادات**\n"
        "`/azkar-channel` `/azkar-toggle` `/stats` `/uptime` `/invite`\n\n"
        "تحتاج مواقيت الصلاة إلى إدخال المدينة والدولة."
    )
    await send(interaction, text, ephemeral=True)


@bot.tree.command(name="play", description="ادخل قناتك الصوتية وشغّل القرآن باستمرار")
@app_commands.guild_only()
async def play_command(interaction: discord.Interaction):
    member = interaction.guild.get_member(interaction.user.id)
    if not member or not member.voice or not member.voice.channel:
        await send(interaction, "ادخل قناة صوتية أولًا، ثم استخدم `/play`.", ephemeral=True)
        return
    if not shutil.which("ffmpeg"):
        await send(interaction, "FFmpeg غير موجود. اتبع خطوات التثبيت في README.", ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True, thinking=True)
    player = get_player(interaction.guild)
    player.voice_channel_id = member.voice.channel.id
    player.stop_requested = False
    if not player.tracks:
        try:
            player.tracks = await load_audio_edition(player.edition)
        except Exception as exc:
            log.exception("Failed to load Quran audio")
            await interaction.followup.send(
                f"تعذّر تحميل قائمة التلاوة: {exc}", ephemeral=True
            )
            return
    player.begin()
    await interaction.followup.send(
        f"دخلت **{member.voice.channel.name}** وبدأت التلاوة. سأعيد الاتصال تلقائيًا إذا انقطع الصوت.",
        ephemeral=True,
    )


@bot.tree.command(name="stop", description="أوقف التلاوة واترك القناة الصوتية")
@app_commands.guild_only()
async def stop_command(interaction: discord.Interaction):
    player = players.get(interaction.guild_id)
    if not player or not player.task or player.task.done():
        await send(interaction, "لا توجد تلاوة تعمل الآن.", ephemeral=True)
        return
    await player.stop_audio()
    await send(interaction, "تم إيقاف التلاوة. بقيت في القناة الصوتية.", ephemeral=True)


@bot.tree.command(name="reciter", description="اختيار القارئ")
@app_commands.guild_only()
@app_commands.choices(name=RECITER_CHOICES)
async def reciter_command(interaction: discord.Interaction, name: app_commands.Choice[str]):
    player = get_player(interaction.guild)
    was_playing = player.task is not None and not player.task.done()
    if was_playing:
        await player.stop_audio()
    player.edition = name.value
    player.tracks = []
    player.index = 0
    if was_playing:
        player.begin()
    await send(
        interaction,
        f"القارئ المحدد: **{name.name}**. "
        + ("بدأت التلاوة بالقارئ الجديد." if was_playing else "سيُستخدم عند تشغيل `/play`."),
        ephemeral=True,
    )


@bot.tree.command(name="surah", description="اختر السورة التي تبدأ منها التلاوة")
@app_commands.guild_only()
@app_commands.describe(number="رقم السورة من 1 إلى 114")
async def surah_command(
    interaction: discord.Interaction,
    number: app_commands.Range[int, 1, 114],
):
    player = get_player(interaction.guild)
    player.tracks = await load_audio_edition(player.edition)
    player.index = surah_start_index(player.tracks, number)
    if player.task and not player.task.done():
        await player.stop_audio()
        player.begin()
    await send(
        interaction,
        f"تم اختيار سورة **{SURAHS[number - 1]}**. "
        + ("أعد تشغيل `/play` لبدء التلاوة من أولها." if not player.task or player.task.done() else "بدأت التلاوة منها."),
        ephemeral=True,
    )


@bot.tree.command(name="volume", description="ضبط مستوى صوت البوت")
@app_commands.guild_only()
@app_commands.describe(percent="من 1 إلى 100")
async def volume_command(
    interaction: discord.Interaction,
    percent: app_commands.Range[int, 1, 100],
):
    player = get_player(interaction.guild)
    player.volume = percent / 100
    voice = interaction.guild.voice_client
    if voice and voice.source and isinstance(voice.source, discord.PCMVolumeTransformer):
        voice.source.volume = player.volume
    await send(interaction, f"مستوى الصوت الآن **{percent}%**.", ephemeral=True)


@bot.tree.command(name="now-playing", description="عرض موضع التلاوة الحالي")
@app_commands.guild_only()
async def now_playing_command(interaction: discord.Interaction):
    player = players.get(interaction.guild_id)
    if not player or not player.current_track:
        await send(interaction, "لا توجد تلاوة تعمل حاليًا.", ephemeral=True)
        return
    track = player.current_track
    reciter = next((key for key, val in RECITERS.items() if val == player.edition), player.edition)
    await send(
        interaction,
        f"🎧 **{SURAHS[track.surah_number - 1]}، الآية {track.ayah_number}**\nالقارئ: {reciter} · الصوت: {round(player.volume * 100)}%",
    )


@bot.tree.command(name="ayah", description="عرض آية من سورة")
@app_commands.describe(surah="رقم السورة (1–114)", number="رقم الآية في السورة")
async def ayah_command(
    interaction: discord.Interaction,
    surah: app_commands.Range[int, 1, 114],
    number: app_commands.Range[int, 1, 286],
):
    await interaction.response.defer(thinking=True)
    try:
        data = await get_surah_text(surah)
        ayahs = data.get("ayahs", [])
        if number > len(ayahs):
            await interaction.followup.send(
                f"سورة **{SURAHS[surah - 1]}** فيها {len(ayahs)} آية فقط."
            )
            return
        ayah = ayahs[number - 1]
        await interaction.followup.send(
            f"**{data.get('name', SURAHS[surah - 1])} · الآية {number}**\n{ayah.get('text')}"
        )
    except Exception:
        log.exception("Ayah request failed")
        await interaction.followup.send("تعذّر جلب الآية الآن. حاول بعد قليل.")


@bot.tree.command(name="tafsir", description="عرض تفسير الميسر لآية")
@app_commands.describe(surah="رقم السورة (1–114)", number="رقم الآية في السورة")
async def tafsir_command(
    interaction: discord.Interaction,
    surah: app_commands.Range[int, 1, 114],
    number: app_commands.Range[int, 1, 286],
):
    await interaction.response.defer(thinking=True)
    try:
        text = await fetch_tafsir(surah, number)
        if not text:
            raise RuntimeError("لا يوجد نص تفسير.")
        await interaction.followup.send(
            f"**تفسير الميسر · {SURAHS[surah - 1]} {surah}:{number}**\n{text[:1900]}"
        )
    except Exception:
        log.exception("Tafsir request failed")
        await interaction.followup.send("تعذّر جلب التفسير الآن. حاول بعد قليل.")


@bot.tree.command(name="daily-verse", description="عرض آية قرآنية عشوائية")
async def daily_verse_command(interaction: discord.Interaction):
    await interaction.response.defer(thinking=True)
    try:
        data = await get_surah_text(random.randint(1, 114))
        ayah = random.choice(data["ayahs"])
        await interaction.followup.send(
            f"📖 **آية للتدبر · {data.get('name')} {ayah['numberInSurah']}**\n{ayah['text']}"
        )
    except Exception:
        log.exception("Daily verse failed")
        await interaction.followup.send("تعذّر جلب الآية الآن.")


@bot.tree.command(name="dua", description="عرض دعاء قرآني")
async def dua_command(interaction: discord.Interaction):
    dua, reference = random.choice(QURANIC_DUAS)
    await send(interaction, f"🤲 **دعاء من القرآن**\n{dua}\n— {reference}")


@bot.tree.command(name="hadith", description="عرض حديث نبوي مع مصدره")
async def hadith_command(interaction: discord.Interaction):
    text, source = random.choice(HADITHS)
    await send(interaction, f"📜 {text}\n— {source}")


@bot.tree.command(name="names", description="عرض اسم من أسماء الله الحسنى ومعناه")
async def names_command(interaction: discord.Interaction):
    name, meaning = random.choice(ASMA)
    await send(interaction, f"✨ **{name}**\n{meaning}")


@bot.tree.command(name="prophet", description="معلومة موجزة عن نبي مذكور في القرآن")
@app_commands.describe(name="اكتب اسم النبي")
async def prophet_command(interaction: discord.Interaction, name: str):
    normalized = name.strip().replace("ال", "", 1) if name.strip().startswith("ال") else name.strip()
    match = next(
        (value for key, value in PROPHETS.items() if key == name.strip() or key == normalized),
        None,
    )
    if not match:
        await send(interaction, "لم أجد الاسم. جرّب أحد أسماء الأنبياء المذكورة في القرآن.", ephemeral=True)
        return
    await send(interaction, f"**النبي {name.strip()}**\n{match}")


async def get_prayer_data(city, country):
    url = f"{ALADHAN_API}/timingsByCity?city={quote(city)}&country={quote(country)}&method=4"
    return await api_json(url)


def prayer_embed(data, title):
    timings = data.get("timings", {})
    names = [
        ("الفجر", "Fajr"), ("الشروق", "Sunrise"), ("الظهر", "Dhuhr"),
        ("العصر", "Asr"), ("المغرب", "Maghrib"), ("العشاء", "Isha"),
    ]
    lines = [f"**{ar}:** {timings.get(en, '—')}" for ar, en in names]
    date = data.get("date", {}).get("readable", "")
    return f"🕌 **{title}** · {date}\n" + "\n".join(lines) + "\nطريقة الحساب: أم القرى (4)."


@bot.tree.command(name="prayer-times", description="عرض مواقيت الصلاة لمدينة")
@app_commands.describe(city="اسم المدينة", country="اسم الدولة")
async def prayer_times_command(interaction: discord.Interaction, city: str, country: str):
    await interaction.response.defer(thinking=True)
    try:
        data = await get_prayer_data(city, country)
        await interaction.followup.send(prayer_embed(data, f"{city}, {country}"))
    except Exception:
        log.exception("Prayer times request failed")
        await interaction.followup.send("تعذّر العثور على مواقيت لهذه المدينة. تحقق من اسم المدينة والدولة.")


@bot.tree.command(name="hijri", description="عرض التاريخ الهجري اليوم")
async def hijri_command(interaction: discord.Interaction):
    await interaction.response.defer(thinking=True)
    try:
        date_str = datetime.now().strftime("%d-%m-%Y")
        data = await api_json(f"{ALADHAN_API}/gToH/{date_str}")
        hijri = data.get("hijri", {})
        await interaction.followup.send(
            f"📅 **التاريخ الهجري:** {hijri.get('day')} "
            f"{hijri.get('month', {}).get('ar')} {hijri.get('year')} هـ\n"
            "قد يختلف التاريخ يومًا بحسب الرؤية والبلد."
        )
    except Exception:
        log.exception("Hijri date failed")
        await interaction.followup.send("تعذّر جلب التاريخ الهجري الآن.")


@bot.tree.command(name="quiz", description="اختبار إسلامي قصير")
async def quiz_command(interaction: discord.Interaction):
    question, choices, answer = random.choice(QUIZZES)
    view = QuizView(interaction.user.id, question, choices, answer)
    await send(interaction, f"❓ **{question}**", view=view)


@bot.tree.command(name="tasbih", description="إضافة تسبيحات إلى عدادك")
@app_commands.describe(count="عدد التسبيحات (استخدم 0 لإعادة العداد)")
async def tasbih_command(
    interaction: discord.Interaction,
    count: app_commands.Range[int, 0, 1000] = 1,
):
    current = tasbih_counts.get(interaction.user.id, 0)
    tasbih_counts[interaction.user.id] = 0 if count == 0 else current + count
    await send(
        interaction,
        "تمت إعادة العداد." if count == 0 else f"🌿 مجموع تسبيحاتك في هذه الجلسة: **{tasbih_counts[interaction.user.id]}**",
        ephemeral=True,
    )


@bot.tree.command(name="zakat", description="حساب تقديري لـ 2.5% من مبلغ")
@app_commands.describe(amount="المبلغ الذي تريد حساب 2.5% منه")
async def zakat_command(
    interaction: discord.Interaction,
    amount: app_commands.Range[float, 0.01, 1000000000000.0],
):
    result = amount * 0.025
    await send(
        interaction,
        f"الحساب التقديري: **{result:,.2f}** (2.5% من {amount:,.2f}).\n"
        "هذا لا يحدد بلوغ النصاب أو الحول ولا يغني عن سؤال مختص.",
        ephemeral=True,
    )


@bot.tree.command(name="quranic-word", description="تعلم كلمة قرآنية ومعناها")
async def quranic_word_command(interaction: discord.Interaction):
    word, meaning, ref = random.choice(QURAN_WORDS)
    await send(interaction, f"📚 **{word}**\nالمعنى المختصر: {meaning}\nالموضع: {ref}")


@bot.tree.command(name="athkar-counter", description="إضافة عدد إلى عداد الأذكار")
@app_commands.describe(count="عدد الأذكار المراد إضافتها")
async def athkar_counter_command(
    interaction: discord.Interaction,
    count: app_commands.Range[int, 1, 1000] = 1,
):
    total = user_counts.get(interaction.user.id, 0) + count
    user_counts[interaction.user.id] = total
    await send(interaction, f"🌿 عداد الأذكار في هذه الجلسة: **{total}**", ephemeral=True)


@bot.tree.command(name="daily-challenge", description="تحدٍّ إيماني بسيط لليوم")
async def daily_challenge_command(interaction: discord.Interaction):
    await send(interaction, f"🎯 **تحدي اليوم**\n{random.choice(CHALLENGES)}")


@bot.tree.command(name="ramadan", description="معلومات موجزة عن رمضان")
async def ramadan_command(interaction: discord.Interaction):
    await interaction.response.defer(thinking=True)
    try:
        date_str = datetime.now().strftime("%d-%m-%Y")
        data = await api_json(f"{ALADHAN_API}/gToH/{date_str}")
        hijri = data.get("hijri", {})
        month = hijri.get("month", {}).get("ar", "")
        response = f"🌙 التاريخ الهجري اليوم: **{hijri.get('day')} {month} {hijri.get('year')} هـ**.\n"
        if month == "رمضان":
            response += "نحن في شهر رمضان بحسب التقويم المحسوب؛ قد تختلف بداية الشهر بحسب الرؤية."
        else:
            response += "موعد رمضان القادم يعتمد على رؤية الهلال وقد يختلف بين البلدان."
        await interaction.followup.send(response)
    except Exception:
        await interaction.followup.send("تعذّر جلب التاريخ الهجري الآن.")


@bot.tree.command(name="iftar", description="عرض وقت المغرب للمدينة، للاستئناس بموعد الإفطار")
@app_commands.describe(city="اسم المدينة", country="اسم الدولة")
async def iftar_command(interaction: discord.Interaction, city: str, country: str):
    await interaction.response.defer(thinking=True)
    try:
        data = await get_prayer_data(city, country)
        timing = data.get("timings", {}).get("Maghrib", "—")
        await interaction.followup.send(
            f"🌇 موعد المغرب المحسوب في **{city}, {country}**: **{timing}**.\n"
            "تحقق من تقويم الجهة الإسلامية المحلية؛ قد تختلف طريقة الحساب."
        )
    except Exception:
        await interaction.followup.send("تعذّر جلب موعد المغرب لهذه المدينة.")


@bot.tree.command(name="ramadan-dua", description="عرض دعاء قرآني في رمضان")
async def ramadan_dua_command(interaction: discord.Interaction):
    dua, reference = random.choice(RAMADAN_DUAS)
    await send(interaction, f"🤲 **دعاء من القرآن**\n{dua}\n— {reference}")


@bot.tree.command(name="khatma", description="حساب عدد الصفحات اليومية لختمة")
@app_commands.describe(days="عدد أيام الختمة (1 إلى 365)")
async def khatma_command(interaction: discord.Interaction, days: app_commands.Range[int, 1, 365]):
    pages = 604
    per_day = pages / days
    juz_per_day = 30 / days
    await send(
        interaction,
        f"لختمة خلال **{days} يومًا**: نحو **{per_day:.1f} صفحة** "
        f"(قرابة **{juz_per_day:.2f} جزء**) يوميًا، على أساس مصحف 604 صفحات.",
    )


@bot.tree.command(name="ramadan-schedule", description="جدول عبادة يومي مقترح لرمضان")
async def ramadan_schedule_command(interaction: discord.Interaction):
    await send(
        interaction,
        "🌙 **اقتراح مرن لليوم**\n"
        "• بعد الفجر: أذكار وورد قرآن\n"
        "• خلال اليوم: المحافظة على الصلاة والراحة\n"
        "• قبل المغرب: دعاء وتهيؤ للإفطار\n"
        "• بعد العشاء: قيام أو تراويح بحسب الاستطاعة\n"
        "• قبل النوم: مراجعة الورد والاستعداد للسحور\n"
        "عدّل الأوقات وفق مواقيت مدينتك وصحتك ومسؤولياتك.",
    )


@bot.tree.command(name="last-ten", description="دليل موجز للعشر الأواخر من رمضان")
async def last_ten_command(interaction: discord.Interaction):
    await send(
        interaction,
        "🌙 تبدأ العشر الأواخر من ليلة 21 رمضان، أي من مغرب يوم 20. "
        "تُرجى ليلة القدر في الليالي الوترية، ويُستحب الاجتهاد في العبادة "
        "والدعاء المأثور: «اللهم إنك عفو تحب العفو فاعف عني» (رواه الترمذي 3513).",
    )


@bot.tree.command(name="azkar-channel", description="تحديد قناة تذكير الأذكار")
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_guild=True)
@app_commands.describe(channel="القناة النصية التي تستقبل تذكيرًا كل 6 ساعات")
async def azkar_channel_command(
    interaction: discord.Interaction,
    channel: discord.TextChannel,
):
    guild_cfg = settings.setdefault("azkar", {}).setdefault(str(interaction.guild_id), {})
    guild_cfg["channel_id"] = channel.id
    save_settings()
    await send(interaction, f"تم تعيين قناة الأذكار إلى {channel.mention}.", ephemeral=True)


@bot.tree.command(name="azkar-toggle", description="تشغيل أو إيقاف تذكيرات الأذكار كل 6 ساعات")
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_guild=True)
@app_commands.describe(enabled="تشغيل أو إيقاف التذكيرات")
async def azkar_toggle_command(interaction: discord.Interaction, enabled: bool):
    guild_cfg = settings.setdefault("azkar", {}).setdefault(str(interaction.guild_id), {})
    if enabled and not guild_cfg.get("channel_id"):
        await send(interaction, "حدد القناة أولًا باستخدام `/azkar-channel`.", ephemeral=True)
        return
    guild_cfg["enabled"] = enabled
    save_settings()
    state = "مفعّلة" if enabled else "متوقفة"
    await send(interaction, f"تذكيرات الأذكار {state}.", ephemeral=True)


@bot.tree.command(name="stats", description="عرض إحصاءات البوت")
async def stats_command(interaction: discord.Interaction):
    await send(
        interaction,
        f"📊 الخوادم: **{len(bot.guilds)}** · زمن الاستجابة: **{round(bot.latency * 1000)} ms**",
        ephemeral=True,
    )


@bot.tree.command(name="uptime", description="عرض مدة تشغيل البوت")
async def uptime_command(interaction: discord.Interaction):
    seconds = int(time.monotonic() - started_at)
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, _ = divmod(rem, 60)
    await send(interaction, f"⏱️ مدة تشغيل هذه العملية: **{days} يوم، {hours} ساعة، {minutes} دقيقة**.", ephemeral=True)


@bot.tree.command(name="invite", description="إنشاء رابط دعوة البوت")
async def invite_command(interaction: discord.Interaction):
    if not bot.user:
        await send(interaction, "تعذّر إنشاء الرابط الآن.", ephemeral=True)
        return
    permissions = discord.Permissions(
        view_channel=True,
        send_messages=True,
        embed_links=True,
        connect=True,
        speak=True,
        use_voice_activation=True,
    )
    url = discord.utils.oauth_url(
        bot.user.id,
        permissions=permissions,
        scopes=("bot", "applications.commands"),
    )
    await send(interaction, f"رابط دعوة البوت: {url}", ephemeral=True)


@bot.tree.error
async def on_app_command_error(
    interaction: discord.Interaction, error: app_commands.AppCommandError
):
    if isinstance(error, app_commands.MissingPermissions):
        message = "هذا الأمر متاح لمن لديه صلاحية إدارة الخادم فقط."
    else:
        log.exception("Slash command error", exc_info=error)
        message = "حدث خطأ غير متوقع. جرّب مرة أخرى."
    try:
        await send(interaction, message, ephemeral=True)
    except discord.HTTPException:
        pass


async def main():
    load_dotenv(ROOT / ".env")
    token = os.getenv("DISCORD_TOKEN", "").strip()
    if not token or token == "PASTE_YOUR_BOT_TOKEN_HERE":
        raise SystemExit(
            "أضف توكن البوت إلى DISCORD_TOKEN في ملف .env. لا ترسله لأي شخص."
        )
    if not shutil.which("ffmpeg"):
        log.warning("FFmpeg not detected; voice playback will not work until installed.")
    try:
        await bot.start(token, reconnect=True)
    finally:
        if http_session and not http_session.closed:
            await http_session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nتم إيقاف البوت.")
