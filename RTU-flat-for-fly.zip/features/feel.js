'use strict';
/**
 * الفضفضة /feel — أي رسالة في الرومات المحددة تتحول تلقائياً إلى إيمبد أنيق باسم صاحبها وصورته
 * (أو بشكل مجهول) مع بقاء الصور المرفقة. أمر واحد بقائمة: الرومات • اللون • مجهول • حذف الأصل • معاينة.
 */
module.exports = (H) => {
const { D, client, SERVER_ID, EPH, row, btn, chSel, input, modal, embed, cut, adminOnly, update, onOff, save, session } = H;
const { ButtonStyle, AttachmentBuilder, EmbedBuilder, PermissionFlagsBits: P } = D;
const db = H.db;

const cfg = () => {
    const f = (db.feel = db.feel || {});
    f.enabled = !!f.enabled;
    f.channels = Array.isArray(f.channels) ? f.channels : [];
    f.color = f.color || '#0F2A66';
    f.anonymous = !!f.anonymous;
    f.deleteOriginal = f.deleteOriginal !== false;
    f.title = f.title || '';
    return f;
};
const colorNum = c => { const m = /^#?([0-9a-f]{6})$/i.exec(String(c || '')); return m ? parseInt(m[1], 16) : 0x0F2A66; };

function buildEmbed(f, member, text, imgName) {
    const e = new EmbedBuilder().setColor(colorNum(f.color)).setTimestamp();
    if (f.title) e.setTitle(cut(f.title, 200));
    e.setDescription(text ? cut(text, 4000) : '\u200e');
    if (f.anonymous) e.setFooter({ text: 'فضفضة مجهولة' });
    else {
        const u = member.user || member;
        e.setThumbnail(u.displayAvatarURL({ size: 256 }));
        e.setFooter({ text: member.displayName || u.username, iconURL: u.displayAvatarURL({ size: 64 }) });
    }
    if (imgName) e.setImage('attachment://' + imgName);
    return e;
}

async function onMessage(msg) {
    const f = cfg();
    if (!f.enabled || !msg.guild || msg.guild.id !== SERVER_ID || msg.author.bot) return false;
    if (!f.channels.includes(msg.channelId)) return false;
    const me = msg.guild.members.me;
    const perms = me && msg.channel.permissionsFor(me);
    if (!perms || !perms.has(P.SendMessages) || !perms.has(P.EmbedLinks)) return false;
    const text = (msg.content || '').trim();
    const img = [...msg.attachments.values()].find(a => (a.contentType || '').startsWith('image/'));
    if (!text && !img) return false;
    const files = []; let imgName = null;
    if (img) {
        try {
            const r = await fetch(img.url, { signal: AbortSignal.timeout(15000) });
            if (r.ok) {
                const buf = Buffer.from(await r.arrayBuffer());
                if (buf.length <= 8 * 1024 * 1024) { imgName = 'feel-' + Date.now().toString(36) + '.' + ((img.name || 'x.png').split('.').pop().replace(/[^a-z0-9]/gi, '') || 'png'); files.push(new AttachmentBuilder(buf, { name: imgName })); }
            }
        } catch {}
    }
    const e = buildEmbed(f, msg.member || msg.author, text, imgName);
    try {
        await msg.channel.send({ embeds: [e], files, allowedMentions: { parse: [] } });
        if (f.deleteOriginal && perms.has(P.ManageMessages)) await msg.delete().catch(() => {});
    } catch (err) { console.error('[feel]', err.message); return false; }
    return true;
}

// ───── القائمة ─────
function view() {
    const f = cfg();
    const e = embed().setTitle('💭 الفضفضة')
        .setDescription('أي رسالة في رومات الفضفضة تتحول تلقائياً إلى إيمبد مرتب.')
        .addFields(
            { name: 'الحالة', value: onOff(f.enabled), inline: true },
            { name: 'الوضع', value: f.anonymous ? '🕶️ مجهول' : '👤 باسم صاحبها', inline: true },
            { name: 'حذف الرسالة الأصلية', value: onOff(f.deleteOriginal), inline: true },
            { name: 'اللون', value: '`' + f.color + '`', inline: true },
            { name: '💬 الرومات', value: f.channels.length ? f.channels.map(x => '<#' + x + '>').join(' ') : '`لم تُحدد`' }
        )
        .setFooter({ text: 'البوت يحتاج: إرسال رسائل + تضمين الروابط + إدارة الرسائل (لحذف الأصل)' });
    return {
        embeds: [e],
        components: [
            row(btn('fl:toggle', f.enabled ? 'إيقاف' : 'تشغيل', f.enabled ? '⛔' : '✅', f.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
                btn('fl:anon', 'مجهول', f.anonymous ? '✅' : '⛔'),
                btn('fl:del', 'حذف الأصل', f.deleteOriginal ? '✅' : '⛔'),
                btn('fl:look', 'المظهر', '🎨', ButtonStyle.Primary),
                btn('fl:preview', 'معاينة', '👁️')),
            row(chSel('fl:chs', 'اختر رومات الفضفضة (حتى 10)', { max: 10, min: 0, selected: f.channels })),
            row(btn('fl:clear', 'مسح الرومات', '🧹'))
        ]
    };
}
async function slash(i) { if (!(await adminOnly(i))) return; return i.reply({ ...view(), flags: EPH }); }
async function component(i) {
    if (!(await adminOnly(i))) return;
    const a = i.customId.split(':')[1]; const f = cfg();
    if (a === 'look') return i.showModal(modal('flm:look', 'مظهر الفضفضة', input('color', 'اللون مثل #0F2A66', { max: 7, value: f.color, required: true }), input('title', 'عنوان فوق الفضفضة (اختياري)', { max: 100, value: f.title })));
    if (a === 'preview') return i.reply({ embeds: [buildEmbed(f, i.member, 'هذا نص تجريبي لمعاينة كيف سيظهر الكلام داخل نظام الفضفضة...', null)], flags: EPH });
    if (a === 'toggle') f.enabled = !f.enabled;
    else if (a === 'anon') f.anonymous = !f.anonymous;
    else if (a === 'del') f.deleteOriginal = !f.deleteOriginal;
    else if (a === 'chs') f.channels = [...i.values];
    else if (a === 'clear') f.channels = [];
    save();
    return update(i, view());
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const f = cfg();
    const col = i.fields.getTextInputValue('color').trim();
    if (!/^#?[0-9a-f]{6}$/i.test(col)) return i.reply({ content: '❌ اللون غير صالح، مثال: #0F2A66', flags: EPH });
    f.color = (col.startsWith('#') ? col : '#' + col).toUpperCase();
    f.title = i.fields.getTextInputValue('title').trim();
    save();
    return i.isFromMessage && i.isFromMessage() ? update(i, view()) : i.reply({ content: '✅ تم الحفظ.', flags: EPH });
}
const commands = [{ name: 'feel', description: 'الفضفضة: رومات تتحول رسائلها إلى إيمبد أنيق (إدارة)' }];
return { prefix: 'fl', commands, ephemeral: ['feel'], slash: { feel: slash }, component, modal: modalSubmit, onMessage };
};
