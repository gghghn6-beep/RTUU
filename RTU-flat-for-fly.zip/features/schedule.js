'use strict';
/**
 * جدولة التوب /schedule — إرسال توب الشات أو الفويس تلقائياً (يومي / أسبوعي / شهري) في روم محدد.
 * التوب يحسب نشاط الفترة فقط (الفرق عن آخر إرسال) ثم يبدأ عدّاد جديد.
 */
module.exports = (H) => {
const { D, client, EPH, row, btn, strSel, chSel, roleSel, input, modal, embed, cut, adminOnly, update, onOff, save, session, rid } = H;
const { ButtonStyle } = D;
const db = H.db;

const TYPES = { chat: { label: 'كتابي (أكثر الأعضاء كتابة)', short: 'الشات', emoji: '💬' }, voice: { label: 'صوتي (أكثر الأعضاء في الفويس)', short: 'الفويس', emoji: '🎙️' } };
const PERIODS = { daily: { label: 'يومي', ms: 864e5, name: 'اليومي' }, weekly: { label: 'أسبوعي', ms: 7 * 864e5, name: 'الأسبوعي' }, monthly: { label: 'شهري', ms: 30 * 864e5, name: 'الشهري' } };

const cfg = () => {
    const s = (db.schedule = db.schedule || {});
    s.tz = Number.isFinite(s.tz) ? s.tz : 3;       // فرق التوقيت عن UTC (افتراضي +3 مكة/الرياض)
    s.hour = Number.isFinite(s.hour) ? s.hour : 21; // ساعة الإرسال
    s.list = s.list || {};
    return s;
};
const snapshot = () => { const o = {}; for (const r of H.getAllStats()) o[r.uid] = [r.messages, r.voiceMs]; return o; };
function nextRun(from) {
    const c = cfg(); const off = c.tz * 36e5;
    const local = new Date(from + off);
    let t = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate(), c.hour, 0, 0) - off;
    if (t <= from) t += 864e5;
    return t;
}
function buildTop(sc) {
    const base = sc.baseline || {};
    const idx = sc.type === 'voice' ? 1 : 0;
    const rows = H.getAllStats().map(r => ({ uid: r.uid, v: Math.max(0, (idx ? r.voiceMs : r.messages) - ((base[r.uid] || [0, 0])[idx] || 0)) }))
        .filter(r => r.v > 0).sort((a, b) => b.v - a.v).slice(0, 10);
    const T = TYPES[sc.type], P = PERIODS[sc.period];
    const medals = ['🥇', '🥈', '🥉'];
    const fmt = v => (idx ? H.fmtVoice(v) : v.toLocaleString('en') + ' رسالة');
    const e = embed().setTitle('🏆 توب ' + T.short + ' ' + P.name)
        .setDescription(rows.length ? rows.map((r, n) => (medals[n] || '**' + (n + 1) + '.**') + ' <@' + r.uid + '> — **' + fmt(r.v) + '**').join('\n') : '*لا يوجد نشاط في هذه الفترة*')
        .addFields({ name: 'الفترة', value: '<t:' + Math.floor((sc.since || Date.now() - P.ms) / 1000) + ':f> ← <t:' + Math.floor(Date.now() / 1000) + ':f>' })
        .setTimestamp();
    const g = client.guilds.cache.get(H.SERVER_ID); if (g && g.iconURL()) e.setThumbnail(g.iconURL({ size: 256 }));
    return e;
}
async function send(sc) {
    const ch = client.channels.cache.get(sc.channelId) || await client.channels.fetch(sc.channelId).catch(() => null);
    if (!ch || !ch.send) throw new Error('الروم غير موجود أو لا أملك صلاحية الوصول إليه.');
    await ch.send({ content: sc.roleId ? '<@&' + sc.roleId + '>' : undefined, embeds: [buildTop(sc)], allowedMentions: sc.roleId ? { roles: [sc.roleId] } : { parse: [] } });
    sc.baseline = snapshot(); sc.since = Date.now(); sc.lastSentAt = Date.now();
    sc.nextAt = Date.now() + PERIODS[sc.period].ms; sc.nextAt = nextRun(sc.nextAt - 864e5 + 1);
    save();
}
function onReady() {
    setInterval(async () => {
        const now = Date.now();
        for (const sc of Object.values(cfg().list)) {
            if (!sc.enabled || sc.nextAt > now) continue;
            try { await send(sc); } catch (e) { console.error('[schedule]', e.message); sc.nextAt = now + 3600e3; save(); }
        }
    }, 30000).unref();
}

// ───── القائمة ─────
const st = i => session(i, 'sc', () => ({ view: 'home', sel: '', draft: { type: 'chat', period: 'daily', channelId: '', roleId: '' } }));
function view(i) {
    const c = cfg(); const s = st(i);
    const list = Object.values(c.list);
    if (s.view === 'add') {
        const d = s.draft;
        const e = embed().setTitle('➕ جدولة جديدة')
            .setDescription('اختر نوع التوب والفترة والروم المخصص، ويمكن تحديد رتبة للمنشن اختيارياً، ثم اضغط تأكيد.')
            .addFields({ name: 'النوع', value: TYPES[d.type].emoji + ' ' + TYPES[d.type].label, inline: true }, { name: 'الفترة', value: PERIODS[d.period].label, inline: true },
                { name: 'الروم', value: d.channelId ? '<#' + d.channelId + '>' : '`لم يُحدد`', inline: true }, { name: 'الرتبة', value: d.roleId ? '<@&' + d.roleId + '>' : '`بدون`', inline: true });
        return { embeds: [e], components: [
            row(strSel('sc:type', 'النوع', Object.entries(TYPES).map(([k, v]) => ({ label: v.label, value: k, emoji: v.emoji, default: d.type === k })))),
            row(strSel('sc:period', 'الفترة', Object.entries(PERIODS).map(([k, v]) => ({ label: v.label, value: k, emoji: '🕒', default: d.period === k })))),
            row(chSel('sc:ch', 'اختر الروم', { selected: d.channelId ? [d.channelId] : [] })),
            row(roleSel('sc:role', 'الرتبة المخصصة (اختياري)', { min: 0, max: 1, selected: d.roleId ? [d.roleId] : [] })),
            row(btn('sc:confirm', 'تأكيد الإضافة', '✅', ButtonStyle.Success, !d.channelId), btn('sc:back', 'رجوع', '↩️'))
        ] };
    }
    const e = embed().setTitle('📅 جدولة التوب')
        .setDescription('إرسال توب الشات أو الفويس تلقائياً في روم محدد.')
        .addFields({ name: '⏰ وقت الإرسال', value: 'الساعة **' + String(c.hour).padStart(2, '0') + ':00** (UTC' + (c.tz >= 0 ? '+' : '') + c.tz + ')', inline: true },
            { name: '📋 الجداول (' + list.length + ')', value: list.length ? cut(list.map(x => '`#' + x.id + '` ' + (x.enabled ? '🟢' : '🔴') + ' ' + TYPES[x.type].emoji + ' ' + PERIODS[x.period].label + ' — <#' + x.channelId + '> — التالي <t:' + Math.floor(x.nextAt / 1000) + ':R>').join('\n'), 1024) : '`لا توجد جداول — اضغط «جدولة جديدة»`' });
    const comps = [row(btn('sc:add', 'جدولة جديدة', '➕', ButtonStyle.Success, list.length >= 10), btn('sc:time', 'الساعة والتوقيت', '⏰', ButtonStyle.Primary))];
    if (list.length) {
        comps.push(row(strSel('sc:pick', 'اختر جدولة لإدارتها...', list.slice(0, 25).map(x => ({ label: '#' + x.id + ' — ' + TYPES[x.type].short + ' ' + PERIODS[x.period].label, value: x.id, emoji: x.enabled ? '🟢' : '🔴', default: s.sel === x.id })))));
        const g = c.list[s.sel];
        if (g) comps.push(row(btn('sc:now', 'إرسال الآن', '📤', ButtonStyle.Primary), btn('sc:tog', g.enabled ? 'إيقاف' : 'تفعيل', g.enabled ? '⏸️' : '▶️'), btn('sc:del', 'حذف', '🗑️', ButtonStyle.Danger)));
    }
    return { embeds: [e], components: comps };
}
async function slash(i) { if (!(await adminOnly(i))) return; const s = st(i); s.view = 'home'; return i.reply({ ...view(i), flags: EPH }); }
async function component(i) {
    if (!(await adminOnly(i))) return;
    const a = i.customId.split(':')[1]; const c = cfg(); const s = st(i);
    if (a === 'time') return i.showModal(modal('scm:time', 'وقت الإرسال', input('hour', 'الساعة (0-23)', { max: 2, value: c.hour, required: true }), input('tz', 'فرق التوقيت عن UTC (مثال 3)', { max: 3, value: c.tz, required: true })));
    if (a === 'add') { s.view = 'add'; return update(i, view(i)); }
    if (a === 'back') { s.view = 'home'; return update(i, view(i)); }
    if (a === 'type') s.draft.type = i.values[0];
    else if (a === 'period') s.draft.period = i.values[0];
    else if (a === 'ch') s.draft.channelId = i.values[0] || '';
    else if (a === 'role') s.draft.roleId = i.values[0] || '';
    else if (a === 'confirm') {
        const d = s.draft; if (!d.channelId) return i.reply({ content: '❌ اختر الروم أولاً.', flags: EPH });
        const id = rid(); c.list[id] = { id, ...d, enabled: true, baseline: snapshot(), since: Date.now(), nextAt: nextRun(Date.now()), lastSentAt: 0 };
        s.view = 'home'; s.sel = id; s.draft = { type: 'chat', period: 'daily', channelId: '', roleId: '' };
    }
    else if (a === 'pick') s.sel = i.values[0];
    else if (a === 'tog') { const g = c.list[s.sel]; if (g) { g.enabled = !g.enabled; if (g.enabled) g.nextAt = nextRun(Date.now()); } }
    else if (a === 'del') { delete c.list[s.sel]; s.sel = ''; }
    else if (a === 'now') {
        const g = c.list[s.sel]; if (!g) return i.reply({ content: '❌ اختر جدولة أولاً.', flags: EPH });
        await i.deferUpdate();
        try { await send(g); await i.editReply(view(i)); return i.followUp({ content: '✅ تم الإرسال.', flags: EPH }); }
        catch (e) { await i.editReply(view(i)); return i.followUp({ content: '❌ ' + e.message, flags: EPH }); }
    }
    save();
    return update(i, view(i));
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const h = parseInt(i.fields.getTextInputValue('hour'), 10), tz = parseInt(i.fields.getTextInputValue('tz'), 10);
    if (!Number.isFinite(h) || h < 0 || h > 23) return i.reply({ content: '❌ الساعة من 0 إلى 23.', flags: EPH });
    if (!Number.isFinite(tz) || tz < -12 || tz > 14) return i.reply({ content: '❌ فرق التوقيت من -12 إلى 14.', flags: EPH });
    const c = cfg(); c.hour = h; c.tz = tz;
    for (const x of Object.values(c.list)) if (x.enabled) x.nextAt = nextRun(Date.now());
    save();
    return i.isFromMessage && i.isFromMessage() ? update(i, view(i)) : i.reply({ content: '✅ تم الحفظ.', flags: EPH });
}
const commands = [{ name: 'schedule', description: 'جدولة إرسال التوب (كتابي/صوتي) تلقائياً يومياً أو أسبوعياً أو شهرياً' }];
return { prefix: 'sc', commands, ephemeral: ['schedule'], slash: { schedule: slash }, component, modal: modalSubmit, onReady };
};
