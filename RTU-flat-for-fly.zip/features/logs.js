'use strict';
/**
 * نظام السجلات /logs — لوقات إدارية وعامة، كل نوع يُفعَّل ويُوجَّه لروم
 *  إدارية: القنوات • السيرفر • البوتات • الرتب • إعطاء/سحب الرتب • الباند • الطرد • التايم اوت • الإيموجي • الملصقات • السحب/الطرد الصوتي • ميوت/ديفن • الحذف الجماعي
 *  عامة: الرسائل • الصور • رسائل البوتات • دخول/خروج • الروابط • دخول/خروج صوتي • التنقل الصوتي • كتم النفس • الأسماء • الحسابات • التفاعلات
 *  setlog! ينشئ الرومات تلقائياً، و detlog! يحذفها.
 */
module.exports = (H) => {
const { D, client, SERVER_ID, EPH, row, btn, strSel, chSel, embed, cut, adminOnly, update, onOff, save, session } = H;
const { ButtonStyle, ChannelType, PermissionFlagsBits: P, AuditLogEvent: AE } = D;
const db = H.db;

const TYPES = [
    // إدارية
    { k: 'channels', g: 'admin', l: 'القنوات', e: '#️⃣', d: 'إنشاء وحذف وتعديل القنوات' },
    { k: 'server', g: 'admin', l: 'تحديث السيرفر', e: '⚙️', d: 'تغيير اسم أو صورة أو بنر السيرفر' },
    { k: 'bots', g: 'admin', l: 'البوتات', e: '🤖', d: 'إضافة البوتات' },
    { k: 'roles', g: 'admin', l: 'الرتب', e: '🛡️', d: 'إنشاء وحذف وتعديل الرتب' },
    { k: 'roleassign', g: 'admin', l: 'إعطاء وسحب الرتب', e: '🏷️', d: 'رتب الأعضاء' },
    { k: 'bans', g: 'admin', l: 'الباند / فك الباند', e: '🔨', d: 'الحظر وإزالته' },
    { k: 'kicks', g: 'admin', l: 'الطرد', e: '👢', d: 'طرد الأعضاء' },
    { k: 'timeout', g: 'admin', l: 'التايم اوت', e: '⏳', d: 'إعطاء وإزالة التايم اوت' },
    { k: 'emoji', g: 'admin', l: 'الإيموجي', e: '😀', d: 'إضافة وحذف الإيموجي' },
    { k: 'stickers', g: 'admin', l: 'الملصقات', e: '🧷', d: 'إضافة وحذف الملصقات' },
    { k: 'voicepull', g: 'admin', l: 'السحب الصوتي', e: '↔️', d: 'نقل الأعضاء صوتياً بواسطة إداري' },
    { k: 'voicekick', g: 'admin', l: 'الطرد الصوتي', e: '🔌', d: 'طرد الأعضاء من الروم الصوتي' },
    { k: 'mutedeaf', g: 'admin', l: 'الميوت / الديفن', e: '🔇', d: 'الكتم والديفن الصوتي من إداري' },
    { k: 'bulk', g: 'admin', l: 'الحذف الجماعي', e: '🧹', d: 'حذف رسائل جماعي' },
    // عامة
    { k: 'messages', g: 'general', l: 'الرسائل النصية', e: '💬', d: 'حذف وتعديل الرسائل' },
    { k: 'images', g: 'general', l: 'الصور', e: '🖼️', d: 'الصور والوسائط المرسلة' },
    { k: 'botmsgs', g: 'general', l: 'رسائل البوتات', e: '🤖', d: 'الرسائل التي ترسلها البوتات الأخرى' },
    { k: 'joinleave', g: 'general', l: 'دخول وخروج الأعضاء', e: '👤', d: 'دخول وخروج الأعضاء' },
    { k: 'links', g: 'general', l: 'الروابط', e: '🔗', d: 'نشر الروابط' },
    { k: 'voice', g: 'general', l: 'دخول وخروج صوتي', e: '🎙️', d: 'الدخول والخروج من الرومات الصوتية' },
    { k: 'voicemove', g: 'general', l: 'التنقل بالرومات الصوتية', e: '🔀', d: 'تنقل الأعضاء بأنفسهم' },
    { k: 'selfmute', g: 'general', l: 'كتم النفس', e: '🔕', d: 'كتم وإلغاء كتم الأعضاء لأنفسهم' },
    { k: 'nick', g: 'general', l: 'الأسماء المستعارة', e: '📛', d: 'تغيير الأسماء في السيرفر' },
    { k: 'account', g: 'general', l: 'تعديل الحسابات', e: '🪪', d: 'تغيير الأفتار واليوزر' },
    { k: 'reactions', g: 'general', l: 'التفاعلات', e: '😄', d: 'إضافة وإزالة الريأكشنات' }
];
const T = Object.fromEntries(TYPES.map(t => [t.k, t]));

const cfg = () => {
    const c = (db.logs = db.logs || {});
    c.enabled = c.enabled !== false;
    c.adminCh = c.adminCh || ''; c.generalCh = c.generalCh || '';
    c.types = c.types || {};
    for (const t of TYPES) { const x = (c.types[t.k] = c.types[t.k] || {}); x.on = x.on !== false; x.ch = x.ch || ''; }
    c.created = Array.isArray(c.created) ? c.created : []; // رومات أنشأها setlog!
    return c;
};

// ───── الإرسال ─────
const logChannelIds = () => { const c = cfg(); return new Set([c.adminCh, c.generalCh, ...Object.values(c.types).map(x => x.ch), ...c.created].filter(Boolean)); };
async function send(key, e, files) {
    try {
        const c = cfg(); if (!c.enabled) return;
        const t = T[key]; const x = c.types[key]; if (!x || !x.on) return;
        const id = x.ch || (t.g === 'admin' ? c.adminCh : c.generalCh); if (!id) return;
        const ch = client.channels.cache.get(id) || await client.channels.fetch(id).catch(() => null);
        if (!ch || !ch.send) return;
        e.setColor(H.BLUE).setTimestamp();
        if (!e.data.footer) e.setFooter({ text: t.e + ' ' + t.l });
        await ch.send({ embeds: [e], files: files || [], allowedMentions: { parse: [] } });
    } catch (err) { console.warn('[logs] send:', err.message); }
}
const E = () => new D.EmbedBuilder();
const u = id => '<@' + id + '>';

/** يجلب منفّذ العملية من سجل التدقيق (اختياري: لو ما توفرت الصلاحية يرجع null) */
async function who(guild, type, targetId, extraMatch) {
    try {
        if (!guild.members.me || !guild.members.me.permissions.has(P.ViewAuditLog)) return null;
        const logs = await guild.fetchAuditLogs({ type, limit: 6 });
        const now = Date.now();
        const en = logs.entries.find(x => now - x.createdTimestamp < 10000 && (!targetId || (x.target && x.target.id === targetId)) && (!extraMatch || extraMatch(x)));
        return en ? { by: en.executor, reason: en.reason || '', entry: en } : null;
    } catch { return null; }
}
const byField = w => (w && w.by ? [{ name: '👮 بواسطة', value: u(w.by.id), inline: true }] : []);
const inGuild = g => g && g.id === SERVER_ID;

// ───── الأحداث ─────
function hook(ev, fn) { try { client.on(ev, async (...a) => { try { await fn(...a); } catch (e) { console.warn('[logs:' + ev + ']', e.message); } }); } catch {} }

hook('messageDelete', async (m) => {
    if (!inGuild(m.guild) || logChannelIds().has(m.channelId)) return;
    if (m.author && m.author.bot) return;
    const e = E().setTitle('🗑️ حذف رسالة').addFields(
        { name: '👤 الكاتب', value: m.author ? u(m.author.id) : '`غير معروف`', inline: true },
        { name: '#️⃣ الروم', value: '<#' + m.channelId + '>', inline: true },
        { name: '💬 المحتوى', value: m.content ? cut(m.content, 1000) : '`غير محفوظ أو مرفق فقط`' });
    if (m.attachments && m.attachments.size) e.addFields({ name: '📎 المرفقات', value: String(m.attachments.size), inline: true });
    await send('messages', e);
});
hook('messageUpdate', async (o, n) => {
    if (!inGuild(n.guild) || logChannelIds().has(n.channelId)) return;
    if ((n.author && n.author.bot) || o.content === n.content || !o.content) return;
    await send('messages', E().setTitle('✏️ تعديل رسالة').addFields(
        { name: '👤 الكاتب', value: n.author ? u(n.author.id) : '`—`', inline: true }, { name: '#️⃣ الروم', value: '<#' + n.channelId + '>', inline: true },
        { name: '🔗 الرابط', value: '[الذهاب للرسالة](' + n.url + ')', inline: true },
        { name: 'قبل', value: cut(o.content, 1000) || '—' }, { name: 'بعد', value: cut(n.content, 1000) || '—' }));
});
hook('messageDeleteBulk', async (msgs, ch) => {
    if (!inGuild(ch.guild)) return;
    await send('bulk', E().setTitle('🧹 حذف جماعي').addFields({ name: '#️⃣ الروم', value: '<#' + ch.id + '>', inline: true }, { name: '🔢 العدد', value: String(msgs.size), inline: true }));
});
hook('messageCreate', async (m) => {
    if (!inGuild(m.guild) || logChannelIds().has(m.channelId) || m.system) return;
    const isMe = client.user && m.author && m.author.id === client.user.id;
    if (m.author && m.author.bot && !isMe && !m.webhookId) {
        await send('botmsgs', E().setTitle('🤖 رسالة بوت').addFields({ name: 'البوت', value: u(m.author.id), inline: true }, { name: '#️⃣ الروم', value: '<#' + m.channelId + '>', inline: true }, { name: '💬', value: cut(m.content, 900) || '`إيمبد/مرفق`' }));
    }
    if (!m.author || m.author.bot) return;
    const imgs = [...m.attachments.values()].filter(a => (a.contentType || '').startsWith('image/'));
    if (imgs.length) {
        const e = E().setTitle('🖼️ صورة جديدة').addFields({ name: '👤 الكاتب', value: u(m.author.id), inline: true }, { name: '#️⃣ الروم', value: '<#' + m.channelId + '>', inline: true }, { name: '🔗', value: '[الرسالة](' + m.url + ')', inline: true }).setImage(imgs[0].url);
        await send('images', e);
    }
    const links = (m.content || '').match(/https?:\/\/\S+/gi);
    if (links) await send('links', E().setTitle('🔗 رابط جديد').addFields({ name: '👤 الكاتب', value: u(m.author.id), inline: true }, { name: '#️⃣ الروم', value: '<#' + m.channelId + '>', inline: true }, { name: '🔗 الروابط', value: cut(links.slice(0, 5).join('\n'), 1000) }));
});
hook('guildMemberAdd', async (m) => {
    if (!inGuild(m.guild)) return;
    const created = Math.floor(m.user.createdTimestamp / 1000);
    await send('joinleave', E().setTitle('📥 دخول عضو').setThumbnail(m.user.displayAvatarURL({ size: 128 })).addFields({ name: '👤 العضو', value: u(m.id) + ' (`' + m.user.username + '`)', inline: true }, { name: '📅 عمر الحساب', value: '<t:' + created + ':R>', inline: true }, { name: '👥 العدد', value: String(m.guild.memberCount), inline: true }));
    if (m.user.bot) { const w = await who(m.guild, AE.BotAdd, m.id); await send('bots', E().setTitle('🤖 إضافة بوت').addFields({ name: 'البوت', value: u(m.id), inline: true }, ...byField(w))); }
});
hook('guildMemberRemove', async (m) => {
    if (!inGuild(m.guild)) return;
    const k = await who(m.guild, AE.MemberKick, m.id);
    if (k) await send('kicks', E().setTitle('👢 طرد عضو').addFields({ name: '👤 العضو', value: u(m.id) + ' (`' + (m.user ? m.user.username : '—') + '`)', inline: true }, ...byField(k), { name: '📝 السبب', value: cut(k.reason, 300) || '`—`' }));
    else await send('joinleave', E().setTitle('📤 خروج عضو').addFields({ name: '👤 العضو', value: u(m.id) + ' (`' + (m.user ? m.user.username : '—') + '`)', inline: true }, { name: '👥 العدد', value: String(m.guild.memberCount), inline: true }));
});
hook('guildBanAdd', async (b) => {
    if (!inGuild(b.guild)) return; const w = await who(b.guild, AE.MemberBanAdd, b.user.id);
    await send('bans', E().setTitle('🔨 باند').addFields({ name: '👤 العضو', value: u(b.user.id) + ' (`' + b.user.username + '`)', inline: true }, ...byField(w), { name: '📝 السبب', value: cut(b.reason || (w && w.reason), 300) || '`—`' }));
});
hook('guildBanRemove', async (b) => {
    if (!inGuild(b.guild)) return; const w = await who(b.guild, AE.MemberBanRemove, b.user.id);
    await send('bans', E().setTitle('♻️ فك باند').addFields({ name: '👤 العضو', value: u(b.user.id) + ' (`' + b.user.username + '`)', inline: true }, ...byField(w)));
});
hook('guildMemberUpdate', async (o, n) => {
    if (!inGuild(n.guild)) return;
    if (o.nickname !== undefined && o.nickname !== n.nickname) await send('nick', E().setTitle('📛 تغيير اسم مستعار').addFields({ name: '👤 العضو', value: u(n.id), inline: true }, { name: 'قبل', value: o.nickname || '`—`', inline: true }, { name: 'بعد', value: n.nickname || '`—`', inline: true }));
    if (o.roles && n.roles) {
        const added = n.roles.cache.filter(r => !o.roles.cache.has(r.id)), removed = o.roles.cache.filter(r => !n.roles.cache.has(r.id));
        if (added.size || removed.size) {
            const w = await who(n.guild, AE.MemberRoleUpdate, n.id);
            const e = E().setTitle('🏷️ تغيير رتب عضو').addFields({ name: '👤 العضو', value: u(n.id), inline: true }, ...byField(w));
            if (added.size) e.addFields({ name: '➕ أُعطي', value: added.map(r => '<@&' + r.id + '>').join(' ') });
            if (removed.size) e.addFields({ name: '➖ سُحب', value: removed.map(r => '<@&' + r.id + '>').join(' ') });
            await send('roleassign', e);
        }
    }
    const a = o.communicationDisabledUntilTimestamp || 0, b = n.communicationDisabledUntilTimestamp || 0;
    if (a !== b && (b > Date.now() || a > Date.now())) {
        const w = await who(n.guild, AE.MemberUpdate, n.id);
        await send('timeout', E().setTitle(b > Date.now() ? '⏳ تايم اوت' : '✅ إزالة تايم اوت').addFields({ name: '👤 العضو', value: u(n.id), inline: true }, ...byField(w), ...(b > Date.now() ? [{ name: '⏰ ينتهي', value: '<t:' + Math.floor(b / 1000) + ':R>', inline: true }] : []), ...(w && w.reason ? [{ name: '📝 السبب', value: cut(w.reason, 300) }] : [])));
    }
});
hook('userUpdate', async (o, n) => {
    const g = client.guilds.cache.get(SERVER_ID); if (!g || !g.members.cache.has(n.id)) return;
    const ch = [];
    if (o.username !== n.username) ch.push({ name: '👤 اليوزر', value: '`' + o.username + '` ← `' + n.username + '`' });
    if (o.avatar !== n.avatar) ch.push({ name: '🖼️ الأفتار', value: 'تم تغيير الصورة الشخصية' });
    if (o.globalName !== n.globalName) ch.push({ name: '📛 الاسم العام', value: '`' + (o.globalName || '—') + '` ← `' + (n.globalName || '—') + '`' });
    if (!ch.length) return;
    await send('account', E().setTitle('🪪 تعديل حساب').setThumbnail(n.displayAvatarURL({ size: 128 })).addFields({ name: '👤 العضو', value: u(n.id), inline: true }, ...ch));
});
hook('channelCreate', async (c) => { if (!inGuild(c.guild)) return; const w = await who(c.guild, AE.ChannelCreate, c.id); await send('channels', E().setTitle('🟢 إنشاء قناة').addFields({ name: '#️⃣ القناة', value: '<#' + c.id + '> (`' + c.name + '`)', inline: true }, ...byField(w))); });
hook('channelDelete', async (c) => { if (!inGuild(c.guild) || logChannelIds().has(c.id)) return; const w = await who(c.guild, AE.ChannelDelete, c.id); await send('channels', E().setTitle('🔴 حذف قناة').addFields({ name: '#️⃣ القناة', value: '`' + c.name + '`', inline: true }, ...byField(w))); });
hook('channelUpdate', async (o, n) => {
    if (!inGuild(n.guild)) return;
    const d = [];
    if (o.name !== n.name) d.push({ name: '📛 الاسم', value: '`' + o.name + '` ← `' + n.name + '`' });
    if (o.topic !== n.topic) d.push({ name: '📝 الوصف', value: cut(o.topic || '—', 200) + ' ← ' + cut(n.topic || '—', 200) });
    if (o.parentId !== n.parentId) d.push({ name: '📂 التصنيف', value: (o.parentId ? '<#' + o.parentId + '>' : '—') + ' ← ' + (n.parentId ? '<#' + n.parentId + '>' : '—') });
    if (o.rateLimitPerUser !== n.rateLimitPerUser) d.push({ name: '🐢 السلومود', value: (o.rateLimitPerUser || 0) + 'ث ← ' + (n.rateLimitPerUser || 0) + 'ث' });
    if (!d.length) return;
    const w = await who(n.guild, AE.ChannelUpdate, n.id);
    await send('channels', E().setTitle('🟡 تعديل قناة').addFields({ name: '#️⃣ القناة', value: '<#' + n.id + '>', inline: true }, ...byField(w), ...d));
});
hook('roleCreate', async (r) => { if (!inGuild(r.guild)) return; const w = await who(r.guild, AE.RoleCreate, r.id); await send('roles', E().setTitle('🟢 إنشاء رتبة').addFields({ name: '🛡️ الرتبة', value: '<@&' + r.id + '> (`' + r.name + '`)', inline: true }, ...byField(w))); });
hook('roleDelete', async (r) => { if (!inGuild(r.guild)) return; const w = await who(r.guild, AE.RoleDelete, r.id); await send('roles', E().setTitle('🔴 حذف رتبة').addFields({ name: '🛡️ الرتبة', value: '`' + r.name + '`', inline: true }, ...byField(w))); });
hook('roleUpdate', async (o, n) => {
    if (!inGuild(n.guild)) return; const d = [];
    if (o.name !== n.name) d.push({ name: '📛 الاسم', value: '`' + o.name + '` ← `' + n.name + '`' });
    if (o.color !== n.color) d.push({ name: '🎨 اللون', value: '`#' + o.color.toString(16).padStart(6, '0') + '` ← `#' + n.color.toString(16).padStart(6, '0') + '`' });
    if (!o.permissions.equals(n.permissions)) d.push({ name: '🔐 الصلاحيات', value: 'تم تعديل صلاحيات الرتبة' });
    if (o.hoist !== n.hoist) d.push({ name: '📌 الفصل', value: n.hoist ? 'مفعّل' : 'متوقف' });
    if (!d.length) return;
    const w = await who(n.guild, AE.RoleUpdate, n.id);
    await send('roles', E().setTitle('🟡 تعديل رتبة').addFields({ name: '🛡️ الرتبة', value: '<@&' + n.id + '>', inline: true }, ...byField(w), ...d));
});
hook('guildUpdate', async (o, n) => {
    if (!inGuild(n)) return; const d = [];
    if (o.name !== n.name) d.push({ name: '📛 الاسم', value: '`' + o.name + '` ← `' + n.name + '`' });
    if (o.icon !== n.icon) d.push({ name: '🖼️ الصورة', value: 'تم تغيير صورة السيرفر' });
    if (o.banner !== n.banner) d.push({ name: '🏞️ البنر', value: 'تم تغيير بنر السيرفر' });
    if (!d.length) return;
    const w = await who(n, AE.GuildUpdate, null);
    await send('server', E().setTitle('⚙️ تحديث السيرفر').addFields(...byField(w), ...d));
});
hook('emojiCreate', async (x) => { if (!inGuild(x.guild)) return; const w = await who(x.guild, AE.EmojiCreate, x.id); await send('emoji', E().setTitle('🟢 إضافة إيموجي').setThumbnail(x.url).addFields({ name: '😀', value: x.toString() + ' `' + x.name + '`', inline: true }, ...byField(w))); });
hook('emojiDelete', async (x) => { if (!inGuild(x.guild)) return; const w = await who(x.guild, AE.EmojiDelete, x.id); await send('emoji', E().setTitle('🔴 حذف إيموجي').setThumbnail(x.url).addFields({ name: '😀', value: '`' + x.name + '`', inline: true }, ...byField(w))); });
hook('stickerCreate', async (x) => { if (!inGuild(x.guild)) return; const w = await who(x.guild, AE.StickerCreate, x.id); await send('stickers', E().setTitle('🟢 إضافة ملصق').addFields({ name: '🧷', value: '`' + x.name + '`', inline: true }, ...byField(w))); });
hook('stickerDelete', async (x) => { if (!inGuild(x.guild)) return; const w = await who(x.guild, AE.StickerDelete, x.id); await send('stickers', E().setTitle('🔴 حذف ملصق').addFields({ name: '🧷', value: '`' + x.name + '`', inline: true }, ...byField(w))); });
hook('messageReactionAdd', async (r, usr) => { if (usr.bot || !inGuild(r.message.guild)) return; await send('reactions', E().setTitle('➕ تفاعل').addFields({ name: '👤', value: u(usr.id), inline: true }, { name: 'التفاعل', value: r.emoji.toString(), inline: true }, { name: '🔗', value: '[الرسالة](' + r.message.url + ')', inline: true })); });
hook('messageReactionRemove', async (r, usr) => { if (usr.bot || !inGuild(r.message.guild)) return; await send('reactions', E().setTitle('➖ إزالة تفاعل').addFields({ name: '👤', value: u(usr.id), inline: true }, { name: 'التفاعل', value: r.emoji.toString(), inline: true }, { name: '🔗', value: '[الرسالة](' + r.message.url + ')', inline: true })); });
hook('voiceStateUpdate', async (o, n) => {
    const g = n.guild || o.guild; if (!inGuild(g)) return;
    const id = n.id; const mem = n.member || o.member; if (mem && mem.user && mem.user.bot) return;
    const ch = c => (c ? '<#' + c + '>' : '`—`');
    if (!o.channelId && n.channelId) return send('voice', E().setTitle('🔊 دخول صوتي').addFields({ name: '👤', value: u(id), inline: true }, { name: 'الروم', value: ch(n.channelId), inline: true }));
    if (o.channelId && !n.channelId) {
        const k = await who(g, AE.MemberDisconnect, null, x => true);
        if (k && k.by && k.by.id !== id) return send('voicekick', E().setTitle('🔌 طرد صوتي').addFields({ name: '👤 العضو', value: u(id), inline: true }, ...byField(k), { name: 'من الروم', value: ch(o.channelId), inline: true }));
        return send('voice', E().setTitle('🔈 خروج صوتي').addFields({ name: '👤', value: u(id), inline: true }, { name: 'الروم', value: ch(o.channelId), inline: true }));
    }
    if (o.channelId && n.channelId && o.channelId !== n.channelId) {
        const w = await who(g, AE.MemberMove, null);
        if (w && w.by && w.by.id !== id) return send('voicepull', E().setTitle('↔️ سحب صوتي').addFields({ name: '👤 العضو', value: u(id), inline: true }, ...byField(w), { name: 'من', value: ch(o.channelId), inline: true }, { name: 'إلى', value: ch(n.channelId), inline: true }));
        return send('voicemove', E().setTitle('🔀 تنقل صوتي').addFields({ name: '👤', value: u(id), inline: true }, { name: 'من', value: ch(o.channelId), inline: true }, { name: 'إلى', value: ch(n.channelId), inline: true }));
    }
    if (o.serverMute !== n.serverMute || o.serverDeaf !== n.serverDeaf) {
        const w = await who(g, AE.MemberUpdate, id);
        const s = []; if (o.serverMute !== n.serverMute) s.push(n.serverMute ? '🔇 ميوت' : '🔊 فك ميوت'); if (o.serverDeaf !== n.serverDeaf) s.push(n.serverDeaf ? '🙉 ديفن' : '👂 فك ديفن');
        return send('mutedeaf', E().setTitle('🔇 ميوت / ديفن').addFields({ name: '👤', value: u(id), inline: true }, ...byField(w), { name: 'الإجراء', value: s.join(' • ') }));
    }
    if (o.selfMute !== n.selfMute || o.selfDeaf !== n.selfDeaf) {
        const s = []; if (o.selfMute !== n.selfMute) s.push(n.selfMute ? '🔕 كتم نفسه' : '🔔 فك كتم نفسه'); if (o.selfDeaf !== n.selfDeaf) s.push(n.selfDeaf ? '🙉 ديفن لنفسه' : '👂 فك الديفن');
        return send('selfmute', E().setTitle('🔕 كتم النفس').addFields({ name: '👤', value: u(id), inline: true }, { name: 'الإجراء', value: s.join(' • ') }));
    }
});

// ───── إنشاء/حذف الرومات (setlog! / detlog!) ─────
const GROUP_CHANNELS = [
    { name: 'سجلات-الإدارة', keys: TYPES.filter(t => t.g === 'admin').map(t => t.k), main: 'admin' },
    { name: 'سجلات-الرسائل', keys: ['messages', 'images', 'botmsgs', 'links', 'reactions'] },
    { name: 'سجلات-الصوت', keys: ['voice', 'voicemove', 'selfmute'] },
    { name: 'سجلات-الأعضاء', keys: ['joinleave', 'nick', 'account'], main: 'general' }
];
async function autoCreate(guild) {
    const me = guild.members.me; if (!me || !me.permissions.has(P.ManageChannels)) throw new Error('البوت يحتاج صلاحية Manage Channels.');
    const c = cfg(); await autoDelete(guild, true);
    const adminRoles = (H.tk && H.tk.adminRoleIds ? H.tk.adminRoleIds() : []) || [];
    const overwrites = [{ id: guild.id, deny: [P.ViewChannel] }, { id: me.id, allow: [P.ViewChannel, P.SendMessages, P.EmbedLinks, P.AttachFiles] }, ...adminRoles.filter(r => guild.roles.cache.has(r)).map(r => ({ id: r, allow: [P.ViewChannel, P.ReadMessageHistory] }))];
    const cat = await guild.channels.create({ name: '📜 السجلات', type: ChannelType.GuildCategory, permissionOverwrites: overwrites });
    c.created = [cat.id];
    for (const gc of GROUP_CHANNELS) {
        const ch = await guild.channels.create({ name: gc.name, type: ChannelType.GuildText, parent: cat.id, permissionOverwrites: overwrites });
        c.created.push(ch.id);
        if (gc.main === 'admin') c.adminCh = ch.id; if (gc.main === 'general') c.generalCh = ch.id;
        for (const k of gc.keys) c.types[k].ch = ch.id;
    }
    c.enabled = true; save();
    return c.created.length - 1;
}
async function autoDelete(guild, silent) {
    const c = cfg(); let n = 0;
    for (const id of c.created) { const ch = guild.channels.cache.get(id) || await guild.channels.fetch(id).catch(() => null); if (ch) { await ch.delete('detlog!').catch(() => {}); n++; } }
    const gone = new Set(c.created);
    if (c.adminCh && gone.has(c.adminCh)) c.adminCh = ''; if (c.generalCh && gone.has(c.generalCh)) c.generalCh = '';
    for (const x of Object.values(c.types)) if (x.ch && gone.has(x.ch)) x.ch = '';
    c.created = []; save();
    return n;
}

// ───── القائمة /logs ─────
const st = i => session(i, 'lg', () => ({ view: 'home', type: '' }));
function view(i) {
    const c = cfg(); const s = st(i);
    const adm = TYPES.filter(t => t.g === 'admin'), gen = TYPES.filter(t => t.g === 'general');
    if (s.view === 'override') {
        const t = T[s.type]; const x = t && c.types[t.k];
        const e = embed().setTitle('📍 قناة مخصصة لنوع سجل').setDescription('اختر النوع ثم الروم. الفاضي = الروم العام للمجموعة.')
            .addFields({ name: 'النوع', value: t ? t.e + ' ' + t.l : '`لم يُحدد`', inline: true }, { name: 'الروم', value: x && x.ch ? '<#' + x.ch + '>' : '`الافتراضي`', inline: true });
        return { embeds: [e], components: [
            row(strSel('lg:ovtype', 'اختر نوع السجل', TYPES.map(y => ({ label: y.l, value: y.k, emoji: y.e, description: y.g === 'admin' ? 'إداري' : 'عام', default: y.k === s.type })))),
            row(chSel('lg:ovch', 'اختر الروم', { selected: x && x.ch ? [x.ch] : [], min: 0 })),
            row(btn('lg:ovclear', 'إرجاع للافتراضي', '↩️', ButtonStyle.Secondary, !(x && x.ch)), btn('lg:back', 'رجوع', '⬅️', ButtonStyle.Primary))
        ] };
    }
    const e = embed().setTitle('📜 نظام السجلات')
        .setDescription('قم بتفعيل أنواع السجلات المطلوبة، وحدد روم السجلات الإدارية والعامة، أو أنشئ الرومات تلقائياً.')
        .addFields(
            { name: 'الحالة', value: onOff(c.enabled), inline: true },
            { name: '👮 روم الإدارية', value: c.adminCh ? '<#' + c.adminCh + '>' : '`غير محدد`', inline: true },
            { name: '👥 روم العامة', value: c.generalCh ? '<#' + c.generalCh + '>' : '`غير محدد`', inline: true },
            { name: '📊 المفعّل', value: 'إدارية **' + adm.filter(t => c.types[t.k].on).length + '/' + adm.length + '** • عامة **' + gen.filter(t => c.types[t.k].on).length + '/' + gen.length + '**' })
        .setFooter({ text: 'يحتاج البوت View Audit Log لمعرفة من نفّذ العملية' });
    return { embeds: [e], components: [
        row(strSel('lg:adm', '👮 السجلات الإدارية المفعّلة', adm.map(t => ({ label: t.l, value: t.k, emoji: t.e, description: t.d, default: c.types[t.k].on })), { min: 0, max: adm.length })),
        row(strSel('lg:gen', '👥 السجلات العامة المفعّلة', gen.map(t => ({ label: t.l, value: t.k, emoji: t.e, description: t.d, default: c.types[t.k].on })), { min: 0, max: gen.length })),
        row(chSel('lg:ach', 'روم السجلات الإدارية', { selected: c.adminCh ? [c.adminCh] : [], min: 0 })),
        row(chSel('lg:gch', 'روم السجلات العامة', { selected: c.generalCh ? [c.generalCh] : [], min: 0 })),
        row(btn('lg:toggle', c.enabled ? 'إيقاف' : 'تشغيل', c.enabled ? '⛔' : '✅', c.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
            btn('lg:auto', 'إنشاء الرومات تلقائياً', '🛠️', ButtonStyle.Primary), btn('lg:del', 'حذف الرومات', '🗑️', ButtonStyle.Danger, !c.created.length), btn('lg:ov', 'قناة لنوع', '📍'))
    ] };
}
async function slash(i) { if (!(await adminOnly(i))) return; st(i).view = 'home'; return i.reply({ ...view(i), flags: EPH }); }
async function component(i) {
    if (!(await adminOnly(i))) return;
    const a = i.customId.split(':')[1]; const c = cfg(); const s = st(i);
    if (a === 'auto' || a === 'del') {
        await i.deferUpdate();
        try {
            const n = a === 'auto' ? await autoCreate(i.guild) : await autoDelete(i.guild);
            await i.editReply(view(i)); return i.followUp({ content: a === 'auto' ? '✅ تم إنشاء ' + n + ' رومات سجلات وربطها تلقائياً.' : '✅ تم حذف ' + n + ' من رومات السجلات.', flags: EPH });
        } catch (e) { await i.editReply(view(i)); return i.followUp({ content: '❌ ' + e.message, flags: EPH }); }
    }
    if (a === 'adm' || a === 'gen') { const g = a === 'adm' ? 'admin' : 'general'; const keep = new Set(i.values); for (const t of TYPES.filter(y => y.g === g)) c.types[t.k].on = keep.has(t.k); }
    else if (a === 'ach') c.adminCh = i.values[0] || '';
    else if (a === 'gch') c.generalCh = i.values[0] || '';
    else if (a === 'toggle') c.enabled = !c.enabled;
    else if (a === 'ov') s.view = 'override';
    else if (a === 'back') s.view = 'home';
    else if (a === 'ovtype') s.type = i.values[0];
    else if (a === 'ovch') { if (s.type && c.types[s.type]) c.types[s.type].ch = i.values[0] || ''; }
    else if (a === 'ovclear') { if (s.type && c.types[s.type]) c.types[s.type].ch = ''; }
    save();
    return update(i, view(i));
}
const commands = [{ name: 'logs', description: 'نظام السجلات: إدارية وعامة، تفعيل كل نوع وتحديد رومه (إدارة)' }];
H.logs = { autoCreate, autoDelete };
return { prefix: 'lg', commands, ephemeral: ['logs'], slash: { logs: slash }, component };
};
