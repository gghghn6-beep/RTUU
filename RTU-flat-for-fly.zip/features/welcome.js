'use strict';
module.exports = (H) => {
const { D, path, fs, DATA_DIR, BLUE, isAdmin, SERVER_ID, save } = H;
const db = H.db;
const {
    EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ChannelSelectMenuBuilder,
    ModalBuilder, TextInputBuilder, TextInputStyle, AttachmentBuilder, ChannelType, MessageFlags
} = D;
// ═══════════════════════════════════════════════════════════════
//  نظام الترحيب والمغادرة (قائمة إعدادات تفاعلية /welcomesettings) + أمر الخط
// ═══════════════════════════════════════════════════════════════
let _canvasLib;
function getCanvasLib() {
    if (_canvasLib === undefined) {
        try { _canvasLib = require('@napi-rs/canvas'); }
        catch (e) { _canvasLib = null; console.warn('[welcome] @napi-rs/canvas غير مثبتة — سيُرسل الترحيب بدون دمج الصورة (شغّل npm install)'); }
    }
    return _canvasLib;
}
const WELCOME_BG_FILE = path.join(DATA_DIR, 'welcome-bg.img');
const IMAGE_MODES = { embedded: 'مع الرسالة (داخل الإمبيد)', separate: 'منفصلة (بعد الرسالة)', room: 'روم خاص للصورة', none: 'بدون صورة' };
const SHAPES = { circle: 'دائري', rounded: 'مربع بزوايا دائرية', square: 'مربع' };
const DEFAULT_WELCOME_MSG = '💙 أهلاً وسهلاً {user} في **{server}**\nنوّرتنا! أنت العضو رقم **{memberCount}**.\n📜 اقرأ القوانين  •  🎫 افتح تذكرة إذا احتجت مساعدة.';
const DEFAULT_LEAVE_MSG = '{userName} غادر السيرفر.';

function getWelcomeCfg() {
    const w = db.welcome || {}; const l = w.leave || {};
    const num = (v, d) => Number.isFinite(v) ? v : d;
    return {
        enabled: w.enabled !== false,
        welcomeEnabled: w.welcomeEnabled !== false,
        channelId: w.channelId || '',
        dest: w.dest === 'dm' ? 'dm' : 'channel',
        title: w.title != null ? w.title : 'عضو جديد',
        message: w.message || DEFAULT_WELCOME_MSG,
        imageMode: IMAGE_MODES[w.imageMode] ? w.imageMode : 'embedded',
        imageChannelId: w.imageChannelId || '',
        hasBg: !!w.hasBg && fs.existsSync(WELCOME_BG_FILE),
        avatarX: Math.max(0, Math.min(100, num(w.avatarX, 50))),
        avatarY: Math.max(0, Math.min(100, num(w.avatarY, 50))),
        avatarSize: Math.max(60, Math.min(1200, num(w.avatarSize, 260))),
        avatarShape: SHAPES[w.avatarShape] ? w.avatarShape : 'circle',
        style: w.style === 'plain' ? 'plain' : 'embed',
        showName: !!w.showName,
        supportChannelId: w.supportChannelId || '',
        rulesChannelId: w.rulesChannelId || '',
        youtubeUrl: w.youtubeUrl || '',
        leave: { enabled: l.enabled !== false, channelId: l.channelId || '', message: l.message || DEFAULT_LEAVE_MSG }
    };
}
function wset(patch) { db.welcome = { ...(db.welcome || {}), ...patch }; save(); }
function lset(patch) { const w = db.welcome || {}; db.welcome = { ...w, leave: { ...(w.leave || {}), ...patch } }; save(); }

function fillWelcomeText(tpl, member) {
    const g = member.guild; const u = member.user;
    return String(tpl)
        .replace(/\{user\}/gi, '<@' + u.id + '>')
        .replace(/\{user_?name\}/gi, u.username)
        .replace(/\{server\}/gi, g.name)
        .replace(/\{(member_?count|count)\}/gi, String(g.memberCount));
}
async function fetchBuffer(url, maxBytes) {
    const res = await fetch(url, { signal: (typeof AbortSignal !== 'undefined' && AbortSignal.timeout) ? AbortSignal.timeout(8000) : undefined });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const buf = Buffer.from(await res.arrayBuffer());
    if (maxBytes && buf.length > maxBytes) throw new Error('الملف أكبر من ' + Math.round(maxBytes / 1048576) + 'MB');
    return { buf, ct: res.headers.get('content-type') || '' };
}
function shapePath(ctx, cx, cy, r, shape) {
    ctx.beginPath();
    if (shape === 'circle') ctx.arc(cx, cy, r, 0, Math.PI * 2);
    else if (shape === 'rounded' && ctx.roundRect) ctx.roundRect(cx - r, cy - r, r * 2, r * 2, r * 0.28);
    else ctx.rect(cx - r, cy - r, r * 2, r * 2);
    ctx.closePath();
}

const FONT_STACK = 'ARKFont, "Noto Sans Arabic", "Noto Naskh Arabic", "Segoe UI", Tahoma, Arial, sans-serif';
function rrect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(x, y, w, h, r);
    else { ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
}
/** بطاقة الترحيب الافتراضية «نيون»: أزرق غامق، شبكة منظور، أشعة ضوء، حلقة HUD متوهجة، نص بتأثير ضوئي، كبسولة عدد الأعضاء */
async function renderDefaultCard(lib, member, cfg) {
    const W = 1280, HH = 540;
    const canvas = lib.createCanvas(W, HH);
    const ctx = canvas.getContext('2d');
    const cx = W / 2, cy = 190;
    // ── الخلفية
    const base = ctx.createLinearGradient(0, 0, W, HH);
    base.addColorStop(0, '#02060F'); base.addColorStop(0.5, '#0A1F52'); base.addColorStop(1, '#030A1A');
    ctx.fillStyle = base; ctx.fillRect(0, 0, W, HH);
    const core = ctx.createRadialGradient(cx, cy, 20, cx, cy, 520);
    core.addColorStop(0, 'rgba(37,99,235,0.55)'); core.addColorStop(0.5, 'rgba(29,78,216,0.18)'); core.addColorStop(1, 'rgba(3,10,26,0)');
    ctx.fillStyle = core; ctx.fillRect(0, 0, W, HH);
    // ── كلمة خلفية ضخمة شفافة
    ctx.save(); ctx.globalAlpha = 0.045; ctx.fillStyle = '#9CC4FF'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = '900 230px ' + FONT_STACK; ctx.fillText('WELCOME', cx, 300, W - 40); ctx.restore();
    // ── أشعة ضوء قطرية
    for (const [x0, w, a] of [[120, 90, 0.10], [330, 40, 0.07], [900, 40, 0.07], [1080, 110, 0.10]]) {
        const g = ctx.createLinearGradient(x0, 0, x0 + 160, HH);
        g.addColorStop(0, 'rgba(96,165,250,0)'); g.addColorStop(0.5, 'rgba(96,165,250,' + a + ')'); g.addColorStop(1, 'rgba(96,165,250,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x0, 0); ctx.lineTo(x0 + w, 0); ctx.lineTo(x0 + w - 150, HH); ctx.lineTo(x0 - 150, HH); ctx.closePath(); ctx.fill();
    }
    // ── أرضية شبكية بمنظور
    ctx.save(); ctx.strokeStyle = 'rgba(96,165,250,0.22)'; ctx.lineWidth = 1.2;
    const horizon = 392;
    for (let k = -14; k <= 14; k++) { ctx.beginPath(); ctx.moveTo(cx + k * 34, horizon); ctx.lineTo(cx + k * 190, HH); ctx.stroke(); }
    for (let k = 0; k < 6; k++) { const y = horizon + Math.pow(k / 5, 1.8) * (HH - horizon); ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
    ctx.restore();
    const fade = ctx.createLinearGradient(0, horizon - 10, 0, HH); fade.addColorStop(0, 'rgba(3,10,26,0.0)'); fade.addColorStop(1, 'rgba(3,10,26,0.0)');
    // ── جزيئات متوهجة (ثابتة لكل عضو)
    let seed = parseInt(String(member.id).slice(-7), 10) || 1234567;
    const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    ctx.save(); ctx.shadowColor = '#60A5FA'; ctx.shadowBlur = 10;
    for (let k = 0; k < 60; k++) { ctx.globalAlpha = 0.18 + rnd() * 0.6; ctx.fillStyle = '#DBEAFE'; ctx.beginPath(); ctx.arc(rnd() * W, rnd() * HH, rnd() * 2.4 + 0.6, 0, Math.PI * 2); ctx.fill(); }
    ctx.restore(); ctx.globalAlpha = 1;
    // ── أقواس الزوايا (HUD)
    ctx.save(); ctx.strokeStyle = '#60A5FA'; ctx.lineWidth = 4; ctx.shadowColor = '#3B82F6'; ctx.shadowBlur = 14; ctx.lineCap = 'round';
    const m = 26, L = 70;
    for (const [x, y, sx, sy] of [[m, m, 1, 1], [W - m, m, -1, 1], [m, HH - m, 1, -1], [W - m, HH - m, -1, -1]]) { ctx.beginPath(); ctx.moveTo(x, y + sy * L); ctx.lineTo(x, y); ctx.lineTo(x + sx * L, y); ctx.stroke(); }
    ctx.restore();
    // ── اسم السيرفر
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.save(); ctx.shadowColor = '#3B82F6'; ctx.shadowBlur = 16;
    ctx.fillStyle = 'rgba(219,234,254,0.92)'; ctx.font = '700 24px ' + FONT_STACK;
    ctx.fillText(String(member.guild.name).slice(0, 40), cx, 50, W - 260); ctx.restore();
    // ── الصورة الشخصية مع حلقة HUD
    const r = Math.max(84, Math.min(112, cfg.avatarSize / 2));
    let av = null;
    try { const { buf } = await fetchBuffer(member.user.displayAvatarURL({ extension: 'png', size: 512, forceStatic: true }), 8 * 1048576); av = await lib.loadImage(buf); }
    catch (e) { console.warn('[welcome] avatar:', e.message); }
    ctx.save(); ctx.strokeStyle = 'rgba(96,165,250,0.55)'; ctx.lineWidth = 3; ctx.shadowColor = '#3B82F6'; ctx.shadowBlur = 20;
    if (ctx.setLineDash) ctx.setLineDash([4, 14]); ctx.beginPath(); ctx.arc(cx, cy, r + 44, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
    ctx.save(); ctx.lineWidth = 7; ctx.lineCap = 'round'; ctx.shadowColor = '#60A5FA'; ctx.shadowBlur = 26;
    for (const [a0, a1, col] of [[-0.9, 0.2, '#60A5FA'], [1.1, 2.1, '#2563EB'], [2.5, 3.3, '#93C5FD'], [4.0, 4.9, '#3B82F6']]) { ctx.strokeStyle = col; ctx.beginPath(); ctx.arc(cx, cy, r + 26, a0, a1); ctx.stroke(); }
    ctx.restore();
    const ring = 8;
    ctx.save(); ctx.shadowColor = '#3B8BFF'; ctx.shadowBlur = 50;
    const rg = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r); rg.addColorStop(0, '#BFDBFE'); rg.addColorStop(0.5, '#2F7BFF'); rg.addColorStop(1, '#0F2A66');
    shapePath(ctx, cx, cy, r + ring, cfg.avatarShape); ctx.fillStyle = rg; ctx.fill(); ctx.restore();
    ctx.save(); shapePath(ctx, cx, cy, r + 2, cfg.avatarShape); ctx.fillStyle = '#061633'; ctx.fill(); ctx.restore();
    ctx.save(); shapePath(ctx, cx, cy, r - 3, cfg.avatarShape); ctx.clip();
    if (av) ctx.drawImage(av, cx - r, cy - r, r * 2, r * 2); else { ctx.fillStyle = '#16337a'; ctx.fillRect(cx - r, cy - r, r * 2, r * 2); }
    ctx.restore();
    // ── العنوان بتأثير ضوئي (انفصال لوني)
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = '900 68px ' + FONT_STACK;
    const ty = 352;
    ctx.fillStyle = 'rgba(34,211,238,0.55)'; ctx.fillText('مرحباً بك', cx - 4, ty - 2, W - 160);
    ctx.fillStyle = 'rgba(37,99,235,0.75)'; ctx.fillText('مرحباً بك', cx + 4, ty + 2, W - 160);
    ctx.save(); ctx.shadowColor = '#60A5FA'; ctx.shadowBlur = 24; ctx.fillStyle = '#FFFFFF'; ctx.fillText('مرحباً بك', cx, ty, W - 160); ctx.restore();
    // ── الاسم
    ctx.save(); ctx.shadowColor = '#2563EB'; ctx.shadowBlur = 18;
    const nm = ctx.createLinearGradient(cx - 220, 0, cx + 220, 0); nm.addColorStop(0, '#93C5FD'); nm.addColorStop(0.5, '#FFFFFF'); nm.addColorStop(1, '#93C5FD');
    ctx.fillStyle = nm; ctx.font = '800 46px ' + FONT_STACK;
    ctx.fillText(String(member.user.globalName || member.user.username).slice(0, 28), cx, 414, W - 160); ctx.restore();
    // ── كبسولة عدد الأعضاء
    const label = 'أنت العضو رقم ' + member.guild.memberCount;
    ctx.font = '700 28px ' + FONT_STACK;
    const tw = Math.min(W - 200, ctx.measureText(label).width + 80); const py = 452;
    const pg = ctx.createLinearGradient(cx - tw / 2, 0, cx + tw / 2, 0); pg.addColorStop(0, 'rgba(37,99,235,0.45)'); pg.addColorStop(1, 'rgba(96,165,250,0.25)');
    ctx.save(); ctx.shadowColor = '#3B82F6'; ctx.shadowBlur = 20; ctx.fillStyle = pg; rrect(ctx, cx - tw / 2, py, tw, 54, 27); ctx.fill(); ctx.restore();
    ctx.strokeStyle = 'rgba(147,197,253,0.85)'; ctx.lineWidth = 2; rrect(ctx, cx - tw / 2, py, tw, 54, 27); ctx.stroke();
    ctx.fillStyle = '#EAF3FF'; ctx.fillText(label, cx, py + 28, tw - 30);
    // ── خط نيون سفلي
    const nl = ctx.createLinearGradient(60, 0, W - 60, 0); nl.addColorStop(0, 'rgba(96,165,250,0)'); nl.addColorStop(0.5, 'rgba(147,197,253,1)'); nl.addColorStop(1, 'rgba(96,165,250,0)');
    ctx.save(); ctx.shadowColor = '#60A5FA'; ctx.shadowBlur = 16; ctx.fillStyle = nl; ctx.fillRect(60, HH - 20, W - 120, 3); ctx.restore();
    return canvas.toBuffer('image/png');
}
async function renderWelcomeImage(member, cfg) {
    const lib = getCanvasLib();
    if (!lib) return null;
    if (!cfg.hasBg) return renderDefaultCard(lib, member, cfg);
    const W = Math.max(1000, Math.min(1800, cfg.avatarSize + 80));
    let bg = null;
    if (cfg.hasBg) { try { bg = await lib.loadImage(fs.readFileSync(WELCOME_BG_FILE)); } catch (e) { console.warn('[welcome] bg:', e.message); } }
    const H = bg ? Math.max(cfg.avatarSize + 80, Math.min(1800, Math.round(W * bg.height / bg.width))) : Math.max(400, Math.min(1400, cfg.avatarSize + 120));
    const canvas = lib.createCanvas(W, H);
    const ctx = canvas.getContext('2d');
    if (bg) ctx.drawImage(bg, 0, 0, W, H);
    else {
        const gr = ctx.createLinearGradient(0, 0, W, H);
        gr.addColorStop(0, '#050E24'); gr.addColorStop(1, BLUE);
        ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
    }
    const r = cfg.avatarSize / 2;
    const cx = Math.max(r, Math.min(W - r, W * cfg.avatarX / 100));
    const cy = Math.max(r, Math.min(H - r, H * cfg.avatarY / 100));
    let av = null;
    try {
        const { buf } = await fetchBuffer(member.user.displayAvatarURL({ extension: 'png', size: 512, forceStatic: true }), 8 * 1048576);
        av = await lib.loadImage(buf);
    } catch (e) { console.warn('[welcome] avatar:', e.message); }
    const ring = Math.max(4, r * 0.05);
    ctx.save();
    ctx.shadowColor = BLUE; ctx.shadowBlur = 24;
    shapePath(ctx, cx, cy, r + ring, cfg.avatarShape); ctx.fillStyle = BLUE; ctx.fill();
    ctx.restore();
    ctx.save();
    shapePath(ctx, cx, cy, r, cfg.avatarShape); ctx.clip();
    if (av) ctx.drawImage(av, cx - r, cy - r, r * 2, r * 2);
    else { ctx.fillStyle = '#2b2d31'; ctx.fillRect(cx - r, cy - r, r * 2, r * 2); }
    ctx.restore();
    if (cfg.showName) {
        ctx.save();
        ctx.textAlign = 'center'; ctx.textBaseline = 'top';
        ctx.font = 'bold ' + Math.round(Math.max(22, r * 0.28)) + 'px sans-serif';
        ctx.shadowColor = '#000'; ctx.shadowBlur = 8; ctx.fillStyle = '#fff';
        ctx.fillText(member.user.globalName || member.user.username, cx, Math.min(H - 40, cy + r + ring + 10), W - 40);
        ctx.restore();
    }
    return canvas.toBuffer('image/png');
}
function buildWelcomeButtons(guild, cfg) {
    const btns = [];
    if (cfg.supportChannelId) btns.push(new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel('الدعم الفني').setEmoji('🎫').setURL('https://discord.com/channels/' + guild.id + '/' + cfg.supportChannelId));
    if (cfg.rulesChannelId) btns.push(new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel('القوانين').setEmoji('📜').setURL('https://discord.com/channels/' + guild.id + '/' + cfg.rulesChannelId));
    if (/^https?:\/\//i.test(cfg.youtubeUrl)) btns.push(new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel('يوتيوب').setEmoji('▶️').setURL(cfg.youtubeUrl));
    return btns.length ? [new ActionRowBuilder().addComponents(btns)] : [];
}
/** يبني أجزاء الترحيب: الإمبيد + (صورة) + الأزرار */
async function buildWelcomeParts(member, cfg, withImage) {
    const embed = new EmbedBuilder().setColor(BLUE).setDescription(fillWelcomeText(cfg.message, member).slice(0, 4000));
    if (cfg.title) embed.setTitle(fillWelcomeText(cfg.title, member).slice(0, 250));
    embed.setFooter({ text: member.guild.name + ' • ' + member.guild.memberCount + ' عضو' });
    let img = null;
    if (cfg.imageMode !== 'none') {
        try { img = await renderWelcomeImage(member, cfg); } catch (e) { console.error('[welcome] render:', e.message); }
    }
    const file = img ? new AttachmentBuilder(img, { name: 'welcome.png' }) : null;
    if (withImage && file) embed.setImage('attachment://welcome.png');
    else if (!file && cfg.imageMode !== 'none') { try { embed.setThumbnail(member.user.displayAvatarURL({ size: 256 })); } catch {} }
    return { embed, file, components: buildWelcomeButtons(member.guild, cfg) };
}
async function getTextChannel(guild, id) {
    if (!id) return null;
    const ch = guild.channels.cache.get(id) || await guild.channels.fetch(id).catch(() => null);
    return ch && ch.isTextBased() ? ch : null;
}
/** أول روم نصي يقدر البوت يرسل فيه (روم النظام أولاً) — احتياط لو ما انحدد روم الترحيب أو انحذف */
async function defaultChannel(guild) {
    const me = guild.members && guild.members.me;
    const ok = (c) => { try { return !!(c && c.isTextBased && c.isTextBased() && !(c.isThread && c.isThread()) && c.send && (!me || (c.permissionsFor(me) && c.permissionsFor(me).has(['ViewChannel', 'SendMessages'])))); } catch { return false; } };
    if (ok(guild.systemChannel)) return guild.systemChannel;
    return [...guild.channels.cache.values()].find(ok) || null;
}
const permsIn = (ch, guild) => { try { const me = guild.members && guild.members.me; return me && ch.permissionsFor ? ch.permissionsFor(me) : null; } catch { return null; } };
/** يرسل الترحيب بأكثر من خطة: كامل ← نص فقط ← وجهة بديلة (روم) لو الخاص مقفل. ما يطيح أبداً ويرجع السبب لو فشل */
async function sendWelcome(member, opts = {}) {
    const cfg = getWelcomeCfg();
    if (!opts.force && (!cfg.enabled || !cfg.welcomeEnabled)) return { ok: false, why: 'الترحيب متوقف' };
    const guild = member.guild;
    const chan = async () => (await getTextChannel(guild, cfg.channelId).catch(() => null)) || (await defaultChannel(guild));
    const dests = (cfg.dest === 'dm' ? [member, await chan()] : [await chan()]).filter(Boolean);
    if (!dests.length) return { ok: false, why: 'ما لقيت روم يقدر البوت يرسل فيه — حدد روم الترحيب من /welcomesettings' };
    const plain = cfg.style === 'plain';
    const inline = cfg.imageMode === 'embedded';
    let parts;
    try { parts = await buildWelcomeParts(member, cfg, inline && !plain); }
    catch (e) { console.error('[welcome] build:', e.message); parts = { embed: new EmbedBuilder().setColor(BLUE).setDescription(fillWelcomeText(cfg.message, member).slice(0, 4000)), file: null, components: [] }; }
    const { embed, components } = parts; const file0 = parts.file;
    let lastWhy = 'تعذّر الإرسال';
    for (const dest of dests) {
        const isCh = dest !== member; let file = file0;
        if (isCh) {
            const pm = permsIn(dest, guild);
            if (pm && !pm.has('SendMessages')) { lastWhy = 'البوت ما عنده صلاحية إرسال الرسائل في <#' + dest.id + '>'; console.warn('[welcome] ' + lastWhy); continue; }
            if (pm && file && !pm.has('AttachFiles')) { file = null; console.warn('[welcome] ما فيه صلاحية إرفاق الملفات في <#' + dest.id + '> — يُرسل الترحيب بدون الصورة'); }
        }
        if (file0 && !file) { try { embed.setImage(null); embed.setThumbnail(member.user.displayAvatarURL({ size: 256 })); } catch {} }
        const mention = isCh ? { allowedMentions: { users: [member.id] } } : {};
        const img = () => new AttachmentBuilder(file.attachment, { name: 'welcome.png' });
        let base;
        if (plain) { base = { content: fillWelcomeText(cfg.message, member).slice(0, 2000), components, ...mention }; if (inline && file) base.files = [img()]; }
        else { base = { embeds: [embed], components, ...mention }; if (inline && file) base.files = [img()]; }
        let sent = false;
        try { await dest.send(base); sent = true; }
        catch (e1) {
            console.warn('[welcome] الإرسال الكامل فشل (' + e1.message + ') — أجرّب نص فقط');
            try { await dest.send({ content: fillWelcomeText(cfg.message, member).slice(0, 2000), ...mention }); sent = true; }
            catch (e2) { lastWhy = 'تعذّر الإرسال: ' + e2.message; }
        }
        if (!sent) continue;
        try {
            if (file && cfg.imageMode === 'separate') await dest.send({ files: [img()] });
            if (file && cfg.imageMode === 'room') { const rc = await getTextChannel(guild, cfg.imageChannelId); if (rc) await rc.send({ files: [img()] }); }
        } catch (e3) { console.warn('[welcome] إرسال الصورة المنفصلة:', e3.message); }
        return { ok: true };
    }
    return { ok: false, why: lastWhy };
}
function buildLeaveEmbed(member, cfg) {
    const e = new EmbedBuilder().setColor(BLUE).setTitle('🚪 مغادرة عضو')
        .setDescription(fillWelcomeText(cfg.leave.message, member).slice(0, 4000))
        .setFooter({ text: member.guild.name + ' • ' + member.guild.memberCount + ' عضو' });
    try { e.setThumbnail(member.user.displayAvatarURL({ size: 256 })); } catch {}
    return e;
}
async function sendLeave(member) {
    const cfg = getWelcomeCfg();
    if (!cfg.enabled || !cfg.leave.enabled || !cfg.leave.channelId || !member.user) return;
    const ch = await getTextChannel(member.guild, cfg.leave.channelId);
    if (ch) await ch.send({ embeds: [buildLeaveEmbed(member, cfg)], allowedMentions: { parse: [] } });
}

// ───── قائمة الإعدادات التفاعلية ─────
const WS_PAGES = ['welcome', 'image', 'leave'];
const onOff = b => b ? '✅ يعمل' : '⛔ متوقف';
const chTxt = id => id ? '<#' + id + '>' : '`غير محدد`';
function wsChannelSelect(customId, placeholder, selectedId, disabled) {
    const m = new ChannelSelectMenuBuilder().setCustomId(customId).setPlaceholder(placeholder)
        .setChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement).setMinValues(1).setMaxValues(1).setDisabled(!!disabled);
    if (selectedId) { try { m.setDefaultChannels([selectedId]); } catch {} }
    return new ActionRowBuilder().addComponents(m);
}
async function buildWelcomePanel(i, page) {
    const cfg = getWelcomeCfg();
    const member = i.member;
    const emb = new EmbedBuilder().setColor(BLUE);
    const rows = [];
    rows.push(new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ws:nav:welcome').setLabel('الترحيب').setEmoji('👋').setStyle(page === 'welcome' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('ws:nav:image').setLabel('الصورة').setEmoji('🖼️').setStyle(page === 'image' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('ws:nav:leave').setLabel('المغادرة').setEmoji('🚪').setStyle(page === 'leave' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('ws:toggle:system').setLabel(cfg.enabled ? 'النظام: يعمل' : 'النظام: متوقف').setEmoji('🔌').setStyle(cfg.enabled ? ButtonStyle.Success : ButtonStyle.Danger)
    ));
    const previews = [];
    let file = null;
    if (page === 'welcome') {
        emb.setTitle('👋 إعدادات رسالة الترحيب')
            .setDescription('عدّل الرسالة وطريقة ومكان الإرسال من الأزرار والقوائم تحت. المعاينة تظهر أسفل الإعدادات.')
            .addFields(
                { name: '🔘 الترحيب', value: onOff(cfg.welcomeEnabled), inline: true },
                { name: '📨 مكان الإرسال', value: cfg.dest === 'dm' ? 'الخاص (DM)' : 'روم بالسيرفر', inline: true },
                { name: '🧾 النمط', value: cfg.style === 'plain' ? 'رسالة عادية بدون إمبيد (النص + الصورة)' : 'إمبيد (النص والصورة داخله)', inline: true },
                { name: '📍 الروم', value: cfg.dest === 'dm' ? '—' : chTxt(cfg.channelId), inline: true },
                { name: '💬 الرسالة', value: '```\n' + cfg.message.slice(0, 700) + '\n```' },
                { name: '🧩 المتغيرات', value: '`{user}` منشن العضو • `{userName}` اسم العضو\n`{server}` اسم السيرفر • `{memberCount}` عدد الأعضاء' }
            );
        rows.push(new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('ws:edit:welcome').setLabel('تعديل الرسالة').setEmoji('✏️').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('ws:links').setLabel('الأزرار').setEmoji('🔗').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ws:style').setLabel(cfg.style === 'plain' ? 'النمط: بدون إمبيد' : 'النمط: إمبيد').setEmoji('🧾').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ws:toggle:welcome').setLabel(cfg.welcomeEnabled ? 'إيقاف الترحيب' : 'تشغيل الترحيب').setStyle(cfg.welcomeEnabled ? ButtonStyle.Danger : ButtonStyle.Success)
        ));
        rows.push(new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('ws:dest').setPlaceholder('مكان الإرسال')
            .addOptions(
                { label: 'روم بالسيرفر (Chat)', value: 'channel', emoji: '💬', default: cfg.dest === 'channel' },
                { label: 'الخاص (DM)', value: 'dm', emoji: '✉️', default: cfg.dest === 'dm' }
            )));
        rows.push(wsChannelSelect('ws:wch', 'اختر روم الترحيب', cfg.channelId, cfg.dest === 'dm'));
    } else if (page === 'links') {
        emb.setTitle('🔗 أزرار الترحيب')
            .setDescription('أزرار الروابط اللي تظهر **تحت الصورة** مباشرة في رسالة الترحيب. اترك الحقل فاضي لإلغاء الزر.')
            .addFields(
                { name: '🎫 الدعم الفني', value: cfg.supportChannelId ? chTxt(cfg.supportChannelId) : '`بدون زر`', inline: true },
                { name: '📜 القوانين', value: cfg.rulesChannelId ? chTxt(cfg.rulesChannelId) : '`بدون زر`', inline: true },
                { name: '▶️ يوتيوب', value: cfg.youtubeUrl || '`بدون زر`', inline: true });
        rows.push(new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('ws:yt').setLabel('رابط اليوتيوب').setEmoji('▶️').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('ws:clr').setLabel('حذف الأزرار').setEmoji('🧹').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('ws:back').setLabel('رجوع').setEmoji('⬅️').setStyle(ButtonStyle.Secondary)));
        rows.push(wsChannelSelect('ws:sup', 'روم الدعم الفني (زر 🎫)', cfg.supportChannelId, false));
        rows.push(wsChannelSelect('ws:rul', 'روم القوانين (زر 📜)', cfg.rulesChannelId, false));
    } else if (page === 'image') {
        emb.setTitle('🖼️ تصميم صورة الترحيب')
            .setDescription('حرّك صورة العضو بالأسهم، كبّرها أو صغّرها، وغيّر شكلها. المعاينة تتحدث مباشرة.\nالخلفية: استخدم `/welcomesettings background:<صورة>`')
            .addFields(
                { name: '📤 طريقة الإرسال', value: IMAGE_MODES[cfg.imageMode], inline: true },
                { name: '📍 روم الصورة', value: cfg.imageMode === 'room' ? chTxt(cfg.imageChannelId) : '—', inline: true },
                { name: '🖼️ الخلفية', value: cfg.hasBg ? 'مخصصة' : 'افتراضية', inline: true },
                { name: '↔️ الموضع', value: 'X: **' + cfg.avatarX + '%** • Y: **' + cfg.avatarY + '%**', inline: true },
                { name: '📏 الحجم', value: '**' + cfg.avatarSize + '**', inline: true },
                { name: '⭕ الشكل', value: SHAPES[cfg.avatarShape] + (cfg.showName ? ' • مع الاسم' : ''), inline: true }
            );
        rows.push(new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('ws:mode').setPlaceholder('طريقة إرسال الصورة')
            .addOptions(Object.entries(IMAGE_MODES).map(([v, l]) => ({ label: l, value: v, default: cfg.imageMode === v })))));
        if (cfg.imageMode === 'room') rows.push(wsChannelSelect('ws:ich', 'اختر الروم للصورة', cfg.imageChannelId, false));
        rows.push(new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('ws:mv:left').setEmoji('⬅️').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ws:mv:up').setEmoji('⬆️').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ws:mv:down').setEmoji('⬇️').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ws:mv:right').setEmoji('➡️').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ws:mv:center').setEmoji('🎯').setStyle(ButtonStyle.Primary)
        ));
        rows.push(new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('ws:size:minus').setEmoji('➖').setLabel('تصغير').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ws:size:plus').setEmoji('➕').setLabel('تكبير').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ws:shape').setEmoji('⭕').setLabel('الشكل').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ws:name').setEmoji('🔤').setLabel(cfg.showName ? 'إخفاء الاسم' : 'إظهار الاسم').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ws:xy').setEmoji('🔢').setLabel('دقيق').setStyle(ButtonStyle.Primary)
        ));
    } else {
        emb.setTitle('🚪 إعدادات رسالة المغادرة')
            .setDescription('رسالة تُرسل في الروم المحدد عند خروج أي عضو.')
            .addFields(
                { name: '🔘 الحالة', value: onOff(cfg.leave.enabled), inline: true },
                { name: '📍 الروم', value: chTxt(cfg.leave.channelId), inline: true },
                { name: '💬 الرسالة', value: '```\n' + cfg.leave.message.slice(0, 700) + '\n```' }
            );
        rows.push(new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('ws:edit:leave').setLabel('تعديل الرسالة').setEmoji('✏️').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('ws:toggle:leave').setLabel(cfg.leave.enabled ? 'إيقاف المغادرة' : 'تشغيل المغادرة').setStyle(cfg.leave.enabled ? ButtonStyle.Danger : ButtonStyle.Success)
        ));
        rows.push(wsChannelSelect('ws:lch', 'اختر روم المغادرة', cfg.leave.channelId, false));
    }
    // المعاينة الحية
    if (page === 'leave') previews.push(buildLeaveEmbed(member, cfg));
    else {
        const p = await buildWelcomeParts(member, cfg, true);
        previews.push(p.embed); file = p.file;
        if (page === 'welcome' && cfg.imageMode !== 'embedded') { p.embed.setImage(null); file = null; }
        if (cfg.style === 'plain') p.embed.setTitle('📄 معاينة — الرسالة تُرسل بدون إمبيد');
    }
    emb.setFooter({ text: 'معاينة حية • كل شيء بالألوان الزرقاء 💙' });
    const out = { embeds: [emb, ...previews], components: rows, attachments: [] };
    if (file) out.files = [file];
    return out;
}
const wsPageOf = i => { const t = (i.message?.embeds?.[0]?.title || ''); return t.includes('أزرار') ? 'links' : t.includes('صورة') ? 'image' : t.includes('المغادرة') ? 'leave' : 'welcome'; };

async function handleWelcomeComponent(i) {
    const id = i.customId;
    if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
    const cfg = getWelcomeCfg();
    const [, a, b] = id.split(':');
    // نوافذ الإدخال (لا تحتاج defer)
    if (i.isButton() && a === 'edit') {
        const isL = b === 'leave';
        const modal = new ModalBuilder().setCustomId('wsm:' + b).setTitle(isL ? 'رسالة المغادرة' : 'رسالة الترحيب');
        const rowsM = [];
        if (!isL) rowsM.push(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('title').setLabel('عنوان الإمبيد (اتركه فارغ لحذفه)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(200).setValue(cfg.title.slice(0, 200))));
        rowsM.push(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('message').setLabel('نص الرسالة').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1500).setValue((isL ? cfg.leave.message : cfg.message).slice(0, 1500))));
        modal.addComponents(...rowsM);
        return i.showModal(modal);
    }
    if (i.isButton() && id === 'ws:yt') {
        const modal = new ModalBuilder().setCustomId('wsm:yt').setTitle('زر اليوتيوب');
        const yti = new TextInputBuilder().setCustomId('youtube').setLabel('رابط اليوتيوب (فارغ = بدون زر)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(200).setPlaceholder('https://youtube.com/@...');
        if (cfg.youtubeUrl) yti.setValue(cfg.youtubeUrl);
        modal.addComponents(new ActionRowBuilder().addComponents(yti));
        return i.showModal(modal);
    }
    if (i.isButton() && id === 'ws:xy') {
        const modal = new ModalBuilder().setCustomId('wsm:xy').setTitle('موضع وحجم صورة العضو');
        modal.addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('x').setLabel('الموضع الأفقي X (0 يسار → 100 يمين)').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(3).setValue(String(cfg.avatarX))),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('y').setLabel('الموضع العمودي Y (0 فوق → 100 تحت)').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(3).setValue(String(cfg.avatarY))),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('size').setLabel('الحجم (60 - 1200)').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(4).setValue(String(cfg.avatarSize)))
        );
        return i.showModal(modal);
    }
    // باقي التفاعلات: نؤجل ثم نحدّث اللوحة
    await i.deferUpdate();
    let page = wsPageOf(i);
    if (i.isButton()) {
        if (a === 'nav') page = b;
        else if (id === 'ws:links') page = 'links';
        else if (id === 'ws:back') page = 'welcome';
        else if (id === 'ws:style') wset({ style: cfg.style === 'plain' ? 'embed' : 'plain' });
        else if (id === 'ws:clr') { wset({ supportChannelId: '', rulesChannelId: '', youtubeUrl: '' }); page = 'links'; }
        else if (a === 'toggle') {
            if (b === 'system') wset({ enabled: !cfg.enabled });
            if (b === 'welcome') wset({ welcomeEnabled: !cfg.welcomeEnabled });
            if (b === 'leave') lset({ enabled: !cfg.leave.enabled });
        } else if (a === 'mv') {
            const step = 5; let x = cfg.avatarX, y = cfg.avatarY;
            if (b === 'left') x -= step; if (b === 'right') x += step; if (b === 'up') y -= step; if (b === 'down') y += step;
            if (b === 'center') { x = 50; y = 50; }
            wset({ avatarX: Math.max(0, Math.min(100, x)), avatarY: Math.max(0, Math.min(100, y)) });
        } else if (a === 'size') wset({ avatarSize: Math.max(60, Math.min(1200, cfg.avatarSize + (b === 'plus' ? 25 : -25))) });
        else if (id === 'ws:shape') { const k = Object.keys(SHAPES); wset({ avatarShape: k[(k.indexOf(cfg.avatarShape) + 1) % k.length] }); }
        else if (id === 'ws:name') wset({ showName: !cfg.showName });
    } else if (i.isStringSelectMenu()) {
        if (id === 'ws:dest') wset({ dest: i.values[0] === 'dm' ? 'dm' : 'channel' });
        if (id === 'ws:mode' && IMAGE_MODES[i.values[0]]) wset({ imageMode: i.values[0] });
    } else if (i.isChannelSelectMenu()) {
        if (id === 'ws:wch') wset({ channelId: i.values[0] });
        if (id === 'ws:sup') wset({ supportChannelId: i.values[0] });
        if (id === 'ws:rul') wset({ rulesChannelId: i.values[0] });
        if (id === 'ws:ich') wset({ imageChannelId: i.values[0] });
        if (id === 'ws:lch') lset({ channelId: i.values[0] });
    }
    return i.editReply(await buildWelcomePanel(i, page));
}
async function handleWelcomeModal(i) {
    if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
    const k = i.customId.split(':')[1];
    const f = n => { try { return i.fields.getTextInputValue(n); } catch { return ''; } };
    if (k === 'welcome') wset({ title: f('title').trim(), message: f('message').trim() || DEFAULT_WELCOME_MSG });
    else if (k === 'leave') lset({ message: f('message').trim() || DEFAULT_LEAVE_MSG });
    else if (k === 'xy') {
        const x = parseInt(f('x'), 10), y = parseInt(f('y'), 10), s = parseInt(f('size'), 10);
        if ([x, y, s].some(v => !Number.isFinite(v))) return i.reply({ content: '❌ اكتب أرقام فقط.', flags: MessageFlags.Ephemeral });
        wset({ avatarX: Math.max(0, Math.min(100, x)), avatarY: Math.max(0, Math.min(100, y)), avatarSize: Math.max(60, Math.min(1200, s)) });
    } else if (k === 'yt') {
        const yt = f('youtube').trim();
        if (yt && !/^https?:\/\//i.test(yt)) return i.reply({ content: '❌ رابط اليوتيوب لازم يبدأ بـ https://', flags: MessageFlags.Ephemeral });
        wset({ youtubeUrl: yt });
    }
    if (typeof i.isFromMessage === 'function' && i.isFromMessage()) {
        await i.deferUpdate();
        return i.editReply(await buildWelcomePanel(i, k === 'leave' ? 'leave' : (k === 'xy' ? 'image' : (k === 'yt' ? 'links' : 'welcome'))));
    }
    return i.reply({ content: '✅ تم الحفظ.', flags: MessageFlags.Ephemeral });
}


const slashHandlers = {
    async welcomesettings(i) {
        if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
        const bg = i.options.getAttachment('background');
        if (bg) {
            if (!String(bg.contentType || '').startsWith('image/')) return i.reply({ content: '❌ الخلفية لازم تكون صورة.', flags: MessageFlags.Ephemeral });
            try { const { buf } = await fetchBuffer(bg.url, 25 * 1048576); fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(WELCOME_BG_FILE, buf); wset({ hasBg: true }); }
            catch (e) { return i.reply({ content: '❌ تعذّر تحميل الصورة: ' + e.message, flags: MessageFlags.Ephemeral }); }
        }
        if (i.options.getBoolean('remove_background')) { try { fs.unlinkSync(WELCOME_BG_FILE); } catch {} wset({ hasBg: false }); }
        const panel = await buildWelcomePanel(i, bg ? 'image' : 'welcome');
        return i.reply({ ...panel, flags: MessageFlags.Ephemeral });
    },
    async testwelcome(i) {
        if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
        try {
            const r = await sendWelcome(i.member, { force: true });
            return i.reply({ content: r.ok ? '✅ تم إرسال ترحيب تجريبي حسب إعداداتك.' : '❌ ' + r.why + ' — حدده من /welcomesettings', flags: MessageFlags.Ephemeral });
        } catch (e) { return i.reply({ content: '❌ فشل الإرسال: ' + e.message, flags: MessageFlags.Ephemeral }); }
    }
};
const commands = [
    { name: 'welcomesettings', description: 'قائمة إعدادات الترحيب والمغادرة (الصورة + الموضع + الرسائل)', options: [
        { name: 'background', description: 'صورة الخلفية اللي أنت مصممها', type: 11, required: false },
        { name: 'remove_background', description: 'حذف الخلفية والرجوع للافتراضية', type: 5, required: false }
    ]},
    { name: 'testwelcome', description: 'إرسال ترحيب تجريبي فعلي لك بنفس الإعدادات الحالية' }
];
return { _renderImage: renderWelcomeImage,
    prefix: 'ws', commands, ephemeral: ['welcomesettings', 'testwelcome'], slash: slashHandlers,
    component: handleWelcomeComponent, modal: handleWelcomeModal,
    onMemberAdd: async (m) => { if (m.guild.id === SERVER_ID) { const r = await sendWelcome(m).catch(e => ({ ok: false, why: e.message })); if (r && !r.ok) console.warn('[welcome] لم يُرسل ترحيب لـ ' + (m.user && m.user.tag) + ': ' + r.why); } },
    onMemberRemove: async (m) => { if (m.guild.id === SERVER_ID) await sendLeave(m); }
};
};
