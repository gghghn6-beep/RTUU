'use strict';
/**
 * نظام الاقتراحات /suggestions
 * أي رسالة في روم الاقتراحات تتحول لاقتراح مع أزرار تصويت
 */
module.exports = (H) => {
const { D, client, BLUE, isAdmin, SERVER_ID, save, EPH, row, btn, chSel, strSel, embed, cut, adminOnly, update, onOff, chTxt } = H;
const db = H.db;
const { ButtonStyle, PermissionFlagsBits } = D;

const cfg = () => {
    const s = (db.suggestions = db.suggestions || {});
    s.enabled = !!s.enabled;
    s.channelId = s.channelId || '';
    s.deleteOriginal = s.deleteOriginal !== false;
    s.anonymous = !!s.anonymous;
    s.votes = s.votes || {}; // messageId -> { up: Set, down: Set, authorId, content }
    s.upEmoji = s.upEmoji || '✅';
    s.downEmoji = s.downEmoji || '❌';
    return s;
};

function voteBar(up, down) {
    const total = up + down;
    if (total === 0) return '░░░░░░░░░░ 0%';
    const pct = Math.round((up / total) * 100);
    const filled = Math.round(pct / 10);
    return '█'.repeat(filled) + '░'.repeat(10 - filled) + ` ${pct}%`;
}

// القديم (للاقتراحات القديمة اللي فيها أزرار تصويت)
function legacyEmbed(author, content, up, down, anonymous, attachmentUrl) {
    const e = embed()
        .setTitle('💡 اقتراح جديد')
        .setDescription(cut(content || '*بدون نص*', 4000))
        .addFields(
            { name: '✅ موافق', value: String(up), inline: true },
            { name: '❌ رافض', value: String(down), inline: true },
            { name: 'النتيجة', value: voteBar(up, down), inline: false }
        )
        .setColor(BLUE)
        .setTimestamp();
    if (!anonymous && author) {
        e.setAuthor({ name: author.tag || author.username, iconURL: author.displayAvatarURL?.({ size: 64 }) });
        e.setFooter({ text: `ID: ${author.id}` });
    } else {
        e.setFooter({ text: 'اقتراح مجهول' });
    }
    if (attachmentUrl) e.setImage(attachmentUrl);
    return e;
}

function voteButtons(msgId) {
    return row(
        btn(`sug:up:${msgId}`, 'صح', '✅', ButtonStyle.Success),
        btn(`sug:down:${msgId}`, 'خطأ', '❌', ButtonStyle.Danger)
    );
}

// الشكل الجديد: اسم العضو فوق • النص • صورة صغيرة يمين • صورة كبيرة تحت • اسم السيرفر + الوقت تحت
function buildSuggestion(guild, author, content) {
    const s = cfg();
    const e = embed().setDescription(cut(content || '*بدون نص*', 4000)).setTimestamp();
    if (!s.anonymous && author) e.setAuthor({ name: author.username, iconURL: author.displayAvatarURL?.({ size: 64 }) });
    const icon = guild.iconURL?.({ size: 64 });
    e.setFooter({ text: guild.name, ...(icon ? { iconURL: icon } : {}) });
    if (H.isUrl(s.thumb)) e.setThumbnail(s.thumb);
    if (H.isUrl(s.banner)) e.setImage(s.banner);
    return e;
}

async function onMessage(msg) {
    const s = cfg();
    if (!s.enabled || !s.channelId || msg.channelId !== s.channelId) return false;
    if (msg.author.bot) return false;
    if (!msg.guild || msg.guild.id !== SERVER_ID) return false;

    const content = (msg.content || '').trim();
    if (!content) return false;

    try {
        const sent = await msg.channel.send({ embeds: [buildSuggestion(msg.guild, msg.author, content)] });
        await sent.react(s.upEmoji).catch(() => sent.react('✅').catch(() => {}));
        await sent.react(s.downEmoji).catch(() => sent.react('❌').catch(() => {}));
        await sent.startThread({ name: 'يمكنك المناقشة حول الاقتراح هنا', autoArchiveDuration: 10080 }).catch(e => console.error('[suggestions] thread:', e.message));
        if (s.deleteOriginal) await msg.delete().catch(() => {});
        return true;
    } catch (e) {
        console.error('[suggestions]', e.message);
        return false;
    }
}

async function component(i) {
    const parts = i.customId.split(':');
    if (parts[0] !== 'sug') return;
    const action = parts[1];
    const msgId = parts[2];

    if (action === 'up' || action === 'down') {
        const s = cfg();
        const v = s.votes[msgId];
        if (!v) return i.reply({ content: '❌ هذا الاقتراح لم يعد متاحاً.', flags: EPH });

        const uid = i.user.id;
        const upSet = new Set(v.up || []);
        const downSet = new Set(v.down || []);

        // toggle logic
        if (action === 'up') {
            if (upSet.has(uid)) {
                upSet.delete(uid); // remove vote
            } else {
                upSet.add(uid);
                downSet.delete(uid);
            }
        } else {
            if (downSet.has(uid)) {
                downSet.delete(uid);
            } else {
                downSet.add(uid);
                upSet.delete(uid);
            }
        }
        v.up = [...upSet];
        v.down = [...downSet];
        H.save();

        const author = v.authorId ? await i.client.users.fetch(v.authorId).catch(() => null) : null;
        const e = legacyEmbed(author, v.content, v.up.length, v.down.length, s.anonymous, v.image);
        try {
            await i.update({ embeds: [e], components: [voteButtons(msgId)] });
        } catch {
            try { await i.reply({ content: '✅ تم تسجيل صوتك.', flags: EPH }); } catch {}
        }
        return;
    }

    // settings
    if (!(await adminOnly(i))) return;
    const a = parts[1];
    const s = cfg();
    if (a === 'emo') {
        return i.showModal(H.modal('sugm:emo', 'إيموجي التصويت',
            H.input('up', 'إيموجي الموافق (اسم أو لصق، فاضي = ✅)', { value: s.upEmoji === '✅' ? '' : s.upEmoji, placeholder: 'مثال: yes', max: 100 }),
            H.input('down', 'إيموجي الرافض (اسم أو لصق، فاضي = ❌)', { value: s.downEmoji === '❌' ? '' : s.downEmoji, placeholder: 'مثال: no', max: 100 })));
    }
    if (a === 'img') {
        return i.showModal(H.modal('sugm:img', 'صور الاقتراحات',
            H.input('banner', 'رابط الصورة الكبيرة (تحت النص)', { value: s.banner, placeholder: 'https://...  (اتركه فاضي للحذف)', max: 500 }),
            H.input('thumb', 'رابط الصورة الصغيرة (يمين)', { value: s.thumb, placeholder: 'https://...  (اتركه فاضي للحذف)', max: 500 })));
    }
    if (a === 'toggle') {
        s.enabled = !s.enabled; H.save();
        return update(i, buildPanel());
    }
    if (a === 'setch') {
        s.channelId = i.values[0]; H.save();
        return update(i, buildPanel());
    }
    if (a === 'delorig') {
        s.deleteOriginal = !s.deleteOriginal; H.save();
        return update(i, buildPanel());
    }
    if (a === 'anon') {
        s.anonymous = !s.anonymous; H.save();
        return update(i, buildPanel());
    }
}

async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const s = cfg();
    if (i.customId === 'sugm:emo') {
        const up = H.tk.parseEmoji(i.guild, i.fields.getTextInputValue('up'));
        const down = H.tk.parseEmoji(i.guild, i.fields.getTextInputValue('down'));
        if (up.error || down.error) return i.reply({ content: '❌ ' + (up.error || down.error), flags: EPH });
        s.upEmoji = up.value || '✅'; s.downEmoji = down.value || '❌'; H.save();
        if (i.isFromMessage && i.isFromMessage()) return update(i, buildPanel());
        return i.reply({ content: '✅ تم حفظ الإيموجيات.', flags: EPH });
    }
    const banner = i.fields.getTextInputValue('banner').trim();
    const thumb = i.fields.getTextInputValue('thumb').trim();
    if ((banner && !H.isUrl(banner)) || (thumb && !H.isUrl(thumb))) return i.reply({ content: '❌ الرابط لازم يبدأ بـ https://', flags: EPH });
    s.banner = banner; s.thumb = thumb; H.save();
    if (i.isFromMessage && i.isFromMessage()) return update(i, buildPanel());
    return i.reply({ content: '✅ تم حفظ الصور.', flags: EPH });
}

function buildPanel() {
    const s = cfg();
    const e = embed()
        .setTitle('💡 نظام الاقتراحات')
        .setDescription('أي رسالة تُرسل في روم الاقتراحات تتحول تلقائياً إلى اقتراح مع تفاعلات الموافقة والرفض، مع فتح نقاش.\nيمكنك تخصيص الصور من زر **الصور**.')
        .addFields(
            { name: 'الحالة', value: onOff(s.enabled), inline: true },
            { name: 'الروم', value: chTxt(s.channelId), inline: true },
            { name: 'حذف رسالة العضو', value: s.deleteOriginal ? '✅' : '⛔', inline: true },
            { name: 'إخفاء الاسم', value: s.anonymous ? '✅ مجهول' : '⛔ يظهر الاسم', inline: true },
            { name: 'الصورة الكبيرة', value: H.isUrl(s.banner) ? '✅ محددة' : '`غير محددة`', inline: true },
            { name: 'الصورة الصغيرة', value: H.isUrl(s.thumb) ? '✅ محددة' : '`غير محددة`', inline: true },
            { name: 'إيموجي التصويت', value: s.upEmoji + '  ' + s.downEmoji, inline: true }
        );
    return {
        embeds: [e],
        components: [
            row(
                btn('sug:toggle', s.enabled ? 'إيقاف' : 'تشغيل', s.enabled ? '⛔' : '✅', s.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
                btn('sug:delorig', 'حذف الرسالة الأصلية', s.deleteOriginal ? '✅' : '⛔', ButtonStyle.Secondary),
                btn('sug:anon', 'إخفاء الاسم', s.anonymous ? '✅' : '⛔', ButtonStyle.Secondary),
                btn('sug:img', 'الصور', '🖼️', ButtonStyle.Primary),
                btn('sug:emo', 'الإيموجي', '😀', ButtonStyle.Primary)
            ),
            row(chSel('sug:setch', 'اختر روم الاقتراحات'))
        ]
    };
}

async function slash(i) {
    if (!(await adminOnly(i))) return;
    return i.reply({ ...buildPanel(), flags: EPH });
}

const commands = [{ name: 'suggestions', description: 'إعداد نظام الاقتراحات والتصويت' }];
return {
    prefix: 'sug',
    commands,
    ephemeral: ['suggestions'],
    slash: { suggestions: slash },
    component,
    modal: modalSubmit,
    onMessage
};
};
