'use strict';
/**
 * clockpanel.js — لوحة تسجيل الحضور (دخول / خروج) بشكل احترافي
 *
 *  • الأزرار (تسجيل دخول / تسجيل خروج) داخل البطاقة نفسها وليست تحتها
 *  • الكلام فوق العنوان + العنوان + الرسالة + الصورة (في النص) كلها تتغير من «🎨 تخصيص الشكل»
 *  • نفس منطق الدخول والخروج القديم (clock_in_btn / clock_out_btn) بدون أي تغيير في الحساب
 *
 * الأمر: /clockpanel (إدارة)  ← يفتح قائمة صغيرة: تخصيص الشكل • إرسال اللوحة هنا
 */
module.exports = (H) => {
const { D, EPH, row, btn, embed, cut, adminOnly, update } = H;
const { ButtonStyle } = D;

/** رسالة اللوحة الجاهزة للإرسال */
function panel() {
    return H.looks.card('clock', {
        rows: [row(
            btn('clock_in_btn', 'تسجيل دخول', '✅', ButtonStyle.Success),
            btn('clock_out_btn', 'تسجيل خروج', '❌', ButtonStyle.Danger)
        )],
        color: V2color()
    });
}
const V2color = () => H.V2.parseColor('#0F2A66');

function adminView() {
    const s = H.looks.get('clock');
    const e = embed().setTitle('📋 لوحة تسجيل الحضور')
        .setDescription('اللوحة تُرسل كبطاقة واحدة والأزرار داخلها. خصّص الشكل ثم أرسلها في الروم المطلوب.')
        .addFields(
            { name: 'الكلام فوق العنوان', value: s.header ? cut(s.header, 200) : '`—`', inline: false },
            { name: 'العنوان', value: cut(s.title, 200) || '`—`', inline: false },
            { name: 'الصورة', value: s.image ? '🖼️ محددة (تظهر في النص)' : '`بدون صورة`', inline: true }
        );
    return { embeds: [e], components: [row(
        btn('lk:edit:clock', 'تخصيص الشكل', '🎨', ButtonStyle.Primary),
        btn('ck:send', 'إرسال اللوحة هنا', '📤', ButtonStyle.Success),
        btn('ck:preview', 'معاينة', '👁️', ButtonStyle.Secondary)
    )] };
}
async function slash(i) { if (!(await adminOnly(i))) return; return i.reply({ ...adminView(), flags: EPH }); }
async function component(i) {
    if (!(await adminOnly(i))) return;
    const a = i.customId.split(':')[1];
    if (a === 'send') {
        await i.deferUpdate();
        try { await i.channel.send(panel()); await i.followUp({ content: '✅ تم إرسال اللوحة في هذا الروم.', flags: EPH }); }
        catch (e) { await i.followUp({ content: '❌ تعذّر الإرسال: ' + cut(e.message, 150), flags: EPH }); }
        return i.editReply(adminView());
    }
    if (a === 'preview') {
        const p = panel(); p.flags |= H.V2.EPHEMERAL;
        return i.reply(p);
    }
}

H.clockpanel = { panel, send: (channel) => channel.send(panel()) };
return { prefix: 'ck', commands: [{ name: 'clockpanel', description: 'لوحة تسجيل الدخول والخروج للإدارة: تخصيص وإرسال (إدارة)' }], ephemeral: ['clockpanel'], slash: { clockpanel: slash }, component };
};
