'use strict';
/**
 * v2.js — أدوات Components V2 (الحاويات) + تخزين الصور محلياً
 *
 * الحاوية تسمح بصورة فوق وصورة تحت ونصوص وفواصل وأزرار داخل بطاقة واحدة.
 * الصور تُنزَّل وتُحفظ محلياً داخل data/images لأن روابط ديسكورد المؤقتة تنتهي صلاحيتها.
 * قيمة الصورة المحفوظة في الإعدادات: رابط https عادي، أو  local:اسم_الملف
 */
const fs = require('fs');
const path = require('path');

const IS_V2 = 1 << 15; // MessageFlags.IsComponentsV2
const EPHEMERAL = 1 << 6;
const NAVY = 0x0F2A66;

const j = x => (x && typeof x.toJSON === 'function' ? x.toJSON() : x);

// ───── مكوّنات ─────
const text = content => ({ type: 10, content: String(content == null ? '' : content).slice(0, 4000) });
const sep = (divider = true, large = false) => ({ type: 14, divider, spacing: large ? 2 : 1 });
const gallery = urls => ({ type: 12, items: urls.filter(Boolean).slice(0, 10).map(u => ({ media: { url: u } })) });
const section = (texts, thumbUrl) => ({
    type: 9,
    components: texts.filter(Boolean).slice(0, 3).map(text),
    accessory: { type: 11, media: { url: thumbUrl } }
});
const container = (children, color) => ({ type: 17, accent_color: color == null ? NAVY : color, components: children.filter(Boolean).map(j) });
const parseColor = (c, fallback = NAVY) => {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(c || '').trim());
    return m ? parseInt(m[1], 16) : fallback;
};

// ───── الصور ─────
function makeImages(DATA_DIR) {
    const IMG_DIR = path.join(DATA_DIR, 'images');
    const EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp' };
    const isUrl = u => /^https?:\/\/\S+$/i.test(String(u || '').trim());

    /** ينزّل الصورة ويحفظها محلياً → يرجع  local:اسم  أو يرمي خطأ بسبب واضح */
    async function store(url, key) {
        if (!isUrl(url)) throw new Error('الرابط لازم يبدأ بـ https://');
        const ctl = new AbortController();
        const tm = setTimeout(() => ctl.abort(), 20000);
        let res;
        try { res = await fetch(url, { signal: ctl.signal }); }
        catch (e) { throw new Error('تعذّر تحميل الصورة من الرابط'); }
        finally { clearTimeout(tm); }
        if (!res.ok) throw new Error('الرابط رجّع خطأ ' + res.status + ' (ربما انتهت صلاحيته)');
        const ct = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
        const ext = EXT[ct];
        if (!ext) throw new Error('الرابط ليس صورة مدعومة (png / jpg / gif / webp)');
        const buf = Buffer.from(await res.arrayBuffer());
        if (buf.length > 8 * 1024 * 1024) throw new Error('الصورة أكبر من 8MB');
        fs.mkdirSync(IMG_DIR, { recursive: true });
        const name = String(key).replace(/[^a-z0-9_-]/gi, '').slice(0, 40) + '-' + Date.now().toString(36) + '.' + ext;
        fs.writeFileSync(path.join(IMG_DIR, name), buf);
        return 'local:' + name;
    }
    /** يحوّل قيمة الإعداد إلى { url, file? } جاهزة للاستخدام داخل رسالة */
    function resolve(val) {
        const v = String(val || '').trim();
        if (!v) return null;
        if (v.startsWith('local:')) {
            const name = path.basename(v.slice(6));
            const p = path.join(IMG_DIR, name);
            if (!fs.existsSync(p)) return null;
            return { url: 'attachment://' + name, file: { attachment: p, name } };
        }
        return isUrl(v) ? { url: v } : null;
    }
    /** ملفات الإرفاق المطلوبة لمجموعة قيم (بدون تكرار) */
    function filesOf(...vals) {
        const out = []; const seen = new Set();
        for (const v of vals) { const r = resolve(v); if (r && r.file && !seen.has(r.file.name)) { seen.add(r.file.name); out.push(r.file); } }
        return out;
    }
    function remove(val) {
        try { if (String(val || '').startsWith('local:')) fs.unlinkSync(path.join(IMG_DIR, path.basename(String(val).slice(6)))); } catch {}
    }
    return { store, resolve, filesOf, remove, isUrl };
}

module.exports = { IS_V2, EPHEMERAL, NAVY, text, sep, gallery, section, container, parseColor, makeImages, j };
