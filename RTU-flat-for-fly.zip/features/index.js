'use strict';
/**
 * وحدة الأنظمة المتقدمة — لكل نظام قائمة إعدادات تفاعلية خاصة به (زرقاء):
 * الترحيب • الخط • الإيمبد • الردود التلقائية • الرتب الذاتية • المستويات • الرومات المؤقتة • إدارة الأوامر
 */
module.exports = function initFeatures(ctx) {
    const D = ctx.discord;
    const { client, fs, path, DATA_DIR, BLUE, isAdmin, SERVER_ID, V2, IMG } = ctx;
    const {
        EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ChannelSelectMenuBuilder,
        RoleSelectMenuBuilder, UserSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags
    } = D;

    // ───── التخزين (data/features.json) ─────
    const DB_FILE = path.join(DATA_DIR, 'features.json');
    let db = {};
    try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch {}
    try {
        const cfg = ctx.getConfig() || {};
        if (!db.welcome && cfg.welcome) db.welcome = JSON.parse(JSON.stringify(cfg.welcome));
        if (!db.line && cfg.line) db.line = JSON.parse(JSON.stringify(cfg.line));
    } catch {}
    let saveTimer = null;
    function save() {
        clearTimeout(saveTimer);
        saveTimer = setTimeout(() => {
            try { fs.mkdirSync(path.dirname(DB_FILE), { recursive: true }); const t = DB_FILE + '.tmp'; fs.writeFileSync(t, JSON.stringify(db, null, 2)); fs.renameSync(t, DB_FILE); }
            catch (e) { console.error('[features] save:', e.message); }
        }, 150);
    }
    function saveNow() { clearTimeout(saveTimer); try { fs.mkdirSync(path.dirname(DB_FILE), { recursive: true }); fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); } catch {} }

    // ───── أدوات بناء الواجهة ─────
    const EPH = MessageFlags.Ephemeral;
    const cut = (s, n) => String(s == null ? '' : s).slice(0, n);
    const row = (...c) => new ActionRowBuilder().addComponents(...c);
    const btn = (id, label, emoji, style, disabled) => {
        const b = new ButtonBuilder().setCustomId(cut(id, 100)).setStyle(style || ButtonStyle.Secondary);
        if (label) b.setLabel(cut(label, 80));
        if (emoji) b.setEmoji(emoji);
        if (disabled) b.setDisabled(true);
        return b;
    };
    const strSel = (id, placeholder, options, o = {}) => {
        const m = new StringSelectMenuBuilder().setCustomId(cut(id, 100)).setPlaceholder(cut(placeholder, 150))
            .addOptions(options.slice(0, 25).map(x => ({ label: cut(x.label, 100) || '—', value: cut(x.value, 100), ...(x.emoji ? { emoji: x.emoji } : {}), ...(x.description ? { description: cut(x.description, 100) } : {}), ...(x.default ? { default: true } : {}) })));
        if (o.min != null) m.setMinValues(o.min);
        if (o.max != null) m.setMaxValues(Math.min(o.max, options.length || 1));
        if (o.disabled) m.setDisabled(true);
        return m;
    };
    const chSel = (id, placeholder, o = {}) => {
        const m = new ChannelSelectMenuBuilder().setCustomId(cut(id, 100)).setPlaceholder(cut(placeholder, 150))
            .setChannelTypes(...(o.types || [D.ChannelType.GuildText, D.ChannelType.GuildAnnouncement]))
            .setMinValues(o.min != null ? o.min : 1).setMaxValues(o.max || 1);
        if (o.selected && o.selected.length) { try { m.setDefaultChannels(o.selected.slice(0, o.max || 1)); } catch {} }
        if (o.disabled) m.setDisabled(true);
        return m;
    };
    const roleSel = (id, placeholder, o = {}) => {
        const m = new RoleSelectMenuBuilder().setCustomId(cut(id, 100)).setPlaceholder(cut(placeholder, 150))
            .setMinValues(o.min != null ? o.min : 1).setMaxValues(o.max || 1);
        if (o.selected && o.selected.length) { try { m.setDefaultRoles(o.selected.slice(0, o.max || 1)); } catch {} }
        if (o.disabled) m.setDisabled(true);
        return m;
    };
    const userSel = (id, placeholder) => new UserSelectMenuBuilder().setCustomId(cut(id, 100)).setPlaceholder(cut(placeholder, 150)).setMinValues(1).setMaxValues(1);
    const input = (id, label, o = {}) => {
        const t = new TextInputBuilder().setCustomId(id).setLabel(cut(label, 45))
            .setStyle(o.paragraph ? TextInputStyle.Paragraph : TextInputStyle.Short).setRequired(!!o.required);
        const max = o.max || (o.paragraph ? 1500 : 200);
        t.setMaxLength(max);
        if (o.placeholder) t.setPlaceholder(cut(o.placeholder, 100));
        if (o.value != null && String(o.value) !== '') t.setValue(cut(o.value, max));
        return new ActionRowBuilder().addComponents(t);
    };
    const modal = (id, title, ...rows) => new ModalBuilder().setCustomId(cut(id, 100)).setTitle(cut(title, 45)).addComponents(...rows);
    const embed = () => new EmbedBuilder().setColor(BLUE);
    const onOff = b => b ? '✅ يعمل' : '⛔ متوقف';
    const chTxt = id => id ? '<#' + id + '>' : '`غير محدد`';
    const roleTxt = id => id ? '<@&' + id + '>' : '`غير محدد`';
    const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
    const rid = () => Math.random().toString(36).slice(2, 8);
    const isUrl = u => /^https?:\/\/\S+$/i.test(String(u || '').trim());
    const sessions = new Map();
    const session = (i, key, init) => { const k = i.user.id + ':' + key; if (!sessions.has(k)) sessions.set(k, init()); return sessions.get(k); };
    async function adminOnly(i) {
        if (isAdmin(i.member)) return true;
        try { await i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: EPH }); } catch {}
        return false;
    }
    async function update(i, payload) {
        if (!i.deferred && !i.replied) await i.deferUpdate();
        return i.editReply(payload);
    }
    async function fetchBuffer(url, maxBytes) {
        const res = await fetch(url);
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const buf = Buffer.from(await res.arrayBuffer());
        if (maxBytes && buf.length > maxBytes) throw new Error('الملف أكبر من ' + Math.round(maxBytes / 1048576) + 'MB');
        return { buf, ct: res.headers.get('content-type') || '' };
    }
    async function getTextChannel(guild, id) {
        if (!id || !guild) return null;
        const ch = guild.channels.cache.get(id) || await guild.channels.fetch(id).catch(() => null);
        return ch && ch.isTextBased && ch.isTextBased() ? ch : null;
    }
    function fillVars(tpl, member, extra = {}) {
        const g = member.guild; const u = member.user || member;
        const map = {
            user: '<@' + u.id + '>', username: u.username, username2: u.username, server: g ? g.name : '',
            membercount: String(g ? g.memberCount : ''), count: String(g ? g.memberCount : ''), userid: u.id, ...extra
        };
        return String(tpl).replace(/[\{\[]\s*([a-z_0-9]+)\s*[\}\]]/gi, (m, k) => {
            const key = k.toLowerCase().replace(/_/g, '');
            return Object.prototype.hasOwnProperty.call(map, key) ? map[key] : m;
        });
    }

    const H = {
        D, client, fs, path, DATA_DIR, BLUE, SERVER_ID, V2, IMG, isAdmin, getAllStats: ctx.getAllStats, fmtVoice: ctx.fmtVoice, getConfig: ctx.getConfig, getCMDS: ctx.getCMDS, getStats: ctx.getStats, getClaims: ctx.getClaims,
        get db() { return db; }, tk: ctx.tk, save, saveNow, EPH, cut, row, btn, strSel, chSel, roleSel, userSel, input, modal, embed,
        onOff, chTxt, roleTxt, clamp, rid, isUrl, session, adminOnly, update, fetchBuffer, getTextChannel, fillVars
    };

    // ───── تحميل الأنظمة ─────
    const names = ['looks', 'emojis', 'rules', 'organize', 'levels', 'welcome', 'line', 'embed', 'autoreply', 'selfroles', 'tempvoice', 'cmdmanager', 'help', 'waitroom', 'suggestions', 'twitter', 'tickets', 'apply', 'applypanels', 'streams', 'avatar', 'athkar', 'radio', 'antispam', 'giveaway', 'feel', 'schedule', 'colors', 'promo', 'clockpanel', 'logs', 'music', 'ai', 'chatcmds', 'modcmds', 'limits', 'botprofile', 'hub', 'utils'];
    const mods = names.map(n => { try { return require('./' + n)(H); } catch (e) { console.error('[features] ❌ تعذّر تحميل ' + n + '.js: ' + e.message); return {}; } });
    const slashCommands = [], slashMap = {}, compMap = {}, modalMap = {}, ephemeralCommands = new Set();
    for (const m of mods) {
        for (const c of m.commands || []) slashCommands.push(c);
        for (const [k, f] of Object.entries(m.slash || {})) slashMap[k] = f;
        for (const k of m.ephemeral || []) ephemeralCommands.add(k);
        if (m.prefix) { compMap[m.prefix] = m; modalMap[m.prefix + 'm'] = m; }
        for (const [k, fn] of Object.entries(m.extra || {})) compMap[k] = { component: fn };
    }
    // ───── جسر اللوحة المركزية /setup: يفتح قائمة أي نظام من تفاعل زر/قائمة ─────
    const NOOP_OPTS = new Proxy({}, { get: () => () => null });
    H.helpCats = () => { const m = mods.find(x => x && x._cats); return m ? m._cats : []; };
    H.runSlash = async (i, name) => {
        const f = slashMap[name]; if (!f) return false;
        try { i.commandName = name; } catch {}
        if (!i.options) { try { i.options = NOOP_OPTS; } catch {} }
        await safe(i, () => f(i));
        return true;
    };
    /** أوامر قديمة داخل index.js: نعيد بثّها كأمر سلاش بدون خيارات */
    H.runLegacy = (i, name) => {
        const shim = new Proxy(i, {
            get(t, k) {
                if (k === 'commandName') return name;
                if (k === 'options') return NOOP_OPTS;
                if (typeof k === 'string' && /^is[A-Z]/.test(k)) return () => k === 'isChatInputCommand';
                const v = t[k]; return typeof v === 'function' ? v.bind(t) : v;
            },
            set(t, k, v) { t[k] = v; return true; }
        });
        client.emit('interactionCreate', shim);
    };
    async function safe(i, fn) {
        try { await fn(); }
        catch (e) {
            console.error('[features]', e && e.stack ? e.stack : e);
            const p = { content: '❌ حدث خطأ: ' + cut(e && e.message, 200), flags: EPH };
            try { if (i.deferred || i.replied) await i.followUp(p); else await i.reply(p); } catch {}
        }
    }
    async function handleSlash(i) {
        const f = slashMap[i.commandName];
        if (!f) return false;
        await safe(i, () => f(i));
        return true;
    }
    async function handleComponent(i) {
        const id = i.customId;
        if (typeof id !== 'string') return false;
        const tag = id.split(':')[0];
        if (i.isModalSubmit && i.isModalSubmit()) {
            const m = modalMap[tag];
            if (!m || !m.modal) return false;
            await safe(i, () => m.modal(i));
            return true;
        }
        const m = compMap[tag];
        if (!m || !m.component) return false;
        await safe(i, () => m.component(i));
        return true;
    }
    /** يُستدعى لكل رسالة (حتى من البوتات والويب هوك) — مخصص لمنع السبام */
    async function onRawMessage(msg) {
        for (const m of mods) {
            if (!m.onRawMessage) continue;
            try { if (await m.onRawMessage(msg)) return true; } catch (e) { console.error('[features:raw]', e.message); }
        }
        return false;
    }
    async function onMessage(msg) {
        for (const m of mods) {
            if (!m.onMessage) continue;
            try { if (await m.onMessage(msg)) return true; } catch (e) { console.error('[features:msg]', e.message); }
        }
        return false;
    }
    const each = (hook) => async (...a) => { for (const m of mods) if (m[hook]) { try { await m[hook](...a); } catch (e) { console.error('[features:' + hook + ']', e.message); } } };
    let readied = false;
    const onReady = async () => { if (readied) return; readied = true; await each('onReady')(); };
    try { client.once('clientReady', onReady); client.once('ready', onReady); } catch {}
    try { client.on('voiceStateUpdate', each('onVoiceState')); } catch {}
    function isCommandDisabled(name) { const cm = mods.find(m => m.isCommandDisabled); return cm ? cm.isCommandDisabled(name) : false; }

    return {
        slashCommands, ephemeralCommands, handleSlash, handleComponent, onMessage, onRawMessage, isCommandDisabled,
        onMemberAdd: each('onMemberAdd'), onMemberRemove: each('onMemberRemove'), onReady, H, mods
    };
};
