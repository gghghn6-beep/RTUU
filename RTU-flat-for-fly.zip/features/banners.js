'use strict';
/**
 * banners.js — مولّد البانرات الاحترافية (أزرق غامق) بنفس أسلوب صور اللوحات
 * يرسم صورة 1200×400: خلفية كحلية متدرجة + أشعة ضوء + شبكة خفيفة + شعار دائري متوهج + عنوان عربي كبير.
 * النتيجة تُخزَّن مؤقتاً في الذاكرة، ولو canvas غير مثبتة يرجع null (واللوحة تشتغل بدون صورة).
 */
const path = require('path');
const fs = require('fs');

let Canvas = null;
try { Canvas = require('@napi-rs/canvas'); } catch { Canvas = null; }
let FAMILY = 'ArabicBanner, Arial, sans-serif';
if (Canvas && Canvas.GlobalFonts) {
    try { Canvas.GlobalFonts.registerFromPath(path.join(__dirname, '..', 'assets', 'fonts', 'ArabicBold.ttf'), 'ArabicBanner'); }
    catch (e) { console.warn('[banners] font:', e.message); }
}

const W = 1200, H = 400;
const cache = new Map();

/** يرجع { attachment: Buffer, name } أو null */
function banner(title, subtitle = '', brand = '') {
    if (!Canvas || !title) return null;
    const key = title + '|' + subtitle + '|' + brand;
    if (cache.has(key)) return cache.get(key);
    try {
        const cv = Canvas.createCanvas(W, H); const g = cv.getContext('2d');
        // خلفية
        const bg = g.createLinearGradient(0, 0, W, H);
        bg.addColorStop(0, '#030A1A'); bg.addColorStop(0.5, '#0B1F4B'); bg.addColorStop(1, '#040D24');
        g.fillStyle = bg; g.fillRect(0, 0, W, H);
        // شبكة خفيفة
        g.strokeStyle = 'rgba(96,165,250,0.07)'; g.lineWidth = 1;
        for (let x = 0; x <= W; x += 40) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, H); g.stroke(); }
        for (let y = 0; y <= H; y += 40) { g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
        // أشعة عمودية
        for (const [x, w, a] of [[170, 70, 0.10], [430, 40, 0.07], [770, 40, 0.07], [1030, 70, 0.10]]) {
            const l = g.createLinearGradient(0, 0, 0, H);
            l.addColorStop(0, 'rgba(59,130,246,0)'); l.addColorStop(0.5, `rgba(59,130,246,${a})`); l.addColorStop(1, 'rgba(59,130,246,0)');
            g.fillStyle = l; g.fillRect(x, 0, w, H);
        }
        // توهج مركزي
        const rg = g.createRadialGradient(W / 2, H / 2 + 20, 20, W / 2, H / 2 + 20, 520);
        rg.addColorStop(0, 'rgba(37,99,235,0.35)'); rg.addColorStop(1, 'rgba(37,99,235,0)');
        g.fillStyle = rg; g.fillRect(0, 0, W, H);
        // شعار دائري
        const cx = W / 2, cy = 62;
        g.save(); g.shadowColor = '#3B82F6'; g.shadowBlur = 22;
        g.strokeStyle = '#60A5FA'; g.lineWidth = 3;
        g.beginPath(); g.arc(cx, cy, 30, 0, Math.PI * 2); g.stroke();
        g.lineWidth = 2; g.beginPath(); g.moveTo(cx, cy - 18); g.lineTo(cx + 18, cy); g.lineTo(cx, cy + 18); g.lineTo(cx - 18, cy); g.closePath(); g.stroke();
        g.restore();
        // العنوان
        g.textAlign = 'center'; g.textBaseline = 'middle'; g.direction = 'rtl';
        let size = 96; g.font = `bold ${size}px ${FAMILY}`;
        while (g.measureText(title).width > W - 160 && size > 40) { size -= 4; g.font = `bold ${size}px ${FAMILY}`; }
        g.save(); g.shadowColor = 'rgba(59,130,246,0.9)'; g.shadowBlur = 28;
        g.fillStyle = '#FFFFFF'; g.fillText(title, W / 2, H / 2 + 20);
        g.restore();
        // خط متوهج تحت العنوان
        const ul = g.createLinearGradient(W / 2 - 260, 0, W / 2 + 260, 0);
        ul.addColorStop(0, 'rgba(96,165,250,0)'); ul.addColorStop(0.5, 'rgba(147,197,253,1)'); ul.addColorStop(1, 'rgba(96,165,250,0)');
        g.fillStyle = ul; g.fillRect(W / 2 - 260, H / 2 + 20 + size * 0.62, 520, 3);
        // نص فرعي
        if (subtitle) { g.fillStyle = 'rgba(191,219,254,0.9)'; g.font = `bold 28px ${FAMILY}`; g.fillText(subtitle, W / 2, H - 56); }
        // علامة مائية
        if (brand) { g.fillStyle = 'rgba(147,197,253,0.10)'; g.font = `bold 20px ${FAMILY}`; g.textAlign = 'left'; g.direction = 'ltr'; for (let y = H - 40; y > H - 120; y -= 26) for (let x = 20; x < W; x += 190) g.fillText(brand, x, y); }
        // إطار
        g.strokeStyle = 'rgba(96,165,250,0.35)'; g.lineWidth = 2; g.strokeRect(1, 1, W - 2, H - 2);
        const name = 'banner-' + Buffer.from(key).toString('hex').slice(0, 24) + '.png';
        const out = { attachment: cv.toBuffer('image/png'), name };
        cache.set(key, out);
        return out;
    } catch (e) { console.warn('[banners]', e.message); return null; }
}
module.exports = { banner };
