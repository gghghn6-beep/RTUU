'use strict';
/**
 * نظام الراديو /radio
 * لوحة بقائمة موجات (مواطنين / عصابات / شرطة / ...) — العضو يختار الموجة (بشرط الرتبة) ثم يكتب رقم الراديو
 * (حتى 4 أرقام مثل 11.5 أو 1500) فيُفتح له روم صوتي خاص بهذا التردد وينتقل إليه.
 */
module.exports = (H) => {
const { D, client, BLUE, SERVER_ID, save, EPH, row, btn, chSel, roleSel, strSel, input, modal, embed, cut, rid, isUrl, isAdmin, adminOnly, update, chTxt, roleTxt, getTextChannel } = H;
const { ButtonStyle, ChannelType, PermissionFlagsBits: P } = D;
const BLUE_NUM = 0x0F2A66;

const DEFAULT_WAVES = [
    { name: 'مواطنين', emoji: '🏙️' }, { name: 'شرطة', emoji: '🚓' }, { name: 'صحة', emoji: '🏥' },
    { name: 'عدل', emoji: '⚖️' }, { name: 'مجرمين', emoji: '🦹' }, { name: 'عصابات', emoji: '🔫' }
];
const cfg = () => {
    const r = (H.db.radio = H.db.radio || {});
    if (!Array.isArray(r.waves)) r.waves = [];
    // إضافة الموجات الافتراضية الناقصة مرة واحدة فقط (لا نعيد ما حذفته الإدارة)
    if (!r.seedV2) {
        for (const d of DEFAULT_WAVES) if (!r.waves.some(w => w.name === d.name)) r.waves.push({ id: 'w_' + rid(), name: d.name, emoji: d.emoji, roleIds: [] });
        r.seedV2 = true;
    }
    // ترحيل الرتبة الواحدة القديمة إلى قائمة رتب
    for (const w of r.waves) { if (!Array.isArray(w.roleIds)) w.roleIds = w.roleId ? [w.roleId] : []; delete w.roleId; }
    if (!Array.isArray(r.defaultRoleIds)) r.defaultRoleIds = r.defaultRoleId ? [r.defaultRoleId] : [];
    delete r.defaultRoleId;
    r.categoryId = r.categoryId || '';
    r.panelChannelId = r.panelChannelId || '';
    r.panelMessageId = r.panelMessageId || '';
    r.title = r.title || '📻 نظام الراديو';
    r.description = r.description || 'اختر الموجة من القائمة بالأسفل، ثم اكتب رقم الراديو (حتى 4 أرقام مثل `11.5` أو `1500`) لتدخل الموجة.';
    r.image = r.image || '';
    r.color = r.color || '';
    r.active = r.active || {};
    r.userKey = r.userKey || {};
    return r;
};
const rolesTxt = ids => ids && ids.length ? ids.map(id => '<@&' + id + '>').join(' ') : '';
const needRoles = w => (w && w.roleIds && w.roleIds.length) ? w.roleIds : cfg().defaultRoleIds;
const colorNum = c => /^#?[0-9a-f]{6}$/i.test(c || '') ? parseInt(String(c).replace('#', ''), 16) : BLUE_NUM;
const keep = e => { try { D.EmbedBuilder.keepColor && D.EmbedBuilder.keepColor.add(e); } catch {} return e; };
const waveLabel = w => 'دخول موجة ' + w.name;

/** يتحقق من رقم الراديو: أرقام فقط، حتى 4 أرقام (يسمح بنقطة عشرية مثل 11.5) */
function normFreq(raw) {
    let t = String(raw || '').trim()
        .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
        .replace(/[٫,،]/g, '.').replace(/\s+/g, '');
    if (!/^\d+(\.\d+)?$/.test(t)) return { error: 'اكتب أرقاماً فقط، مثل `11.5` أو `1500`.' };
    if (t.includes('.')) t = t.replace(/0+$/, '').replace(/\.$/, '');
    if (t.replace('.', '').length > 4) return { error: 'رقم الراديو حده الأقصى **4 أرقام** فقط.' };
    if (!t.replace('.', '').length) return { error: 'اكتب رقم الراديو.' };
    return { freq: t };
}
function canUse(member, w) {
    if (isAdmin(member)) return true;
    const need = needRoles(w);
    return !need.length || need.some(id => member.roles.cache.has(id));
}

// ───── اللوحة العامة (يراها الأعضاء) ─────
function buildPublic() {
    const r = cfg();
    const e = keep(new D.EmbedBuilder().setColor(colorNum(r.color)).setTitle(cut(r.title, 256)).setDescription(cut(r.description, 4000)).setFooter({ text: 'نظام الراديو' }));
    if (r.image) e.setImage(r.image);
    if (r.waves.length) e.addFields({ name: '📡 الموجات المتاحة', value: cut(r.waves.map(w => '> ' + (w.emoji || '📻') + '  **' + w.name + '**').join('\n'), 1024) });
    const menu = r.waves.length
        ? strSel('rad:pick', 'اختر الموجة...', r.waves.map(w => ({ label: waveLabel(w), value: w.id, emoji: w.emoji || undefined })))
        : strSel('rad:pick', 'لا توجد موجات بعد', [{ label: 'لا توجد موجات', value: 'none' }], { disabled: true });
    return { embeds: [e], components: [row(menu)] };
}
async function refreshPublished(guild) {
    const r = cfg();
    if (!r.panelChannelId || !r.panelMessageId) return;
    try {
        const ch = await getTextChannel(guild, r.panelChannelId);
        const m = ch && await ch.messages.fetch(r.panelMessageId).catch(() => null);
        if (m) await m.edit(buildPublic());
    } catch {}
}

// ───── لوحة الإدارة ─────
function buildPanel() {
    const r = cfg();
    const e = embed().setTitle('📻 إعدادات الراديو')
        .setDescription('اضبط الموجات والرتب والمظهر ثم انشر اللوحة في الروم.')
        .addFields(
            { name: '📤 روم اللوحة', value: chTxt(r.panelChannelId), inline: true },
            { name: '📁 كاتيجوري الغرف', value: r.categoryId ? '<#' + r.categoryId + '>' : '`نفس كاتيجوري اللوحة`', inline: true },
            { name: '🎖️ الرتب الافتراضية', value: r.defaultRoleIds.length ? rolesTxt(r.defaultRoleIds) : '`بدون (الكل)`', inline: true },
            { name: '📻 الموجات (' + r.waves.length + ')', value: r.waves.length ? r.waves.map(w => (w.emoji || '📻') + ' **' + w.name + '** — ' + (w.roleIds.length ? rolesTxt(w.roleIds) : '`الرتب الافتراضية`')).join('\n') : 'لا توجد موجات — اضغط ➕' },
            { name: '🎨 المظهر', value: 'اللون: `' + (r.color || 'أزرق') + '` • الصورة: ' + (r.image ? '✅' : '—'), inline: false }
        );
    const rows = [
        row(
            btn('rad:pub', r.panelMessageId ? 'تحديث اللوحة' : 'نشر اللوحة', '📤', ButtonStyle.Success),
            btn('rad:addw', 'موجة جديدة', '➕', ButtonStyle.Primary, r.waves.length >= 25),
            btn('rad:look', 'المظهر', '🎨', ButtonStyle.Secondary)
        ),
        row(chSel('rad:pubch', 'روم نشر اللوحة', { selected: r.panelChannelId ? [r.panelChannelId] : [] })),
        row(chSel('rad:cat', 'كاتيجوري غرف الراديو (اختياري)', { types: [ChannelType.GuildCategory], min: 0, selected: r.categoryId ? [r.categoryId] : [] })),
        row(roleSel('rad:role', 'الرتب الافتراضية لاستخدام الراديو (حتى 10)', { min: 0, max: 10, selected: r.defaultRoleIds }))
    ];
    if (r.waves.length) rows.push(row(strSel('rad:wave', 'تعديل موجة...', r.waves.map(w => ({ label: waveLabel(w), value: w.id, emoji: w.emoji || undefined })))));
    return { embeds: [e], components: rows };
}
function buildWaveEditor(id) {
    const r = cfg(); const w = r.waves.find(x => x.id === id);
    if (!w) return buildPanel();
    const e = embed().setTitle((w.emoji || '📻') + ' ' + waveLabel(w))
        .setDescription('**الرتب المسموح لها بدخول هذه الموجة:**\n' + (w.roleIds.length ? rolesTxt(w.roleIds) : '`الرتب الافتراضية` ' + (r.defaultRoleIds.length ? rolesTxt(r.defaultRoleIds) : '(بدون — الكل)')) + '\n\nاختر **رتبة أو أكثر** (حتى 10) لهذه الموجة فقط، أو امسح الاختيار لاستخدام الرتب الافتراضية.');
    return { embeds: [e], components: [
        row(roleSel('rad:wrole:' + id, 'رتب هذه الموجة (حتى 10)', { min: 0, max: 10, selected: w.roleIds })),
        row(btn('rad:wren:' + id, 'تعديل الاسم', '✏️', ButtonStyle.Primary), btn('rad:wdel:' + id, 'حذف الموجة', '🗑️', ButtonStyle.Danger), btn('rad:back', 'رجوع', '↩️', ButtonStyle.Secondary))
    ] };
}

// ───── الدخول للموجة ─────
async function joinModal(i, waveId) {
    await i.deferReply({ flags: EPH });
    const r = cfg(); const w = r.waves.find(x => x.id === waveId);
    if (!w) return i.editReply({ content: '❌ هذه الموجة لم تعد موجودة.' });
    if (!canUse(i.member, w)) return i.editReply({ content: '❌ لدخول هذه الموجة تحتاج إحدى الرتب: ' + rolesTxt(needRoles(w)) });
    const f = normFreq(i.fields.getTextInputValue('freq'));
    if (f.error) return i.editReply({ content: '❌ ' + f.error });
    const guild = i.guild; const key = w.id + ':' + f.freq; const uid = i.user.id;
    const allowUser = { ViewChannel: true, Connect: true, Speak: true };
    try {
        let ch = null; const act = r.active[key];
        if (act) ch = guild.channels.cache.get(act.channelId) || await guild.channels.fetch(act.channelId).catch(() => null);
        if (ch) {
            await ch.permissionOverwrites.edit(uid, allowUser);
        } else {
            const roles = (H.getConfig() || {}).roles || {};
            const adminIds = [roles.admin, ...(roles.admins || [])].filter(Boolean);
            let parent = r.categoryId && guild.channels.cache.has(r.categoryId) ? r.categoryId : null;
            if (!parent && r.panelChannelId) parent = guild.channels.cache.get(r.panelChannelId)?.parentId || null;
            ch = await guild.channels.create({
                name: cut('📻 ' + w.name + ' • ' + f.freq, 100), type: ChannelType.GuildVoice, parent,
                reason: 'غرفة راديو',
                permissionOverwrites: [
                    { id: guild.id, deny: [P.ViewChannel, P.Connect] },
                    { id: client.user.id, allow: [P.ViewChannel, P.Connect, P.Speak, P.ManageChannels, P.MoveMembers] },
                    ...adminIds.map(id => ({ id, allow: [P.ViewChannel, P.Connect, P.Speak] })),
                    { id: uid, allow: [P.ViewChannel, P.Connect, P.Speak] }
                ]
            });
            r.active[key] = { channelId: ch.id, createdAt: Date.now(), waveId: w.id, freq: f.freq };
        }
        let moved = false;
        if (i.member.voice && i.member.voice.channelId) { try { await i.member.voice.setChannel(ch); moved = true; } catch {} }
        // إزالة وصول العضو من غرفته السابقة
        const prevKey = r.userKey[uid];
        if (prevKey && prevKey !== key && r.active[prevKey]) {
            const pc = guild.channels.cache.get(r.active[prevKey].channelId);
            if (pc) pc.permissionOverwrites.delete(uid).catch(() => {});
        }
        r.userKey[uid] = key; save();
        const e = embed().setAuthor({ name: 'نظام الراديو' }).setTitle((w.emoji || '📻') + ' ' + waveLabel(w))
            .addFields(
                { name: '📡 الموجة', value: '**' + w.name + '**', inline: true },
                { name: '🔢 التردد', value: '**' + f.freq + '**', inline: true },
                { name: '🔊 الغرفة', value: '<#' + ch.id + '>', inline: true }
            )
            .setDescription(moved ? '✅ **تم نقلك إلى غرفة الراديو.**' : '🔊 **ادخل غرفة الراديو من الزر أدناه.**\nأدخل أي روم صوتي قبل اختيار الموجة ليتم نقلك تلقائياً.')
            .setFooter({ text: 'الغرفة تُحذف تلقائياً عند خلوها' });
        return i.editReply({ embeds: [e] });
    } catch (err) {
        console.error('[radio] join:', err.message);
        return i.editReply({ content: '❌ تعذر فتح الغرفة. تأكد أن البوت يملك صلاحيات Manage Channels و Move Members. (' + cut(err.message, 120) + ')' });
    }
}

// ───── التنظيف (حذف الغرف الفارغة) ─────
async function dropIfEmpty(guild, key) {
    const r = cfg(); const a = r.active[key]; if (!a) return;
    const ch = guild.channels.cache.get(a.channelId);
    if (!ch) { delete r.active[key]; save(); return; }
    if (ch.members.size === 0) { await ch.delete('راديو فارغ').catch(() => {}); delete r.active[key]; save(); }
}
async function onVoiceState(oldS, newS) {
    if (!oldS.channelId || oldS.channelId === newS.channelId) return;
    const r = cfg();
    const key = Object.keys(r.active).find(k => r.active[k].channelId === oldS.channelId);
    if (!key) return;
    setTimeout(() => dropIfEmpty(oldS.guild, key).catch(() => {}), 15000);
}
let timer = null;
function onReady() {
    if (timer) return;
    console.log('[radio] ✅ نظام الراديو جاهز — استخدم /radio');
    timer = setInterval(async () => {
        try {
            const guild = client.guilds.cache.get(SERVER_ID) || client.guilds.cache.first(); if (!guild) return;
            const r = cfg();
            for (const [key, a] of Object.entries(r.active)) if (Date.now() - a.createdAt > 120000) await dropIfEmpty(guild, key);
        } catch (e) { console.error('[radio] sweep:', e.message); }
    }, 60000);
    if (timer.unref) timer.unref();
}

// ───── التفاعلات ─────
async function component(i) {
    const parts = i.customId.split(':'); const a = parts[1];
    if (a === 'pick') {
        const r = cfg(); const w = r.waves.find(x => x.id === i.values[0]);
        if (!w) return i.reply({ content: '❌ هذه الموجة لم تعد موجودة.', flags: EPH });
        if (!canUse(i.member, w)) return i.reply({ content: '❌ لدخول **' + waveLabel(w) + '** تحتاج إحدى الرتب: ' + rolesTxt(needRoles(w)), flags: EPH });
        await i.showModal(modal('radm:join:' + w.id, cut(waveLabel(w), 45), input('freq', 'رقم الراديو (حتى 4 أرقام)', { required: true, max: 8, placeholder: 'مثال: 11.5 أو 1500' })));
        i.message.edit(buildPublic()).catch(() => {}); // يعيد القائمة لوضعها الطبيعي ليختار نفس الموجة مرة ثانية
        return;
    }
    if (!(await adminOnly(i))) return;
    const r = cfg();
    if (a === 'pub') {
        const ch = await getTextChannel(i.guild, r.panelChannelId);
        if (!ch) return i.reply({ content: '⚠️ اختر روم نشر اللوحة أولاً.', flags: EPH });
        let m = null;
        if (r.panelMessageId) m = await ch.messages.fetch(r.panelMessageId).catch(() => null);
        if (m) await m.edit(buildPublic()); else { m = await ch.send(buildPublic()); r.panelMessageId = m.id; save(); }
        await i.reply({ content: '✅ تم نشر لوحة الراديو في <#' + ch.id + '>', flags: EPH });
        return;
    }
    if (a === 'addw') return i.showModal(modal('radm:add', 'موجة جديدة', input('name', 'اسم الموجة (مثل: مواطنين)', { required: true, max: 40 }), input('emoji', 'إيموجي (اختياري)', { max: 60 })));
    if (a === 'look') return i.showModal(modal('radm:look', 'مظهر لوحة الراديو',
        input('title', 'العنوان', { value: r.title, max: 100, required: true }),
        input('desc', 'الوصف', { value: r.description, paragraph: true, max: 1000, required: true }),
        input('image', 'رابط الصورة (فارغ = بدون)', { value: r.image, max: 500 }),
        input('color', 'اللون HEX مثل #0F2A66 (فارغ = أزرق)', { value: r.color, max: 7 })));
    if (a === 'wren') { const w = r.waves.find(x => x.id === parts[2]); if (!w) return update(i, buildPanel());
        return i.showModal(modal('radm:ren:' + w.id, 'تعديل الموجة', input('name', 'اسم الموجة', { required: true, max: 40, value: w.name }), input('emoji', 'إيموجي (اختياري)', { max: 60, value: w.emoji }))); }
    if (a === 'pubch') { r.panelChannelId = i.values[0]; r.panelMessageId = ''; save(); return update(i, buildPanel()); }
    if (a === 'cat') { r.categoryId = i.values[0] || ''; save(); return update(i, buildPanel()); }
    if (a === 'role') { r.defaultRoleIds = [...i.values]; save(); await update(i, buildPanel()); return refreshPublished(i.guild); }
    if (a === 'wave') return update(i, buildWaveEditor(i.values[0]));
    if (a === 'wrole') { const w = r.waves.find(x => x.id === parts[2]); if (w) { w.roleIds = [...i.values]; save(); } return update(i, buildWaveEditor(parts[2])); }
    if (a === 'wdel') { r.waves = r.waves.filter(x => x.id !== parts[2]); save(); await update(i, buildPanel()); return refreshPublished(i.guild); }
    if (a === 'back') return update(i, buildPanel());
}
async function modalSubmit(i) {
    const parts = i.customId.split(':'); const a = parts[1];
    if (a === 'join') return joinModal(i, parts[2]);
    if (!(await adminOnly(i))) return;
    const r = cfg();
    const getV = k => { try { return i.fields.getTextInputValue(k).trim(); } catch { return ''; } };
    if (a === 'add') {
        const name = getV('name'); if (!name) return i.reply({ content: '❌ اكتب اسم الموجة.', flags: EPH });
        r.waves.push({ id: 'w_' + rid(), name: cut(name, 40), emoji: getV('emoji'), roleIds: [] }); save();
    } else if (a === 'ren') {
        const w = r.waves.find(x => x.id === parts[2]);
        if (w) { w.name = cut(getV('name') || w.name, 40); w.emoji = getV('emoji'); save(); }
    } else if (a === 'look') {
        const color = getV('color'), image = getV('image');
        if (color && !/^#?[0-9a-f]{6}$/i.test(color)) return i.reply({ content: '❌ اللون لازم يكون HEX مثل `#0F2A66`.', flags: EPH });
        if (image && !isUrl(image)) return i.reply({ content: '❌ رابط الصورة غير صحيح (لازم يبدأ بـ https).', flags: EPH });
        r.title = getV('title') || r.title; r.description = getV('desc') || r.description;
        r.image = image; r.color = color ? '#' + color.replace('#', '').toUpperCase() : ''; save();
    }
    await update(i, buildPanel());
    return refreshPublished(i.guild);
}

async function slash(i) {
    if (!(await adminOnly(i))) return;
    return i.reply({ ...buildPanel(), flags: EPH });
}

return {
    prefix: 'rad',
    commands: [{ name: 'radio', description: 'نظام الراديو: موجات برقم تردد (حتى 4 أرقام) بصلاحية رتبة' }],
    ephemeral: ['radio'],
    slash: { radio: slash },
    component, modal: modalSubmit, onVoiceState, onReady
};
};
