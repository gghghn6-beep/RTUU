'use strict';
/**
 * looks.js — «الشكل الموحّد» لكل لوحات البوت
 *
 * لكل نظام (دخول/خروج، ألوان، ترقيات، عقوبات...) تقدر من الإدارة تغيّر:
 *   • الكلام فوق العنوان • العنوان • الرسالة (الوصف) • الصورة (تظهر في النص بين العنوان والرسالة)
 *
 * كل اللوحات تُبنى بنفس الشكل الأم (بطاقة Components V2 بحاوية واحدة):
 *   [كلام فوق العنوان]  →  العنوان  →  الصورة  →  الرسالة  →  التفاصيل  →  الأزرار (داخل البطاقة)  →  الفوتر
 *
 * الأمر: /looks  (إدارة)  — أو زر «🎨 تخصيص الشكل» داخل لوحة كل نظام.
 * الاستخدام من الأنظمة الأخرى:  H.looks.card('clock', { lines, rows, ephemeral })
 */
module.exports = (H) => {
const { D, EPH, row, btn, strSel, input, modal, cut, adminOnly, save, V2, IMG, client, SERVER_ID } = H;
const db = H.db;

// ───── الأنظمة المدعومة وقيمها الافتراضية ─────
const KEYS = {
    clock: {
        label: 'لوحة تسجيل الدخول والخروج', emoji: '🕐', system: 'نظام الحضور',
        def: { header: '', title: '📋 لوحة تسجيل الحضور والإداريين', desc: 'قم بالضغط على الأزرار أدناه لتسجيل **دخولك** أو **خروجك** من فترة العمل الإداري.' },
        sample: () => ({})
    },
    colors: {
        label: 'قائمة الألوان', emoji: '🎨', system: 'نظام الألوان',
        def: { header: '', title: '🎨 قائمة الألوان', desc: 'اختر لونك من القائمة بالأسفل، أو اكتب `color! رقم` (مثال: `color! 3`)، و`color! 0` لإزالة لونك.' },
        sample: () => ({})
    },
    promo_request: {
        label: 'لوحة طلب الترقية', emoji: '📨', system: 'نظام الترقيات',
        def: { header: '', title: '📨 طلب ترقية', desc: 'وصلت العدد المطلوب من الاستلامات؟ اضغط الزر بالأسفل لطلب ترقيتك.' },
        sample: () => ({})
    },
    promo_announce: {
        label: 'رسالة «تم ترقيتك»', emoji: '🏆', system: 'نظام الترقيات',
        def: { header: '', title: '🏆 ترقية جديدة', desc: '' },
        sample: () => ({ lines: ['**الإداري:** <@' + client.user.id + '>', '**عدد الاستلامات:** 20', '**الترقية:** `اسم الرتبة`', '**حالة الترقية:** ✅ تمت الترقية بنجاح'] })
    },
    promo_ladder: {
        label: 'سلم الترقيات', emoji: '👑', system: 'نظام الترقيات',
        def: { header: '', title: '🏆 سلم ترقيات الإدارة', desc: '' },
        sample: () => ({ lines: ['• **20** استلام — ⬆️ `رتبة 1`', '• **40** استلام — ⬆️ `رتبة 2`'] })
    },
    punish: {
        label: 'العقوبات (تحذير/ميوت/باند...)', emoji: '⚠️', system: 'نظام الإدارة',
        def: { header: '', title: '', desc: '' },
        sample: () => ({}), imageOnly: true
    }
};

const store = () => (db.looks = db.looks || {});
const own = key => (store()[key] = store()[key] || {});

/** القيم الحالية: ما ضبطته الإدارة، وإلا الافتراضي */
function get(key) {
    const k = KEYS[key]; if (!k) return { header: '', title: '', desc: '', image: '' };
    const s = own(key);
    return {
        header: s.header != null ? s.header : k.def.header,
        title: s.title != null ? s.title : k.def.title,
        desc: s.desc != null ? s.desc : k.def.desc,
        image: s.image || ''
    };
}

/**
 * يبني بطاقة بالشكل الأم.
 * o.lines   : أسطر التفاصيل (نص)
 * o.rows    : صفوف أزرار/قوائم تُوضع داخل البطاقة
 * o.color   : لون الشريط الجانبي
 * o.ephemeral : رسالة خاصة
 * o.gallery : روابط صور إضافية تُعرض بعد الرسالة (مثلاً صورة الألوان)
 * o.files   : ملفات مرفقة إضافية للصور أعلاه
 * o.footer  : نص الفوتر (افتراضي: اسم السيرفر • اسم النظام)
 * o.override: { header, title, desc } لاستبدال مؤقت
 */
function card(key, o = {}) {
    const k = KEYS[key] || { system: '' }; const s = { ...get(key), ...(o.override || {}) };
    const img = IMG.resolve(s.image);
    const kids = [];
    if (s.header) kids.push(V2.text(s.header));
    if (s.title) kids.push(V2.text('# ' + s.title));
    if (img) { kids.push(V2.sep()); kids.push(V2.gallery([img.url])); }
    if (s.desc || (o.lines && o.lines.length)) kids.push(V2.sep());
    if (s.desc) kids.push(V2.text(s.desc));
    if (o.gallery && o.gallery.length) { kids.push(V2.sep(false)); kids.push(V2.gallery(o.gallery)); }
    if (o.lines && o.lines.length) kids.push(V2.text(o.lines.join('\n')));
    if (o.rows && o.rows.length) { kids.push(V2.sep(false)); for (const r of o.rows) kids.push(r); }
    const gname = (client.guilds.cache.get(SERVER_ID) || {}).name || '';
    const foot = o.footer != null ? o.footer : [gname, k.system].filter(Boolean).join(' • ');
    if (foot) kids.push(V2.text('-# ' + foot + ' | <t:' + Math.floor(Date.now() / 1000) + ':f>'));
    return {
        components: [V2.container(kids, o.color != null ? o.color : V2.NAVY)],
        flags: V2.IS_V2 | (o.ephemeral ? V2.EPHEMERAL : 0),
        files: [...IMG.filesOf(s.image), ...(o.files || [])],
        allowedMentions: { parse: [] }
    };
}

// ───── تعديل الشكل ─────
const KEEP = '(محفوظة — اتركها كما هي)';
const imgShow = v => (!v ? '' : (String(v).startsWith('local:') ? KEEP : String(v)));

function openModal(i, key) {
    const k = KEYS[key]; if (!k) return i.reply({ content: '❌ نظام غير معروف.', flags: EPH });
    const s = get(key);
    const rows = [];
    if (!k.imageOnly) {
        rows.push(input('header', 'الكلام فوق العنوان (اختياري)', { value: s.header, max: 200 }));
        rows.push(input('title', 'العنوان', { value: s.title, max: 100 }));
        rows.push(input('desc', 'الرسالة (اكتب - لإخفائها)', { paragraph: true, value: s.desc, max: 1500 }));
    }
    rows.push(input('image', 'الصورة — رابط (فاضي = بدون صورة)', { value: imgShow(s.image), max: 500, placeholder: 'https://...' }));
    return i.showModal(modal('lkm:' + key, 'تخصيص: ' + k.label, ...rows));
}

async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const key = i.customId.split(':')[1]; const k = KEYS[key]; if (!k) return i.reply({ content: '❌ نظام غير معروف.', flags: EPH });
    await i.deferReply({ flags: EPH });
    const s = own(key); const errs = [];
    const val = id => { try { return i.fields.getTextInputValue(id).trim(); } catch { return ''; } };
    if (!k.imageOnly) {
        s.header = val('header') === '-' ? '' : val('header');
        const t = val('title'); if (t) s.title = t; else delete s.title;
        const d = val('desc'); if (d === '-') s.desc = ''; else if (d) s.desc = d; else delete s.desc;
    }
    const raw = val('image');
    try {
        if (raw === KEEP) { /* بدون تغيير */ }
        else if (!raw || raw === '-') { if (s.image) IMG.remove(s.image); s.image = ''; }
        else { const nv = await IMG.store(raw, 'look-' + key); if (s.image && s.image !== nv) IMG.remove(s.image); s.image = nv; }
    } catch (e) { errs.push('الصورة: ' + e.message); }
    save();
    await i.editReply({ content: errs.length ? '⚠️ انحفظ الباقي لكن ' + errs.join(' • ') : '✅ تم الحفظ. هذي معاينة الشكل الجديد 👇' });
    try { await i.followUp({ ...card(key, { ...k.sample(), ephemeral: true }) }); } catch (e) { /* المعاينة اختيارية */ }
}

// ───── /looks ─────
async function slash(i) {
    if (!(await adminOnly(i))) return;
    const e = H.embed().setTitle('🎨 تخصيص شكل اللوحات')
        .setDescription('اختر النظام، وتقدر تغيّر **الكلام فوق العنوان** و**العنوان** و**الرسالة** و**الصورة** (تظهر في النص).\n\n' +
            Object.entries(KEYS).map(([key, k]) => k.emoji + ' **' + k.label + '** — ' + (get(key).image ? '🖼️ صورة محددة' : '`بدون صورة`')).join('\n'));
    return i.reply({ embeds: [e], components: [row(strSel('lk:pick', 'اختر النظام لتخصيصه...', Object.entries(KEYS).map(([key, k]) => ({ label: k.label, value: key, emoji: k.emoji }))))], flags: EPH });
}
async function component(i) {
    if (!(await adminOnly(i))) return;
    const a = i.customId.split(':')[1];
    if (a === 'pick' && i.isStringSelectMenu()) return openModal(i, i.values[0]);
    if (a === 'edit') return openModal(i, i.customId.split(':')[2]);
}

H.looks = { get, card, openModal, KEYS };
return {
    prefix: 'lk', commands: [{ name: 'looks', description: 'تخصيص شكل اللوحات: الكلام فوق العنوان والعنوان والرسالة والصورة (إدارة)' }],
    ephemeral: ['looks'], slash: { looks: slash }, component, modal: modalSubmit
};
};
