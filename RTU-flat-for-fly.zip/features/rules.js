'use strict';
// ═══ نظام القوانين: /rules — لوحة قوانين احترافية بأقسام، تُنشر في روم، والعضو يقرأ كل قسم بقائمة ═══
module.exports = (H) => {
const { D, EPH, row, btn, strSel, chSel, input, modal, embed, cut, rid, session, adminOnly, update, chTxt, getTextChannel, V2, IMG, client } = H;
const db = H.db; const { ButtonStyle } = D;
const R = () => { const r = (db.rules = db.rules || {});
    r.title = r.title || '📜 قوانين السيرفر'; r.desc = r.desc || 'اقرأ القوانين جيداً قبل المشاركة، الجهل بالقانون لا يُعفي من العقوبة.\nاختر القسم من القائمة بالأسفل لقراءته.';
    r.color = r.color || '#0F2A66'; r.channelId = r.channelId || ''; r.messageId = r.messageId || ''; r.sections = r.sections || []; r.top = r.top || ''; return r; };
const sess = (i) => session(i, 'ru', () => ({ sel: '' }));
const normColor = c => { const m = /^#?([0-9a-f]{6})$/i.exec(String(c || '').trim()); return m ? '#' + m[1] : ''; };

function publicMessage(g) {
    const r = R(); const b = IMG.resolve(r.top) ? null : require('./banners').banner(cut(r.title.replace(/^[^\w\u0600-\u06FF]+/u, '') || 'القوانين', 40), 'القوانين');
    const top = IMG.resolve(r.top) || (b ? { url: 'attachment://' + b.name } : null);
    const kids = [];
    if (top) kids.push(V2.gallery([top.url]));
    kids.push(V2.text('# ' + cut(r.title, 250) + '\n' + cut(r.desc, 1500)));
    kids.push(V2.sep());
    kids.push(V2.text(r.sections.map((s, n) => (s.emoji || '▫️') + ' **' + (n + 1) + '. ' + cut(s.title, 60) + '**').join('\n') || '—'));
    kids.push(V2.sep());
    kids.push(row(strSel('ru:read', 'اضغط هنا لقراءة القوانين..', r.sections.slice(0, 25).map((s, n) => ({ label: (n + 1) + '. ' + cut(s.title, 80), value: s.id, ...(s.emoji ? { emoji: s.emoji } : {}) })))));
    kids.push(V2.text('-# ' + (g ? g.name : '') + ' • نظام القوانين'));
    return { components: [V2.container(kids, V2.parseColor(r.color, V2.NAVY))], flags: V2.IS_V2, files: [...IMG.filesOf(r.top), ...(b ? [b] : [])], allowedMentions: { parse: [] } };
}
function view(i) {
    const r = R(); const s = sess(i);
    const e = embed().setTitle('📜 نظام القوانين')
        .setDescription('أنشئ أقسام القوانين ثم انشر اللوحة في روم. العضو يختار القسم من القائمة فتظهر له قوانينه بشكل خاص.')
        .addFields({ name: '📝 العنوان', value: cut(r.title, 200), inline: true }, { name: '🎨 اللون', value: '`' + r.color + '`', inline: true }, { name: '📍 روم النشر', value: chTxt(r.channelId), inline: true },
            { name: '📂 الأقسام (' + r.sections.length + ')', value: cut(r.sections.map((x, n) => (x.emoji || '▫️') + ' ' + (n + 1) + '. ' + x.title).join('\n') || '`لا يوجد — اضغط إضافة قسم`', 1000) },
            { name: '📤 الحالة', value: r.messageId ? '✅ منشورة' : '⛔ غير منشورة' });
    const rows = [];
    if (r.sections.length) rows.push(row(strSel('ru:pick', 'اختر قسماً لتعديله أو حذفه…', r.sections.slice(0, 25).map(x => ({ label: cut(x.title, 100), value: x.id, ...(x.emoji ? { emoji: x.emoji } : {}), default: x.id === s.sel })))));
    rows.push(row(chSel('ru:ch', 'روم نشر القوانين…', { selected: r.channelId ? [r.channelId] : [] })));
    rows.push(row(btn('ru:add', 'إضافة قسم', '➕', ButtonStyle.Success, r.sections.length >= 25), btn('ru:edit', 'تعديل', '✏️', ButtonStyle.Primary, !s.sel), btn('ru:del', 'حذف', '🗑️', ButtonStyle.Danger, !s.sel),
        btn('ru:look', 'العنوان واللون', '🎨', ButtonStyle.Secondary), btn('ru:pub', r.messageId ? 'تحديث المنشورة' : 'نشر', '📤', ButtonStyle.Success, !r.channelId || !r.sections.length)));
    return { embeds: [e], components: rows };
}
async function publish(i) {
    const r = R(); const ch = await getTextChannel(i.guild, r.channelId);
    if (!ch) return '❌ اختر روم النشر أولاً.';
    const payload = publicMessage(i.guild);
    try {
        if (r.messageId) { const old = await ch.messages.fetch(r.messageId).catch(() => null); if (old) { await old.edit({ ...payload, attachments: [] }); return '✅ تم تحديث اللوحة.'; } }
        const m = await ch.send(payload); r.messageId = m.id; H.save(); return '✅ تم نشر اللوحة في ' + chTxt(ch.id);
    } catch (e) { return '❌ تعذّر النشر: ' + cut(e.message, 120) + '\nتأكد من صلاحيات البوت في الروم.'; }
}
const secModal = (id, t) => modal(id, t ? 'تعديل القسم' : 'قسم جديد', input('title', 'عنوان القسم', { required: true, max: 80, value: t && t.title }), input('emoji', 'إيموجي القسم (اختياري)', { max: 100, value: t && t.emoji }), input('text', 'نص القوانين', { required: true, paragraph: true, max: 3500, value: t && t.text }));
async function slash(i) { if (!(await adminOnly(i))) return; sess(i).sel = ''; return i.reply({ ...view(i), flags: EPH }); }
async function component(i) {
    const a = i.customId.split(':')[1]; const r = R();
    if (a === 'read') {
        const x = r.sections.find(z => z.id === i.values[0]);
        if (!x) return i.reply({ content: '⛔ هذا القسم لم يعد متاحاً.', flags: EPH });
        return i.reply({ embeds: [embed().setTitle((x.emoji ? x.emoji + ' ' : '') + x.title).setDescription(cut(x.text, 4000)).setFooter({ text: (i.guild ? i.guild.name : '') + ' • نظام القوانين' })], flags: EPH });
    }
    if (!(await adminOnly(i))) return;
    const s = sess(i);
    if (a === 'add') return i.showModal(secModal('rum:add'));
    if (a === 'edit') { const x = r.sections.find(z => z.id === s.sel); return x ? i.showModal(secModal('rum:edit:' + x.id, x)) : update(i, view(i)); }
    if (a === 'look') return i.showModal(modal('rum:look', 'العنوان واللون', input('title', 'العنوان', { required: true, max: 100, value: r.title }), input('desc', 'الوصف', { paragraph: true, max: 1000, value: r.desc }), input('color', 'اللون مثل #0F2A66', { max: 7, value: r.color })));
    await i.deferUpdate();
    if (a === 'pick') s.sel = i.values[0]; else if (a === 'ch') { r.channelId = i.values[0] || ''; H.save(); }
    else if (a === 'del') { r.sections = r.sections.filter(z => z.id !== s.sel); s.sel = ''; H.save(); }
    else if (a === 'pub') { const msg = await publish(i); await i.editReply(view(i)); return i.followUp({ content: msg, flags: EPH }); }
    return i.editReply(view(i));
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const [, act, id] = i.customId.split(':'); const r = R(); const g = k => i.fields.getTextInputValue(k).trim();
    if (act === 'look') { r.title = g('title'); r.desc = g('desc') || r.desc; r.color = normColor(g('color')) || r.color; H.save(); }
    else {
        const em = g('emoji'); let emoji = '';
        if (em) { const p = H.tk.parseEmoji(i.guild, em); if (p.error) return i.reply({ content: '❌ ' + p.error, flags: EPH }); emoji = p.value; }
        if (act === 'add') { const x = { id: rid(), title: cut(g('title'), 80), emoji, text: g('text') }; r.sections.push(x); sess(i).sel = x.id; }
        else { const x = r.sections.find(z => z.id === id); if (x) { x.title = cut(g('title'), 80); x.emoji = emoji; x.text = g('text'); } }
        H.save();
    }
    await i.deferUpdate().catch(() => {}); return i.editReply(view(i)).catch(() => {});
}
const commands = [{ name: 'rules', description: 'نظام القوانين: أقسام قوانين ولوحة احترافية تُنشر في روم' }];
return { prefix: 'ru', commands, ephemeral: ['rules'], slash: { rules: slash }, component, modal: modalSubmit };
};
