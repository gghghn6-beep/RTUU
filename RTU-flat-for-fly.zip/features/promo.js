'use strict';
/**
 * promo.js — نظام الترقيات (حسب عدد التذاكر المستلمة)
 *
 *  • السلم يحدده الأدمن بالكامل (عدد الاستلامات + الرتبة + الاسم) — مثلاً 20 تصير 100 أو 200 — من /promo
 *  • عند وصول الإداري للعدد: يُعطى الرتبة تلقائياً وتُرسل رسالة «تمت ترقيتك» في روم الترقيات
 *  • لوحة «طلب ترقية»: زر داخل البطاقة — يرسل اسم الإداري + عدد استلاماته + ترقيته + الحالة
 *  • «سلم الترقيات»: عرض كل المستويات (زر أو /myrank)
 *  • شكل كل رسالة (كلام فوق العنوان / عنوان / رسالة / صورة) يتغير من زر «🎨» أو /looks
 *
 * التخزين: السلم في config.json → ticket.ranks (نفس القديم) • باقي الإعدادات في data/features.json → promo
 */
module.exports = (H) => {
const { D, EPH, row, btn, strSel, chSel, roleSel, input, modal, embed, cut, adminOnly, update, save, V2, client } = H;
const { ButtonStyle } = D;
const db = H.db;
const GREEN = V2.parseColor('#22C55E'), AMBER = V2.parseColor('#F59E0B'), NAVY = V2.NAVY;

// ───── الإعدادات ─────
const P = () => {
    const p = (db.promo = db.promo || {});
    if (p.enabled == null) p.enabled = true;
    if (p.removeOld == null) p.removeOld = false;
    p.channelId = p.channelId || '';
    p.announced = p.announced || {};
    return p;
};
const tiers = () => {
    const c = H.getConfig(); c.ticket = c.ticket || {};
    if (!Array.isArray(c.ticket.ranks)) c.ticket.ranks = [];
    c.ticket.ranks.sort((a, b) => a.claims - b.claims);
    return c.ticket.ranks;
};
const saveCfg = () => { try { H.tk.saveConfig(); } catch (e) { console.error('[promo] saveConfig:', e.message); } };
const name = t => (t.roleId ? '<@&' + t.roleId + '>' : '`' + (t.label || ('رتبة ' + t.claims)) + '`');
const claimsOf = uid => { try { return H.getClaims(uid) || 0; } catch { return 0; } };
const topReached = n => { const r = tiers().filter(t => n >= t.claims); return r.length ? r[r.length - 1] : null; };
const nextTier = n => tiers().find(t => n < t.claims) || null;

// ───── منح الرتبة ─────
async function grant(guild, userId, claimed) {
    const p = P(); const reached = tiers().filter(t => claimed >= t.claims); const top = reached[reached.length - 1] || null;
    const granted = []; let member = null;
    try { member = await guild.members.fetch(userId); } catch { /* العضو غير موجود */ }
    if (member && top) {
        for (const t of reached) {
            if (!t.roleId || member.roles.cache.has(t.roleId)) continue;
            if (p.removeOld && t !== top) continue;
            try { await member.roles.add(t.roleId, 'ترقية تذاكر: ' + claimed + ' استلام'); granted.push(t); }
            catch (e) { console.error('[promo] add role:', e.message); }
        }
        if (p.removeOld && top.roleId && member.roles.cache.has(top.roleId)) {
            const old = reached.filter(t => t !== top && t.roleId && t.roleId !== top.roleId && member.roles.cache.has(t.roleId)).map(t => t.roleId);
            if (old.length) await member.roles.remove(old, 'ترقية: إزالة الرتبة السابقة').catch(() => {});
        }
    }
    return { granted, top, member };
}
const detailLines = (uid, claimed, tier, status) => [
    '**الإداري:** <@' + uid + '>',
    '**عدد الاستلامات:** ' + claimed,
    '**الترقية:** ' + (tier ? name(tier) : '`—`'),
    '**حالة الترقية:** ' + status
];

/** رسالة «تمت ترقيتك» في روم الترقيات */
async function announce(guild, uid, claimed, tier) {
    const p = P(); if (!p.channelId) return false;
    const ch = await H.getTextChannel(guild, p.channelId); if (!ch) return false;
    const msg = H.looks.card('promo_announce', { lines: detailLines(uid, claimed, tier, '✅ تمت الترقية بنجاح'), color: GREEN });
    msg.allowedMentions = { users: [uid] };
    try { await ch.send(msg); return true; } catch (e) { console.error('[promo] announce:', e.message); return false; }
}

/** يُستدعى من index.js بعد كل استلام تذكرة. يرجع المستويات التي تحققت الآن */
async function onClaim(guild, user, claimed) {
    const p = P(); if (!p.enabled || !guild || !user) return [];
    const { top } = await grant(guild, user.id, claimed);
    if (!top) return [];
    const prev = p.announced[user.id] || 0;
    if (top.claims <= prev) return [];
    p.announced[user.id] = top.claims; save();
    await announce(guild, user.id, claimed, top);
    return [top];
}

// ───── للأعضاء ─────
function ladderLines() {
    const ts = tiers();
    return ts.length ? ts.map(t => '• **' + t.claims + '** استلام — ⬆️ ' + name(t)) : ['`لم يُضبط السلم بعد`'];
}
function ladderCard(extraLines = [], ephemeral = true) {
    return H.looks.card('promo_ladder', { lines: [...ladderLines(), ...extraLines, '', '📋 يتم احتساب الاستلام مرة واحدة لكل تذكرة.'], ephemeral, color: GREEN });
}
async function requestPromo(i) {
    const p = P();
    if (!p.enabled) return i.reply({ content: '⛔ نظام الترقيات متوقف حالياً.', flags: EPH });
    const claimed = claimsOf(i.user.id); const top = topReached(claimed); const nxt = nextTier(claimed);
    if (!top) {
        const need = nxt ? 'المطلوب **' + nxt.claims + '** استلام (باقي **' + (nxt.claims - claimed) + '**)' : '`لا يوجد سلم`';
        return i.reply(H.looks.card('promo_announce', { override: { title: '⏳ لم تصل لأول ترقية بعد' }, lines: detailLines(i.user.id, claimed, nxt, '🔒 ' + need), ephemeral: true, color: AMBER }));
    }
    const has = top.roleId ? i.member.roles.cache.has(top.roleId) : (p.announced[i.user.id] || 0) >= top.claims;
    if (has) {
        const more = nxt ? '\n**التالية:** ' + name(nxt) + ' عند **' + nxt.claims + '** (باقي **' + (nxt.claims - claimed) + '**)' : '';
        const c = H.looks.card('promo_announce', { override: { title: '🏆 لديه ترقية بالفعل' }, lines: [...detailLines(i.user.id, claimed, top, 'لديه ترقية بالفعل')], color: AMBER });
        if (more) c.components[0].components.splice(c.components[0].components.length - 1, 0, V2.text(more.trim()));
        return i.reply(c);
    }
    const { top: t2 } = await grant(i.guild, i.user.id, claimed);
    p.announced[i.user.id] = Math.max(p.announced[i.user.id] || 0, (t2 || top).claims); save();
    const posted = await announce(i.guild, i.user.id, claimed, t2 || top);
    if (posted && p.channelId !== i.channelId) return i.reply({ content: '✅ تمت ترقيتك إلى ' + name(t2 || top) + ' — شوف رسالتك في <#' + p.channelId + '>', flags: EPH });
    if (posted) return; // الرسالة نزلت في نفس الروم
    const c = H.looks.card('promo_announce', { lines: detailLines(i.user.id, claimed, t2 || top, '✅ تمت الترقية بنجاح'), color: GREEN });
    c.allowedMentions = { users: [i.user.id] };
    return i.reply(c);
}
function requestPanel() {
    return H.looks.card('promo_request', {
        rows: [row(btn('pr:req', 'طلب ترقية', '📨', ButtonStyle.Success), btn('pr:ladder', 'سلم الترقيات', '🏆', ButtonStyle.Secondary))],
        color: NAVY
    });
}
async function myrank(i) {
    const c = claimsOf(i.user.id); const cur = topReached(c); const nxt = nextTier(c);
    const mine = ['', '🎫 استلاماتك: **' + c + '**', '📌 رتبتك الحالية: ' + (cur ? name(cur) : '`لا توجد بعد`'), '🎯 التالية: ' + (nxt ? '**' + nxt.claims + '** استلام (باقي **' + (nxt.claims - c) + '**)' : '`وصلت أعلى رتبة`')];
    return i.reply(ladderCard(mine, true));
}

// ───── لوحة الإدارة /promo ─────
function adminView() {
    const p = P(); const ts = tiers();
    const e = embed().setTitle('🏆 نظام الترقيات')
        .setDescription('الإداري يترقى تلقائياً لما يوصل عدد الاستلامات اللي تحدده، وتنزل رسالة «تمت ترقيتك» في روم الترقيات.')
        .addFields(
            { name: 'الحالة', value: H.onOff(p.enabled), inline: true },
            { name: 'روم الترقيات', value: H.chTxt(p.channelId), inline: true },
            { name: 'إزالة الرتبة السابقة', value: p.removeOld ? '✅ نعم' : '❌ لا (تتراكم الرتب)', inline: true },
            { name: 'سلم الترقيات', value: cut(ts.map(t => '• **' + t.claims + '** استلام ← ' + name(t)).join('\n') || '`فارغ — أضف مستوى`', 1000) }
        );
    const opts = ts.slice(0, 24).map(t => ({ label: t.claims + ' استلام — ' + (t.label || 'رتبة ' + t.claims), value: String(t.claims), emoji: '🎟️' }));
    opts.push({ label: 'إضافة مستوى جديد', value: 'new', emoji: '➕' });
    return { embeds: [e], components: [
        row(strSel('pr:tier', 'اختر مستوى لتعديله أو أضف جديد...', opts)),
        row(chSel('pr:ch', 'اختر روم الترقيات...', { selected: p.channelId ? [p.channelId] : [] })),
        row(btn('pr:toggle', p.enabled ? 'إيقاف النظام' : 'تشغيل النظام', p.enabled ? '⛔' : '✅', p.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
            btn('pr:rm', p.removeOld ? 'إبقاء الرتب القديمة' : 'إزالة الرتبة السابقة', '♻️', ButtonStyle.Secondary),
            btn('pr:send', 'إرسال لوحة الطلب هنا', '📤', ButtonStyle.Primary),
            btn('pr:post', 'نشر السلم هنا', '🏆', ButtonStyle.Primary)),
        row(btn('lk:edit:promo_announce', 'شكل «تمت ترقيتك»', '🎨', ButtonStyle.Secondary),
            btn('lk:edit:promo_request', 'شكل لوحة الطلب', '🎨', ButtonStyle.Secondary),
            btn('lk:edit:promo_ladder', 'شكل السلم', '🎨', ButtonStyle.Secondary))
    ] };
}
function tierView(claims) {
    const t = tiers().find(x => x.claims === claims); if (!t) return adminView();
    const e = embed().setTitle('🎟️ مستوى ' + t.claims + ' استلام')
        .addFields({ name: 'عدد الاستلامات', value: '**' + t.claims + '**', inline: true }, { name: 'الاسم', value: '`' + (t.label || '—') + '`', inline: true }, { name: 'الرتبة', value: t.roleId ? '<@&' + t.roleId + '>' : '`غير محددة`', inline: true });
    return { embeds: [e], components: [
        row(roleSel('pr:trole:' + claims, 'اختر رتبة هذا المستوى...', { selected: t.roleId ? [t.roleId] : [] })),
        row(btn('pr:tedit:' + claims, 'تعديل العدد والاسم', '✏️', ButtonStyle.Primary), btn('pr:tdel:' + claims, 'حذف المستوى', '🗑️', ButtonStyle.Danger), btn('pr:home', 'رجوع', '⬅️', ButtonStyle.Secondary))
    ] };
}

async function slashPromo(i) { if (!(await adminOnly(i))) return; return i.reply({ ...adminView(), flags: EPH }); }

async function component(i) {
    const parts = i.customId.split(':'); const a = parts[1];
    if (a === 'req') return requestPromo(i);
    if (a === 'ladder') return i.reply(ladderCard([], true));
    if (!(await adminOnly(i))) return;
    const p = P();
    if (a === 'tier') {
        if (i.values[0] === 'new') return i.showModal(modal('prm:new', 'مستوى ترقية جديد', input('claims', 'عدد الاستلامات المطلوب', { required: true, max: 6, placeholder: '100' }), input('label', 'اسم الرتبة', { max: 40, placeholder: 'مثال: Supervisor' })));
        return update(i, tierView(parseInt(i.values[0], 10)));
    }
    if (a === 'ch') { p.channelId = i.values[0]; save(); return update(i, adminView()); }
    if (a === 'toggle') { p.enabled = !p.enabled; save(); return update(i, adminView()); }
    if (a === 'rm') { p.removeOld = !p.removeOld; save(); return update(i, adminView()); }
    if (a === 'home') return update(i, adminView());
    if (a === 'send') {
        await i.deferUpdate();
        try { await i.channel.send(requestPanel()); } catch (e) { await i.followUp({ content: '❌ ' + cut(e.message, 150), flags: EPH }); }
        return i.editReply(adminView());
    }
    if (a === 'post') {
        await i.deferUpdate();
        try { await i.channel.send(ladderCard([], false)); } catch (e) { await i.followUp({ content: '❌ ' + cut(e.message, 150), flags: EPH }); }
        return i.editReply(adminView());
    }
    const claims = parseInt(parts[2], 10);
    if (a === 'trole') { const t = tiers().find(x => x.claims === claims); if (t) { t.roleId = i.values[0]; saveCfg(); } return update(i, tierView(claims)); }
    if (a === 'tedit') {
        const t = tiers().find(x => x.claims === claims); if (!t) return update(i, adminView());
        return i.showModal(modal('prm:edit:' + claims, 'تعديل المستوى', input('claims', 'عدد الاستلامات المطلوب', { required: true, max: 6, value: t.claims }), input('label', 'اسم الرتبة', { max: 40, value: t.label || '' })));
    }
    if (a === 'tdel') { const c = H.getConfig(); c.ticket.ranks = tiers().filter(x => x.claims !== claims); saveCfg(); return update(i, adminView()); }
}

async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const parts = i.customId.split(':'); const mode = parts[1];
    const n = parseInt(String(i.fields.getTextInputValue('claims')).replace(/[^\d٠-٩]/g, '').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)), 10);
    const label = i.fields.getTextInputValue('label').trim();
    if (!n || n < 1 || n > 100000) return i.reply({ content: '❌ اكتب رقماً صحيحاً بين 1 و 100000.', flags: EPH });
    const ts = tiers();
    if (mode === 'new') {
        if (ts.some(t => t.claims === n)) return i.reply({ content: '❌ يوجد مستوى بنفس العدد (' + n + ') — عدّله من القائمة.', flags: EPH });
        ts.push({ claims: n, roleId: '', label: label || ('رتبة ' + n) });
    } else {
        const old = parseInt(parts[2], 10); const t = ts.find(x => x.claims === old); if (!t) return i.reply({ content: '❌ المستوى غير موجود.', flags: EPH });
        if (n !== old && ts.some(x => x.claims === n)) return i.reply({ content: '❌ يوجد مستوى بنفس العدد (' + n + ').', flags: EPH });
        t.claims = n; if (label) t.label = label;
        // لا نعتبر الإداريين مُعلَنين سابقاً عند تغيير العدد
        const p = P(); for (const k of Object.keys(p.announced)) if (p.announced[k] === old) p.announced[k] = Math.min(p.announced[k], n);
    }
    saveCfg(); save();
    const view = tierView(n);
    return (i.isFromMessage && i.isFromMessage()) ? update(i, view) : i.reply({ ...view, flags: EPH });
}

H.promo = { onClaim, announce, requestPanel, ladderCard };
return {
    prefix: 'pr',
    commands: [
        { name: 'promo', description: 'نظام الترقيات: السلم وعدد الاستلامات وروم الترقيات (إدارة)' },
        { name: 'myrank', description: 'عرض استلاماتك وسلم الترقيات ورتبتك التالية' }
    ],
    ephemeral: ['promo', 'myrank'],
    slash: { promo: slashPromo, myrank },
    component, modal: modalSubmit
};
};
