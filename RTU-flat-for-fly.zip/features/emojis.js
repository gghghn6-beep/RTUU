'use strict';
// ═══ مركز الإيموجيات: /emojis — تغيير إيموجي أي عنصر في البوت بإيموجيات السيرفر الخاصة ═══
module.exports = (H) => {
const { D, EPH, row, btn, strSel, embed, cut, session, adminOnly, update, input, modal } = H;
const db = H.db;
const { ButtonStyle } = D;
const store = () => (db.emojis = db.emojis || {});
const guild = () => H.client.guilds.cache.get(H.SERVER_ID) || H.client.guilds.cache.first();

// ───── عناصر عامة تُحفظ في db.emojis ─────
const GENERIC = {
    ap: { name: 'التقديمات', emoji: '📋', items: [
        { key: 'ap.accept', label: 'زر قبول التقديم', def: '✅' }, { key: 'ap.reject', label: 'زر رفض التقديم', def: '❌' },
        { key: 'ap.send', label: 'زر إرسال التقديم', def: '✅' }, { key: 'ap.cancel', label: 'زر إلغاء التقديم', def: '✖️' },
        { key: 'ap.rules', label: 'زر قوانين التقديم', def: '📜' }] },
    ui: { name: 'رسائل الحالة', emoji: '💬', items: [
        { key: 'ui.ok', label: 'نجاح', def: '✅' }, { key: 'ui.err', label: 'خطأ / فشل', def: '❌' },
        { key: 'ui.warn', label: 'تنبيه', def: '⚠️' }, { key: 'ui.info', label: 'معلومة', def: 'ℹ️' }, { key: 'ui.load', label: 'جاري التحميل', def: '🔄' }] },
    mod: { name: 'العقوبات واللوقات', emoji: '🛡️', items: [
        { key: 'mod.ban', label: 'حظر', def: '🚫' }, { key: 'mod.unban', label: 'فك حظر', def: '✅' }, { key: 'mod.warn', label: 'تحذير', def: '⚠️' },
        { key: 'mod.mute', label: 'ميوت', def: '🔇' }, { key: 'mod.unmute', label: 'فك ميوت', def: '🔊' }, { key: 'mod.kick', label: 'طرد', def: '👢' },
        { key: 'mod.summon', label: 'استدعاء', def: '📢' }, { key: 'mod.unsummon', label: 'إلغاء استدعاء', def: '🔓' },
        { key: 'mod.activation', label: 'تفعيل', def: '❌' }, { key: 'mod.other', label: 'أخرى', def: '📋' }] }
};
const DEF = {}; for (const g of Object.values(GENERIC)) for (const x of g.items) DEF[x.key] = x.def;
/** يرجع الإيموجي المخصص أو الافتراضي — تستخدمه بقية الأنظمة: H.E('ui.ok') */
function E(key) { return store()[key] || DEF[key] || ''; }
H.E = E;

// ───── مجموعات خاصة لها تخزين في أنظمتها ─────
const origCat = {};
const cats = () => (H.helpCats && H.helpCats()) || [];
function applyCats() { for (const c of cats()) { if (!(c.id in origCat)) origCat[c.id] = c.emoji; const v = store()['cat.' + c.id]; c.emoji = v || origCat[c.id]; } }
const tkCfg = () => { const c = H.getConfig(); c.ticket = c.ticket || {}; c.ticket.emojis = c.ticket.emojis || {}; return c.ticket; };

function groups() {
    const out = [];
    const tk = (H.tk && H.tk.emojis && H.tk.emojis()) || [];
    out.push({ id: 'tk', name: 'التذاكر', emoji: '🎫', items: tk.map(x => ({ key: x.key, label: x.label, def: x.def,
        get: () => tkCfg().emojis[x.key] || x.def,
        set: v => { if (v) tkCfg().emojis[x.key] = v; else delete tkCfg().emojis[x.key]; H.tk.saveConfig(); } })) });
    out.push({ id: 'help', name: 'قائمة الأوامر (الأقسام)', emoji: '📖', items: cats().map(c => ({ key: 'cat.' + c.id, label: c.name, def: origCat[c.id] || c.emoji,
        get: () => c.emoji,
        set: v => { if (!(c.id in origCat)) origCat[c.id] = c.emoji; if (v) store()['cat.' + c.id] = v; else delete store()['cat.' + c.id]; c.emoji = v || origCat[c.id]; H.save(); } })) });
    out.push({ id: 'sug', name: 'الاقتراحات', emoji: '💡', items: [
        { key: 'sug.up', label: 'إيموجي الموافق', def: '✅', get: () => (db.suggestions && db.suggestions.upEmoji) || '✅', set: v => { db.suggestions = db.suggestions || {}; db.suggestions.upEmoji = v || '✅'; H.save(); } },
        { key: 'sug.down', label: 'إيموجي الرافض', def: '❌', get: () => (db.suggestions && db.suggestions.downEmoji) || '❌', set: v => { db.suggestions = db.suggestions || {}; db.suggestions.downEmoji = v || '❌'; H.save(); } }] });
    out.push({ id: 'gw', name: 'القيف أوي', emoji: '🎉', items: [
        { key: 'gw.join', label: 'زر المشاركة', def: '🎉', get: () => (db.giveaway && db.giveaway.joinEmoji) || '🎉', set: v => { db.giveaway = db.giveaway || {}; db.giveaway.joinEmoji = v || '🎉'; H.save(); } },
        { key: 'gw.leave', label: 'زر الانسحاب', def: '❌', get: () => (db.giveaway && db.giveaway.leaveEmoji) || '❌', set: v => { db.giveaway = db.giveaway || {}; db.giveaway.leaveEmoji = v || '❌'; H.save(); } }] });
    for (const [id, g] of Object.entries(GENERIC)) out.push({ id, name: g.name, emoji: g.emoji, items: g.items.map(x => ({ ...x,
        get: () => E(x.key), set: v => { if (v) store()[x.key] = v; else delete store()[x.key]; H.save(); } })) });
    return out;
}
const PAGE = 25;
const sess = (i) => session(i, 'emj', () => ({ view: 'home', g: '', k: '', ip: 0, sp: 0 }));
const shown = (x) => x.get();
const custom = (x) => String(shown(x)) !== String(x.def);

function viewHome() {
    const gs = groups();
    const e = embed().setTitle('😀 مركز الإيموجيات')
        .setDescription('غيّر إيموجي **أي عنصر** في البوت بإيموجيات سيرفرك الخاصة: أزرار، قوائم، تقييمات، عقوبات، أقسام قائمة الأوامر وغيرها.\n\nاختر المجموعة من القائمة بالأسفل.')
        .addFields(gs.map(g => ({ name: g.emoji + ' ' + g.name, value: g.items.filter(custom).length + ' مخصص من ' + g.items.length, inline: true })));
    return { embeds: [e], components: [
        row(strSel('emj:grp', 'اختر المجموعة…', gs.map(g => ({ label: g.name, value: g.id, emoji: g.emoji, description: g.items.length + ' عنصر' })))),
        row(btn('emj:rsta', 'إرجاع الكل للأصلي', '🔄', ButtonStyle.Danger))] };
}
function viewGroup(s) {
    const g = groups().find(x => x.id === s.g); if (!g) return viewHome();
    const pages = Math.max(1, Math.ceil(g.items.length / PAGE)); s.ip = Math.min(s.ip, pages - 1);
    const sl = g.items.slice(s.ip * PAGE, s.ip * PAGE + PAGE);
    const e = embed().setTitle(g.emoji + ' ' + g.name)
        .setDescription(cut(sl.map(x => shown(x) + '  ' + x.label + (custom(x) ? '  ✔️' : '')).join('\n') || '—', 4000))
        .setFooter({ text: 'اختر العنصر لتغيير إيموجيه • صفحة ' + (s.ip + 1) + '/' + pages });
    const rows = [];
    if (sl.length) rows.push(row(strSel('emj:item', 'اختر العنصر…', sl.map(x => ({ label: x.label, value: x.key, emoji: shown(x) })))));
    rows.push(row(btn('emj:ip', 'السابق', '◀️', ButtonStyle.Secondary, s.ip <= 0), btn('emj:in', 'التالي', '▶️', ButtonStyle.Secondary, s.ip >= pages - 1),
        btn('emj:rstg', 'إرجاع المجموعة', '🔄', ButtonStyle.Danger), btn('emj:home', 'الرئيسية', '🏠')));
    return { embeds: [e], components: rows };
}
function viewItem(s) {
    const g = groups().find(x => x.id === s.g); const x = g && g.items.find(y => y.key === s.k); if (!x) return viewGroup(s);
    const srv = guild() ? [...guild().emojis.cache.values()] : [];
    const pages = Math.max(1, Math.ceil(srv.length / PAGE)); s.sp = Math.min(s.sp, pages - 1);
    const sl = srv.slice(s.sp * PAGE, s.sp * PAGE + PAGE);
    const e = embed().setTitle('✏️ ' + x.label)
        .setDescription('الحالي: ' + shown(x) + '\nالأصلي: ' + x.def + '\n\nاختر إيموجي من سيرفرك بالقائمة، أو اضغط **كتابة يدوي** للصق أي إيموجي أو كتابة اسمه.')
        .setFooter({ text: srv.length ? 'إيموجيات السيرفر: ' + srv.length + ' • صفحة ' + (s.sp + 1) + '/' + pages : 'ما فيه إيموجيات في السيرفر — استخدم الكتابة اليدوية' });
    const rows = [];
    if (sl.length) rows.push(row(strSel('emj:srv', 'إيموجيات السيرفر…', sl.map(z => ({ label: z.name, value: z.toString(), emoji: z.toString() })))));
    rows.push(row(btn('emj:sp', 'السابق', '◀️', ButtonStyle.Secondary, s.sp <= 0), btn('emj:sn', 'التالي', '▶️', ButtonStyle.Secondary, s.sp >= pages - 1),
        btn('emj:man', 'كتابة يدوي', '⌨️', ButtonStyle.Primary), btn('emj:rst', 'الأصلي', '↩️', ButtonStyle.Danger), btn('emj:back', 'رجوع', '◀️')));
    return { embeds: [e], components: rows };
}
const build = (s) => s.view === 'item' ? viewItem(s) : s.view === 'group' ? viewGroup(s) : viewHome();
const cur = (s) => { const g = groups().find(x => x.id === s.g); return g && g.items.find(y => y.key === s.k); };

async function slash(i) { if (!(await adminOnly(i))) return; const s = sess(i); s.view = 'home'; return i.reply({ ...build(s), flags: EPH }); }
async function component(i) {
    if (!(await adminOnly(i))) return;
    const s = sess(i); const a = i.customId.split(':')[1];
    if (a === 'man') { const x = cur(s); if (!x) return update(i, build(s)); return i.showModal(modal('emjm:set', 'إيموجي: ' + cut(x.label, 30), input('v', 'اسم إيموجي السيرفر أو الصقه', { required: false, max: 100, placeholder: 'مثال: ark أو 🔥 • فاضي = الأصلي' }))); }
    await i.deferUpdate();
    if (a === 'grp') { s.g = i.values[0]; s.view = 'group'; s.ip = 0; }
    else if (a === 'item') { s.k = i.values[0]; s.view = 'item'; s.sp = 0; }
    else if (a === 'srv') { const x = cur(s); if (x) x.set(i.values[0]); }
    else if (a === 'rst') { const x = cur(s); if (x) x.set(''); }
    else if (a === 'rstg') { const g = groups().find(y => y.id === s.g); if (g) g.items.forEach(x => x.set('')); }
    else if (a === 'rsta') { groups().forEach(g => g.items.forEach(x => x.set(''))); s.view = 'home'; }
    else if (a === 'ip') s.ip = Math.max(0, s.ip - 1); else if (a === 'in') s.ip++;
    else if (a === 'sp') s.sp = Math.max(0, s.sp - 1); else if (a === 'sn') s.sp++;
    else if (a === 'back') s.view = 'group';
    else if (a === 'home') s.view = 'home';
    return i.editReply(build(s));
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const s = sess(i); const x = cur(s);
    if (!x) return i.reply({ content: '❌ انتهت الجلسة، افتح /emojis من جديد.', flags: EPH });
    const r = H.tk.parseEmoji(guild(), i.fields.getTextInputValue('v'));
    if (r.error) return i.reply({ content: '❌ ' + r.error, flags: EPH });
    x.set(r.value);
    await i.deferUpdate().catch(() => {});
    return i.editReply(build(s)).catch(() => {});
}
const commands = [{ name: 'emojis', description: 'مركز الإيموجيات: غيّر إيموجي أي شيء في البوت بإيموجيات السيرفر' }];
return { prefix: 'emj', commands, ephemeral: ['emojis'], slash: { emojis: slash }, component, modal: modalSubmit, onReady: applyCats, _applyCats: applyCats };
};
