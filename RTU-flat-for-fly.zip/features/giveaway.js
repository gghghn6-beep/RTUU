'use strict';
/**
 * السحب /giveaway — أمر واحد بقائمة تحكم كاملة
 *  • تفعيل/إيقاف + رتب الإدارة المسموح لها • قالب الرسالة بمتغيرات {prize} {winners_count} {host} {participants_count} {end_time}
 *  • لون + صورة علوية + نصوص وأيقونات الأزرار • إشعار الفائزين في الخاص
 *  • إنشاء • إنهاء الآن • إعادة سحب • حذف — والإنهاء التلقائي في موعده
 */
module.exports = (H) => {
const { D, client, SERVER_ID, EPH, row, btn, strSel, chSel, roleSel, input, modal, embed, cut, adminOnly, update, onOff, save, session, rid, isAdmin, V2, IMG } = H;
const { ButtonStyle, ChannelType } = D;
const db = H.db;

const DEFAULT_TPL = '> - الجائزة : **{prize}**\n> - الفائزين : **{winners_count}**\n> - مقدمة من : {host}\n> - المشاركين : **{participants_count}**\n> - تنتهي بعد : {end_time}';
const cfg = () => {
    const g = (db.giveaway = db.giveaway || {});
    g.enabled = g.enabled !== false;
    g.roleIds = Array.isArray(g.roleIds) ? g.roleIds : [];
    g.dm = g.dm !== false;
    g.color = g.color || '#0F2A66';
    g.title = g.title || '🎉 السحب';
    g.template = g.template || DEFAULT_TPL;
    g.image = g.image || '';
    g.joinLabel = g.joinLabel || 'مشاركة'; g.joinEmoji = g.joinEmoji || '🎉';
    g.leaveLabel = g.leaveLabel || 'انسحاب'; g.leaveEmoji = g.leaveEmoji || '❌';
    g.list = g.list || {};
    return g;
};

// ───── أدوات ─────
const ts = ms => Math.floor(ms / 1000);
function parseDur(s) {
    const m = /^\s*(\d+)\s*(s|m|h|d|ث|د|س|ي)?\s*$/i.exec(String(s || ''));
    if (!m) return 0;
    const n = parseInt(m[1], 10); const u = (m[2] || 'm').toLowerCase();
    const mult = { s: 1e3, 'ث': 1e3, m: 6e4, 'د': 6e4, h: 36e5, 'س': 36e5, d: 864e5, 'ي': 864e5 }[u];
    return Math.min(30 * 864e5, n * mult);
}
function fillTpl(tpl, gw) {
    const vars = {
        prize: gw.prize, winners_count: String(gw.winners), host: '<@' + gw.hostId + '>',
        participants_count: String(gw.participants.length),
        end_time: gw.ended ? '<t:' + ts(gw.endsAt) + ':f>' : '<t:' + ts(gw.endsAt) + ':R>'
    };
    return String(tpl).replace(/\{([a-z_]+)\}/gi, (m, k) => (Object.prototype.hasOwnProperty.call(vars, k.toLowerCase()) ? vars[k.toLowerCase()] : m));
}
function gwMessage(gw) {
    const c = cfg();
    const img = IMG.resolve(c.image);
    const kids = [];
    kids.push(V2.text('# ' + c.title));
    kids.push(V2.sep());
    if (img) { kids.push(V2.gallery([img.url])); kids.push(V2.sep()); } // الصورة في النص بين العنوان والرسالة
    kids.push(V2.text(fillTpl(c.template, gw).slice(0, 3500)));
    if (gw.ended) {
        kids.push(V2.sep());
        kids.push(V2.text(gw.winnersIds.length ? '### 🏆 الفائزون\n' + gw.winnersIds.map(id => '<@' + id + '>').join(' ') : '### 😔 لا يوجد فائزون (لم يشارك أحد)'));
    } else {
        kids.push(row(
            btn('gw:join:' + gw.id, c.joinLabel, c.joinEmoji, ButtonStyle.Primary),
            btn('gw:leave:' + gw.id, c.leaveLabel, c.leaveEmoji, ButtonStyle.Secondary)
        ));
    }
    kids.push(V2.text('-# ' + (client.guilds.cache.get(SERVER_ID)?.name || '') + ' • نظام السحب • #' + gw.id));
    return { components: [V2.container(kids, gw.ended ? V2.NAVY : V2.parseColor(c.color))], flags: V2.IS_V2, files: IMG.filesOf(c.image), allowedMentions: { parse: [] } };
}
async function fetchMsg(gw) {
    const ch = client.channels.cache.get(gw.channelId) || await client.channels.fetch(gw.channelId).catch(() => null);
    if (!ch) return null;
    return ch.messages.fetch(gw.messageId).catch(() => null);
}
const pending = new Map();
function scheduleRefresh(gw) {
    if (pending.has(gw.id)) return;
    pending.set(gw.id, setTimeout(async () => {
        pending.delete(gw.id);
        const m = await fetchMsg(gw); if (m) await m.edit({ ...gwMessage(gw), attachments: [] }).catch(() => {});
    }, 4000));
}

// ───── الإنشاء والإنهاء ─────
async function start(guild, channel, hostId, prize, winners, durMs) {
    const gw = { id: rid(), channelId: channel.id, messageId: '', prize: cut(prize, 200), winners, hostId, endsAt: Date.now() + durMs, participants: [], ended: false, winnersIds: [] };
    const sent = await channel.send(gwMessage(gw));
    gw.messageId = sent.id;
    cfg().list[gw.id] = gw; save();
    return gw;
}
function pickWinners(gw, exclude = []) {
    const pool = gw.participants.filter(id => !exclude.includes(id));
    const out = [];
    while (out.length < gw.winners && pool.length) out.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
    return out;
}
async function announce(gw, reroll) {
    const ch = client.channels.cache.get(gw.channelId) || await client.channels.fetch(gw.channelId).catch(() => null);
    if (!ch) return;
    const text = gw.winnersIds.length
        ? (reroll ? '🔄 **إعادة سحب** — ' : '🎊 ') + 'مبروك ' + gw.winnersIds.map(id => '<@' + id + '>').join(' ') + '! فزتم بـ **' + gw.prize + '**'
        : '😔 انتهى السحب على **' + gw.prize + '** بدون فائزين.';
    await ch.send({ content: text, allowedMentions: { users: gw.winnersIds } }).catch(() => {});
    if (cfg().dm) {
        for (const id of gw.winnersIds) {
            try { const u = await client.users.fetch(id); await u.send('🎉 مبروك! فزت بـ **' + gw.prize + '** في سيرفر **' + (ch.guild ? ch.guild.name : '') + '**.\nhttps://discord.com/channels/' + (ch.guildId) + '/' + gw.channelId + '/' + gw.messageId); } catch {}
        }
    }
}
async function end(gw, reroll) {
    if (!reroll) { if (gw.ended) return; gw.ended = true; }
    gw.winnersIds = pickWinners(gw, reroll ? gw.winnersIds : []);
    if (reroll && !gw.winnersIds.length) gw.winnersIds = [];
    save();
    const m = await fetchMsg(gw); if (m) await m.edit({ ...gwMessage(gw), attachments: [] }).catch(() => {});
    await announce(gw, reroll);
}
function onReady() {
    setInterval(() => {
        const now = Date.now();
        for (const gw of Object.values(cfg().list)) if (!gw.ended && gw.endsAt <= now) end(gw).catch(e => console.error('[giveaway]', e.message));
    }, 15000).unref();
}

// ───── التفاعل مع الأزرار العامة ─────
async function publicButton(i) {
    const [, act, id] = i.customId.split(':');
    const gw = cfg().list[id];
    if (!gw) return i.reply({ content: '❌ هذا السحب غير موجود.', flags: EPH });
    if (gw.ended) return i.reply({ content: '⛔ انتهى هذا السحب.', flags: EPH });
    if (!cfg().enabled) return i.reply({ content: '⛔ نظام السحب متوقف.', flags: EPH });
    const has = gw.participants.includes(i.user.id);
    if (act === 'join') {
        if (has) return i.reply({ content: '✅ أنت مشارك بالفعل. حظاً موفقاً!', flags: EPH });
        gw.participants.push(i.user.id); save(); scheduleRefresh(gw);
        return i.reply({ content: '🎉 تم تسجيل مشاركتك، بالتوفيق!', flags: EPH });
    }
    if (act === 'leave') {
        if (!has) return i.reply({ content: '⚠️ أنت غير مشارك.', flags: EPH });
        gw.participants = gw.participants.filter(x => x !== i.user.id); save(); scheduleRefresh(gw);
        return i.reply({ content: '👋 تم سحب مشاركتك.', flags: EPH });
    }
}

// ───── القائمة ─────
const st = i => session(i, 'gw', () => ({ channelId: '', sel: '' }));
const canUse = m => isAdmin(m) || (m && m.roles && m.roles.cache.some(r => cfg().roleIds.includes(r.id)));
function view(i) {
    const c = cfg(); const s = st(i);
    const all = Object.values(c.list).sort((a, b) => b.endsAt - a.endsAt);
    const active = all.filter(x => !x.ended);
    const e = embed().setTitle('🎉 السحب')
        .setDescription('إنشاء المسابقات وإدارتها وتخصيص شكل الرسالة والجوائز.')
        .addFields(
            { name: 'الحالة', value: onOff(c.enabled), inline: true },
            { name: 'إشعار الفائزين بالخاص', value: onOff(c.dm), inline: true },
            { name: 'رتب الإدارة المسموح لها', value: c.roleIds.length ? c.roleIds.map(x => '<@&' + x + '>').join(' ') : '`الإدارة العليا فقط`' },
            { name: '📌 الجاري (' + active.length + ')', value: active.length ? cut(active.slice(0, 8).map(x => '`#' + x.id + '` **' + cut(x.prize, 40) + '** — <#' + x.channelId + '> — <t:' + ts(x.endsAt) + ':R> — 👥 ' + x.participants.length).join('\n'), 1024) : '`لا يوجد`' },
            { name: '🗂️ آخر المنتهية', value: all.filter(x => x.ended).length ? cut(all.filter(x => x.ended).slice(0, 4).map(x => '`#' + x.id + '` **' + cut(x.prize, 40) + '** — ' + (x.winnersIds.length ? x.winnersIds.map(w => '<@' + w + '>').join(' ') : 'بلا فائزين')).join('\n'), 1024) : '`—`' }
        );
    const comps = [
        row(btn('gw:new', 'إنشاء السحب', '➕', ButtonStyle.Success, !c.enabled),
            btn('gw:toggle', c.enabled ? 'إيقاف النظام' : 'تشغيل النظام', c.enabled ? '⛔' : '✅', c.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
            btn('gw:dm', 'إشعار الخاص', c.dm ? '✅' : '⛔'),
            btn('gw:look', 'المظهر والقالب', '🎨', ButtonStyle.Primary)),
        row(chSel('gw:ch', s.channelId ? 'روم الإرسال: ' + (client.channels.cache.get(s.channelId)?.name || 'محدد') : 'اختر روم الإرسال (الافتراضي: الروم الحالي)', { selected: s.channelId ? [s.channelId] : [] })),
        row(roleSel('gw:roles', 'رتب الإدارة المسموح لها', { min: 0, max: 10, selected: c.roleIds }))
    ];
    if (all.length) {
        comps.push(row(strSel('gw:pick', 'اختر السحب لإدارته...', all.slice(0, 25).map(x => ({ label: '#' + x.id + ' — ' + cut(x.prize, 60), value: x.id, emoji: x.ended ? '🏁' : '🟢', description: (x.ended ? 'منتهي' : 'جاري') + ' • ' + x.participants.length + ' مشارك', default: s.sel === x.id })))));
        const g = c.list[s.sel];
        if (g) comps.push(row(btn('gw:end', 'إنهاء الآن', '🏁', ButtonStyle.Primary, g.ended), btn('gw:reroll', 'إعادة سحب', '🔄', ButtonStyle.Secondary, !g.ended), btn('gw:del', 'حذف', '🗑️', ButtonStyle.Danger)));
    }
    return { embeds: [e], components: comps };
}
async function slash(i) {
    if (!canUse(i.member)) return i.reply({ content: '❌ ما عندك صلاحية استخدام السحب.', flags: EPH });
    return i.reply({ ...view(i), flags: EPH });
}
async function component(i) {
    const [, a, extra] = i.customId.split(':');
    if (a === 'join' || a === 'leave') return publicButton(i);
    if (!canUse(i.member)) return i.reply({ content: '❌ ما عندك صلاحية.', flags: EPH });
    const c = cfg(); const s = st(i);
    const adminActs = ['toggle', 'dm', 'look', 'roles'];
    if (adminActs.includes(a) && !(await adminOnly(i))) return;
    if (a === 'look') return i.showModal(modal('gwm:look', 'مظهر السحب',
        input('title', 'العنوان', { max: 80, value: c.title, required: true }),
        input('color', 'اللون مثل #0F2A66', { max: 7, value: c.color }),
        input('tpl', 'القالب (متغيرات بين { })', { paragraph: true, max: 900, value: c.template, required: true }),
        input('img', 'صورة علوية (رابط • فاضي = بدون)', { max: 500, value: c.image ? (String(c.image).startsWith('local:') ? '(محفوظة — اتركها كما هي)' : c.image) : '' }),
        input('btns', 'الأزرار: مشاركة|🎉|انسحاب|❌', { max: 120, value: [c.joinLabel, c.joinEmoji, c.leaveLabel, c.leaveEmoji].join('|') })));
    if (a === 'new') return i.showModal(modal('gwm:new', 'سحب جديد',
        input('prize', 'الجائزة', { max: 200, required: true }),
        input('winners', 'عدد الفائزين', { max: 2, value: '1', required: true }),
        input('dur', 'المدة: 30m أو 2h أو 1d', { max: 8, value: '1h', required: true })));
    if (a === 'toggle') c.enabled = !c.enabled;
    else if (a === 'dm') c.dm = !c.dm;
    else if (a === 'roles') c.roleIds = [...i.values];
    else if (a === 'ch') s.channelId = i.values[0] || '';
    else if (a === 'pick') s.sel = i.values[0] || '';
    else if (a === 'end' || a === 'reroll' || a === 'del') {
        const gw = c.list[s.sel]; if (!gw) return i.reply({ content: '❌ اختر السحب أولاً.', flags: EPH });
        await i.deferUpdate();
        if (a === 'end') await end(gw);
        else if (a === 'reroll') await end(gw, true);
        else { const m = await fetchMsg(gw); if (m) await m.delete().catch(() => {}); delete c.list[gw.id]; s.sel = ''; save(); }
        return i.editReply(view(i));
    }
    save();
    return update(i, view(i));
}
async function modalSubmit(i) {
    const a = i.customId.split(':')[1]; const c = cfg(); const s = st(i);
    if (a === 'look') {
        if (!(await adminOnly(i))) return;
        const tpl = i.fields.getTextInputValue('tpl').trim();
        const col = i.fields.getTextInputValue('color').trim();
        if (col && !/^#?[0-9a-f]{6}$/i.test(col)) return i.reply({ content: '❌ اللون غير صالح، مثال: #0F2A66', flags: EPH });
        const imgRaw = i.fields.getTextInputValue('img').trim();
        const [jl, je, ll, le] = i.fields.getTextInputValue('btns').split('|').map(x => x.trim());
        const fromMsg = i.isFromMessage && i.isFromMessage();
        if (fromMsg) await i.deferUpdate(); else await i.deferReply({ flags: EPH });
        try {
            if (imgRaw !== '(محفوظة — اتركها كما هي)') {
                if (!imgRaw || imgRaw === '-') { if (c.image) IMG.remove(c.image); c.image = ''; }
                else { const nv = await IMG.store(imgRaw, 'gw'); if (c.image && c.image !== nv) IMG.remove(c.image); c.image = nv; }
            }
        } catch (e) { return i.followUp({ content: '❌ ' + e.message, flags: EPH }); }
        c.title = i.fields.getTextInputValue('title').trim() || c.title; c.template = tpl || DEFAULT_TPL;
        c.color = col ? (col.startsWith('#') ? col : '#' + col).toUpperCase() : c.color;
        if (jl) c.joinLabel = cut(jl, 80); if (je) c.joinEmoji = je; if (ll) c.leaveLabel = cut(ll, 80); if (le) c.leaveEmoji = le;
        save();
        return fromMsg ? i.editReply(view(i)) : i.editReply({ content: '✅ تم الحفظ.' });
    }
    if (a === 'new') {
        if (!canUse(i.member)) return i.reply({ content: '❌ ما عندك صلاحية.', flags: EPH });
        const winners = parseInt(i.fields.getTextInputValue('winners'), 10);
        const dur = parseDur(i.fields.getTextInputValue('dur'));
        if (!Number.isFinite(winners) || winners < 1 || winners > 20) return i.reply({ content: '❌ عدد الفائزين من 1 إلى 20.', flags: EPH });
        if (dur < 10000) return i.reply({ content: '❌ المدة غير صالحة. أمثلة: `30m` `2h` `1d` (الحد الأدنى 10 ثواني، الأعلى 30 يوم).', flags: EPH });
        const ch = (s.channelId && (await i.guild.channels.fetch(s.channelId).catch(() => null))) || i.channel;
        await i.deferReply({ flags: EPH });
        try {
            const gw = await start(i.guild, ch, i.user.id, i.fields.getTextInputValue('prize').trim(), winners, dur);
            return i.editReply({ content: '✅ تم إنشاء السحب في <#' + ch.id + '> (#' + gw.id + ').' });
        } catch (e) { return i.editReply({ content: '❌ ما قدرت أرسل السحب: ' + cut(e.message, 150) + '\nتأكد من صلاحيات الإرسال والإرفاق في الروم.' }); }
    }
}

const commands = [{ name: 'giveaway', description: 'السحب: إنشاء المسابقات وإدارتها وتخصيص شكلها' }];
return { prefix: 'gw', commands, ephemeral: ['giveaway'], slash: { giveaway: slash }, component, modal: modalSubmit, onReady };
};
