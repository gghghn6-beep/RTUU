'use strict';
// ═══ لوحات التقديم: /applypanels ═══
// لوحة بشكل «حاوية» مثل الصورة: عنوان + بانر + وصف + أزرار/قائمة. كل لوحة تحمل أي عدد من التقديمات (يتوزع على رسائل تلقائياً)،
// وتقدر تسوي أكثر من لوحة. النمط: أزرار (20 زر لكل رسالة) أو قائمة منسدلة (100 تقديم لكل رسالة) وكلها داخل الحاوية.
module.exports = (H) => {
const { D, EPH, row, btn, strSel, chSel, input, modal, embed, cut, rid, isUrl, session, adminOnly, update, chTxt, getTextChannel, V2 } = H;
const db = H.db; const { ButtonStyle } = D;
const DEF_TITLE = 'تقديم إدارة';
const DEF_DESC = 'مرحباً بك في قسم الدعم الفني.\nإذا كنت تريد الانضمام إلى الإدارة، يرجى اختيار التقديم المناسب من الأسفل.\nوإذا كنت تريد التقديم على الإدارة العليا، يمكنك الضغط على الزر المخصص لها.';
const BTN_PER_MSG = 20, MENU_PER_MSG = 100;
const AP = () => (db.apply = db.apply || {});
const panels = () => (AP().panels = Array.isArray(AP().panels) ? AP().panels : []);
const apps = () => (AP().apps = Array.isArray(AP().apps) ? AP().apps : []);
const find = (id) => panels().find(p => p.id === id);
const norm = (p) => { p.appIds = Array.isArray(p.appIds) ? p.appIds : []; p.messageIds = Array.isArray(p.messageIds) ? p.messageIds : []; p.mode = p.mode === 'menu' ? 'menu' : 'buttons';
    p.title = p.title || DEF_TITLE; p.desc = p.desc || DEF_DESC; p.color = p.color || '#0F2A66'; p.banner = p.banner || ''; p.placeholder = p.placeholder || 'اختر التقديم المناسب…'; p.channelId = p.channelId || ''; return p; };
const emojiOf = (e) => { e = String(e || '').trim(); const m = /^<(a?):(\w{2,32}):(\d{15,25})>$/.exec(e); if (m) return { id: m[3], name: m[2], animated: !!m[1] }; return e || undefined; };
const normColor = c => { const m = /^#?([0-9a-f]{6})$/i.exec(String(c || '').trim()); return m ? '#' + m[1].toLowerCase() : ''; };
const panelApps = (p) => p.appIds.map(id => apps().find(a => a.id === id)).filter(Boolean);
const chunksOf = (p) => { const list = panelApps(p); const size = p.mode === 'menu' ? MENU_PER_MSG : BTN_PER_MSG; const out = []; for (let k = 0; k < list.length; k += size) out.push(list.slice(k, k + size)); return out.length ? out : [[]]; };

// ───── بناء رسالة اللوحة (حاوية) ─────
function render(p, idx, total, guild) {
    norm(p); const list = chunksOf(p)[idx] || [];
    const kids = []; let file = null;
    if (idx === 0) {
        kids.push(V2.text('# ' + cut(p.title, 200)));
        kids.push(V2.sep());
        let url = isUrl(p.banner) ? p.banner.trim() : '';
        if (!url) { const b = require('./banners').banner(cut(p.title, 40), 'نظام التقديمات'); if (b) { file = b; url = 'attachment://' + b.name; } }
        if (url) { kids.push(V2.gallery([url])); kids.push(V2.sep()); }
        kids.push(V2.text(cut(p.desc, 3000)));
        kids.push(V2.sep());
    } else kids.push(V2.text('**' + cut(p.title, 100) + '** — تكملة الأقسام (' + (idx + 1) + '/' + total + ')'));
    if (!list.length) kids.push(V2.text('⚠️ لا توجد تقديمات في هذه اللوحة بعد.'));
    else if (p.mode === 'menu') {
        const open = list.filter(x => x.open); const groups = [];
        for (let k = 0; k < open.length; k += 25) groups.push(open.slice(k, k + 25));
        if (!groups.length) kids.push(V2.text('🔒 كل التقديمات مغلقة حالياً.'));
        groups.forEach((g, n) => kids.push(row(strSel(n === 0 && idx === 0 ? 'ap:pick' : 'ap:pick:' + idx + n, p.placeholder + (groups.length > 1 ? ' (' + (n + 1) + '/' + groups.length + ')' : ''),
            g.map(x => ({ label: x.name, value: x.id, description: x.description || undefined, emoji: emojiOf(x.emoji) }))))));
    } else {
        for (let k = 0; k < list.length; k += 5) kids.push(row(...list.slice(k, k + 5).map(x => {
            const b = new D.ButtonBuilder().setCustomId('ap:start:' + x.id).setStyle(x.open ? ButtonStyle.Primary : ButtonStyle.Secondary).setLabel(cut(x.name, 80));
            if (!x.open) b.setDisabled(true);
            const em = x.open ? emojiOf(x.emoji) : '🔒'; if (em) { try { b.setEmoji(em); } catch {} }
            return b;
        })));
    }
    const out = { components: [V2.container(kids, V2.parseColor(p.color, V2.NAVY))], flags: V2.IS_V2, allowedMentions: { parse: [] } };
    if (file) out.files = [file];
    return out;
}
async function publish(guild, p) {
    norm(p);
    const ch = await getTextChannel(guild, p.channelId);
    if (!ch) return '❌ اختر روم النشر أولاً.';
    if (!panelApps(p).length) return '❌ اختر تقديماً واحداً على الأقل لهذه اللوحة.';
    const cs = chunksOf(p); const ids = [];
    try {
        for (let k = 0; k < cs.length; k++) {
            const payload = render(p, k, cs.length, guild);
            const old = p.messageIds[k] ? await ch.messages.fetch(p.messageIds[k]).catch(() => null) : null;
            if (old) { await old.edit({ ...payload, attachments: [] }); ids.push(old.id); }
            else { const m = await ch.send(payload); ids.push(m.id); }
        }
        for (const extra of p.messageIds.slice(cs.length)) { const m = await ch.messages.fetch(extra).catch(() => null); if (m) await m.delete().catch(() => {}); }
        p.messageIds = ids; H.save();
        return '✅ تم نشر اللوحة في ' + chTxt(ch.id) + (cs.length > 1 ? ' (' + cs.length + ' رسائل)' : '');
    } catch (e) { return '❌ تعذّر النشر: ' + cut(e.message, 150) + '\nتأكد من صلاحيات البوت في الروم.'; }
}
// تستخدمها apply.js: إعادة رسم نفس رسالة اللوحة بعد اختيار عضو (يرجع القائمة لوضعها الأصلي)
H.aplRerender = (messageId, guild) => {
    for (const p of panels()) { const k = norm(p).messageIds.indexOf(messageId); if (k >= 0) return { ...render(p, k, chunksOf(p).length, guild), attachments: [] }; }
    return null;
};

// ───── لوحة الإدارة ─────
const sess = (i) => session(i, 'apl', () => ({ sel: '', pg: 0, confirm: false }));
const APPS_PER = 25;
function view(i) {
    const s = sess(i); const ps = panels(); const p = find(s.sel);
    if (!p) {
        s.sel = '';
        const e = embed().setTitle('🗂️ لوحات التقديم')
            .setDescription('سوِّ أي عدد من اللوحات، وكل لوحة تحمل أي عدد من التقديمات (إدارة، إدارة عليا، عصابة…) بأزرار أو بقائمة منسدلة، وتنشرها في الروم اللي تبغاه.\n\nالتقديمات نفسها (أسئلتها ورومات القبول) تنضبط من `/apply`.')
            .addFields({ name: 'اللوحات (' + ps.length + ')', value: cut(ps.map(x => '▫️ **' + cut(x.title, 40) + '** — ' + panelApps(norm(x)).length + ' تقديم • ' + (x.mode === 'menu' ? 'قائمة' : 'أزرار') + (x.messageIds.length ? ' • ✅ منشورة' : '')).join('\n') || '`لا توجد لوحات — اضغط «لوحة جديدة»`', 1000) },
                { name: 'عدد التقديمات المتاحة', value: String(apps().length), inline: true });
        const rows = [];
        if (ps.length) rows.push(row(strSel('apl:pick', 'اختر لوحة لإدارتها…', ps.slice(0, 25).map(x => ({ label: cut(x.title, 90), value: x.id, description: panelApps(x).length + ' تقديم' })))));
        rows.push(row(btn('apl:new', 'لوحة جديدة', '➕', ButtonStyle.Success, ps.length >= 25)));
        return { embeds: [e], components: rows };
    }
    norm(p); const all = apps(); const pages = Math.max(1, Math.ceil(all.length / APPS_PER)); s.pg = Math.min(s.pg, pages - 1);
    const slice = all.slice(s.pg * APPS_PER, s.pg * APPS_PER + APPS_PER);
    const e = embed().setTitle('🗂️ ' + cut(p.title, 80))
        .addFields({ name: '🔀 النمط', value: p.mode === 'menu' ? 'قائمة منسدلة' : 'أزرار', inline: true }, { name: '📂 التقديمات', value: panelApps(p).length + ' من ' + all.length, inline: true },
            { name: '📍 روم النشر', value: chTxt(p.channelId), inline: true }, { name: '📤 الحالة', value: p.messageIds.length ? '✅ منشورة (' + p.messageIds.length + ' رسالة)' : '⛔ غير منشورة', inline: true },
            { name: '📋 المختارة', value: cut(panelApps(p).map(x => (x.emoji ? x.emoji + ' ' : '') + x.name).join(' • ') || '`لم تختر بعد`', 1000) });
    const rows = [];
    if (slice.length) rows.push(row(strSel('apl:apps', 'اختر تقديمات هذه اللوحة (صفحة ' + (s.pg + 1) + '/' + pages + ')', slice.map(x => ({ label: x.name, value: x.id, emoji: emojiOf(x.emoji), default: p.appIds.includes(x.id) })), { min: 0, max: slice.length })));
    rows.push(row(btn('apl:pp', 'السابق', '◀️', ButtonStyle.Secondary, s.pg <= 0), btn('apl:pn', 'التالي', '▶️', ButtonStyle.Secondary, s.pg >= pages - 1), btn('apl:all', 'تحديد كل التقديمات', '✅', ButtonStyle.Secondary, !all.length), btn('apl:none', 'مسح', '🧹', ButtonStyle.Secondary, !p.appIds.length)));
    rows.push(row(chSel('apl:ch', 'روم نشر اللوحة…', { selected: p.channelId ? [p.channelId] : [] })));
    rows.push(row(btn('apl:text', 'النص والبانر', '✏️', ButtonStyle.Primary), btn('apl:mode', p.mode === 'menu' ? 'تحويل لأزرار' : 'تحويل لقائمة', '🔀', ButtonStyle.Primary),
        btn('apl:prev', 'معاينة', '👁️', ButtonStyle.Secondary), btn('apl:pub', p.messageIds.length ? 'تحديث المنشورة' : 'نشر', '📤', ButtonStyle.Success, !p.channelId || !p.appIds.length)));
    rows.push(row(btn('apl:back', 'رجوع', '⬅️', ButtonStyle.Secondary), btn('apl:del', s.confirm ? 'تأكيد الحذف ⚠️' : 'حذف اللوحة', '🗑️', ButtonStyle.Danger)));
    return { embeds: [e], components: rows };
}
async function slash(i) { if (!(await adminOnly(i))) return; const s = sess(i); s.sel = ''; s.pg = 0; s.confirm = false; return i.reply({ ...view(i), flags: EPH }); }
async function component(i) {
    if (!(await adminOnly(i))) return;
    const a = i.customId.split(':')[1]; const s = sess(i); const p = find(s.sel);
    if (a === 'new') return i.showModal(modal('aplm:new', 'لوحة جديدة', input('title', 'عنوان اللوحة', { required: true, max: 100, value: DEF_TITLE })));
    if (a === 'text' && p) return i.showModal(modal('aplm:text', 'نص اللوحة', input('title', 'العنوان', { required: true, max: 100, value: p.title }), input('desc', 'الوصف', { required: true, paragraph: true, max: 1500, value: p.desc }),
        input('color', 'اللون مثل #0F2A66', { max: 7, value: p.color }), input('banner', 'رابط البانر (فاضي = بانر أزرق تلقائي)', { max: 300, value: p.banner }), input('ph', 'نص القائمة (لنمط القائمة)', { max: 100, value: p.placeholder })));
    await i.deferUpdate();
    if (a === 'pick') { s.sel = i.values[0]; s.pg = 0; s.confirm = false; }
    else if (a === 'back') { s.sel = ''; s.confirm = false; }
    else if (!p) { /* لا شيء */ }
    else if (a === 'apps') { const page = apps().slice(s.pg * APPS_PER, s.pg * APPS_PER + APPS_PER).map(x => x.id); const keep = p.appIds.filter(id => !page.includes(id)); p.appIds = [...keep, ...page.filter(id => i.values.includes(id))]; H.save(); }
    else if (a === 'all') { p.appIds = apps().map(x => x.id); H.save(); }
    else if (a === 'none') { p.appIds = []; H.save(); }
    else if (a === 'pp') s.pg = Math.max(0, s.pg - 1); else if (a === 'pn') s.pg++;
    else if (a === 'ch') { p.channelId = i.values[0] || ''; H.save(); }
    else if (a === 'mode') { p.mode = p.mode === 'menu' ? 'buttons' : 'menu'; H.save(); }
    else if (a === 'prev') { const pl = render(p, 0, chunksOf(p).length, i.guild); await i.editReply(view(i)); return i.followUp({ ...pl, flags: V2.IS_V2 | V2.EPHEMERAL }); }
    else if (a === 'pub') { const msg = await publish(i.guild, p); await i.editReply(view(i)); return i.followUp({ content: msg, flags: EPH }); }
    else if (a === 'del') { if (!s.confirm) s.confirm = true; else { AP().panels = panels().filter(x => x.id !== p.id); s.sel = ''; s.confirm = false; H.save(); } }
    if (a !== 'del') s.confirm = false;
    return i.editReply(view(i));
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const act = i.customId.split(':')[1]; const s = sess(i); const g = k => i.fields.getTextInputValue(k).trim();
    if (act === 'new') { const p = norm({ id: rid(), title: cut(g('title'), 100) }); panels().push(p); s.sel = p.id; s.pg = 0; H.save(); }
    else { const p = find(s.sel); if (!p) return i.reply({ content: '❌ انتهت الجلسة، افتح /applypanels من جديد.', flags: EPH });
        p.title = cut(g('title'), 100); p.desc = g('desc') || DEF_DESC; p.color = normColor(g('color')) || p.color; p.banner = g('banner'); p.placeholder = g('ph') || p.placeholder; H.save(); }
    await i.deferUpdate().catch(() => {}); return i.editReply(view(i)).catch(() => {});
}
const commands = [{ name: 'applypanels', description: 'لوحات التقديم: لوحات بأزرار أو قائمة، كل لوحة تحمل أي عدد من التقديمات' }];
return { prefix: 'apl', commands, ephemeral: ['applypanels'], slash: { applypanels: slash }, component, modal: modalSubmit, _render: render };
};
