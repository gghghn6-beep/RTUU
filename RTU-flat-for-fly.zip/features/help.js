'use strict';
// ═══ /help — مركز المساعدة: قائمة أقسام + صفحات + معاينة ═══
module.exports = (H) => {
const { D, EPH, row, btn, strSel, embed, cut, session, update } = H;
const { ButtonStyle } = D;
const C = (cmd, desc) => ({ cmd, desc });
const CATS = [
    { id: 'antispam', emoji: '🛡️', name: 'منع السبام', desc: 'حماية متكاملة بقائمة تحكم واحدة', items: [
        C('/antispam', 'قائمة منع السبام: الحمايات • قناة الفحص (الفخ) • العقوبة • الاستثناءات • القنوات المراقبة • السجلات')] },
    { id: 'ai', emoji: '🤖', name: 'الذكاء الاصطناعي والصوت', desc: 'مساعد يتكلم ويشغّل المقاطع والقرآن', items: [
        C('/ai', 'إعداد المساعد: رومات المحادثة • الأوامر الصوتية • الشخصية'), C('/music', 'مشغّل يوتيوب والقرآن بأزرار تحكم'),
        C('كلّم البوت', 'اكتب في روم الذكاء الاصطناعي أو منشن البوت: «السلام عليكم» • «شغّل سورة الكهف» • «اطلع برا الروم»')] },
    { id: 'giveaway', emoji: '🎉', name: 'القيف أوي', desc: 'مسابقات بقالب وأزرار مشاركة', items: [C('/giveaway', 'إنشاء وإدارة وإعادة سحب وتخصيص الشكل')] },
    { id: 'feel', emoji: '💭', name: 'الفقاعات', desc: 'رسائل تتحول إلى إيمبد أنيق', items: [C('/feel', 'رومات الفضفضة • اللون • مجهول • حذف الأصل')] },
    { id: 'schedule', emoji: '📅', name: 'جدولة التوب', desc: 'توب الشات والفويس تلقائياً', items: [C('/schedule', 'يومي / أسبوعي / شهري في روم محدد')] },
    { id: 'logs', emoji: '📜', name: 'السجلات', desc: 'لوقات إدارية وعامة', items: [C('/logs', 'تفعيل كل نوع سجل وتحديد رومه • إنشاء الرومات تلقائياً'), C('setlog! / detlog!', 'إنشاء وحذف رومات السجلات')] },
    { id: 'colors', emoji: '🎨', name: 'نظام الألوان', desc: 'رتب ألوان لكل الأعضاء', items: [C('/colors', 'مجموعات ألوان • العنوان • الشكل • الخلفية'), C('colors!', 'عرض قائمة الألوان بصورة'), C('color! 3', 'تغيير لونك (color! 0 للإزالة)')] },
    { id: 'chatcmds', emoji: '⌨️', name: 'أوامر الشات (!)', desc: 'أوامر سريعة للإدارة', items: [C('hide! / unhide!', 'إخفاء/إظهار الروم'), C('lock! / unlock!', 'قفل/فتح الكتابة'), C('slowmode! 5', 'الوضع البطيء'), C('setvoice!', 'تثبيت البوت في روم صوتي (setvoice! off للإلغاء)')] },
    { id: 'modcmds', emoji: '🛡️', name: 'أوامر الإدارة (!)', desc: 'عقوبات وتحذيرات وميوت وسجن', items: [
        C('warn! @عضو السبب', 'تحذير مع حفظه في السجل وإرسال خاص للعضو'), C('warnings! @عضو', 'عرض تحذيرات العضو'), C('dinfractions! @عضو', 'سجل العقوبات كاملاً (clear للمسح • del رقم للحذف)'),
        C('timeout! @عضو 10m السبب', 'تايم أوت (s / m / h / d)'), C('untimeout! @عضو', 'فك التايم أوت'),
        C('mute! @عضو 1h السبب', 'اسكات كتابي برتبة Muted تُنشأ تلقائياً'), C('unmute! @عضو', 'فك الاسكات الكتابي'), C('mymute!', 'معلومات الميوت الخاص بك'),
        C('prison! @عضو 1d السبب', 'سجن عضو (تُسحب رتبه وتُرجَع عند الفك)'), C('unprison! @عضو', 'فك السجن'), C('myprison!', 'معلومات سجنك'), C('stats! @إداري', 'إحصائيات إجراءات الإداري')] },
    { id: 'voicecmds', emoji: '🔊', name: 'أوامر الصوت (!)', desc: 'سحب ونقل وطرد من الفويس', items: [
        C('move! @عضو', 'سحب عضو إلى رومك'), C('moveme! @عضو', 'انتقال إلى روم عضو'), C('moveto! [@عضو] #روم', 'نقل عضو أو نفسك لروم محدد'), C('moveall! #من #إلى', 'سحب كل أعضاء روم إلى روم آخر'),
        C('vkick! @عضو', 'طرد من الروم الصوتي'), C('vmute! @عضو', 'ميوت صوتي'), C('unvmute! @عضو', 'فك الميوت الصوتي')] },
    { id: 'rolecmds', emoji: '🏷️', name: 'أوامر الرتب والصور (!)', desc: 'إعطاء رتب وبلوك رتب وبلوك صور وإيموجي', items: [
        C('role! @عضو @رتبة', 'إعطاء رتبة (أو سحبها إن كانت موجودة)'), C('rblock! @عضو @رتبة', 'منع عضو من رتبة معينة'), C('removeblock! @عضو [@رتبة]', 'فك بلوك الرتبة'), C('roleblocks! [@عضو]', 'عرض بلوكات الرتب'),
        C('blockpic! @عضو', 'منع عضو من إرسال الصور'), C('blocked!', 'قائمة المحظورين من الصور'), C('removeblockpic! @عضو', 'فك بلوك الصور'),
        C('aemoji!', 'إضافة إيموجي للسيرفر (إيموجي / صورة / رابط)'), C('stickers! الاسم', 'إضافة ستيكر للسيرفر من صورة مرفقة')] },
    { id: 'infocmds', emoji: '📌', name: 'أوامر المعلومات (!)', desc: 'بروفايل ومستوى وإحصائيات', items: [
        C('help!', 'قائمة أوامر الشات'), C('avatar! / banner!', 'صورة وبانر عضو'), C('profile! / user!', 'الملف الشخصي وتاريخ الانضمام والإنشاء'), C('level!', 'مستواك ونقاط XP'), C('server!', 'معلومات السيرفر'),
        C('ping!', 'سرعة اتصال البوت'), C('semoji! 😀', 'إرسال صورة الإيموجي'), C('statistics!', 'لوحة تفاعل السيرفر'), C('messages! [@رتبة]', 'ترتيب ومجموع الرسائل'), C('point!', 'نقاط الأعضاء (add / remove / set / top)'),
        C('bots! / botstatus!', 'البوتات وحالتها'), C('advice!', 'نصيحة أمنية'), C('pslist!', 'قائمة الحماية المفعلة والمعطلة')] },
    { id: 'limits', emoji: '🔐', name: 'حدود الصلاحيات والبروفايل', desc: 'حماية من التخريب وتخصيص مظهر البوت', items: [
        C('/limits', 'حد أعلى للباند والطرد والرومات والرتب وإدارة الرتب + إجراء + قائمة بيضاء + روم سجل'), C('automod! 5', 'قاعدة AutoMod لمنع منشن السبام (automod! off للإيقاف)'),
        C('/botprofile', 'لقب وأفتار وبانر البوت داخل هذا السيرفر فقط')] },
    { id: 'clock', emoji: '🕐', name: 'الدوام والنقاط', desc: 'تسجيل دوام الإداريين ونقاطهم', items: [
        C('-تسجيلدخول / -تسجيلخروج', 'بدء وإنهاء الدوام'), C('-وقتي', 'مدة دوامك'), C('-لوحةوقت', 'لوحة الدوام'), C('-نقاط', 'ترتيب نقاط الإدارة'),
        C('/staffpoints', 'النقاط والإعداد'), C('/rating', 'تقييمات إداري'), C('/clockpanel', 'إرسال لوحة تسجيل الدخول'), C('/setclockpoints', 'دقائق = نقاط'), C('/setpresence', 'تحقق التواجد')] },
    { id: 'ticket', emoji: '🎫', name: 'التذاكر', desc: 'نظام التذاكر والدعم الفني', items: [
        C('/tickets', 'قائمة التذاكر: اللوحات والأقسام والإعدادات والصلاحيات'), C('/ticketstats', 'إحصائيات التذاكر'), C('/testrating', 'تجربة رسالة التقييم')] },
    { id: 'stats', emoji: '📊', name: 'المكافآت والإحصائيات', desc: 'نظام المكافآت وأوامر الإحصائيات', items: [
        C('/setrewards', 'إعداد المكافآت (الروم + المبلغ + المدة)'), C('مكافأة / توب / معلومات', 'تُكتب في روم المكافآت'), C('/setstats', 'روم أوامر الإحصائيات'), C('/setstatscmds', 'تغيير أسماء أوامر الإحصائيات'), C('حسابي / توب فويس / توب شات', 'تُكتب في روم الإحصائيات')] },
    { id: 'welcome', emoji: '👋', name: 'الترحيب والمغادرة', desc: 'ترحيب بإمبيد أو رسالة عادية مع صورة العضو', items: [
        C('/welcomesettings', 'قائمة الترحيب والصورة والأزرار والمغادرة'), C('/testwelcome', 'إرسال ترحيب تجريبي فعلي')] },
    { id: 'embed', emoji: '🧩', name: 'الإيمبد والردود', desc: 'رسائل مصممة وردود تلقائية وأمر الخط', items: [
        C('/embed', 'صانع الإيمبد + إجراءات تفاعلية (أزرار / قائمة بردود مخفية)'), C('/autoreply', 'الردود التلقائية بصلاحيات متقدمة'), C('/setline', 'أمر الخط: كلمة + صورة + عدة رومات')] },
    { id: 'roles', emoji: '🏷️', name: 'الرتب والمستويات', desc: 'رتب ذاتية ونظام XP', items: [
        C('/selfroles', 'لوحات الرتب القابلة للأخذ'), C('/levels', 'إعدادات المستويات والمكافآت'), C('/rank', 'بطاقة مستواك'), C('/leveltop', 'أعلى 10 أعضاء'), C('حسابي / T', 'كرت مستواك كصورة (يُكتب في روم الإحصائيات)'), C('توب / top', 'قائمة توب الشات والفويس مع الـXP')] },
    { id: 'organize', emoji: '🗂️', name: 'تنظيم الشات والسيرفر', desc: 'قواعد الرومات ورسائل ثابتة وتنظيف تلقائي وتقرير', items: [
        C('/organize', 'قواعد الرومات (صور فقط / بدون روابط…) • رسائل ثابتة • تنظيف تلقائي • ثريد وتفاعلات تلقائية • تقرير تنظيم السيرفر')] },
    { id: 'apply', emoji: '📋', name: 'التقديمات', desc: 'تقديمات بأي اسم وأسئلة بالعشرات وقبول/رفض احترافي', items: [
        C('/apply', 'لوحة التقديمات: اللوحة والأسئلة والأوراق ورومات الاستقبال والقبول والرفض والتقييم')] },
    { id: 'streams', emoji: '📡', name: 'إشعارات البثوث', desc: 'يوتيوب • تيك توك • كيك', items: [
        C('/streams', 'إضافة حسابات وروم الإرسال والمنشن والرسالة والصورة + فحص وإرسال تجريبي')] },
    { id: 'voice', emoji: '🔊', name: 'الرومات المؤقتة والانتظار', desc: 'غرفة صوتية خاصة + روم الانتظار', items: [
        C('/tempvoice', 'الإعدادات + 📤 إرسال لوحة التحكم + صلاحيات صاحب الغرفة'), C('/waitroom', 'روم الانتظار وطلبات الدعم الصوتي')] },
    { id: 'protect', emoji: '🛡️', name: 'الاقتراحات والقفل', desc: 'اقتراحات، قفل القنوات', items: [
        C('/suggestions', 'نظام الاقتراحات (تفاعل ✅❌ وثريد للنقاش)'),
        C('/lock /unlock', 'قفل وفتح قناة'), C('/lockdown /unlockall', 'قفل/فتح الكل (طوارئ)'),
        C('-قفل / -فتح / -قفل_الكل', 'أوامر الشات للقفل')] },
    { id: 'utils', emoji: '🧰', name: 'أوامر مساعدة', desc: 'مسح، معلومات، أفاتار، رتبة تلقائية', items: [
        C('/clear', 'مسح رسائل'), C('-مسح 10', 'مسح بعدد'), C('/slowmode', 'السلومود'),
        C('/serverinfo', 'معلومات السيرفر'), C('/userinfo', 'معلومات عضو'), C('/avatar', 'عرض الأفاتار'), C('a / b', 'صورة وبانر عضو بكلمة (تتغير بـ -اختصار)'),
        C('/autorole', 'رتبة تلقائية للأعضاء الجدد')] },
    { id: 'admin', emoji: '⚙️', name: 'الإعدادات والإدارة', desc: 'إعدادات عامة للبوت', items: [
        C('/applypanels', 'لوحات التقديم: لوحة بأزرار أو قائمة بأي عدد تقديمات'), C('/rules', 'نظام القوانين: أقسام ولوحة قراءة احترافية'), C('/emojis', 'مركز الإيموجيات: غيّر إيموجي أي شيء في البوت بإيموجيات السيرفر'), C('/setadmin', 'رتبة الإدارة العليا'), C('/botperms', 'صلاحيات رتب الموظفين داخل البوت'), C('/athkar', 'نظام الأذكار العشوائي'), C('/radio', 'نظام الراديو والموجات'), C('/setbotrole', 'رتبة موظفين وصلاحيات التذاكر'), C('/cmdmanager', 'تفعيل وإيقاف أوامر الشات'), C('/ping', 'زمن الاستجابة'), C('/help', 'هذه القائمة')] }
];
const PER = 8;
const sess = (i) => session(i, 'hp', () => ({ cat: 'home', page: 0 }));
function pagesOf(cat) { const n = Math.max(1, Math.ceil(cat.items.length / PER)); return n; }
function build(i) {
    const s = sess(i); const g = i.guild; const icon = g && g.iconURL ? g.iconURL({ size: 256 }) : null;
    const total = CATS.reduce((a, c) => a + c.items.length, 0);
    const e = embed();
    if (g) e.setAuthor({ name: g.name, ...(icon ? { iconURL: icon } : {}) });
    if (icon) e.setThumbnail(icon);
    const cat = CATS.find(c => c.id === s.cat);
    const rows = [];
    if (!cat) {
        e.setTitle('📚 مركز المساعدة — RTU')
            .setDescription('**قائمة أنظمة وأوامر البوت**\nاختر قسماً من القائمة لعرض التفاصيل.\n\n• أوامر الشات تبدأ بـ `!` (للإدارة حسب الصلاحية)\n• هذا هو الأمر الوحيد المسجّل، وباقي الأنظمة تُدار عبر لوحة الإعدادات\n• الأوامر الإدارية محمية ولا يستخدمها الأعضاء')
            .addFields(...CATS.map(c => ({ name: c.emoji + ' ' + c.name, value: c.desc + '\n`' + c.items.length + ' أمر`', inline: true })))
            .setFooter({ text: total + ' أمر في ' + CATS.length + ' أقسام • كل شيء بالألوان الزرقاء 💙' });
    } else {
        const pages = pagesOf(cat); s.page = Math.min(s.page, pages - 1);
        const slice = cat.items.slice(s.page * PER, s.page * PER + PER);
        e.setTitle(cat.emoji + ' ' + cat.name).setDescription(cat.desc + '\n\n' + slice.map(x => '▸ **' + x.cmd + '**\n   ' + x.desc).join('\n\n'))
            .setFooter({ text: 'الصفحة ' + (s.page + 1) + ' / ' + pages + ' • ' + cat.items.length + ' أمر' });
        rows.push(row(btn('hp:home', 'الرئيسية', '🏠', ButtonStyle.Primary), btn('hp:prev', 'السابق', '◀️', ButtonStyle.Secondary, s.page <= 0), btn('hp:next', 'التالي', '▶️', ButtonStyle.Secondary, s.page >= pages - 1)));
    }
    if (!cat && H.isAdmin && i.member && H.isAdmin(i.member)) rows.push(row(btn('hp:setup', 'لوحة الإعدادات (للإدارة)', '⚙️', ButtonStyle.Primary)));
    rows.unshift(row(strSel('hp:cat', 'اختر القسم', [{ label: 'الرئيسية', value: 'home', emoji: '🏠', default: !cat }, ...CATS.map(c => ({ label: c.name, value: c.id, emoji: c.emoji, description: cut(c.desc, 90), default: cat && cat.id === c.id }))])));
    return { embeds: [e], components: rows };
}
async function slash(i) { sess(i).cat = 'home'; sess(i).page = 0; return i.reply({ ...build(i), flags: EPH }); }
async function component(i) {
    const s = sess(i); const a = i.customId.split(':')[1];
    if (a === 'setup') { if (!(H.isAdmin && H.isAdmin(i.member))) return i.reply({ content: '❌ هذا الزر مخصص للإدارة فقط.', flags: EPH }); return H.runSlash(i, 'setup'); }
    await i.deferUpdate();
    if (a === 'cat') { s.cat = i.values[0]; s.page = 0; }
    else if (a === 'home') { s.cat = 'home'; s.page = 0; }
    else if (a === 'prev') s.page = Math.max(0, s.page - 1);
    else if (a === 'next') s.page++;
    return i.editReply(build(i));
}
return { prefix: 'hp', commands: [{ name: 'help', description: 'مركز المساعدة: كل أوامر البوت مرتبة بأقسام' }], ephemeral: ['help'], slash: { help: slash }, component, _build: build, _cats: CATS };
};
