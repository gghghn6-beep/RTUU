/**
 * بوت الرقابة فقط — بدون تذاكر / موسيقى / ترحيب
 */
// بعض لوحات الاستضافة تشغّل `node index.js` مباشرة ولا تثبّت الحزم تلقائياً.
// ثبّت الاعتمادات من lockfile قبل أول require خارجي حتى لا يتوقف البوت بـ MODULE_NOT_FOUND.
const __bootstrapFs = require('node:fs');
const __bootstrapPath = require('node:path');
const __bootstrapChild = require('node:child_process');

// ─── تحميل .env تلقائياً (بدون مكتبة خارجية) ───
(function loadDotEnv() {
    try {
        const envPath = __bootstrapPath.join(__dirname, '.env');
        if (!__bootstrapFs.existsSync(envPath)) return;
        const lines = __bootstrapFs.readFileSync(envPath, 'utf8').split(/\r?\n/);
        for (const line of lines) {
            const s = line.trim();
            if (!s || s.startsWith('#')) continue;
            const eq = s.indexOf('=');
            if (eq < 1) continue;
            const key = s.slice(0, eq).trim();
            let val = s.slice(eq + 1).trim();
            if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1);
            if (key && process.env[key] == null) process.env[key] = val;
        }
        console.log('[startup] تم تحميل ملف .env');
    } catch (e) { console.warn('[startup] .env:', e.message); }
})();

try {
    require.resolve('discord.js', { paths: [__dirname] });
} catch {
    const packageFile = __bootstrapPath.join(__dirname, 'package.json');
    const lockFile = __bootstrapPath.join(__dirname, 'package-lock.json');
    if (!__bootstrapFs.existsSync(packageFile)) {
        console.error('❌ discord.js غير مثبتة ولا يوجد package.json بجانب index.js. ارفع ملفات المشروع إلى /home/container.');
        process.exit(1);
    }
    console.log('[startup] discord.js غير موجودة؛ جارٍ تثبيت الاعتمادات تلقائياً...');
    const useCi = __bootstrapFs.existsSync(lockFile);
    const install = __bootstrapChild.spawnSync('npm', useCi ? ['ci', '--omit=dev', '--no-audit', '--no-fund'] : ['install', '--omit=dev', '--no-audit', '--no-fund'], {
        cwd: __dirname,
        stdio: 'inherit',
        timeout: 10 * 60 * 1000,
        env: process.env
    });
    if (install.error || install.status !== 0) {
        console.error('❌ فشل التثبيت التلقائي للاعتمادات.', install.error?.message || `npm exit code: ${install.status}`);
        process.exit(1);
    }
    try { require.resolve('discord.js', { paths: [__dirname] }); }
    catch (e) { console.error('❌ لم تظهر discord.js بعد التثبيت:', e.message); process.exit(1); }
    console.log('[startup] ✅ تم تثبيت الاعتمادات بنجاح.');
}
const {
    Client, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder,
    ButtonBuilder, StringSelectMenuBuilder, RoleSelectMenuBuilder, ModalBuilder, TextInputBuilder,
    TextInputStyle, ButtonStyle, REST, Routes, ActivityType, MessageFlags, ChannelType, PermissionFlagsBits
} = require('discord.js');
const fs = require('fs');
const BLUE = '#0F2A66';
const { banner: autoBanner } = require('./features/banners');
/** إذا ما فيه صورة محفوظة، يولّد بانر أزرق غامق بالعنوان تلقائياً */
function withAutoBanner(resolved, title, sub) {
    if (resolved) return { img: resolved, extra: [] };
    const b = autoBanner(title, sub || '', '');
    return b ? { img: { url: 'attachment://' + b.name }, extra: [b] } : { img: null, extra: [] };
}

// ═══ هوية موحّدة: أي رسالة Embed بدون تذييل تأخذ تذييل البوت الافتراضي تلقائياً ═══
(() => {
    EmbedBuilder.keepColor = new WeakSet(); // إيمبد يحتفظ بلونه الخاص (مثل لوحة الراديو)
    const origToJSON = EmbedBuilder.prototype.toJSON;
    EmbedBuilder.prototype.toJSON = function () {
        if (!EmbedBuilder.keepColor.has(this)) this.data.color = 0x0F2A66; // هوية موحّدة: كل الإيمبد أزرق
        if (!this.data.footer) this.data.footer = { text: 'RTU Moderation' };
        if (!this.data.timestamp) this.data.timestamp = new Date().toISOString();
        return origToJSON.call(this);
    };
})();
const path = require('path');

const CONFIG_DEFAULT_PATH = path.join(__dirname, 'config.json');
const CONFIG_PATH = process.env.CONFIG_PATH ? path.resolve(process.env.CONFIG_PATH) : CONFIG_DEFAULT_PATH;
// عند استخدام مسار مخصص (مثل volume في Docker) ننسخ الإعدادات الافتراضية أول مرة فقط
if (CONFIG_PATH !== CONFIG_DEFAULT_PATH && !fs.existsSync(CONFIG_PATH)) {
    try { fs.mkdirSync(path.dirname(CONFIG_PATH), { recursive: true }); fs.copyFileSync(CONFIG_DEFAULT_PATH, CONFIG_PATH); } catch (e) { console.error('[config] تعذر إنشاء ملف الإعدادات:', e.message); }
}
function loadConfigFile() {
    const raw = fs.readFileSync(CONFIG_PATH, 'utf8').replace(/^\uFEFF/, '');
    try { return JSON.parse(raw); } catch (e1) {
        // إصلاح الخطأ الشائع: علامة تنصيص زائدة في آخر القيمة مثل "abc""  أو "abc“
        // 1) إعادة بناء سطر التوكن كاملاً مهما كان فيه من علامات أو رموز زائدة
        const rebuilt = raw.replace(/^([ \t]*)"token"[ \t]*:[^\n]*$/m, (line, ind) => {
            const tk = (line.match(/[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{4,}\.[A-Za-z0-9_\-]{20,}/) || [''])[0];
            return ind + '"token": "' + tk + '",';
        });
        try {
            const cfg = JSON.parse(rebuilt);
            console.warn('[config] ⚠️ تم إصلاح سطر التوكن في config.json تلقائياً. الأفضل استخدام DISCORD_TOKEN في الاستضافة.');
            return cfg;
        } catch {}
        const fixed = raw.replace(/(\"[^"\n]*\")["“”]+(\s*[,}\n])/g, '$1$2').replace(/[“”]/g, '"');
        try {
            const cfg = JSON.parse(fixed);
            console.warn('[config] ⚠️ تم إصلاح خطأ تنصيص في config.json تلقائياً. صحّحه في الملف لاحقاً.');
            return cfg;
        } catch {
            console.error('❌ ملف config.json فيه خطأ: ' + e1.message + '\nافتح الملف عند هذا السطر وتأكد من القيم بين علامتي تنصيص واحدة فقط، ومن الفواصل. أو استخدم DISCORD_TOKEN في الاستضافة واترك التوكن فارغاً في الملف.');
            process.exit(1);
        }
    }
}
let config = loadConfigFile();

function cleanToken(raw) {
    if (typeof raw !== 'string') return '';
    let t = raw.trim();
    if (/ضع_التوكن_هنا|استخدم_متغير_البيئة/i.test(t)) return '';
    if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'"))) t = t.slice(1, -1).trim();
    t = t.replace(/[\r\n\t\s]/g, '');
    if (!t || t.length < 50) return '';
    return t;
}
const DISCORD_ENV_TOKEN = cleanToken(process.env.DISCORD_TOKEN);
const TOKEN_ENV_TOKEN = cleanToken(process.env.TOKEN);
const BOT_ENV_TOKEN = cleanToken(process.env.BOT_TOKEN);
const ENV_TOKEN = DISCORD_ENV_TOKEN || TOKEN_ENV_TOKEN || BOT_ENV_TOKEN;
const CONFIG_TOKEN = cleanToken(config.bot?.token);
const BOT_TOKEN = ENV_TOKEN || CONFIG_TOKEN;
const TOKEN_SOURCE = DISCORD_ENV_TOKEN ? 'DISCORD_TOKEN' : (TOKEN_ENV_TOKEN ? 'TOKEN' : (BOT_ENV_TOKEN ? 'BOT_TOKEN' : (CONFIG_TOKEN ? 'config.json' : 'none')));
const BOT_ID = String(config.bot?.clientId || '').trim();
const SERVER_ID = String(config.bot?.guildId || '').trim();
if (!BOT_TOKEN) { console.error('❌ أضف DISCORD_TOKEN في بيئة الاستضافة أو bot.token في config.json'); process.exit(1); }
if (!/^\d{17,20}$/.test(BOT_ID) || !/^\d{17,20}$/.test(SERVER_ID)) { console.error('❌ clientId / guildId غلط'); process.exit(1); }
try { console.log('[build] RTU v' + require('./package.json').version); } catch {}
console.log(`[startup] Token loaded from ${TOKEN_SOURCE} (${BOT_TOKEN.length} characters) | Client: ${BOT_ID} | Guild: ${SERVER_ID}`);

const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(__dirname, 'data');
const V2 = require('./features/v2');
const IMG = V2.makeImages(DATA_DIR);
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
const FILES = {
    memberLogs: path.join(DATA_DIR, 'memberLogs.json'),
    accountingLogs: path.join(DATA_DIR, 'accountingLogs.json'),
    staffClock: path.join(DATA_DIR, 'staffClock.json'),
    ratings: path.join(DATA_DIR, 'ratings.json'),
    leftRoles: path.join(DATA_DIR, 'leftRoles.json'),
    savedRoles: path.join(DATA_DIR, 'savedRoles.json'),
    tickets: path.join(DATA_DIR, 'tickets.json'),
    counter: path.join(DATA_DIR, 'counter.json'),
    rewards: path.join(DATA_DIR, 'rewards.json'),
    stats: path.join(DATA_DIR, 'stats.json')
};
let memberLogs = {}, accountingLogs = [], staffClock = {}, savedRoles = {};
let staffRatings = {}; // userId -> [{stars, by, ticket, date}]
let leftMemberRoles = {}; // userId -> { roles: [], tag, leftAt }
let presencePending = {}; // userId -> { timeout, guildId, leftAt }
let afkCheckTimers = {}; // userId -> timeout (تحقق بعد 15 دقيقة من تسجيل الدخول)
let activeTickets = {}; // channelId -> ticket info
let ticketCounter = 1000;
let rewardsData = {}; // userId -> { balance, lastClaim, claims }
let statsData = {}; // userId -> { voiceMs: 0, messages: 0, joinedAt: null }
function writeJson(file, data) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const t = file + '.tmp';
    fs.writeFileSync(t, JSON.stringify(data, null, 2));
    fs.renameSync(t, file);
}
function loadData() {
    try { if (fs.existsSync(FILES.memberLogs)) memberLogs = JSON.parse(fs.readFileSync(FILES.memberLogs, 'utf8')); } catch {}
    try { if (fs.existsSync(FILES.accountingLogs)) accountingLogs = JSON.parse(fs.readFileSync(FILES.accountingLogs, 'utf8')); } catch {}
    try { if (fs.existsSync(FILES.staffClock)) staffClock = JSON.parse(fs.readFileSync(FILES.staffClock, 'utf8')); } catch {}
    try { if (fs.existsSync(FILES.ratings)) staffRatings = JSON.parse(fs.readFileSync(FILES.ratings, 'utf8')); } catch {}
    try { if (fs.existsSync(FILES.leftRoles)) leftMemberRoles = JSON.parse(fs.readFileSync(FILES.leftRoles, 'utf8')); } catch {}
    try { if (fs.existsSync(FILES.savedRoles)) savedRoles = JSON.parse(fs.readFileSync(FILES.savedRoles, 'utf8')); } catch {}
    try { if (fs.existsSync(FILES.tickets)) activeTickets = JSON.parse(fs.readFileSync(FILES.tickets, 'utf8')); } catch { activeTickets = {}; }
    try { if (fs.existsSync(FILES.rewards)) rewardsData = JSON.parse(fs.readFileSync(FILES.rewards, 'utf8')); } catch { rewardsData = {}; }
    try { if (fs.existsSync(FILES.stats)) statsData = JSON.parse(fs.readFileSync(FILES.stats, 'utf8')); } catch { statsData = {}; }
    try { if (fs.existsSync(FILES.counter)) ticketCounter = JSON.parse(fs.readFileSync(FILES.counter, 'utf8')).counter || 1000; } catch { ticketCounter = 1000; }
}
function saveAll() { try { writeJson(FILES.memberLogs, memberLogs); writeJson(FILES.accountingLogs, accountingLogs); writeJson(FILES.staffClock, staffClock); writeJson(FILES.savedRoles, savedRoles); writeJson(FILES.ratings, staffRatings); writeJson(FILES.leftRoles, leftMemberRoles); writeJson(FILES.tickets, activeTickets); writeJson(FILES.counter, { counter: ticketCounter }); writeJson(FILES.rewards, rewardsData); writeJson(FILES.stats, statsData); } catch (e) { console.error(e.message); } }
function saveConfig() { try { writeJson(CONFIG_PATH, config); } catch {} }
loadData();
// ترحيل مرة واحدة: إزالة النصوص الافتراضية القديمة من لوحة التذاكر (تُضبط الآن من /tickets)
(function cleanOldTicketDefaults() {
    try {
        const t = config.ticket; if (!t || t._defaultsCleaned) return;
        const OLD = { rules: 'يرجى مراجعة قوانين التذكرة قبل فتحها', title: 'مركز الدعم', desc: 'أهلاً بك في مركز الدعم، اختر القسم المناسب من القائمة بالأسفل' };
        if (t.rulesText === OLD.rules) t.rulesText = '';
        if (t.panel) {
            if (t.panel.rules === OLD.rules) t.panel.rules = '';
            if (t.panel.title === OLD.title) t.panel.title = '';
            if (t.panel.description === OLD.desc) t.panel.description = '';
        }
        t._defaultsCleaned = true;
        saveConfig();
    } catch {}
})();
setInterval(saveAll, 300000);

// نسخ احتياطي تلقائي لمجلد data كل 6 ساعات
setInterval(() => {
    try {
        const backupRoot = process.env.BACKUP_DIR ? path.resolve(process.env.BACKUP_DIR) : path.join(__dirname, 'backups');
        if (!fs.existsSync(backupRoot)) fs.mkdirSync(backupRoot, { recursive: true });
        const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
        const dest = path.join(backupRoot, 'data-' + stamp);
        fs.mkdirSync(dest, { recursive: true });
        for (const f of fs.readdirSync(DATA_DIR)) {
            const src = path.join(DATA_DIR, f);
            if (fs.statSync(src).isFile()) fs.copyFileSync(src, path.join(dest, f));
        }
        const dirs = fs.readdirSync(backupRoot).filter(d => d.startsWith('data-')).sort();
        while (dirs.length > 10) {
            const old = dirs.shift();
            try { fs.rmSync(path.join(backupRoot, old), { recursive: true, force: true }); } catch {}
        }
        console.log('[backup] data → ' + dest);
    } catch (e) { console.error('[backup]', e.message); }
}, 6 * 3600 * 1000);

const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildModeration, GatewayIntentBits.GuildVoiceStates, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMessageReactions, GatewayIntentBits.GuildExpressions || GatewayIntentBits.GuildEmojisAndStickers],
    partials: [Partials.Channel, Partials.Message, Partials.GuildMember, Partials.Reaction, Partials.User]
});
// ═══ الأنظمة المتقدمة (ترحيب • خط • إيمبد • ردود • رتب ذاتية • مستويات • رومات مؤقتة • إدارة الأوامر) ═══
const features = require('./features')({
    discord: require('discord.js'), client, fs, path, DATA_DIR, BLUE, SERVER_ID, V2, IMG,
    isAdmin: (m) => isAdmin(m), getConfig: () => config, getCMDS: () => CMDS,
    getAllStats: () => Object.entries(statsData).map(([uid, v]) => ({ uid, messages: v.messages || 0, voiceMs: (v.voiceMs || 0) + (v.joinedAt ? Date.now() - v.joinedAt : 0) })),
    fmtVoice: (ms) => fmtVoiceTime(ms),
    getClaims: (uid) => (ensureClock(uid).ticketsClaimed || 0),
    getStats: (uid) => {
        const s = ensureStats(uid);
        let ms = s.voiceMs || 0; if (s.joinedAt) ms += Date.now() - s.joinedAt;
        const rk = (key) => { const r = getRank(uid, key); return r && r[0] === '#' ? parseInt(r.slice(1), 10) : null; };
        return { messages: s.messages || 0, voiceMs: ms, chatRank: rk('messages'), voiceRank: rk('voiceMs') };
    },
    tk: {
        saveConfig: () => saveConfig(),
        buildPanelEmbed: (id) => buildPanelEmbed(id),
        buildPanelSelect: (id) => buildPanelSelect(id),
        buildPanelMessage: (id) => buildPanelMessage(id),
        refreshTicketPanel: (g) => refreshTicketPanel(g),
        deptSystemId: (d) => deptSystemId(d),
        adminRoleIds: () => adminRoleIds(),
        buildBotPermsPanel: (g, u) => buildBotPermsPanel(g, u),
        emojis: () => TICKET_EMOJIS,
        tEmo: (k) => tEmo(k),
        parseEmoji: (g, r) => parseEmojiInput(g, r),
        emo: (t) => emo(t)
    }
});
let startupWatchdog = null;
client.on('error', err => console.error('[discord] Client error:', err.message));
client.on('warn', message => console.warn('[discord] Warning:', message));
client.on('shardError', (err, shardId) => console.error(`[discord] Gateway error (shard ${shardId}):`, err.message));
client.on('shardDisconnect', (event, shardId) => console.error(`[discord] Gateway disconnected (shard ${shardId}, code ${event.code})`));
client.on('shardReconnecting', shardId => console.warn(`[discord] Gateway reconnecting (shard ${shardId})`));
client.on('shardResume', (shardId, replayedEvents) => console.log(`[discord] Gateway resumed (shard ${shardId}, replayed ${replayedEvents} events)`));

const LOGS_PER_PAGE = 2;
function getMod() { return config.moderation || {}; }
function getLogs(uid) { if (!memberLogs[uid]) memberLogs[uid] = []; return memberLogs[uid]; }
function fmtDate(ts) { const d = new Date(ts || Date.now()); return `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`; }
function fmtDur(ms) {
    if (!ms || ms <= 0) return 'دائم';
    const m = Math.floor(ms / 60000), h = Math.floor(m / 60), mm = m % 60;
    if (h >= 24) { const days = Math.floor(h / 24); return `${days} يوم` + (h % 24 ? ` و ${h % 24} ساعة` : ''); }
    if (h > 0) return `${h} ساعة` + (mm ? ` و ${mm} دقيقة` : '');
    return `${mm} دقيقة`;
}
function parseDur(str) {
    if (!str) return 0;
    const m = String(str).toLowerCase().match(/^(\d+)\s*(دقيقة|دقائق|min|m|ساعة|ساعات|h|يوم|أيام|d)?/i);
    if (!m) return 0;
    const n = parseInt(m[1], 10); const u = (m[2] || 'm').toLowerCase();
    if (u.startsWith('د') || u.startsWith('m')) return n * 60000;
    if (u.startsWith('س') || u.startsWith('h')) return n * 3600000;
    if (u.startsWith('ي') || u.startsWith('d')) return n * 86400000;
    return n * 60000;
}
function emoji(type) {
    const t = (type || '').toLowerCase();
    const E = (k, d) => { try { return features.H.E(k) || d; } catch { return d; } };
    if (t.includes('فك باند')) return E('mod.unban', '✅');
    if (t.includes('باند')) return E('mod.ban', '🚫');
    if (t.includes('تحذير')) return E('mod.warn', '⚠️');
    if (t.includes('ميوت') && t.includes('فك')) return E('mod.unmute', '🔊');
    if (t.includes('ميوت')) return E('mod.mute', '🔇');
    if (t.includes('كيك')) return E('mod.kick', '👢');
    if (t.includes('إلغاء استدعاء')) return E('mod.unsummon', '🔓');
    if (t.includes('استدعاء')) return E('mod.summon', '📢');
    if (t.includes('تفعيل')) return E('mod.activation', '❌');
    return E('mod.other', '📋');
}
function adminRoleIds() {
    // الإدارة العليا: رتبة أساسية + رتب إضافية (تُضبط بـ /setadmin)
    const ids = new Set();
    const main = config.roles?.admin || config.roles?.management;
    if (main) ids.add(main);
    for (const r of (config.roles?.admins || [])) if (r) ids.add(r);
    return [...ids];
}
function isAdmin(m) {
    // الإدارة العليا (أو Administrator في ديسكورد)
    if (!m) return false;
    if (m.permissions?.has?.('Administrator')) return true;
    return adminRoleIds().some(r => m.roles?.cache?.has(r));
}

// ═══ صلاحيات البوت لكل رتبة (تُضبط بـ /botperms) ═══
const BOT_PERMS = [
    { key: 'view_tickets', label: 'رؤية التذاكر غير المستلمة', emoji: '👁️', group: '🎫 التذاكر' },
    { key: 'claim',        label: 'استلام التذاكر',            emoji: '🎯', group: '🎫 التذاكر' },
    { key: 'close',        label: 'إغلاق التذاكر',             emoji: '🔒', group: '🎫 التذاكر' },
    { key: 'delete',       label: 'حذف التذاكر',               emoji: '🗑️', group: '🎫 التذاكر' },
    { key: 'rename',       label: 'تغيير اسم التذكرة',         emoji: '✏️', group: '🎫 التذاكر' },
    { key: 'summon',       label: 'استدعاء صاحب التذكرة',      emoji: '📢', group: '🎫 التذاكر' },
    { key: 'rate',         label: 'إرسال طلب التقييم',         emoji: '⭐', group: '🎫 التذاكر' },
    { key: 'clock',        label: 'الدوام والنقاط',            emoji: '🕐', group: '🛡️ البوت', desc: 'تسجيل دخول/خروج ولوحة الدوام' },
    { key: 'stats',        label: 'الإحصائيات والتقييمات',     emoji: '📊', group: '🛡️ البوت', desc: '/ticketstats • /rating • /staffpoints' }
];
function hasBotPerm(m, perm) {
    if (!m) return false;
    if (isAdmin(m)) return true;
    const perms = config.ticket?.staffRolePermissions || {};
    for (const roleId of m.roles?.cache?.keys?.() || []) {
        if (perms[roleId] && perms[roleId][perm] === true) return true;
    }
    return false;
}
function isStaff(m, perm) {
    // بدون perm = للإدارة العليا فقط. مع perm = الإدارة أو رتبة مُنحت هذه الصلاحية من /botperms
    return perm ? hasBotPerm(m, perm) : isAdmin(m);
}
const TICKET_ACTIONS = ['view_tickets', 'claim', 'close', 'delete', 'rename', 'summon', 'rate'];
function deptOf(ticket) { return ticket && (config.departments || []).find(d => d.id === ticket.departmentId); }
function ticketStaffRoleIds(ticket) {
    const strictRole = deptOf(ticket)?.roleId;
    if (strictRole) return [strictRole]; // القسم له رتبة: هذه الرتبة فقط
    const ids = new Set();
    const legacy = config.roles?.support;
    const deptRole = ticket && (config.departments || []).find(d => d.id === ticket.departmentId)?.roleId;
    if (legacy) ids.add(legacy);
    if (deptRole) ids.add(deptRole);
    const perms = config.ticket?.staffRolePermissions || {};
    for (const [roleId, settings] of Object.entries(perms)) {
        if (settings && TICKET_ACTIONS.some(k => settings[k] === true)) ids.add(roleId);
    }
    return [...ids];
}
function ticketViewerRoleIds(ticket) {
    // الرتب التي ترى التذكرة وهي غير مستلمة
    const strictRole = deptOf(ticket)?.roleId;
    if (strictRole) return [strictRole];
    return ticketStaffRoleIds(ticket).filter(roleId => {
        const settings = config.ticket?.staffRolePermissions?.[roleId];
        if (settings) return settings.view_tickets === true || settings.claim === true;
        const deptRole = ticket && (config.departments || []).find(d => d.id === ticket.departmentId)?.roleId;
        return roleId === config.roles?.support || roleId === deptRole;
    });
}
function hasTicketPermission(member, action, ticket) {
    if (!member) return false;
    if (isAdmin(member)) return true;
    const permissions = config.ticket?.staffRolePermissions || {};
    const ticketDeptRole = ticket && (config.departments || []).find(d => d.id === ticket.departmentId)?.roleId;
    for (const roleId of member.roles?.cache?.keys?.() || []) {
        const hasRole = ticketDeptRole ? roleId === ticketDeptRole : (roleId === config.roles?.support || Object.prototype.hasOwnProperty.call(permissions, roleId));
        if (!hasRole) continue;
        const explicit = permissions[roleId];
        if (explicit && Object.prototype.hasOwnProperty.call(explicit, action)) {
            if (explicit[action] === true) return true;
            continue;
        }
        // توافق مع رتبة الدعم والأقسام القديمة التي لم تُضبط من /setbotrole.
        if (roleId === config.roles?.support || roleId === ticketDeptRole) return true;
    }
    return false;
}
async function resolveUser(message, raw) {
    if (!raw) return null;
    const id = String(raw).replace(/[<@!>]/g, '');
    if (/^\d{17,20}$/.test(id)) { try { return await client.users.fetch(id); } catch { return null; } }
    return null;
}
function addLog(userId, entry) {
    const logs = getLogs(userId);
    const full = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 5), type: entry.type, reason: entry.reason || 'بدون سبب', modId: entry.modId, modTag: entry.modTag, duration: entry.duration || null, durationMs: entry.durationMs || 0, endsAt: entry.endsAt || null, active: entry.active !== false, date: Date.now() };
    logs.push(full); saveAll(); return full;
}
async function sendLog(guild, type, embed) {
    const L = getMod().logs || {};
    const chId = L[type] || (type === 'permban' ? L.ban : null) || L.general;
    if (!chId) return;
    try {
        if (!embed.data?.footer) embed.setFooter({ text: guild.name + ' • RTU Moderation', ...(guild.iconURL?.() ? { iconURL: guild.iconURL() } : {}) });
        const ch = await guild.channels.fetch(chId).catch(() => null); if (ch?.isTextBased()) await ch.send({ embeds: [embed] });
    } catch {}
}
function actionEmbed(type, target, mod, reason, extra = {}) {
    const ts = Math.floor(Date.now() / 1000);
    const e = new EmbedBuilder()
        .setColor(BLUE)
        .setTitle(emoji(type) + '  ' + type)
        .addFields(
            { name: '👤 العضو', value: '<@' + target.id + '>\n`' + (target.username || target.id) + '`\n`' + target.id + '`', inline: true },
            { name: '👮 المسؤول', value: '<@' + mod.id + '>\n`' + (mod.username || mod.id) + '`', inline: true }
        );
    if (extra.duration) e.addFields({ name: '⏳ المدة', value: '`' + extra.duration + '`', inline: true });
    e.addFields(
        { name: '📝 السبب', value: '```' + String(reason || 'بدون سبب').slice(0, 900) + '```' },
        { name: '🕐 الوقت', value: '<t:' + ts + ':F>  ·  <t:' + ts + ':R>' }
    ).setTimestamp();
    try { const mav = mod.displayAvatarURL?.({ size: 64 }); e.setAuthor({ name: 'نظام الرقابة', ...(mav ? { iconURL: mav } : {}) }); } catch {}
    e.setFooter({ text: (extra.caseId ? 'Case #' + extra.caseId + ' • ' : '') + 'RTU Moderation' });
    try { const av = target.displayAvatarURL?.({ size: 128 }); if (av) e.setThumbnail(av); } catch {}
    e._meta = { type, target, mod, reason, extra };
    return e;
}

/** رسالة التأكيد التي تظهر في الروم بعد تنفيذ إجراء (اللوق يبقى كما هو) */
function confirmEmbed(emb) {
    const m = emb && emb._meta;
    if (!m) return emb;
    const t = String(m.type || '');
    const verbs = [
        ['فك باند', '✅ تم رفع الحظر', 'تم فك الحظر عن <@{id}> بنجاح.', BLUE],
        ['باند نهائي', '⛔ تم الحظر النهائي', 'تم تبنيد <@{id}> **نهائياً** من الماب.', BLUE],
        ['باند مؤقت', '⏳ تم الحظر المؤقت', 'تم حظر <@{id}> مؤقتاً.', BLUE],
        ['باند', '🚫 تم تنفيذ الحظر', 'تم حظر <@{id}> بنجاح.', BLUE],
        ['فك ميوت', '🔊 تم فك الكتم', 'تم فك الكتم عن <@{id}> بنجاح.', BLUE],
        ['ميوت', '🔇 تم تنفيذ الكتم', 'تم كتم <@{id}> بنجاح.', BLUE],
        ['تحذير', '⚠️ تم إصدار تحذير', 'تم توجيه تحذير رسمي إلى <@{id}>.', BLUE],
        ['كيك', '👢 تم الطرد', 'تم طرد <@{id}> من السيرفر.', BLUE],
        ['إلغاء استدعاء', '✅ تم إلغاء الاستدعاء', 'تم إلغاء استدعاء <@{id}> وإعادة رتبه.', BLUE],
        ['استدعاء', '📢 تم الاستدعاء', 'تم استدعاء <@{id}> للرقابة.', BLUE],
        ['تفعيل', '❌ تم سحب التفعيل', 'تم سحب تفعيل <@{id}>.', BLUE]
    ];
    const v = verbs.find(x => t.includes(x[0]));
    if (!v) return emb;
    const e = new EmbedBuilder()
        .setColor(v[3])
        .setTitle(v[1])
        .setDescription(v[2].replace('{id}', m.target.id))
        .addFields(
            { name: '👤 العضو', value: '<@' + m.target.id + '>', inline: true },
            { name: '👮 المسؤول', value: '<@' + m.mod.id + '>', inline: true },
            ...(m.extra && m.extra.duration ? [{ name: '⏳ المدة', value: '`' + m.extra.duration + '`', inline: true }] : []),
            { name: '📝 السبب', value: '```' + String(m.reason || 'بدون سبب').slice(0, 900) + '```' }
        )
        .setFooter({ text: (m.extra && m.extra.caseId ? 'رقم القضية: ' + m.extra.caseId + ' • ' : '') + 'تم تسجيل الإجراء في السجل' })
        .setTimestamp();
    try { const av = m.target.displayAvatarURL?.({ size: 128 }); if (av) e.setThumbnail(av); } catch {}
    return e;
}

const STAR_LABELS = { 5: 'ممتاز', 4: 'جيد جداً', 3: 'جيد', 2: 'مقبول', 1: 'ضعيف' };
/** متوسط تقييم موظف: { avg, count } */
function staffRatingStats(staffId) {
    const list = (typeof staffRatings !== 'undefined' && staffRatings[staffId]) || [];
    if (!list.length) return { avg: 0, count: 0 };
    return { avg: list.reduce((a, r) => a + (r.stars || 0), 0) / list.length, count: list.length };
}
const starBar = n => '★'.repeat(n) + '☆'.repeat(Math.max(0, 5 - n));
/** نقاط إضافية حسب التقييم — قابلة للتعديل من config.ticket.ratingPoints */
function ratingBonus(stars) {
    const map = (config.ticket && config.ticket.ratingPoints) || { 5: 2, 4: 1 };
    return Number(map[stars]) || 0;
}
function fmtResponse(ms) {
    const s = Math.max(0, Math.round(ms / 1000));
    if (s < 60) return s + ' ثانية';
    const m = Math.floor(s / 60);
    if (m < 60) return m + ' دقيقة';
    const h = Math.floor(m / 60);
    return h + ' ساعة و' + (m % 60) + ' دقيقة';
}
/** بطاقة نتيجة التقييم (تُرسل في روم التقييمات) */
async function buildRatingResult(guild, staffId, raterId, stars, ticketNum, feedback) {
    const st = staffRatingStats(staffId);
    const entry = Object.values(activeTickets).find(tk => String(tk.ticketNumber) === String(ticketNum));
    let roleLine = '';
    try {
        const m = guild && await guild.members.fetch(staffId);
        const top = m && m.roles.highest && m.roles.highest.id !== guild.id ? m.roles.highest : null;
        if (top) roleLine = '<@&' + top.id + '> • ';
    } catch {}
    const bonus = ratingBonus(stars);
    const kids = [
        V2.text('## ⭐ شكراً لرأيك يعسل'), V2.sep(),
        V2.text('**عضو:** <@' + raterId + '>'), V2.sep(),
        V2.text('**التقييم:** ' + '⭐'.repeat(stars)), V2.sep(),
        V2.text('**الفيدباك:** ' + (feedback ? String(feedback).slice(0, 600) : '—')), V2.sep(),
        V2.text('**إداري:** ' + roleLine + '<@' + staffId + '>'),
        V2.text('-# متوسط الإداري **' + st.avg.toFixed(2) + '/5** من ' + st.count + ' تقييم' + (bonus ? '  •  +' + bonus + ' نقطة' : ''))
    ];
    return { components: [V2.container(kids, V2.parseColor('#0F2A66', V2.NAVY))], flags: V2.IS_V2, allowedMentions: { parse: [] } };
}
/** طلب التقييم (يُرسل في الخاص): نص + زر «تقييم» */
function buildRatingRequest(t, guild, ownerId) {
    const kids = [
        V2.text('## ⭐ تقييم الخدمة'),
        V2.text('شكراً لتواصلك مع فريق الدعم في **' + guild.name + '**.\nتم إغلاق تذكرتك رقم **#' + t.ticketNumber + '** بنجاح.'),
        V2.sep(),
        V2.text('نرجو تقييم الإداري <@' + t.claimedBy + '> الذي قام بخدمتك.\nرأيك يساعدنا على تطوير مستوى الخدمة باستمرار.'),
        V2.sep(),
        new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('rate_open_' + t.ticketNumber + '_' + t.claimedBy + '_' + (ownerId || '0')).setLabel('تقييم الخدمة').setEmoji('⭐').setStyle(ButtonStyle.Primary)
        ),
        V2.text('-# ' + guild.name + ' • يستغرق التقييم ثوانٍ معدودة')
    ];
    return { components: [V2.container(kids, V2.parseColor('#0F2A66', V2.NAVY))], flags: V2.IS_V2 };
}
/** رسالة الشكر بعد إرسال التقييم (تستبدل رسالة الطلب) */
function buildRatingThanks(staffId, stars, guild, feedback) {
    const kids = [
        V2.text('## ✅ شكراً لرأيك'),
        V2.sep(),
        V2.text('**الإداري:** <@' + staffId + '>\n**تقييمك:** ' + '⭐'.repeat(stars) + (feedback ? '\n**ملاحظتك:** ' + String(feedback).slice(0, 400) : '')),
        V2.sep(),
        V2.text('-# ' + (guild ? guild.name : 'فريق الدعم') + ' • نسعد بخدمتك دائماً')
    ];
    return { components: [V2.container(kids, V2.parseColor('#0F2A66', V2.NAVY))], flags: V2.IS_V2, allowedMentions: { parse: [] } };
}
async function recordRating(staffId, raterId, ticketNum, stars, guild, feedback) {
    if (!staffRatings[staffId]) staffRatings[staffId] = [];
    staffRatings[staffId].push({ stars, by: raterId, ticket: ticketNum, date: Date.now(), feedback: feedback ? String(feedback).slice(0, 600) : '' });
    const bonus = ratingBonus(stars);
    if (bonus) { const clk = ensureClock(staffId); clk.points = (clk.points || 0) + bonus; }
    saveAll();
    try {
        if (!guild) { console.error('[rating] السيرفر غير موجود، ما أقدر أرسل لوق التقييم'); return; }
        const payload = await buildRatingResult(guild, staffId, raterId, stars, ticketNum, feedback);
        const tc = config.ticket || {};
        let ch = null;
        for (const id of [tc.ratingChannelId, tc.logsChannelId]) {
            if (!id) continue;
            ch = await guild.channels.fetch(id).catch(() => null);
            if (ch) break;
        }
        if (!ch) {
            const entry = Object.entries(activeTickets).find(([, tk]) => String(tk.ticketNumber) === String(ticketNum));
            if (entry) ch = await guild.channels.fetch(entry[0]).catch(() => null);
        }
        if (!ch) { console.error('[rating] ما فيه روم تقييم — حدده من /tickets'); return; }
        await ch.send(payload);
        console.log('[rating] تم إرسال التقييم إلى #' + ch.name);
    } catch (e) { console.error('[rating] فشل إرسال لوق التقييم:', e.message); }
}

/** لوحة صدارة نقاط الإدارة (كانت مستدعاة بدون تعريف، تم إضافتها) */
function buildStaffPointsBoard() {
    const rows = Object.entries(staffClock)
        .map(([uid, c]) => ({ uid, points: c.points || 0, tickets: c.ticketsClaimed || 0, week: c.totalMsWeek || 0 }))
        .filter(r => r.points > 0 || r.tickets > 0 || r.week > 0)
        .sort((a, b) => b.points - a.points)
        .slice(0, 10);
    const medals = ['🥇', '🥈', '🥉'];
    const g = client.guilds.cache.get(SERVER_ID);
    const icon = g?.iconURL?.({ size: 256 });
    const e = new EmbedBuilder().setColor(BLUE).setTitle('🏆 لوحة صدارة نقاط الإدارة').setTimestamp();
    if (icon) e.setThumbnail(icon);
    if (!rows.length) return e.setDescription('لا توجد نقاط مسجّلة حتى الآن.');
    e.setDescription(rows.map((r, idx) =>
        (medals[idx] || '**' + (idx + 1) + '.**') + ' <@' + r.uid + '>\n' +
        '> 🏆 النقاط: **' + r.points + '**  •  🎫 التذاكر: **' + r.tickets + '**  •  ⭐ التقييم: **' + (staffRatingStats(r.uid).count ? staffRatingStats(r.uid).avg.toFixed(1) + '/5' : '—') + '**  •  ⏱️ الأسبوع: `' + fmtDur(r.week) + '`'
    ).join('\n\n'));
    e.setFooter({ text: 'أفضل 10 موظفين حسب النقاط' });
    return e;
}

function ensureClock(uid) { if (!staffClock[uid]) staffClock[uid] = { in: null, totalMsToday: 0, totalMsWeek: 0, lastPointAt: 0, points: 0, ticketsClaimed: 0 }; if (staffClock[uid].points == null) staffClock[uid].points = 0; if (staffClock[uid].ticketsClaimed == null) staffClock[uid].ticketsClaimed = 0; return staffClock[uid]; }

/** ترقيات التذاكر: عتبات استلام → رتب (قابلة للتعديل من الإعدادات) */
const DEFAULT_TICKET_RANKS = [
    { claims: 20, roleId: '', label: 'رتبة 20' },
    { claims: 40, roleId: '', label: 'رتبة 40' },
    { claims: 50, roleId: '', label: 'رتبة 50' },
    { claims: 60, roleId: '', label: 'رتبة 60' },
    { claims: 80, roleId: '', label: 'رتبة 80' }
];
function getTicketRanks() {
    const tc = getTicketCfg();
    if (!Array.isArray(tc.ranks) || !tc.ranks.length) {
        tc.ranks = DEFAULT_TICKET_RANKS.map(r => ({ ...r }));
        return tc.ranks;
    }
    return tc.ranks.sort((a, b) => a.claims - b.claims);
}
function nextTicketRank(claimed) {
    const ranks = getTicketRanks();
    for (const r of ranks) if (claimed < r.claims) return r;
    return null;
}
function currentTicketRank(claimed) {
    const ranks = getTicketRanks();
    let cur = null;
    for (const r of ranks) if (claimed >= r.claims) cur = r;
    return cur;
}
async function applyTicketRanks(guild, userId, claimed) {
    if (!guild || !userId) return [];
    const ranks = getTicketRanks().filter(r => r.roleId && claimed >= r.claims);
    if (!ranks.length) return [];
    let member;
    try { member = await guild.members.fetch(userId); } catch { return []; }
    const added = [];
    for (const r of ranks) {
        if (member.roles.cache.has(r.roleId)) continue;
        try {
            await member.roles.add(r.roleId, 'ترقية تذاكر: ' + claimed + ' استلام');
            added.push(r);
        } catch (e) { console.error('[ticketrank] add role:', e.message); }
    }
    return added;
}
function buildMyRankEmbed(user, claimed) {
    const ranks = getTicketRanks();
    const cur = currentTicketRank(claimed);
    const nxt = nextTicketRank(claimed);
    const lines = ranks.map(r => {
        const done = claimed >= r.claims;
        const role = r.roleId ? '<@&' + r.roleId + '>' : '`' + (r.label || ('رتبة ' + r.claims)) + '`';
        return (done ? '✅' : '🔒') + ' **' + r.claims + '** استلام ← ' + role;
    });
    const e = new EmbedBuilder().setColor(BLUE)
        .setTitle('👑 ترقياتي')
        .setDescription('كل تذكرة تستلمها أول واحد = **+1 نقطة استلام**\nوصلت الرقم؟ تترقى تلقائياً.')
        .addFields(
            { name: '🎫 استلاماتك', value: '**' + claimed + '**', inline: true },
            { name: '📌 رتبتك الحالية', value: cur ? (cur.roleId ? '<@&' + cur.roleId + '>' : (cur.label || String(cur.claims))) : '`لا توجد بعد`', inline: true },
            { name: '🎯 التالية', value: nxt ? ('**' + nxt.claims + '** استلام (باقي **' + (nxt.claims - claimed) + '**)') : '`وصلت أعلى رتبة`', inline: true },
            { name: '📋 سلم الترقيات', value: lines.join('\n') || '`لم يُضبط بعد`' }
        )
        .setFooter({ text: 'اكتب /myrank في أي وقت' })
        .setTimestamp();
    if (user) e.setAuthor({ name: user.username, iconURL: user.displayAvatarURL({ size: 128 }) });
    return e;
}
function buildRanksInfoEmbed() {
    const ranks = getTicketRanks();
    const lines = ranks.map(r => {
        const role = r.roleId ? '<@&' + r.roleId + '>' : '`' + (r.label || 'رتبة') + '`';
        return '🎟️ **' + r.claims + '** استلام ← ' + role;
    });
    return new EmbedBuilder().setColor(BLUE)
        .setTitle('👑 شرح الترقيات')
        .setDescription('🎟️ كل تذكرة تستلمها **أول واحد** = **+1 نقطة**\n\nوصلت رقم معين؟ تترقى تلقائياً 👑')
        .addFields({ name: 'سلم الترقيات', value: lines.join('\n') || '`لم تُضبط الرتب بعد`' })
        .setFooter({ text: 'اكتب /myrank عشان تشوف كم عندك وكم باقي للترقية الجاية' })
        .setTimestamp();
}

function getSupportVoiceIds() {
    const m = config.moderation || {};
    if (Array.isArray(m.supportVoiceChannelIds) && m.supportVoiceChannelIds.length) return m.supportVoiceChannelIds;
    if (m.supportVoiceChannelId) return [m.supportVoiceChannelId];
    return [];
}
function isSupportVoice(channelId) {
    if (!channelId) return false;
    return getSupportVoiceIds().includes(channelId);
}



function buildAutoClockOutEmbed(uid, channelName, sessionMs, dailyMs, weeklyMs) {
    let desc = '';
    desc += 'تم تسجيل خروجك تلقائياً لأنك غادرت' + '\n';
    desc += 'الرومات الصوتية المخصصة للدعم' + '\n';
    desc += 'الفني.' + '\n\n';
    desc += '**الروم السابق**' + '\n';
    desc += '• ' + (channelName || 'الدعم الفني') + '\n\n';
    desc += '**مدة المباشرة**' + '\n';
    desc += '`' + fmtDur(sessionMs) + '`' + '\n\n';
    desc += '**الإجمالي اليومي**' + '\n';
    desc += '`' + fmtDur(dailyMs) + '`' + '\n\n';
    desc += '**الإجمالي الأسبوعي**' + '\n';
    desc += '`' + fmtDur(weeklyMs) + '`';
    return new EmbedBuilder()
        .setColor(BLUE)
        .setTitle('⚠️ تم إيقاف حساب وقتك تلقائياً')
        .setDescription(desc)
        .setTimestamp();
}
function buildClockInEmbed(uid, channelId, auto) {
    return new EmbedBuilder()
        .setColor(BLUE)
        .setTitle('🟢 تسجيل دخول — الدعم الفني')
        .addFields(
            { name: '👤 الموظف', value: '<@' + uid + '>', inline: true },
            { name: '🎧 الروم', value: channelId ? '<#' + channelId + '>' : '-', inline: true },
            { name: '🕐 الوقت', value: '<t:' + Math.floor(Date.now() / 1000) + ':T>', inline: true }
        )
        .setFooter({ text: auto ? 'تم تسجيل الدخول تلقائياً عند دخول روم الدعم' : 'تم تسجيل الدخول يدوياً' })
        .setTimestamp();
}
function buildMyTimeEmbed(c, user) {
    const e = new EmbedBuilder()
        .setColor(BLUE)
        .setTitle('⏱️ ملخص وقت الدوام')
        .addFields(
            { name: '📌 الحالة', value: c.in ? '🟢 مسجّل الدخول' : '🔴 غير مسجّل', inline: true },
            { name: '📅 اليوم', value: '`' + fmtDur(c.totalMsToday || 0) + '`', inline: true },
            { name: '📆 الأسبوع', value: '`' + fmtDur(c.totalMsWeek || 0) + '`', inline: true }
        );
    if (c.in) e.addFields({ name: '⏳ الجلسة الحالية', value: '`' + fmtDur(Date.now() - c.in) + '`', inline: true });
    if (user) { e.setAuthor({ name: user.username, iconURL: user.displayAvatarURL?.({ size: 64 }) }); }
    return e;
}
function buildClockOutDM(channelName, sessionMs, dailyMs, weeklyMs, auto) {
    if (auto) return buildAutoClockOutEmbed(null, channelName, sessionMs, dailyMs, weeklyMs);
    return new EmbedBuilder()
        .setColor(BLUE)
        .setTitle('🔴 تم تسجيل الخروج')
        .setDescription('تم تسجيل خروجك من الدعم الفني بنجاح، شكراً لجهودك.')
        .addFields(
            { name: '⏱️ مدة الجلسة', value: '`' + fmtDur(sessionMs) + '`', inline: true },
            { name: '📅 اليوم', value: '`' + fmtDur(dailyMs) + '`', inline: true },
            { name: '📆 الأسبوع', value: '`' + fmtDur(weeklyMs) + '`', inline: true }
        )
        .setTimestamp();
}
function buildClockOutLog(uid, sessionMs) {
    return new EmbedBuilder()
        .setColor(BLUE)
        .setTitle('🔴 تسجيل خروج — الدعم الفني')
        .addFields(
            { name: '👤 الموظف', value: '<@' + uid + '>', inline: true },
            { name: '⏱️ مدة الجلسة', value: '`' + fmtDur(sessionMs) + '`', inline: true },
            { name: '🕐 الوقت', value: '<t:' + Math.floor(Date.now() / 1000) + ':T>', inline: true }
        )
        .setTimestamp();
}
function buildSupportLeaveLog(uid, channelName, sessionMs, dailyMs, weeklyMs) {
    let desc = '';
    desc += '**الموظف**\n<@' + uid + '>\n\n';
    desc += '**الحالة**\nغادر روم الدعم الفني الصوتي ولم يؤكد تواجده خلال المهلة المحددة.\n\n';
    desc += '**الروم السابق**\n' + (channelName || 'غير معروف') + '\n\n';
    desc += '⏱️ **مدة الجلسة**\n`' + fmtDur(sessionMs) + '`\n\n';
    desc += '📅 **اليومي**\n`' + fmtDur(dailyMs) + '`\n\n';
    desc += '📆 **الأسبوعي**\n`' + fmtDur(weeklyMs) + '`\n\n';
    desc += '🕐 **وقت المغادرة**\n<t:' + Math.floor(Date.now() / 1000) + ':f>\n\n';
    desc += 'يرجى من الإدارة العليا المراجعة.';
    return new EmbedBuilder()
        .setColor(BLUE)
        .setTitle('🎧 الدعم الفني الصوتي — مغادرة')
        .setDescription(desc)
        .setTimestamp();
}
function buildPresenceEmbed(minutes) {
    return new EmbedBuilder()
        .setColor(BLUE)
        .setTitle('⚠️ التحقق من التواجد')
        .setDescription(
            'أنت مسجل دخولك في الدعم الفني منذ\n**' + minutes + '** دقيقة\n\n' +
            'هل هل ما زلت متواجداً؟\n' +
            'اضغط الزر خلال **دقيقة ونصف** للتأكيد.\n\n' +
            'في حال عدم الاستجابة سيتم **خصم نقاط** وإشعار الإدارة.'
        )
        .setTimestamp();
}
function presenceButton() {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('presence_yes').setLabel('نعم أنا هنا').setStyle(ButtonStyle.Success).setEmoji('✅')
    );
}

/** بعد 15 دقيقة من تسجيل الدخول → رسالة تحقق في الخاص، لو ما رد يخصم نقاط */
function scheduleAfkCheck(uid, guildId) {
    if (afkCheckTimers[uid]) {
        clearTimeout(afkCheckTimers[uid]);
        delete afkCheckTimers[uid];
    }
    const mins = (getMod().presenceMinutes != null) ? getMod().presenceMinutes : 15;
    const FIFTEEN_MIN = mins * 60 * 1000;
    const REPLY_WINDOW = 90 * 1000; // 90 ثانية للرد على التحقق الدوري
    const DEDUCT_POINTS = (getMod().presenceDeductPoints != null) ? getMod().presenceDeductPoints : 2;

    afkCheckTimers[uid] = setTimeout(async () => {
        delete afkCheckTimers[uid];
        try {
            const c = staffClock[uid];
            if (!c || !c.in) return; // خرج أصلاً
            // وصل لحد الإعفاء (مثلاً 50 دقيقة) → بدون رسالة تحقق ولا تنبيه
            if (isPresenceExempt(uid)) return;

            // أرسل تحقق في الخاص
            let sent = false;
            try {
                const u = await client.users.fetch(uid);
                await u.send({ embeds: [buildPresenceEmbed(mins)], components: [presenceButton()] });
                sent = true;
            } catch (e) {
                console.error('[afk] فشل إرسال تحقق الخاص لـ', uid, e.message);
            }

            // إذا ما رد خلال REPLY_WINDOW → خصم نقاط
            // نستخدم presencePending عشان زر "نعم أنا هنا" يلغي الخصم
            if (presencePending[uid]?.timeout) clearTimeout(presencePending[uid].timeout);
            presencePending[uid] = {
                guildId,
                leftAt: Date.now(),
                minutes: 15,
                channelName: 'تحقق دوري',
                isAfkCheck: true,
                timeout: setTimeout(async () => {
                    try {
                        if (!presencePending[uid] || !presencePending[uid].isAfkCheck) return;
                        delete presencePending[uid];
                        const stillIn = staffClock[uid]?.in;
                        if (!stillIn) return;
                        // خصم نقاط
                        const c2 = ensureClock(uid);
                        const before = c2.points || 0;
                        c2.points = Math.max(0, before - DEDUCT_POINTS);
                        saveAll();
                        const guild = client.guilds.cache.get(guildId) || await client.guilds.fetch(guildId).catch(() => null);
                        const emb = new EmbedBuilder().setColor(BLUE).setTitle('⚠️ لم يتم الرد على التحقق')
                            .setDescription('<@' + uid + '> لم يرد على رسالة التحقق بعد 15 دقيقة من تسجيل الدخول.\nتم خصم **' + DEDUCT_POINTS + '** نقطة. (كان: ' + before + ' → صار: ' + c2.points + ')')
                            .setTimestamp();
                        if (guild) await sendLog(guild, 'clock', emb);
                        try {
                            const u = await client.users.fetch(uid);
                            await u.send({ embeds: [new EmbedBuilder().setColor(BLUE).setTitle('⚠️ خصم نقاط')
                                .setDescription(`لم تقم بالرد على رسالة التحقق خلال الوقت المحدد.\nتم خصم **${DEDUCT_POINTS}** نقطة من رصيدك.\nرصيدك الحالي: **${c2.points}**`).setTimestamp()] });
                        } catch {}
                    } catch (e) {
                        console.error('[afk] deduct error', e.message);
                    }
                }, REPLY_WINDOW)
            };
        } catch (e) {
            console.error('[afk] schedule error', e.message);
        }
    }, FIFTEEN_MIN);
}

/** الحد (بالدقائق) الذي بعده لا تُرسل رسائل تحقق/تنبيه ولا يُخصم شيء. 0 = معطّل. يتغير من /staffpoints إعداد */
function getPresenceExemptMinutes() {
    const v = getMod().presenceExemptMinutes;
    return (v != null && !isNaN(v)) ? Number(v) : 50;
}
function sessionMinutes(uid) {
    const c = staffClock[uid];
    return (c && c.in) ? Math.floor((Date.now() - c.in) / 60000) : 0;
}
function isPresenceExempt(uid) {
    const lim = getPresenceExemptMinutes();
    return lim > 0 && sessionMinutes(uid) >= lim;
}

/** لوجو التذكرة: المخصص من الإعدادات، وإلا أيقونة السيرفر، وإلا صورة البوت */
function getTicketLogo(guild) {
    const t = (config.ticket && config.ticket.embed && config.ticket.embed.logo) || '';
    if (/^https?:\/\//.test(t)) return t;
    try {
        const g = guild || client.guilds.cache.get(SERVER_ID);
        const gi = g && g.iconURL && g.iconURL({ size: 256 });
        if (gi) return gi;
    } catch {}
    try { return client.user?.displayAvatarURL({ size: 256 }) || null; } catch { return null; }
}

function clearAfkCheck(uid) {
    if (afkCheckTimers[uid]) {
        clearTimeout(afkCheckTimers[uid]);
        delete afkCheckTimers[uid];
    }
}


// ═══════════════ الباند: سحب كل الرتب ووضع رتبة الباند فقط ═══════════════
function banKey(id) { return 'ban:' + id; }
// كل رتب الباند: عادي (banned) • مؤقت (tempban) • نهائي (permban)
function allBanRoleIds() {
    const r = config.roles || {};
    return [...new Set([r.banned || r.ban, r.tempban, r.permban].filter(Boolean))];
}
// kind: 'normal' | 'temp' | 'perm'  (لو الرتبة الخاصة غير محددة يرجع للباند العادي)
function pickBanRole(kind) {
    const r = config.roles || {};
    const normal = r.banned || r.ban;
    if (kind === 'temp') return r.tempban || normal;
    if (kind === 'perm') return r.permban || normal;
    return normal;
}
function heldBanRole(member) { return allBanRoleIds().find(id => member.roles.cache.has(id)); }
async function applyBanRoles(member, banRoleId, reason) {
    const ids = allBanRoleIds();
    if (!heldBanRole(member)) {
        savedRoles[banKey(member.id)] = member.roles.cache
            .filter(r => r.id !== member.guild.id && !ids.includes(r.id) && !r.managed)
            .map(r => r.id);
    }
    const keep = member.roles.cache.filter(r => r.managed).map(r => r.id);
    await member.roles.set([banRoleId, ...keep], 'باند: ' + reason);
    saveAll();
}
async function liftBanRoles(member, banRoleId, reason) {
    const saved = savedRoles[banKey(member.id)];
    delete savedRoles[banKey(member.id)];
    const keep = member.roles.cache.filter(r => r.managed).map(r => r.id);
    if (saved && saved.length) {
        const ids = allBanRoleIds();
        const valid = saved.filter(id => member.guild.roles.cache.has(id) && !ids.includes(id));
        await member.roles.set([...new Set([...valid, ...keep])], reason);
    } else {
        const held = allBanRoleIds().filter(id => member.roles.cache.has(id));
        await member.roles.remove(held.length ? held : banRoleId, reason);
    }
    saveAll();
}

// ═══════════════ دخول / خروج الأعضاء ═══════════════
function fmtRoleList(names) { return (names && names.length) ? names.map(n => '• ' + n).join('\n') : 'لا يوجد'; }
function memberHeader(id, username, nick) {
    return '**يوزر روبلوكس:**\n`' + (nick || username) + '`\n' +
        '**الحساب:** <@' + id + '> (`' + username + '`)\n' +
        '**المعرف:** `' + id + '`';
}
function buildMemberLeaveEmbed(user, rec) {
    const e = new EmbedBuilder().setColor(BLUE).setTitle('📤 عضو غادر السيرفر')
        .setDescription(
            memberHeader(user.id, user.username || rec.tag || 'unknown', rec.nick) + '\n\n' +
            '🏷️ **الرتب التي كانت معه**\n' + fmtRoleList(rec.roleNames) + '\n\n' +
            'ℹ️ **ملاحظة**\nإذا عاد العضو خلال **24 ساعة** فستُعاد له جميع رتبه واسمه تلقائياً.')
        .setFooter({ text: 'معرف العضو: ' + user.id }).setTimestamp();
    try { const av = user.displayAvatarURL?.({ size: 128 }); if (av) e.setThumbnail(av); } catch {}
    return e;
}
function buildMemberReturnEmbed(user, rec, within, restoredNames, failed) {
    const e = new EmbedBuilder().setTimestamp().setFooter({ text: 'معرف العضو: ' + user.id });
    if (within) {
        e.setColor(BLUE).setTitle('🔄 عودة عضو (خلال 24 ساعة)')
            .setDescription(
                memberHeader(user.id, user.username, rec.nick) + '\n\n' +
                '🏷️ **الرتب التي تمت إعادتها**\n' + fmtRoleList(restoredNames) +
                (failed ? '\n\n⚠️ تعذّر إرجاع ' + failed + ' رتبة (تأكد أن رتبة البوت فوقها).' : '') + '\n\n' +
                'ℹ️ **ملاحظة**\nعاد العضو خلال 24 ساعة، وتمت إعادة الرتب والاسم تلقائياً.');
    } else {
        e.setColor(BLUE).setTitle('🔄 عودة عضو (بعد 24 ساعة)')
            .setDescription(
                memberHeader(user.id, user.username, rec.nick).replace('**يوزر روبلوكس:**', '**يوزر روبلوكس السابق:**') + '\n\n' +
                '⚠️ **ملاحظة**\nعاد العضو بعد مرور أكثر من 24 ساعة، لذلك لم تتم إعادة الرتب تلقائياً.');
    }
    try { const av = user.displayAvatarURL?.({ size: 128 }); if (av) e.setThumbnail(av); } catch {}
    return e;
}

const ACTION_STYLES = [
    { test: t => t.includes('إلغاء استدعاء'), color: BLUE, title: '✅ إشعار إلغاء الاستدعاء', intro: 'نفيدك بأنه تم **إلغاء استدعائك** في **{g}**، وتمت إعادة جميع رتبك السابقة.', outro: 'نشكر تعاونك.' },
    { test: t => t.includes('استدعاء'), color: BLUE, title: '📢 إشعار استدعاء للرقابة', intro: 'نفيدك بأنه تم **استدعاؤك** في **{g}**.', outro: 'يرجى التوجه إلى الرقابة في أقرب وقت.' },
    { test: t => t.includes('باند') && t.includes('فك'), color: BLUE, title: '✅ إشعار فك الحظر', intro: 'نفيدك بأنه تم **فك الحظر** عن حسابك في **{g}**.', outro: 'نأمل منك الالتزام بقوانين السيرفر.' },
    { test: t => t.includes('باند نهائي'), color: BLUE, title: '⛔ إشعار حظر نهائي', intro: 'نفيدك بأنه تم **تبنيدك نهائياً من الماب** في **{g}**.', outro: 'هذا القرار نهائي. إذا كان لديك اعتراض فيمكنك التواصل مع الإدارة.' },
    { test: t => t.includes('باند مؤقت'), color: BLUE, title: '⏳ إشعار حظر مؤقت', intro: 'نفيدك بأنه تم **حظر حسابك مؤقتاً** في **{g}**.', outro: 'سيتم فك الحظر تلقائياً بعد انتهاء المدة.' },
    { test: t => t.includes('باند'), color: BLUE, title: '🚫 إشعار حظر', intro: 'نفيدك بأنه تم **حظر حسابك** في **{g}**.', outro: 'إذا كان لديك اعتراض فيمكنك التواصل مع الإدارة.' },
    { test: t => t.includes('ميوت') && t.includes('فك'), color: BLUE, title: '🔊 إشعار فك الكتم', intro: 'نفيدك بأنه تم **فك الكتم** عنك في **{g}**.', outro: 'نأمل منك الالتزام بقوانين السيرفر.' },
    { test: t => t.includes('ميوت'), color: BLUE, title: '🔇 إشعار كتم', intro: 'نفيدك بأنه تم **كتمك** في **{g}**.', outro: 'يرجى الالتزام بقوانين السيرفر.' },
    { test: t => t.includes('تحذير'), color: BLUE, title: '⚠️ إشعار تحذير رسمي', intro: 'نفيدك بأنه تم توجيه **تحذير** إليك في **{g}**.', outro: 'نأمل منك الالتزام بقوانين السيرفر لتجنّب اتخاذ إجراءات إضافية.' },
    { test: t => t.includes('تفعيل'), color: BLUE, title: '❌ إشعار سحب التفعيل', intro: 'نفيدك بأنه تم **سحب تفعيل** حسابك وسحب رتبك في **{g}**.', outro: 'للاستفسار يرجى التواصل مع الإدارة.' }
];
async function sendActionDM(user, guild, type, reason, mod, extra = {}) {
    try {
        const t = (type || '').toLowerCase();
        const icon = guild.iconURL?.({ size: 256 }) || null;
        const st = ACTION_STYLES.find(x => x.test(t)) || { color: BLUE, title: '📋 إشعار من الإدارة', intro: 'نفيدك بإجراء **' + type + '** في **{g}**.', outro: '' };
        const ts = Math.floor(Date.now() / 1000);
        const emb = new EmbedBuilder()
            .setColor(st.color)
            .setAuthor({ name: guild.name, ...(icon ? { iconURL: icon } : {}) })
            .setTitle(st.title)
            .setDescription(st.intro.replace('{g}', guild.name) + (st.outro ? '\n\n' + st.outro : ''))
            .addFields(
                { name: '📝 السبب', value: '```' + String(reason || 'بدون سبب').slice(0, 900) + '```' },
                { name: '👮 بواسطة', value: mod ? '<@' + mod.id + '>' : 'الإدارة', inline: true },
                ...(extra.duration ? [{ name: '⏳ المدة', value: '`' + extra.duration + '`', inline: true }] : []),
                { name: '🕐 الوقت', value: '<t:' + ts + ':F>', inline: true }
            )
            .setFooter({ text: guild.name + ' • هذه رسالة تلقائية من نظام الرقابة', ...(icon ? { iconURL: icon } : {}) })
            .setTimestamp();
        if (icon) emb.setThumbnail(icon);
        await user.send({ embeds: [emb] });
        return true;
    } catch {
        return false;
    }
}

function buildSijill(user, logs, page, total) {
    const start = (page - 1) * LOGS_PER_PAGE;
    const slice = logs.slice().reverse().slice(start, start + LOGS_PER_PAGE);
    let desc = '**إجمالي:** `' + logs.length + '` · **صفحة:** `' + page + '/' + total + '`\n\n';
    if (!logs.length) {
        desc += 'لا توجد سجلات.';
    } else {
        slice.forEach((l, i) => {
            const n = logs.length - (start + i);
            desc += '**#' + n + '** ' + emoji(l.type) + ' **' + (l.type || '-') + '**\n';
            desc += 'السبب: ' + (l.reason || '-') + '\n';
            desc += 'بواسطة: <@' + l.modId + '>\n';
            if (l.duration) desc += 'المدة: ' + l.duration + '\n';
            desc += '`' + fmtDate(l.date) + '`\n\n';
        });
    }
    return new EmbedBuilder()
        .setColor(BLUE)
        .setAuthor({ name: '📋 السجل الكامل للعضو' })
        .setDescription('**العضو:** <@' + user.id + '>\n`' + user.id + '`\n\n' + desc)
        .setTimestamp();
}
function sijillBtns(uid, page, total) {
    return [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('sijill_prev_' + uid + '_' + page).setLabel('السابق').setStyle(ButtonStyle.Secondary).setDisabled(page <= 1),
        new ButtonBuilder().setCustomId('sijill_next_' + uid + '_' + page).setLabel('التالي').setStyle(ButtonStyle.Secondary).setDisabled(page >= total),
        new ButtonBuilder().setCustomId('sijill_refresh_' + uid + '_' + page).setLabel('تحديث').setStyle(ButtonStyle.Primary)
    )];
}

async function cmdSijill(msg, arg) {
    if (!isStaff(msg.member, 'mod')) return msg.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
    const u = await resolveUser(msg, arg.trim().split(/\s+/)[0]);
    if (!u) return msg.reply({ content: '📌 **طريقة الاستخدام:** `-سجل @العضو`' });
    const logs = getLogs(u.id);
    const total = Math.max(1, Math.ceil(logs.length / LOGS_PER_PAGE));
    await msg.reply({ embeds: [buildSijill(u, logs, 1, total)], components: sijillBtns(u.id, 1, total) });
}
async function cmdWarn(msg, arg) {
    if (!isStaff(msg.member, 'mod')) return msg.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
    const p = arg.trim().split(/\s+/);
    const u = await resolveUser(msg, p[0]);
    if (!u) return msg.reply({ content: '📌 **طريقة الاستخدام:** `-تحذير @العضو السبب`' });
    const reason = p.slice(1).join(' ') || 'بدون سبب';
    const e = addLog(u.id, { type: 'تحذير', reason, modId: msg.author.id, modTag: msg.author.username });
    const emb = actionEmbed('تحذير', u, msg.author, reason, { caseId: e.id });
    await msg.reply({ embeds: [confirmEmbed(emb)] }); await sendLog(msg.guild, 'warn', emb);
    const dmOk = await sendActionDM(u, msg.guild, 'تحذير', reason, msg.author);
    if (!dmOk) try { await msg.channel.send(`⚠️ تعذّر إرسال رسالة خاصة إلى <@${u.id}>`); } catch {}
}
async function cmdKick(msg, arg) {
    if (!isStaff(msg.member, 'mod')) return msg.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
    const p = arg.trim().split(/\s+/);
    const u = await resolveUser(msg, p[0]);
    if (!u) return msg.reply({ content: '📌 **طريقة الاستخدام:** `-كيك @العضو السبب`' });
    const reason = p.slice(1).join(' ') || 'بدون سبب';
    const m = await msg.guild.members.fetch(u.id).catch(() => null);
    if (!m?.kickable) return msg.reply({ content: '❌ لا أستطيع طرد هذا العضو، تحقق من ترتيب رتبة البوت وصلاحياته.' });
    try { await m.kick(reason); } catch (e) { return msg.reply({ content: '❌ ' + e.message }); }
    const e = addLog(u.id, { type: 'كيك', reason, modId: msg.author.id, modTag: msg.author.username });
    const emb = actionEmbed('كيك', u, msg.author, reason, { caseId: e.id });
    await msg.reply({ embeds: [confirmEmbed(emb)] }); await sendLog(msg.guild, 'kick', emb);
}
async function cmdBan(msg, arg) {
    if (!isStaff(msg.member, 'mod')) return msg.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
    const p = arg.trim().split(/\s+/);
    const u = await resolveUser(msg, p[0]);
    if (!u) return msg.reply({ content: '📌 **طريقة الاستخدام:** `-باند @العضو السبب`' });
    const reason = p.slice(1).join(' ') || 'بدون سبب';
    const banRoleId = pickBanRole('normal');
    if (!banRoleId) return msg.reply({ content: '❌ حدد رتبة الباند: `/setrole type:باند role:@الرتبة`' });
    const m = await msg.guild.members.fetch(u.id).catch(() => null);
    if (!m) return msg.reply({ content: '❌ هذا العضو غير موجود في السيرفر.' });
    try {
        await applyBanRoles(m, banRoleId, reason);
    } catch (e) {
        const tip = /Missing Permissions|50013/i.test(e.message) ? '\n⚠️ ارفع رتبة البوت + Manage Roles' : '';
        return msg.reply({ content: '❌ فشل رتبة الباند: ' + e.message + tip });
    }
    const e = addLog(u.id, { type: 'باند ماب', reason, modId: msg.author.id, modTag: msg.author.username, active: true });
    const emb = actionEmbed('باند ماب', u, msg.author, reason, { caseId: e.id });
    await msg.reply({ embeds: [confirmEmbed(emb)] });
    await sendLog(msg.guild, 'ban', emb);
    const dmOk = await sendActionDM(u, msg.guild, 'باند', reason, msg.author);
    if (!dmOk) { try { await msg.channel.send('⚠️ تعذّر إرسال رسالة خاصة إلى <@' + u.id + '>'); } catch {} }
}
async function cmdUnban(msg, arg) {
    if (!isStaff(msg.member, 'mod')) return msg.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
    const p = arg.trim().split(/\s+/);
    const u = await resolveUser(msg, p[0]);
    if (!u) return msg.reply({ content: '📌 **طريقة الاستخدام:** `-فكباند @العضو [السبب]`' });
    const reason = p.slice(1).join(' ') || 'فك باند الماب';
    const banRoleId = allBanRoleIds()[0];
    if (!banRoleId) return msg.reply({ content: '❌ رتبة الباند غير محددة. `/setrole type:باند`' });
    const m = await msg.guild.members.fetch(u.id).catch(() => null);
    if (!m) return msg.reply({ content: '❌ هذا العضو غير موجود في السيرفر.' });
    try {
        if (heldBanRole(m)) await liftBanRoles(m, heldBanRole(m), reason);
        else return msg.reply({ content: '⚠️ هذا العضو لا يملك رتبة الباند.' });
    } catch (e) { return msg.reply({ content: '❌ ' + e.message }); }
    getLogs(u.id).forEach(l => { if ((l.type || '').includes('باند') && l.active) l.active = false; });
    const e = addLog(u.id, { type: 'فك باند ماب', reason, modId: msg.author.id, modTag: msg.author.username });
    saveAll();
    const emb = actionEmbed('فك باند ماب', u, msg.author, reason, { caseId: e.id });
    await msg.reply({ embeds: [confirmEmbed(emb)] });
    await sendLog(msg.guild, 'unban', emb);
    await sendActionDM(u, msg.guild, 'فك باند', reason, msg.author);
}
async function cmdMute(msg, arg) {
    if (!isStaff(msg.member, 'mod')) return msg.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
    const p = arg.trim().split(/\s+/);
    const u = await resolveUser(msg, p[0]);
    if (!u) return msg.reply({ content: '📌 **طريقة الاستخدام:** `-ميوت @العضو السبب [مدة]`' });
    const m = await msg.guild.members.fetch(u.id).catch(() => null);
    if (!m?.moderatable) return msg.reply({ content: '❌ لا أستطيع كتم هذا العضو، تحقق من ترتيب رتبة البوت وصلاحياته.' });
    let dur = null, rp = p.slice(1);
    if (rp.length >= 2 && parseDur(rp.slice(-2).join(' ')) > 0) { dur = rp.slice(-2).join(' '); rp = rp.slice(0, -2); }
    const reason = rp.join(' ') || 'بدون سبب';
    let ms = parseDur(dur) || (getMod().defaultMuteMinutes || 60) * 60000;
    if (!dur) dur = fmtDur(ms);
    try { await m.timeout(ms, reason); } catch (e) { return msg.reply({ content: '❌ ' + e.message }); }
    const e = addLog(u.id, { type: 'ميوت', reason, modId: msg.author.id, modTag: msg.author.username, duration: dur, durationMs: ms, endsAt: Date.now() + ms, active: true });
    const emb = actionEmbed('ميوت', u, msg.author, reason, { caseId: e.id, duration: dur });
    await msg.reply({ embeds: [confirmEmbed(emb)] }); await sendLog(msg.guild, 'mute', emb);
    await sendActionDM(u, msg.guild, 'ميوت', reason, msg.author);
}
async function cmdUnmute(msg, arg) {
    if (!isStaff(msg.member, 'mod')) return msg.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
    const p = arg.trim().split(/\s+/);
    const u = await resolveUser(msg, p[0]);
    if (!u) return msg.reply({ content: '📌 **طريقة الاستخدام:** `-فكميوت @العضو`' });
    const m = await msg.guild.members.fetch(u.id).catch(() => null);
    if (!m) return msg.reply({ content: '❌ هذا العضو غير موجود في السيرفر.' });
    const reason = p.slice(1).join(' ') || 'فك الميوت';
    try { await m.timeout(null, reason); } catch (e) { return msg.reply({ content: '❌ ' + e.message }); }
    const e = addLog(u.id, { type: 'فك ميوت', reason, modId: msg.author.id, modTag: msg.author.username });
    getLogs(u.id).forEach(l => { if ((l.type || '').includes('ميوت') && l.active) l.active = false; });
    saveAll();
    const emb = actionEmbed('فك ميوت', u, msg.author, reason, { caseId: e.id });
    await msg.reply({ embeds: [confirmEmbed(emb)] }); await sendLog(msg.guild, 'unmute', emb);
}
async function cmdSummon(msg, arg) {
    if (!isStaff(msg.member, 'mod')) return msg.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
    const p = arg.trim().split(/\s+/);
    const u = await resolveUser(msg, p[0]);
    if (!u) return msg.reply({ content: '📌 **طريقة الاستخدام:** `-استدعاء @العضو السبب`' });
    const reason = p.slice(1).join(' ') || 'استدعاء إداري';
    const m = await msg.guild.members.fetch(u.id).catch(() => null);
    if (!m) return msg.reply({ content: '❌ هذا العضو غير موجود في السيرفر.' });
    savedRoles[u.id] = m.roles.cache.filter(r => r.id !== msg.guild.id).map(r => r.id);
    const summonRoleId = config.roles?.summon;
    if (!summonRoleId) {
        await msg.reply({ content: '❌ حدد رتبة الاستدعاء أولاً: `/setrole type:استدعاء role:@الرتبة`' });
        return;
    }
    try {
        // نسحب كل الرتب ونحط فقط رتبة الاستدعاء
        await m.roles.set([summonRoleId], 'استدعاء إدارة');
    } catch (e) {
        const tip = /Missing Permissions|50013/i.test(e.message)
            ? '\n⚠️ ارفع رتبة البوت فوق رتبة العضو، وأعطه صلاحية Manage Roles.'
            : '';
        await msg.channel.send('❌ فشل سحب الرتب: ' + e.message + tip);
        return;
    }
    const e = addLog(u.id, { type: 'استدعاء', reason, modId: msg.author.id, modTag: msg.author.username });
    accountingLogs.push({ id: e.id, type: 'استدعاء', reason, modId: msg.author.id, modTag: msg.author.username, targetId: u.id, targetTag: u.username, date: Date.now() });
    saveAll();
    const emb = actionEmbed('استدعاء', u, msg.author, reason, { caseId: e.id });
    await msg.reply({ embeds: [confirmEmbed(emb)] }); await sendLog(msg.guild, 'summon', emb);
    const dmOk = await sendActionDM(u, msg.guild, 'استدعاء', reason, msg.author);
    if (!dmOk) try { await msg.channel.send(`⚠️ تعذّر إرسال رسالة خاصة إلى <@${u.id}>`); } catch {}
}
async function cmdUnsummon(msg, arg) {
    if (!isStaff(msg.member, 'mod')) return msg.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
    const p = arg.trim().split(/\s+/);
    const u = await resolveUser(msg, p[0]);
    if (!u) return msg.reply({ content: '📌 **طريقة الاستخدام:** `-الغاءاستدعاء @العضو`' });
    const reason = p.slice(1).join(' ') || 'إلغاء استدعاء';
    const m = await msg.guild.members.fetch(u.id).catch(() => null);
    if (!m) return msg.reply({ content: '❌ هذا العضو غير موجود في السيرفر.' });
    try {
        if (savedRoles[u.id]?.length) await m.roles.set(savedRoles[u.id], 'إلغاء استدعاء');
        else if (config.roles?.summon) await m.roles.remove(config.roles.summon, 'إلغاء استدعاء');
        delete savedRoles[u.id];
    } catch (e) { await msg.channel.send('❌ حدث خطأ: ' + e.message); }
    const e = addLog(u.id, { type: 'إلغاء استدعاء', reason, modId: msg.author.id, modTag: msg.author.username });
    accountingLogs.push({ id: e.id, type: 'إلغاء استدعاء', reason, modId: msg.author.id, modTag: msg.author.username, targetId: u.id, targetTag: u.username, date: Date.now() });
    saveAll();
    const emb = actionEmbed('إلغاء استدعاء', u, msg.author, reason, { caseId: e.id });
    await msg.reply({ embeds: [confirmEmbed(emb)] }); await sendLog(msg.guild, 'unsummon', emb);
    await sendActionDM(u, msg.guild, 'إلغاء استدعاء', reason, msg.author);
}
async function cmdActivation(msg, arg) {
    if (!isStaff(msg.member, 'mod')) return msg.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
    const p = arg.trim().split(/\s+/);
    const u = await resolveUser(msg, p[0]);
    if (!u) return msg.reply({ content: '📌 **طريقة الاستخدام:** `-سحب_تفعيل @العضو`' });
    const reason = p.slice(1).join(' ') || 'سحب تفعيل';
    const m = await msg.guild.members.fetch(u.id).catch(() => null);
    if (!m) return msg.reply({ content: '❌ هذا العضو غير موجود في السيرفر.' });
    // سحب كل الرتب عند سحب التفعيل
    savedRoles[u.id] = m.roles.cache.filter(r => r.id !== msg.guild.id).map(r => r.id);
    try {
        await m.roles.set([], 'سحب تفعيل - سحب كل الرتب');
    } catch (e) {
        const tip = /Missing Permissions|50013/i.test(e.message)
            ? '\n⚠️ ارفع رتبة البوت فوق رتب العضو + صلاحية Manage Roles.'
            : '';
        return msg.reply({ content: '❌ فشل سحب الرتب: ' + e.message + tip });
    }
    const e = addLog(u.id, { type: 'سحب تفعيل', reason, modId: msg.author.id, modTag: msg.author.username });
    accountingLogs.push({ id: e.id, type: 'سحب تفعيل', reason, modId: msg.author.id, modTag: msg.author.username, targetId: u.id, targetTag: u.username, date: Date.now() });
    saveAll();
    const emb = actionEmbed('سحب تفعيل', u, msg.author, reason, { caseId: e.id });
    await msg.reply({ embeds: [confirmEmbed(emb)] }); await sendLog(msg.guild, 'activation', emb);
    await sendActionDM(u, msg.guild, 'سحب تفعيل', reason, msg.author);
}
async function cmdMuhasaba(msg, arg) {
    const p = (arg || '').trim().split(/\s+/).filter(Boolean);
    if (p.length) {
        if (!isStaff(msg.member, 'mod')) return msg.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
        const u = await resolveUser(msg, p[0]);
        if (!u) return msg.reply({ content: '📌 **طريقة الاستخدام:** `-محاسبة @العضو`' });
        const emb = new EmbedBuilder().setColor(BLUE).setAuthor({ name: 'لوحة الرقابة' })
            .setTitle('🛡️ محاسبة عضو')
            .setDescription('اختر الإجراء المناسب من القائمة بالأسفل.')
            .addFields(
                { name: '👤 العضو', value: '<@' + u.id + '>\n`' + u.username + '`', inline: true },
                { name: '👮 الرقابي', value: '<@' + msg.author.id + '>', inline: true },
                { name: '🆔 المعرف', value: '`' + u.id + '`', inline: true }
            ).setTimestamp();
        try { emb.setThumbnail(u.displayAvatarURL({ size: 128 })); } catch {}
        const row = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder().setCustomId('censor_' + u.id).setPlaceholder('🛡️ اختر الإجراء المطلوب')
                .addOptions(
                    { label: 'تحذيرات', description: 'إعطاء تحذير للعضو', value: 'warn', emoji: '⚠️' },
                    { label: 'باند', description: 'حظر أو فك حظر العضو', value: 'ban', emoji: '🚫' },
                    { label: 'استدعاء', description: 'استدعاء العضو للرقابة', value: 'summon', emoji: '📢' },
                    { label: 'إلغاء استدعاء', description: 'إلغاء استدعاء العضو', value: 'unsummon', emoji: '✅' },
                    { label: 'سحب تفعيل', description: 'سحب تفعيل العضو', value: 'activation', emoji: '❌' }
                )
        );
        return msg.reply({ embeds: [confirmEmbed(emb)], components: [row] });
    }
    if (!accountingLogs.length) return msg.reply({ embeds: [new EmbedBuilder().setColor(BLUE).setAuthor({ name: '📋 سجل المحاسبة' }).setDescription('لا توجد إجراءات مسجّلة حتى الآن.\nاستخدم `-محاسبة @عضو` لبدء إجراء.')] });
    let desc = '';
    for (const e of accountingLogs.slice(-8).reverse()) {
        desc += `${emoji(e.type)} **${e.type}**\n> 👮 الرقابي: <@${e.modId}>\n> 👤 العضو: <@${e.targetId}>\n> 📝 السبب: ${e.reason || '-'}\n> 🕐 \`${fmtDate(e.date)}\`\n\n`;
    }
    await msg.reply({ embeds: [new EmbedBuilder().setColor(BLUE).setAuthor({ name: '📋 سجل المحاسبة' }).setDescription(desc)] });
}
async function cmdClockIn(msg) {
    if (!isStaff(msg.member, 'clock')) return msg.reply({ content: '❌ هذا الأمر مخصص للمسؤولين فقط.' });
    if (!msg.member.voice?.channelId) return msg.reply({ content: '❌ يجب أن تكون داخل روم صوتي أولاً.' });
    const c = ensureClock(msg.author.id);
    if (c.in) return msg.reply({ content: '⚠️ لديك تسجيل دخول نشط بالفعل.' });
    c.in = Date.now(); c.lastPointAt = Date.now(); saveAll();
    scheduleAfkCheck(msg.author.id, msg.guild.id);
    const emb = buildClockInEmbed(msg.author.id, msg.member.voice.channelId, false);
    await msg.reply({ embeds: [confirmEmbed(emb)] }); await sendLog(msg.guild, 'clock', emb);
}
async function cmdClockOut(msg) {
    if (!isStaff(msg.member, 'clock')) return msg.reply({ content: '❌ هذا الأمر مخصص للمسؤولين فقط.' });
    clearAfkCheck(msg.author.id);
    const c = ensureClock(msg.author.id);
    if (!c.in) return msg.reply({ content: '⚠️ لست مسجّل الدخول حالياً.' });
    const elapsed = Date.now() - c.in;
    c.totalMsToday = (c.totalMsToday || 0) + elapsed;
    c.totalMsWeek = (c.totalMsWeek || 0) + elapsed;
    c.in = null; saveAll();
    const emb = buildClockOutLog(msg.author.id, elapsed);
    await msg.reply({ embeds: [confirmEmbed(emb)] }); await sendLog(msg.guild, 'clock', emb);
    try {
        const mins = Math.floor(elapsed / 60000);
        await msg.author.send({ embeds: [buildClockOutDM('الدعم الفني', elapsed, c.totalMsToday, c.totalMsWeek, false)] });
    } catch {}
}
async function cmdMyTime(msg) {
    const c = ensureClock(msg.author.id);
    await msg.reply({ embeds: [buildMyTimeEmbed(c, msg.author)] });
}
async function cmdClockPanel(msg) {
    if (!isStaff(msg.member, 'clock')) return msg.reply({ content: '❌ هذا الأمر مخصص للمسؤولين فقط.' });
    if (features.H.clockpanel) await features.H.clockpanel.send(msg.channel);
    try { await msg.delete(); } catch {}
}

// ═══════════════ نظام المكافآت (مكافأة / توب / معلومات) ═══════════════
function getRewardsCfg() {
    const r = config.rewards || {};
    return {
        channelId: r.channelId || '',
        min: r.min != null ? Number(r.min) : 100,
        max: r.max != null ? Number(r.max) : 1000,
        hours: r.hours != null ? Number(r.hours) : 24,
        currency: r.currency || 'RT'
    };
}
const fmtNum = n => Number(n || 0).toLocaleString('en-US');
function fmtHM(ms) {
    const m = Math.max(0, Math.floor(ms / 60000));
    return Math.floor(m / 60) + ' ساعة و ' + (m % 60) + ' دقيقة';
}
function ensureReward(uid) {
    if (!rewardsData[uid]) rewardsData[uid] = { balance: 0, lastClaim: 0, claims: 0 };
    return rewardsData[uid];
}
/** يعمل فقط في الروم المحدد بأمر /setrewards */
function rewardsGate(msg) {
    const cfg = getRewardsCfg();
    return !!cfg.channelId && msg.channelId === cfg.channelId;
}
async function cmdReward(msg) {
    if (!rewardsGate(msg)) return;
    const cfg = getRewardsCfg();
    const d = ensureReward(msg.author.id);
    const cd = cfg.hours * 3600000;
    const left = (d.lastClaim || 0) + cd - Date.now();
    if (d.lastClaim && left > 0) {
        return msg.reply({ embeds: [new EmbedBuilder().setColor(BLUE)
            .setTitle('⏳ المكافأة غير متاحة الآن')
            .setDescription('لقد استلمت المكافأة مسبقاً.\nيمكنك استلام المكافأة التالية بعد **' + fmtHM(left) + '**\n(<t:' + Math.floor((d.lastClaim + cd) / 1000) + ':R>)')] });
    }
    const lo = Math.min(cfg.min, cfg.max), hi = Math.max(cfg.min, cfg.max);
    const amount = lo + Math.floor(Math.random() * (hi - lo + 1));
    d.balance += amount; d.lastClaim = Date.now(); d.claims = (d.claims || 0) + 1;
    saveAll();
    return msg.reply({ embeds: [new EmbedBuilder().setColor(BLUE)
        .setTitle('⭐ مكافأة يومية')
        .setDescription('لقد حصلت على **' + fmtNum(amount) + ' ' + cfg.currency + '**!')] });
}
function buildTopPage(page) {
    const cfg = getRewardsCfg();
    const all = Object.entries(rewardsData).filter(([, v]) => (v.balance || 0) > 0).sort((a, b) => b[1].balance - a[1].balance);
    const per = 10, pages = Math.max(1, Math.ceil(all.length / per));
    page = Math.min(Math.max(1, page), pages);
    const slice = all.slice((page - 1) * per, page * per);
    const desc = slice.length
        ? slice.map(([uid, v], idx) => '**#' + ((page - 1) * per + idx + 1) + '** | <@' + uid + '> — **' + fmtNum(v.balance) + ' ' + cfg.currency + '**').join('\n')
        : 'لا توجد نقاط مسجّلة حتى الآن.';
    return {
        page, pages,
        embed: new EmbedBuilder().setColor(BLUE).setTitle('🏆 قائمة التوب — الصفحة ' + page).setDescription(desc)
            .setFooter({ text: 'صفحة ' + page + ' من ' + pages })
    };
}
function topButtons(page, pages, ownerId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('rtop_' + (page - 1) + '_' + ownerId).setLabel('السابق').setEmoji('◀️').setStyle(ButtonStyle.Secondary).setDisabled(page <= 1),
        new ButtonBuilder().setCustomId('rtop_' + (page + 1) + '_' + ownerId).setLabel('التالي').setEmoji('▶️').setStyle(ButtonStyle.Secondary).setDisabled(page >= pages)
    );
}
async function cmdTop(msg) {
    if (!rewardsGate(msg)) return;
    const p = buildTopPage(1);
    return msg.reply({ embeds: [p.embed], components: p.pages > 1 ? [topButtons(p.page, p.pages, msg.author.id)] : [] });
}
async function cmdRewardInfo(msg) {
    if (!rewardsGate(msg)) return;
    const cfg = getRewardsCfg();
    const d = ensureReward(msg.author.id);
    const cd = cfg.hours * 3600000;
    const ago = d.lastClaim ? 'قبل ' + fmtHM(Date.now() - d.lastClaim) : 'لم تستلم أي مكافأة بعد';
    const left = (d.lastClaim || 0) + cd - Date.now();
    const next = (!d.lastClaim || left <= 0) ? '✅ متاحة الآن، اكتب `مكافأة`' : 'بعد ' + fmtHM(left);
    return msg.reply({ embeds: [new EmbedBuilder().setColor(BLUE)
        .setTitle('📊 معلومات حسابك')
        .setDescription(
            '**العضو :**\n<@' + msg.author.id + '>\n\n' +
            '**رصيدك :**\n' + fmtNum(d.balance) + ' ' + cfg.currency + '\n\n' +
            '**آخر مكافأة حصلت عليها :**\n' + ago + '\n\n' +
            '**موعد المكافأة القادمة :**\n' + next)] });
}

// ═══════════════ نظام الإحصائيات (حسابي / توب فويس / توب شات) ═══════════════
function getStatsCfg() {
    const s = config.stats || {};
    return {
        channelId: s.channelId || '',
        account: String(s.account || 'حسابي').toLowerCase().replace(/\s+/g, ''),
        top: String(s.top || 'توب').toLowerCase().replace(/\s+/g, ''),
        topvoice: String(s.topvoice || 'فويس').toLowerCase().replace(/\s+/g, ''),
        topchat: String(s.topchat || 'شات').toLowerCase().replace(/\s+/g, '')
    };
}
function statsGate(msg) {
    const cfg = getStatsCfg();
    return !!cfg.channelId && msg.channelId === cfg.channelId;
}
function ensureStats(uid) {
    if (!statsData[uid]) statsData[uid] = { voiceMs: 0, messages: 0, joinedAt: null };
    return statsData[uid];
}
function fmtVoiceTime(ms) {
    const totalMin = Math.max(0, Math.floor(Number(ms || 0) / 60000));
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    return h + ' ساعة و ' + m + ' دقيقة';
}
function getRank(uid, key) {
    const sorted = Object.entries(statsData)
        .filter(([, v]) => (v[key] || 0) > 0)
        .sort((a, b) => (b[1][key] || 0) - (a[1][key] || 0));
    const idx = sorted.findIndex(([id]) => id === uid);
    return idx === -1 ? '—' : '#' + (idx + 1);
}
function buildStatsAccountEmbed(user) {
    const s = ensureStats(user.id);
    let liveMs = s.voiceMs || 0;
    if (s.joinedAt) liveMs += Date.now() - s.joinedAt;
    const vRank = getRank(user.id, 'voiceMs');
    const mRank = getRank(user.id, 'messages');
    const emb = new EmbedBuilder()
        .setColor(BLUE)
        .setAuthor({ name: user.username + ' — إحصائيات', iconURL: user.displayAvatarURL({ size: 128 }) })
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .setDescription(
            '🎤 **وقت الفويس**\n' + fmtVoiceTime(liveMs) + '\n\n' +
            '🏆 **ترتيب الفويس**\n' + vRank + '\n\n' +
            '💬 **رسائل الشات**\n' + (s.messages || 0).toLocaleString('en-US') + '\n\n' +
            '🏆 **ترتيب الشات**\n' + mRank
        )
        .setFooter({ text: user.username + ' | طلب بواسطة' });
    return emb;
}
function buildTopVoiceEmbed(page = 1) {
    const all = Object.entries(statsData)
        .map(([uid, v]) => {
            let ms = v.voiceMs || 0;
            if (v.joinedAt) ms += Date.now() - v.joinedAt;
            return [uid, ms];
        })
        .filter(([, ms]) => ms > 0)
        .sort((a, b) => b[1] - a[1]);
    const per = 10;
    const pages = Math.max(1, Math.ceil(all.length / per));
    page = Math.min(Math.max(1, page), pages);
    const slice = all.slice((page - 1) * per, page * per);
    const medals = ['🥇', '🥈', '🥉'];
    const lines = slice.length
        ? slice.map(([uid, ms], i) => {
            const rank = (page - 1) * per + i + 1;
            const medal = rank <= 3 ? medals[rank - 1] + ' ' : '';
            return medal + '**#' + rank + '** — <@' + uid + '> — **' + fmtVoiceTime(ms) + '**';
        }).join('\n')
        : '*لا توجد بيانات بعد*';
    return new EmbedBuilder()
        .setColor(BLUE)
        .setTitle('🎤 توب الفويس')
        .setDescription(lines)
        .setFooter({ text: 'الصفحة ' + page + '/' + pages });
}
function buildTopChatEmbed(page = 1) {
    const all = Object.entries(statsData)
        .filter(([, v]) => (v.messages || 0) > 0)
        .sort((a, b) => (b[1].messages || 0) - (a[1].messages || 0));
    const per = 10;
    const pages = Math.max(1, Math.ceil(all.length / per));
    page = Math.min(Math.max(1, page), pages);
    const slice = all.slice((page - 1) * per, page * per);
    const medals = ['🥇', '🥈', '🥉'];
    const lines = slice.length
        ? slice.map(([uid, v], i) => {
            const rank = (page - 1) * per + i + 1;
            const medal = rank <= 3 ? medals[rank - 1] + ' ' : '';
            return medal + '**#' + rank + '** — <@' + uid + '> — **' + (v.messages || 0).toLocaleString('en-US') + '** رسالة';
        }).join('\n')
        : '*لا توجد بيانات بعد*';
    return new EmbedBuilder()
        .setColor(BLUE)
        .setTitle('💬 توب الشات')
        .setDescription(lines)
        .setFooter({ text: 'الصفحة ' + page + '/' + pages });
}
async function cmdStatsAccount(msg) {
    if (!statsGate(msg)) return;
    try {
        const lv = features.mods.find(x => x && typeof x.accountCard === 'function');
        if (lv) { const sent = await lv.accountCard(msg); if (sent) return sent; }
    } catch (e) { console.error('[stats card]', e); }
    const emb = buildStatsAccountEmbed(msg.author);
    return msg.reply({ embeds: [emb] });
}
async function cmdStatsTopVoice(msg) {
    if (!statsGate(msg)) return;
    return msg.reply({ embeds: [buildTopVoiceEmbed(1)] });
}
async function cmdStatsTopChat(msg) {
    if (!statsGate(msg)) return;
    return msg.reply({ embeds: [buildTopChatEmbed(1)] });
}
async function cmdStatsTopHelp(msg) {
    if (!statsGate(msg)) return;
    const cfg = getStatsCfg();
    return msg.reply({ embeds: [new EmbedBuilder()
        .setColor(BLUE)
        .setTitle('📊 أوامر التوب')
        .setDescription(
            '`-' + cfg.top + ' ' + cfg.topvoice + '` — أعلى 10 في وقت الفويس\n' +
            '`-' + cfg.top + ' ' + cfg.topchat + '` — أعلى 10 في رسائل الشات'
        )] });
}

const CMDS = {
    'مكافأة': cmdReward, 'مكافاة': cmdReward, 'مكافئة': cmdReward,
    'توب': cmdTop, 'top': cmdTop,
    'معلومات': cmdRewardInfo, 'رصيد': cmdRewardInfo,
    // (تمت إزالة نظام الرقابة: تحذير/كيك/باند/ميوت/استدعاء/تفعيل)
    'تسجيلدخول': cmdClockIn, 'دخول': cmdClockIn, 'تسجيلخروج': cmdClockOut, 'خروج': cmdClockOut,
    'وقتي': cmdMyTime, 'وقت': cmdMyTime, 'لوحةوقت': cmdClockPanel, 'لوحهوقت': cmdClockPanel, 'نقاط': async (msg) => { if (!isStaff(msg.member, 'stats')) return msg.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' }); await msg.reply({ embeds: [buildStaffPointsBoard()] }); }
};

function permSummary(perms) {
    const on = BOT_PERMS.filter(p => perms && perms[p.key] === true);
    return on.length ? on.map(p => p.emoji + ' ' + p.label).join('\n') : '— لا توجد صلاحيات —';
}
const bpSessions = new Map(); // userId -> [roleIds] الرتب المختارة حالياً في لوحة /botperms
function buildBotPermsPanel(guild, userId) {
    const all = config.ticket?.staffRolePermissions || {};
    const picked = (bpSessions.get(userId) || []).filter(r => guild.roles.cache.has(r));
    const emb = new EmbedBuilder().setColor(BLUE)
        .setAuthor({ name: guild.name, ...(guild.iconURL?.() ? { iconURL: guild.iconURL() } : {}) })
        .setTitle('🔐 صلاحيات البوت')
        .setFooter({ text: 'لا أحد يستخدم أوامر الإدارة إلا من تحدده هنا • الإدارة العليا من /setadmin' });
    const rows = [new ActionRowBuilder().addComponents(
        new RoleSelectMenuBuilder().setCustomId('bp_roles').setPlaceholder('① اختر رتبة أو أكثر (حتى 10)').setMinValues(1).setMaxValues(10)
            .setDefaultRoles(picked.slice(0, 10))
    )];
    if (!picked.length) {
        emb.setDescription('**① اختر الرتب** من القائمة بالأسفل، ثم **② حدّد صلاحياتها**.\nيمكنك اختيار عدة رتب وإعطاؤها نفس الصلاحيات دفعة واحدة.');
        const ids = Object.keys(all);
        emb.addFields({ name: '📋 الرتب المضبوطة حالياً', value: ids.length ? ids.slice(0, 15).map(id => '<@&' + id + '> — ' + BOT_PERMS.filter(p => all[id][p.key] === true).map(p => p.emoji).join(' ')).join('\n') || '—' : 'لا توجد رتب بعد — لا أحد غير الإدارة العليا يستخدم البوت.' });
        const admins = adminRoleIds();
        emb.addFields({ name: '👑 الإدارة العليا', value: admins.length ? admins.map(r => '<@&' + r + '>').join(' ') : 'غير محددة — استخدم `/setadmin`' });
        return { embeds: [emb], components: rows };
    }
    // الصلاحيات المفعلة عند كل الرتب المختارة تظهر محددة
    const common = k => picked.every(r => all[r] && all[r][k] === true);
    emb.setDescription('**الرتب المختارة:** ' + picked.map(r => '<@&' + r + '>').join(' ') + '\n**② حدّد الصلاحيات** — ما تختاره يُطبّق على كل الرتب أعلاه ويُحفظ مباشرة.')
        .addFields(
            { name: '🎫 التذاكر', value: BOT_PERMS.filter(p => p.group.includes('التذاكر')).map(p => (common(p.key) ? '✅' : '❌') + ' ' + p.label).join('\n'), inline: true },
            { name: '🛡️ البوت', value: BOT_PERMS.filter(p => !p.group.includes('التذاكر')).map(p => (common(p.key) ? '✅' : '❌') + ' ' + p.label).join('\n'), inline: true }
        );
    rows.push(new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId('bp_sel').setPlaceholder('② اختر الصلاحيات...').setMinValues(0).setMaxValues(BOT_PERMS.length)
            .addOptions(BOT_PERMS.map(p => ({ label: p.label, value: p.key, emoji: p.emoji, description: p.desc, default: common(p.key) })))
    ));
    rows.push(new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('bp_basic').setLabel('الأساسيات').setStyle(ButtonStyle.Primary).setEmoji('⚡'),
        new ButtonBuilder().setCustomId('bp_all').setLabel('كل الصلاحيات').setStyle(ButtonStyle.Success).setEmoji('✅'),
        new ButtonBuilder().setCustomId('bp_rm').setLabel('إزالة الرتب').setStyle(ButtonStyle.Danger).setEmoji('🧹'),
        new ButtonBuilder().setCustomId('bp_back').setLabel('رجوع').setStyle(ButtonStyle.Secondary).setEmoji('↩️')
    ));
    return { embeds: [emb], components: rows };
}
async function handleBotPermsComponent(i) {
    if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الإجراء مخصص للإدارة العليا فقط.', flags: MessageFlags.Ephemeral });
    const kind = i.customId.slice(3);
    if (!config.ticket) config.ticket = {};
    if (!config.ticket.staffRolePermissions) config.ticket.staffRolePermissions = {};
    const store = config.ticket.staffRolePermissions;
    const picked = bpSessions.get(i.user.id) || [];
    const full = fn => Object.fromEntries(BOT_PERMS.map(p => [p.key, fn(p.key)]));
    if (kind === 'roles') bpSessions.set(i.user.id, [...i.values]);
    else if (kind === 'back') bpSessions.delete(i.user.id);
    else if (!picked.length) return i.update(buildBotPermsPanel(i.guild, i.user.id));
    else if (kind === 'sel') { for (const r of picked) store[r] = full(k => i.values.includes(k)); saveConfig(); }
    else if (kind === 'basic') { for (const r of picked) store[r] = full(k => k !== 'delete'); saveConfig(); }
    else if (kind === 'all') { for (const r of picked) store[r] = full(() => true); saveConfig(); }
    else if (kind === 'rm') { for (const r of picked) delete store[r]; saveConfig(); bpSessions.delete(i.user.id); }
    return i.update(buildBotPermsPanel(i.guild, i.user.id));
}

const slashCommands = [
    { name: 'setmodlogs', description: 'تحديد قناة لوق', options: [
        { name: 'type', description: 'نوع اللوق', type: 3, required: true, choices: [
            { name: 'تحذيرات', value: 'warn' }, { name: 'باند', value: 'ban' }, { name: 'باند نهائي', value: 'permban' }, { name: 'فك باند', value: 'unban' },
            { name: 'كيك', value: 'kick' }, { name: 'ميوت', value: 'mute' }, { name: 'فك ميوت', value: 'unmute' },
            { name: 'استدعاء', value: 'summon' }, { name: 'إلغاء استدعاء', value: 'unsummon' },
            { name: 'سحب تفعيل', value: 'activation' }, { name: 'تسجيل دخول', value: 'clock' }, { name: 'خروج عضو', value: 'leave' }, { name: 'دخول عضو', value: 'join' }, { name: 'عام', value: 'general' }
        ]},
        { name: 'channel', description: 'قناة اللوق', type: 7, required: true, channel_types: [0, 5] }
    ]},
    { name: 'setadmin', description: 'تحديد رتب الإدارة العليا (تتحكم بالبوت وترى التذاكر المستلمة)', options: [
        { name: 'role', description: 'رتبة الإدارة العليا', type: 8, required: false },
        { name: 'action', description: 'الإجراء (الافتراضي: إضافة)', type: 3, required: false, choices: [
            { name: 'إضافة رتبة', value: 'add' }, { name: 'إزالة رتبة', value: 'remove' },
            { name: 'تعيين كرتبة وحيدة', value: 'set' }, { name: 'عرض الرتب الحالية', value: 'list' }
        ]}
    ]},
    { name: 'botperms', description: 'تحديد صلاحيات رتبة أو عدة رتب داخل البوت (تذاكر • رقابة • دوام • إحصائيات)', options: [
        { name: 'role', description: 'رتبة للبدء بها (اتركها فارغة لاختيار عدة رتب من القائمة)', type: 8, required: false }
    ]},
    { name: 'setbotrole', description: 'تحديد رتبة موظفي البوت وصلاحياتهم داخل التذاكر', options: [
        { name: 'role', description: 'رتبة الموظفين', type: 8, required: true },
        { name: 'view_tickets', description: 'رؤية التذاكر غير المستلمة', type: 5, required: false },
        { name: 'claim', description: 'استلام التذاكر', type: 5, required: false },
        { name: 'close', description: 'إغلاق التذاكر', type: 5, required: false },
        { name: 'delete', description: 'حذف التذاكر', type: 5, required: false },
        { name: 'rename', description: 'تغيير اسم التذكرة', type: 5, required: false },
        { name: 'summon', description: 'استدعاء صاحب التذكرة', type: 5, required: false },
        { name: 'rate', description: 'إرسال طلب تقييم التذكرة', type: 5, required: false }
    ]},
    { name: 'setrole', description: 'تحديد رتبة استدعاء أو تفعيل', options: [
        { name: 'type', description: 'النوع', type: 3, required: true, choices: [
            { name: 'استدعاء', value: 'summon' },
            { name: 'تفعيل', value: 'activation' },
            { name: 'باند', value: 'banned' },
            { name: 'باند مؤقت', value: 'tempban' },
            { name: 'باند نهائي', value: 'permban' }
        ]},
        { name: 'role', description: 'الرتبة', type: 8, required: true }
    ]},
    { name: 'setclockpoints', description: 'دقائق = نقاط', options: [
        { name: 'minutes', description: 'كل كم دقيقة', type: 4, required: true, min_value: 5, max_value: 480 },
        { name: 'points', description: 'كم نقطة', type: 4, required: true, min_value: 0, max_value: 50 }
    ]},
    { name: 'setpresence', description: 'إعداد تحقق التواجد (بعد كم دقيقة + كم نقطة تخصم)', options: [
        { name: 'minutes', description: 'بعد كم دقيقة من تسجيل الدخول / المغادرة يرسل التحقق (افتراضي 15)', type: 4, required: false, min_value: 1, max_value: 120 },
        { name: 'deduct', description: 'عدد النقاط المخصومة عند عدم الرد (افتراضي 2)', type: 4, required: false, min_value: 0, max_value: 50 }
    ]},
    { name: 'testrating', description: 'تجربة رسالة التقييم (ترسل لك في الخاص)' },
    { name: 'staffpoints', description: 'نقاط الإدارة / الدوام / التذاكر / الفويس', options: [
        { name: 'action', description: 'ماذا تريد؟', type: 3, required: true, choices: [
            { name: 'لوحة النقاط', value: 'board' },
            { name: 'نقاطي', value: 'me' },
            { name: 'نقاط عضو', value: 'member' },
            { name: 'إعداد النظام', value: 'setup' }
        ]},
        { name: 'member', description: 'العضو (لنقاط عضو)', type: 6, required: false },
        { name: 'support_voice', description: 'روم الدعم الفني الصوتي', type: 7, required: false, channel_types: [2] },
        { name: 'ticket_points', description: 'كم نقطة لكل استلام تذكرة', type: 4, required: false, min_value: 0, max_value: 50 },
        { name: 'voice_minutes', description: 'كل كم دقيقة نقطة فويس', type: 4, required: false, min_value: 5, max_value: 480 },
        { name: 'voice_points', description: 'كم نقطة كل فترة فويس', type: 4, required: false, min_value: 0, max_value: 50 },
        { name: 'exempt_minutes', description: 'بعد كم دقيقة لا تُرسل رسالة تحقق/تنبيه (0 = تعطيل الإعفاء)', type: 4, required: false, min_value: 0, max_value: 600 }
    ]},
    { name: 'rating', description: 'عرض متوسط تقييمات إداري', options: [
        { name: 'member', description: 'الإداري (اتركه فارغاً لعرض تقييمك)', type: 6, required: false }
    ]},
    { name: 'ticketstats', description: 'إحصائيات نظام التذاكر' },
    ...features.slashCommands,
    { name: 'setrewards', description: 'إعداد نظام المكافآت (الروم + المبلغ + المدة)', options: [
        { name: 'channel', description: 'الروم الذي تعمل فيه أوامر (مكافأة / توب / معلومات)', type: 7, required: false, channel_types: [0, 5] },
        { name: 'min', description: 'أقل مبلغ للمكافأة', type: 4, required: false, min_value: 1 },
        { name: 'max', description: 'أعلى مبلغ للمكافأة (ساوِه بالأقل لمبلغ ثابت)', type: 4, required: false, min_value: 1 },
        { name: 'hours', description: 'كل كم ساعة يستلم المكافأة (الافتراضي 24)', type: 4, required: false, min_value: 1, max_value: 720 },
        { name: 'currency', description: 'اسم العملة مثل RT', type: 3, required: false }
    ]},
    { name: 'setstats', description: 'تحديد روم أوامر الإحصائيات (حسابي / توب فويس / توب شات)', options: [
        { name: 'channel', description: 'الروم الذي تعمل فيه أوامر الإحصائيات', type: 7, required: false, channel_types: [0, 5] }
    ]},
    { name: 'setstatscmds', description: 'تغيير أسماء أوامر الإحصائيات (حسابي / توب / فويس / شات)', options: [
        { name: 'account', description: 'كلمة أمر حسابي (مثل حسابي)', type: 3, required: false },
        { name: 'top', description: 'كلمة أمر التوب الرئيسي (مثل توب)', type: 3, required: false },
        { name: 'topvoice', description: 'كلمة توب الفويس (مثل فويس)', type: 3, required: false },
        { name: 'topchat', description: 'كلمة توب الشات (مثل شات)', type: 3, required: false }
    ]},
    { name: 'ping', description: 'البينق' }
];
// إزالة أوامر نظام الرقابة من التسجيل
{ const REMOVED = new Set(['setmodlogs', 'setrole']); for (let k = slashCommands.length - 1; k >= 0; k--) if (REMOVED.has(slashCommands[k].name)) slashCommands.splice(k, 1); }
// وضع «أمر واحد»: يُسجَّل أمر /help فقط (قائمة أوامر البوت)، والإدارة تفتح لوحة الإعدادات من زر داخله.
// لتغيير الأمر الوحيد: "bot": { "mainCommand": "setup" } • ولإرجاع كل الأوامر: "bot": { "singleCommand": false }
if (!config.bot || config.bot.singleCommand !== false) { const MAIN = (config.bot && config.bot.mainCommand) || 'help'; for (let k = slashCommands.length - 1; k >= 0; k--) if (slashCommands[k].name !== MAIN) slashCommands.splice(k, 1); }



// ═══════════════ نظام التذاكر ═══════════════
function getTicketCfg() { return config.ticket || {}; }
function getDepts() { return config.departments || []; }
function getSystems() { return config.ticketSystems || []; }
function getSystem(id) { return id && id !== 'main' ? getSystems().find(s => s.id === id) || null : null; }
function deptSystemId(d) { return d.systemId && getSystem(d.systemId) ? d.systemId : 'main'; }
function ticketOpenCat(dept) { return dept.openCategoryId || getSystem(deptSystemId(dept))?.openCategoryId || getTicketCfg().openCategoryId; }
function ticketClosedCat(t) {
    const d = deptOf(t);
    return (d && (d.closedCategoryId || getSystem(deptSystemId(d))?.closedCategoryId)) || getTicketCfg().closedCategoryId;
}

// ───── إيموجيات التذاكر (تتغير من /tickets ← 😀 الإيموجيات) ─────
const TICKET_EMOJIS = [
    { key: 'claim', label: 'استلام التذكرة', def: '🎯' },
    { key: 'unclaim', label: 'إلغاء الاستلام', def: '↩️' },
    { key: 'close', label: 'إغلاق التذكرة', def: '🔒' },
    { key: 'delete', label: 'حذف التذكرة', def: '🗑️' },
    { key: 'rename', label: 'تغيير الاسم', def: '✏️' },
    { key: 'summon', label: 'استدعاء صاحب التذكرة', def: '📢' },
    { key: 'rate', label: 'تقييم التذكرة والإدارة', def: '⭐' },
    { key: 'ticket', label: 'عنوان التذكرة وزر فتحها', def: '🎫' },
    { key: 'star5', label: 'تقييم: ممتاز', def: '🌟' },
    { key: 'star4', label: 'تقييم: جيد جداً', def: '⭐' },
    { key: 'star3', label: 'تقييم: جيد', def: '⭐' },
    { key: 'star2', label: 'تقييم: مقبول', def: '⭐' },
    { key: 'star1', label: 'تقييم: ضعيف', def: '⭐' }
];
function tEmo(key) {
    const d = TICKET_EMOJIS.find(e => e.key === key);
    const v = config.ticket && config.ticket.emojis && config.ticket.emojis[key];
    return v || (d ? d.def : undefined);
}
// يحوّل :اسم: إلى إيموجي السيرفر الخاص (يشتغل في كل نصوص التذاكر)
function emo(text) {
    if (!text) return text;
    const g = client.guilds.cache.get(SERVER_ID);
    if (!g) return text;
    return String(text).replace(/(?<![<\w]):([A-Za-z0-9_]{2,32}):/g, (m, n) => {
        const e = g.emojis.cache.find(x => x.name && x.name.toLowerCase() === n.toLowerCase());
        return e ? e.toString() : m;
    });
}
// يقبل: :اسم: أو اسم أو <:اسم:123> أو إيموجي عادي. الفاضي = رجوع للأصلي
function parseEmojiInput(guild, raw) {
    const t = String(raw || '').trim();
    if (!t) return { value: '' };
    if (/^<a?:\w{1,32}:\d{15,25}>$/.test(t)) return { value: t };
    const m = t.match(/^:?([A-Za-z0-9_]{2,32}):?$/);
    if (m) {
        const e = guild && guild.emojis.cache.find(x => x.name && x.name.toLowerCase() === m[1].toLowerCase());
        return e ? { value: e.toString() } : { error: 'ما لقيت إيموجي باسم `' + m[1] + '` في السيرفر.' };
    }
    if (/^(?:\p{Extended_Pictographic}|\p{Emoji_Component}|\u200d|\ufe0f)+$/u.test(t)) return { value: t };
    return { error: 'اكتب اسم إيموجي السيرفر (مثل `ark`) أو الصق الإيموجي نفسه.' };
}

function buildPanelEmbed(systemId = 'main') {
    const t = getTicketCfg();
    const sys = getSystem(systemId);
    const p = sys || t.panel || {};
    const g0 = client.guilds.cache.get(SERVER_ID);
    const isUrl = u => /^https?:\/\//i.test(String(u || ''));
    const emb = new EmbedBuilder().setColor(p.color || BLUE);
    if (p.title) emb.setTitle(emo(String(p.title)).slice(0, 256));
    if (p.description) emb.setDescription(emo(String(p.description)).slice(0, 4000));
    if (p.rules) emb.addFields({ name: '📜 القوانين', value: emo(String(p.rules)).slice(0, 1024) });
    if (p.steps) emb.addFields({ name: '📌 طريقة فتح تذكرة', value: emo(String(p.steps)).slice(0, 1024) });
    if (isUrl(p.banner)) emb.setImage(p.banner);
    if (isUrl(p.thumb)) emb.setThumbnail(p.thumb);
    if (!p.title && !p.description && !p.rules && !p.steps && !isUrl(p.banner)) emb.setDescription('\u200e');
    if (g0) emb.setFooter({ text: g0.name, ...(g0.iconURL?.() ? { iconURL: g0.iconURL() } : {}) });
    return emb;
}
function buildPanelSelect(systemId = 'main') {
    const depts = getDepts().filter(d => deptSystemId(d) === systemId);
    const cid = 'ticket_open:' + systemId;
    if (!depts.length) {
        return new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder().setCustomId(cid).setPlaceholder('لا توجد أقسام بعد').setDisabled(true)
                .addOptions({ label: 'لا يوجد', value: 'none' })
        );
    }
    return new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId(cid).setPlaceholder('اختر القسم...')
            .addOptions(depts.slice(0, 25).map(d => ({
                label: d.name,
                value: d.id,
                emoji: d.emoji || '📋',
                description: (d.description || d.name).slice(0, 100)
            })))
    );
}

/** لوحة التذاكر بتصميم الحاوية: صورة علوية • عنوان/وصف (+صورة صغيرة) • قوانين • قائمة الأقسام • صورة سفلية */
function buildPanelMessage(systemId = 'main') {
    const t = getTicketCfg();
    const sys = getSystem(systemId);
    const p = sys || t.panel || {};
    const g0 = client.guilds.cache.get(SERVER_ID);
    const ab = withAutoBanner(IMG.resolve(p.banner), String(p.title || 'مركز الدعم').slice(0, 40), 'نظام التذاكر');
    const top = ab.img, bottom = IMG.resolve(p.bottomImage), thumb = IMG.resolve(p.thumb);
    const kids = [];
    if (top) kids.push(V2.gallery([top.url]));
    const head = [p.title ? '# ' + emo(String(p.title)).slice(0, 250) : '', p.description ? emo(String(p.description)).slice(0, 3000) : ''].filter(Boolean).join('\n');
    if (head) kids.push(thumb ? V2.section([head], thumb.url) : V2.text(head));
    if (p.rules) { kids.push(V2.sep()); kids.push(V2.text('### 📜 القوانين\n' + emo(String(p.rules)).slice(0, 1500))); }
    if (p.steps) { kids.push(V2.sep()); kids.push(V2.text('### 📌 طريقة فتح تذكرة\n' + emo(String(p.steps)).slice(0, 1500))); }
    if (kids.length) kids.push(V2.sep());
    kids.push(buildPanelSelect(systemId));
    if (bottom) kids.push(V2.gallery([bottom.url]));
    if (g0) kids.push(V2.text('-# ' + g0.name + ' • نظام التذاكر'));
    return {
        components: [V2.container(kids, V2.parseColor(p.color, V2.NAVY))],
        flags: V2.IS_V2,
        files: [...IMG.filesOf(p.banner, p.bottomImage, p.thumb), ...ab.extra]
    };
}
/** حمولة التعديل (تُرسل فيها الملفات من جديد وتُمسح المرفقات القديمة) */
const panelEditPayload = (id) => { const m = buildPanelMessage(id); return { content: null, embeds: [], components: m.components, flags: m.flags, files: m.files, attachments: [] }; };

async function refreshTicketPanel(guild) {
    if (!guild) return false;
    const refs = [{ sys: 'main', ref: getTicketCfg().panelRef }, ...getSystems().map(s => ({ sys: s.id, ref: s.panelRef }))];
    let any = false;
    for (const { sys, ref } of refs) {
        if (!ref) continue;
        try {
            const ch = await guild.channels.fetch(ref.channelId);
            const m = await ch.messages.fetch(ref.messageId);
            await m.edit(panelEditPayload(sys));
            any = true;
        } catch {}
    }
    return any;
}

async function openTicket(interaction, deptId, openReason = '') {
    const guild = interaction.guild;
    const user = interaction.user;
    const tcfg = getTicketCfg();
    const depts = getDepts();
    const dept = depts.find(d => d.id === deptId) || depts[0];
    if (!dept) return interaction.reply({ content: '❌ لا يوجد قسم.', flags: MessageFlags.Ephemeral });

    // max tickets
    const max = tcfg.maxTickets != null ? tcfg.maxTickets : 0; // 0 = بلا حد
    if (max > 0) {
        for (const [cid, tk] of Object.entries(activeTickets)) { if (!tk.closed && !guild.channels.cache.has(cid)) { tk.closed = true; tk.deleted = true; } }
        const owned = Object.values(activeTickets).filter(t => t.ownerId === user.id && !t.closed).length;
        if (owned >= max) return interaction.reply({ content: `❌ عندك ${owned} تذاكر مفتوحة (الحد ${max}).`, flags: MessageFlags.Ephemeral });
    }

    const openCat = ticketOpenCat(dept);
    if (!openCat) return interaction.reply({ content: '❌ لم يتم تحديد تصنيف التذاكر المفتوحة بعد. يرجى من الإدارة تحديده من `/tickets`', flags: MessageFlags.Ephemeral });

    ticketCounter++;
    const num = ticketCounter;
    const nameFmt = (tcfg.ticketNameFormat || '{number}-🎫').replace('{number}', String(num));

    const overwrites = [
        { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
        { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageMessages] }
    ];
    const supportRole = config.roles?.support || dept.roleId;
    const ticketInfoForAccess = { departmentId: dept.id };
    const canViewRoles = ticketViewerRoleIds(ticketInfoForAccess);
    const adminIds = adminRoleIds(); // رتبة القسم + الإدارة العليا فقط
    for (const roleId of canViewRoles) if (!adminIds.includes(roleId)) overwrites.push({ id: roleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
    for (const roleId of adminIds) overwrites.push({ id: roleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });

    let channel;
    try {
        channel = await guild.channels.create({
            name: nameFmt,
            type: ChannelType.GuildText,
            parent: openCat,
            permissionOverwrites: overwrites,
            topic: `ticket:${num}|owner:${user.id}`
        });
    } catch (e) {
        return interaction.reply({ content: '❌ فشل إنشاء القناة: ' + e.message, flags: MessageFlags.Ephemeral });
    }

    const info = {
        ticketNumber: num,
        channelId: channel.id,
        ownerId: user.id,
        ownerTag: user.username,
        departmentId: dept.id,
        departmentName: dept.name,
        claimedBy: null,
        closed: false,
        openReason: openReason || '',
        createdAt: Date.now()
    };
    activeTickets[channel.id] = info;
    saveAll();

    // داخل التذكرة — بطاقة بتصميم الحاوية (صور علوية/سفلية قابلة للتخصيص)
    await channel.send(buildTicketMessage(guild, info, { first: true }));

    // لوق

    await interaction.reply({ content: `✅ تم فتح تذكرتك بنجاح: ${channel}`, flags: MessageFlags.Ephemeral });
}

const fmtTs = (ms, f = 'F') => '<t:' + Math.floor(ms / 1000) + ':' + f + '>';

const TICKET_VIEW_ALLOW = { ViewChannel: true, SendMessages: true, ReadMessageHistory: true };
const TICKET_VIEW_DENY = { ViewChannel: false, SendMessages: false, ReadMessageHistory: false };

/** يجعل التذكرة خاصة: تُسحب الرؤية من كل رتب الموظفين فوراً وتبقى للمستلم والإدارة العليا وصاحب التذكرة */
async function lockTicketToClaimer(channel, t, claimerId) {
    const admins = adminRoleIds();
    const hidden = ticketStaffRoleIds(t).filter(r => !admins.includes(r));
    for (const roleId of hidden) await channel.permissionOverwrites.edit(roleId, TICKET_VIEW_DENY);
    await channel.permissionOverwrites.edit(claimerId, { ...TICKET_VIEW_ALLOW, AttachFiles: true });
    for (const roleId of admins) await channel.permissionOverwrites.edit(roleId, TICKET_VIEW_ALLOW);
    t.hiddenRoles = hidden;
}
/** يعيد التذكرة مرئية لرتب الموظفين (عند إلغاء الاستلام) */
async function unlockTicket(channel, t, prevClaimerId) {
    const admins = adminRoleIds();
    for (const roleId of ticketViewerRoleIds(t)) {
        if (!admins.includes(roleId)) await channel.permissionOverwrites.edit(roleId, TICKET_VIEW_ALLOW);
    }
    if (prevClaimerId && prevClaimerId !== t.ownerId) await channel.permissionOverwrites.delete(prevClaimerId).catch(() => {});
    delete t.hiddenRoles;
}
/** بطاقة التذكرة: ترحيب • القسم • الحالة • وقت الفتح • قائمة الإجراءات • الأزرار — مع صورة علوية وسفلية */
function buildTicketMessage(guild, t, o = {}) {
    const tcfg = getTicketCfg();
    const em = tcfg.embed || {};
    const top = IMG.resolve(em.topImage), bottom = IMG.resolve(em.image);
    const d = deptOf(t);
    const supportRole = config.roles?.support || (d && d.roleId);
    const kids = [];
    if (top) kids.push(V2.gallery([top.url]));
    // تصميم مطابق للصورة المطلوبة (نمط اللوحة الداكنة)
    kids.push(V2.text('## مرحباً بك <@' + t.ownerId + '>'));
    if (supportRole) kids.push(V2.text('<@&' + supportRole + '>'));
    kids.push(V2.sep());
    kids.push(V2.text('يرجى انتظار رد من الإدارة وعدم الإزعاج'));
    kids.push(V2.sep());
    kids.push(V2.text('**نوع التذكرة:** ' + (t.departmentName || 'الدعم الفني')));
    kids.push(V2.text('**مفتوحة منذ:** <t:' + Math.floor((t.createdAt || Date.now()) / 1000) + ':R>'));
    if (t.claimedBy) kids.push(V2.text('**المستلم:** <@' + t.claimedBy + '>'));
    if (t.openReason) kids.push(V2.text('**سبب الفتح:**\n```' + String(t.openReason).slice(0, 900) + '```'));
    kids.push(V2.sep());
    kids.push(new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId('ticket_actions').setPlaceholder('إجراءات التذكرة')
            .addOptions(
                { label: 'ترك الاستلام', value: 'unclaim', emoji: tEmo('unclaim') },
                { label: 'استدعاء عضو', value: 'summon', emoji: tEmo('summon') },
                { label: 'تقييم التذكرة', value: 'rate_admin', emoji: tEmo('rate') },
                { label: 'إغلاق التذكرة', value: 'close', emoji: tEmo('close') },
                { label: 'حذف التذكرة', value: 'delete', emoji: tEmo('delete') },
                { label: 'تغيير الاسم', value: 'rename', emoji: tEmo('rename') }
            )
    ));
    const claimBtn = t.claimedBy
        ? new ButtonBuilder().setCustomId('ticket_unclaim').setLabel('ترك الاستلام').setStyle(ButtonStyle.Secondary).setEmoji('👤')
        : new ButtonBuilder().setCustomId('ticket_claim').setLabel('استلام').setStyle(ButtonStyle.Primary).setEmoji(tEmo('claim'));
    kids.push(new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ticket_delete').setLabel('حذف').setStyle(ButtonStyle.Danger).setEmoji('🗑️'),
        claimBtn,
        new ButtonBuilder().setCustomId('ticket_summon_owner').setLabel('استدعاء عضو').setStyle(ButtonStyle.Secondary).setEmoji('🔔')
    ));
    if (bottom) kids.push(V2.gallery([bottom.url]));
    kids.push(V2.text('-# ' + (guild.name || 'RTU') + ' • نظام التذاكر'));
    const out = {
        components: [V2.container(kids, V2.parseColor(em.color || '#0F2A66', V2.NAVY))],
        flags: V2.IS_V2
    };
    if (o.first) out.files = IMG.filesOf(em.topImage, em.image);
    return out;
}

/** يحدّث رسالة التذكرة الأصلية (الحالة + زر الاستلام) بإعادة بنائها من بيانات التذكرة */
async function refreshTicketMessage(message, t) {
    try {
        const p = buildTicketMessage(message.guild, t);
        await message.edit({ components: p.components, flags: p.flags });
    } catch (e) { console.error('[ticket] refresh message:', e.message); }
}

async function handleTicketClaim(interaction) {
    const t = activeTickets[interaction.channel.id];
    if (!t || t.closed) return interaction.reply({ content: '❌ هذه ليست تذكرة نشطة.', flags: MessageFlags.Ephemeral });
    if (!hasTicketPermission(interaction.member, 'claim', t)) return interaction.reply({ content: '❌ لا تملك صلاحية استلام التذاكر. تضبطها الإدارة من `/botperms`.', flags: MessageFlags.Ephemeral });
    if (t.claimedBy) return interaction.reply({ content: `⚠️ هذه التذكرة مستلمة مسبقاً من <@${t.claimedBy}>`, flags: MessageFlags.Ephemeral });
    // نحجز التذكرة فوراً (قبل أي انتظار) حتى لا يستلمها اثنان في نفس اللحظة
    t.claimedBy = interaction.user.id;
    t.claimedByTag = interaction.user.username;
    t.claimedAt = Date.now();
    try {
        await lockTicketToClaimer(interaction.channel, t, interaction.user.id);
    } catch (e) {
        t.claimedBy = null; t.claimedByTag = null; t.claimedAt = null;
        return interaction.reply({ content: '❌ لم أستطع جعل التذكرة خاصة بعد الاستلام. تأكد أن البوت يملك صلاحية Manage Channels وأن رتبته أعلى من رتب الموظفين: ' + e.message, flags: MessageFlags.Ephemeral });
    }
    const claimPts = (getTicketCfg().claimPoints != null) ? getTicketCfg().claimPoints : 1;
    const c = ensureClock(interaction.user.id);
    c.points = (c.points || 0) + claimPts;
    c.ticketsClaimed = (c.ticketsClaimed || 0) + 1;
    saveAll();
    // ترقية تلقائية حسب عدد الاستلامات
    let rankNote = '';
    try {
        const promoted = (features.H.promo && features.H.promo.onClaim)
            ? await features.H.promo.onClaim(interaction.guild, interaction.user, c.ticketsClaimed)
            : await applyTicketRanks(interaction.guild, interaction.user.id, c.ticketsClaimed);
        if (promoted.length) {
            rankNote = '\n👑 **ترقية:** ' + promoted.map(r => (r.roleId ? '<@&' + r.roleId + '>' : (r.label || r.claims))).join(' • ');
        }
    } catch (e) { console.error('[ticketrank]', e.message); }
    const respMs = Date.now() - (t.createdAt || Date.now());
    t.firstResponseMs = t.firstResponseMs != null ? t.firstResponseMs : respMs;
    const emb = new EmbedBuilder()
        .setColor(BLUE)
        .setDescription('✅ **تم استلام التذكرة**\nالتذكرة **#' + t.ticketNumber + '** أصبحت خاصة بين صاحبها والمستلم والإدارة العليا.\n🎫 استلاماتك: **' + c.ticketsClaimed + '**' + rankNote)
        .setTimestamp();
    await interaction.reply({ embeds: [emb] });
    if (interaction.message) await refreshTicketMessage(interaction.message, t);
}

async function handleTicketUnclaim(interaction) {
    const t = activeTickets[interaction.channel.id];
    if (!t || t.closed) return interaction.reply({ content: '❌ هذه ليست تذكرة نشطة.', flags: MessageFlags.Ephemeral });
    if (!t.claimedBy) return interaction.reply({ content: '⚠️ التذكرة غير مستلمة.', flags: MessageFlags.Ephemeral });
    if (t.claimedBy !== interaction.user.id && !isAdmin(interaction.member)) {
        return interaction.reply({ content: '❌ يمكن لمستلم التذكرة أو الإدارة العليا فقط إلغاء الاستلام.', flags: MessageFlags.Ephemeral });
    }
    const prevClaimer = t.claimedBy;
    try {
        await unlockTicket(interaction.channel, t, prevClaimer);
    } catch (e) {
        return interaction.reply({ content: '❌ تعذر إعادة التذكرة للموظفين: ' + e.message, flags: MessageFlags.Ephemeral });
    }
    t.claimedBy = null;
    t.claimedByTag = null;
    t.claimedAt = null;
    saveAll();
    const emb = new EmbedBuilder().setColor(BLUE)
        .setDescription('↩️ **تم ترك الاستلام**\nالتذكرة **#' + t.ticketNumber + '** أصبحت متاحة للموظفين من جديد.')
        .setTimestamp();
    await interaction.reply({ embeds: [emb] });
    if (interaction.message) await refreshTicketMessage(interaction.message, t);
}

async function handleTicketSettings(interaction) {
    const t = activeTickets[interaction.channel.id];
    if (!t || t.closed) return interaction.reply({ content: '❌ هذه ليست تذكرة نشطة.', flags: MessageFlags.Ephemeral });
    if (!hasTicketPermission(interaction.member, 'close', t)) return interaction.reply({ content: '❌ هذا الإجراء مخصص للموظفين فقط.', flags: MessageFlags.Ephemeral });
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ticket_close').setLabel('تقفيل التذكرة').setStyle(ButtonStyle.Danger).setEmoji(tEmo('close')),
        new ButtonBuilder().setCustomId('ticket_rename').setLabel('تغيير اسم التذكرة').setStyle(ButtonStyle.Primary).setEmoji(tEmo('rename')),
        new ButtonBuilder().setCustomId('ticket_summon_owner').setLabel('استدعاء صاحب التذكرة').setStyle(ButtonStyle.Secondary).setEmoji(tEmo('summon'))
    );
    await interaction.reply({ content: '**اختر الإجراء المطلوب:**', components: [row], flags: MessageFlags.Ephemeral });
}

async function handleTicketClose(interaction) {
    const t = activeTickets[interaction.channel.id];
    if (!t || t.closed) return interaction.reply({ content: '❌ هذه ليست تذكرة نشطة.', flags: MessageFlags.Ephemeral });
    if (!hasTicketPermission(interaction.member, 'close', t) && interaction.user.id !== t.ownerId) {
        return interaction.reply({ content: '❌ تعذّر تنفيذ الطلب.', flags: MessageFlags.Ephemeral });
    }
    const modal = new ModalBuilder().setCustomId('ticket_close_modal').setTitle('إغلاق التذكرة');
    modal.addComponents(new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('reason').setLabel('سبب الإغلاق').setStyle(TextInputStyle.Paragraph).setRequired(true).setPlaceholder('مثال: تم حل المشكلة')
    ));
    return interaction.showModal(modal);
}

/** تنزيل صورة وتحويلها إلى data URI لتُحفظ داخل ملف HTML نفسه. يحاول عدة روابط ويعيد null عند الفشل */
async function downloadImageDataUri(urls, name, contentType, maxBytes) {
    if (typeof fetch !== 'function') return null;
    for (const url of urls.filter(Boolean)) {
        for (let attempt = 0; attempt < 2; attempt++) {
            const ctl = new AbortController();
            const tm = setTimeout(() => ctl.abort(), 20000);
            try {
                const r = await fetch(url, { signal: ctl.signal, headers: { 'User-Agent': 'Mozilla/5.0 (compatible; TicketBot)' } });
                if (!r.ok) { clearTimeout(tm); continue; }
                const buf = Buffer.from(await r.arrayBuffer());
                clearTimeout(tm);
                if (!buf.length) continue;
                if (buf.length > maxBytes) return { tooBig: true, bytes: buf.length };
                let ct = String(contentType || r.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
                if (!/^image\//.test(ct)) {
                    const ext = (String(name).match(/\.(png|jpe?g|gif|webp|bmp|heic|avif|svg)/i) || [])[1];
                    ct = ext ? 'image/' + ext.toLowerCase().replace('jpg', 'jpeg') : 'image/png';
                }
                return { uri: 'data:' + ct + ';base64,' + buf.toString('base64'), bytes: buf.length };
            } catch (e) { clearTimeout(tm); }
        }
    }
    return null;
}

async function finishTicketClose(interaction, reason, opts = {}) {
    const deleteAfter = !!opts.deleteAfter;
    const t = activeTickets[interaction.channel.id];
    if (!t || t.closed) return interaction.reply({ content: '❌ هذه ليست تذكرة نشطة.', flags: MessageFlags.Ephemeral });
    if (deleteAfter ? !hasTicketPermission(interaction.member, 'delete', t) : (!hasTicketPermission(interaction.member, 'close', t) && interaction.user.id !== t.ownerId)) return interaction.reply({ content: '❌ لا تملك الصلاحية المطلوبة لهذا الإجراء.', flags: MessageFlags.Ephemeral });
    
    // رد سريع عشان ما يفشل التفاعل
    try {
        await interaction.reply({ content: deleteAfter ? '🗑️ جارٍ حفظ السجل ثم حذف التذكرة...' : '🔒 جارٍ إغلاق التذكرة...' });
    } catch (e) {
        try { await interaction.followUp({ content: deleteAfter ? '🗑️ جارٍ حفظ السجل ثم حذف التذكرة...' : '🔒 جارٍ إغلاق التذكرة...' }); } catch {}
    }

    t.closed = true;
    t.closedBy = interaction.user.id;
    t.closedByTag = interaction.user.username;
    t.closedAt = Date.now();
    t.closeReason = reason || 'تم الإغلاق';
    saveAll();

    // ========== 1) إنشاء ملف السجل HTML ==========
    let htmlFile = null;
    let msgCount = 0;
    // حد حجم الملف: 7.5MB تقريباً (حد رفع ديسكورد الافتراضي 10MB والـ base64 يزيد الحجم 33%)
    let imgSaved = 0, imgFailed = 0, imgBudget = 5 * 1024 * 1024;
    const imgToDataUri = async (a) => {
        const name = a.name || a.url || '';
        const res = await downloadImageDataUri([a.url, a.proxyURL], name, a.contentType, Math.min(3 * 1024 * 1024, imgBudget));
        if (res && res.uri) { imgBudget -= res.bytes; imgSaved++; return res.uri; }
        imgFailed++;
        return null;
    };
    try {
        let all = [];
        let lastId = undefined;
        for (let i = 0; i < 25; i++) {
            const opts = { limit: 100 };
            if (lastId) opts.before = lastId;
            const batch = await interaction.channel.messages.fetch(opts).catch(() => null);
            if (!batch || !batch.size) break;
            all.push(...batch.values());
            lastId = batch.last().id;
            if (batch.size < 100) break;
        }
        all.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
        msgCount = all.length;

        const escapeHtml = (s) => String(s || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');

        const formatTime = (ts) => {
            try {
                const d = new Date(ts);
                const h = d.getHours();
                const m = String(d.getMinutes()).padStart(2, '0');
                const ampm = h >= 12 ? 'PM' : 'AM';
                const hh = h % 12 || 12;
                const date = String(d.getMonth() + 1).padStart(2, '0') + '/' + String(d.getDate()).padStart(2, '0') + '/' + d.getFullYear();
                return hh + ':' + m + ' ' + ampm + ' · ' + date;
            } catch { return ''; }
        };

        let messagesHtml = '';
        for (const m of all) {
            try {
                const authorName = escapeHtml(m.author?.username || m.author?.tag || 'Unknown');
                const timeStr = formatTime(m.createdTimestamp);
                let content = escapeHtml(m.content || '').replace(/\r\n|\n|\r/g, '<br>');

                messagesHtml += `<div class="msg">
  <div class="msg-head">
    <span class="msg-author">${authorName}</span>
    <span class="msg-time">${timeStr}</span>
  </div>
  <div class="msg-content">${content || '<span style="color:#6d6f78;font-style:italic">[بدون نص]</span>'}</div>`;

                if (m.embeds && m.embeds.length) {
                    for (const e of m.embeds) {
                        const parts = [];
                        if (e.title) parts.push(escapeHtml(e.title));
                        if (e.description) parts.push(escapeHtml(String(e.description).slice(0, 400)));
                        for (const f of (e.fields || []).slice(0, 8)) parts.push(escapeHtml(f.name) + ': ' + escapeHtml(String(f.value).slice(0, 150)));
                        if (parts.length) {
                            messagesHtml += `<div class="msg-embed">📌 ${parts.join(' — ')}</div>`;
                        }
                    }
                }

                const atts = (m.attachments && typeof m.attachments.values === 'function')
                    ? [...m.attachments.values()]
                    : [];
                if (atts.length) {
                    messagesHtml += '<div class="msg-att">';
                    for (const a of atts) {
                        const url = a.url || '';
                        const name = a.name || url;
                        const isImg = String(a.contentType || '').startsWith('image/') || !!(a.width && a.height) ||
                            /\.(png|jpe?g|gif|webp|bmp|heic|avif)(\?|$)/i.test(name) || /\.(png|jpe?g|gif|webp|bmp|heic|avif)(\?|$)/i.test(url);
                        if (isImg && url) {
                            const dataUri = await imgToDataUri(a);
                            if (dataUri) {
                                messagesHtml += `<img src="${dataUri}" alt="${escapeHtml(name)}">`;
                            } else {
                                messagesHtml += `<img src="${escapeHtml(url)}" alt="${escapeHtml(name)}"><div><a href="${escapeHtml(url)}" target="_blank">🖼️ ${escapeHtml(name)} (تعذّر حفظ الصورة داخل الملف — صورة كبيرة أو الرابط غير متاح)</a></div>`;
                            }
                        } else if (url) {
                            messagesHtml += `<div><a href="${escapeHtml(url)}" target="_blank">📎 ${escapeHtml(name)}</a></div>`;
                        }
                    }
                    messagesHtml += '</div>';
                }
                messagesHtml += '</div>';
            } catch (msgErr) {
                console.error('[transcript] msg error:', msgErr.message);
            }
        }

        const closedAtStr = (() => {
            try {
                const d = new Date(t.closedAt || Date.now());
                return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0') + ' ' +
                       String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0') + ':' + String(d.getSeconds()).padStart(2,'0');
            } catch { return new Date().toISOString(); }
        })();

        const claimedDisplay = t.claimedByTag || (t.claimedBy ? String(t.claimedBy) : 'لا يوجد');
        const ownerDisplay = t.ownerTag || t.ownerId || 'Unknown';

        const html = `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>سجل التذكرة #${t.ticketNumber}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Segoe UI', Tahoma, 'Noto Sans Arabic', Arial, sans-serif;
    background: #111214;
    color: #dbdee1;
    padding: 20px;
    line-height: 1.5;
  }
  .container {
    max-width: 720px;
    margin: 0 auto;
    background: #1e1f22;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  }
  .header {
    background: linear-gradient(135deg, #2b2d31 0%, #1e1f22 100%);
    padding: 20px 24px 16px;
    border-bottom: 1px solid #2b2d31;
  }
  .header-title h1 {
    font-size: 1.35rem;
    font-weight: 700;
    color: #fff;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .header-title .badge {
    background: #0F2A66;
    color: #fff;
    font-size: 0.85rem;
    padding: 2px 10px;
    border-radius: 20px;
    font-weight: 600;
  }
  .server-name {
    color: #949ba4;
    font-size: 0.9rem;
    margin-top: 6px;
  }
  .info-card {
    margin: 16px 20px;
    background: #2b2d31;
    border-radius: 12px;
    border-right: 4px solid #0F2A66;
    padding: 14px 16px;
  }
  .info-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 5px 0;
    font-size: 0.95rem;
  }
  .info-row .label { color: #949ba4; }
  .info-row .value { color: #6FA3F7; font-weight: 600; }
  .reason-box {
    margin: 0 20px 16px;
    background: #ed4245;
    color: #fff;
    border-radius: 10px;
    padding: 12px 16px;
    font-weight: 600;
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
  .reason-box .r-label { font-size: 0.85rem; opacity: 0.9; }
  .reason-box .r-text { font-size: 1.05rem; }
  .messages-section { padding: 0 20px 20px; }
  .messages-header {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #6FA3F7;
    font-weight: 700;
    font-size: 1rem;
    margin-bottom: 12px;
    padding-bottom: 8px;
    border-bottom: 1px solid #2b2d31;
  }
  .msg {
    background: #2b2d31;
    border-radius: 10px;
    padding: 12px 14px;
    margin-bottom: 10px;
    border-right: 3px solid #0F2A66;
  }
  .msg-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 6px;
  }
  .msg-author { color: #6FA3F7; font-weight: 700; font-size: 0.95rem; }
  .msg-time { color: #949ba4; font-size: 0.8rem; }
  .msg-content {
    color: #dbdee1;
    white-space: pre-wrap;
    word-break: break-word;
    font-size: 0.95rem;
    line-height: 1.55;
  }
  .msg-content a { color: #6FA3F7; }
  .msg-embed {
    margin-top: 8px;
    padding: 8px 10px;
    background: #1e1f22;
    border-radius: 6px;
    border-right: 3px solid #0F2A66;
    font-size: 0.85rem;
    color: #b5bac1;
  }
  .msg-att { margin-top: 8px; }
  .msg-att img {
    max-width: 100%;
    max-height: 320px;
    border-radius: 8px;
    margin-top: 6px;
    display: block;
  }
  .msg-att a {
    color: #6FA3F7;
    font-size: 0.85rem;
    word-break: break-all;
  }
  .footer {
    text-align: center;
    padding: 16px 20px 20px;
    color: #6d6f78;
    font-size: 0.8rem;
    border-top: 1px solid #2b2d31;
  }
  .empty-msgs {
    text-align: center;
    color: #6d6f78;
    padding: 24px;
  }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="header-title">
      <h1>📋 سجل التذكرة <span class="badge">#${t.ticketNumber}</span></h1>
    </div>
    <div class="server-name">السيرفر: ${escapeHtml(interaction.guild?.name || 'Unknown')}</div>
  </div>

  <div class="info-card">
    <div class="info-row"><span class="label">رقم التذكرة:</span><span class="value">#${t.ticketNumber}</span></div>
    <div class="info-row"><span class="label">صاحب التذكرة:</span><span class="value">${escapeHtml(ownerDisplay)}</span></div>
    <div class="info-row"><span class="label">المستلم:</span><span class="value">${escapeHtml(claimedDisplay)}</span></div>
    <div class="info-row"><span class="label">تم الإغلاق بواسطة:</span><span class="value">${escapeHtml(interaction.user.username)}</span></div>
  </div>

  <div class="reason-box">
    <span class="r-label">سبب الإغلاق:</span>
    <span class="r-text">${escapeHtml(t.closeReason)}</span>
  </div>

  <div class="messages-section">
    <div class="messages-header">📝 الرسائل (${msgCount})</div>
    ${messagesHtml || '<div class="empty-msgs">لا توجد رسائل في هذه التذكرة</div>'}
  </div>
  <div class="footer">
    تم إنشاء هذا السجل بواسطة بوت التذاكر<br>
    ${closedAtStr}
  </div>
</div>
</body>
</html>`;

        htmlFile = path.join(DATA_DIR, 'ticket-' + t.ticketNumber + '.html');
        fs.writeFileSync(htmlFile, html, 'utf8');
        console.log('[transcript] تم إنشاء الملف:', htmlFile, '| رسائل:', msgCount);
    } catch (e) {
        console.error('[transcript] فشل إنشاء السجل:', e.message, e.stack);
        htmlFile = null;
    }

    // ========== 2) نقل القناة للكتفوري المغلق ==========
    const closedCat = ticketClosedCat(t);
    if (!deleteAfter) try {
        await interaction.channel.setName('closed-' + t.ticketNumber).catch(() => {});
        if (closedCat) await interaction.channel.setParent(closedCat, { lockPermissions: false }).catch(() => {});
    } catch (e) {
        console.error('[close] setParent/name:', e.message);
    }

    // ========== 3) رسالة داخل التذكرة ==========
    if (!deleteAfter) try {
        await interaction.channel.send({ embeds: [
            new EmbedBuilder().setColor(BLUE).setTitle('🔒 تم إغلاق التذكرة')
                .setDescription('تم إغلاق هذه التذكرة بنجاح.\nشكراً لتواصلك معنا، نسعد بخدمتك دائماً.')
                .addFields(
                    { name: 'رقم التذكرة', value: '#' + t.ticketNumber, inline: true },
                    { name: 'أُغلقت بواسطة', value: '<@' + interaction.user.id + '>', inline: true },
                    { name: 'سبب الإغلاق', value: '```' + String(t.closeReason).slice(0, 900) + '```', inline: false }
                ).setTimestamp()
        ]});
    } catch (e) {
        console.error('[close] channel send:', e.message);
    }

    // ========== 4) إيمبد اللوق + الملف ==========
    let claimedName = 'لا يوجد';
    if (t.claimedBy) {
        try {
            const u = await client.users.fetch(t.claimedBy);
            claimedName = u.username;
        } catch {
            claimedName = t.claimedByTag || String(t.claimedBy);
        }
    }

    const logEmb = new EmbedBuilder()
        .setColor(BLUE)
        .setTitle('📋 سجل التذكرة')
        .addFields(
            { name: 'رقم التذكرة', value: '#' + t.ticketNumber, inline: false },
            { name: 'السيرفر', value: interaction.guild?.name || '-', inline: false },
            { name: 'الإداري المستلم', value: claimedName, inline: false },
            { name: 'تم الإغلاق بواسطة', value: interaction.user.username, inline: false },
            { name: 'سبب الإغلاق', value: '```' + (t.closeReason || '-') + '```', inline: false }
        )
        .setTimestamp();

    const payload = { embeds: [logEmb] };
    if (htmlFile && fs.existsSync(htmlFile)) {
        payload.files = [{ attachment: htmlFile, name: 'ticket-' + t.ticketNumber + '.html' }];
    } else {
        console.warn('[log] لا يوجد ملف HTML للإرفاق');
    }

    // إرسال السجل في روم اللوقات (مع بدائل وتنبيه واضح عند الفشل)
    const logsId = getTicketCfg().logsChannelId;
    let logSent = false, logErr = '';
    if (!logsId) {
        logErr = 'لم يتم تحديد روم السجل، حدده من `/tickets` ← الإعدادات العامة';
    } else {
        try {
            const logCh = await interaction.guild.channels.fetch(logsId).catch(() => null);
            if (!logCh) {
                logErr = 'روم السجل غير موجود أو البوت لا يستطيع رؤيته (تحقق من الآيدي والصلاحيات)';
            } else {
                try { await logCh.send(payload); logSent = true; }
                catch (e1) {
                    console.error('[log] فشل الإرسال مع الملف:', e1.message);
                    try { await logCh.send({ embeds: payload.embeds }); logSent = true; logErr = 'أُرسلت الرسالة بدون الملف: ' + e1.message; }
                    catch (e2) { logErr = e2.message + ' — تأكد أن للبوت صلاحيات: عرض الروم + إرسال رسائل + تضمين روابط + إرفاق ملفات'; }
                }
                if (logSent) console.log('[log] تم إرسال سجل التذكرة إلى #' + logCh.name);
            }
        } catch (e) { logErr = e.message; }
    }
    if (logErr) console.error('[log] ' + logErr);
    if (!logSent) {
        // بديل: أرسله في روم التذكرة نفسها (إن لم تكن ستُحذف) مع سبب المشكلة
        try {
            if (!deleteAfter) await interaction.channel.send(Object.assign({ content: '⚠️ تعذّر إرسال السجل إلى روم السجل: ' + logErr }, payload));
            else await interaction.followUp({ content: '⚠️ تعذّر إرسال السجل إلى روم السجل: ' + logErr + '\nتم إرساله لك في الخاص.' });
        } catch {}
    }

    // إرسال نفس اللوق + الملف في الخاص للي أقفل
    try {
        await interaction.user.send(payload);
        console.log('[log] تم إرسال اللوق في الخاص لـ ' + interaction.user.username);
    } catch (e) {
        console.error('[log] فشل إرسال اللوق في الخاص:', e.message);
    }

    if (deleteAfter) {
        t.deleted = true; saveAll();
        const chD = interaction.channel;
        setTimeout(async () => {
            try { await chD.delete('حذف تذكرة #' + t.ticketNumber); } catch {}
            delete activeTickets[chD.id];
            saveAll();
        }, 3000);
        return;
    }

    // ========== 5) نظام التقييم — يرسل في الخاص أولاً (تقييم التذكرة) ==========
    const rateStaff = t.claimedBy || (interaction.user.id !== t.ownerId ? interaction.user.id : null);
    if (rateStaff && t.ownerId) {
        try {
            const reqPayload = buildRatingRequest(
                Object.assign({}, t, { claimedBy: rateStaff }),
                interaction.guild,
                t.ownerId
            );

            let dmSent = false;
            // أولاً: الخاص (هذا المطلوب)
            try {
                const owner = await client.users.fetch(t.ownerId).catch(() => null);
                if (owner) {
                    await owner.send(reqPayload);
                    dmSent = true;
                    console.log('[rating] ✅ تم إرسال طلب تقييم التذكرة في الخاص لـ ' + t.ownerId);
                }
            } catch (e) {
                console.error('[rating] فشل الإرسال في الخاص:', e.message);
            }

            // ثانياً: لو الخاص فشل → أرسل في روم التذكرة
            if (!dmSent) {
                try {
                    await interaction.channel.send(Object.assign({
                        content: '<@' + t.ownerId + '> ⭐ تم إغلاق تذكرتك، يمكنك تقييم الإداري من هنا:'
                    }, reqPayload));
                    console.log('[rating] أرسلت التقييم في الروم (لأن الخاص فشل)');
                } catch (e2) {
                    console.error('[rating] فشل الإرسال في الروم أيضاً:', e2.message);
                }
            }
        } catch (e) {
            console.error('[rating] خطأ عام في التقييم:', e.message);
        }
    } else {
        console.log('[rating] ما فيه إداري للتقييم');
    }
}

/** حذف التذكرة: تظهر نافذة لكتابة السبب أولاً ثم يُنفَّذ الحذف */
async function handleTicketDelete(interaction) {
    const t = activeTickets[interaction.channel.id];
    if (!t) return interaction.reply({ content: '❌ هذه ليست تذكرة.', flags: MessageFlags.Ephemeral });
    if (!hasTicketPermission(interaction.member, 'delete', t)) return interaction.reply({ content: '❌ لا تملك صلاحية حذف التذاكر.', flags: MessageFlags.Ephemeral });
    const modal = new ModalBuilder().setCustomId('ticket_delete_modal').setTitle('حذف التذكرة');
    modal.addComponents(new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('reason').setLabel('سبب حذف / إغلاق التذكرة').setStyle(TextInputStyle.Paragraph)
            .setRequired(true).setMaxLength(900).setPlaceholder('مثال: تم حل المشكلة / تذكرة مكررة')
    ));
    return interaction.showModal(modal);
}
async function finishTicketDelete(interaction, reason) {
    const t = activeTickets[interaction.channel.id];
    if (!t) return interaction.reply({ content: '❌ هذه ليست تذكرة.', flags: MessageFlags.Ephemeral });
    if (!hasTicketPermission(interaction.member, 'delete', t)) return interaction.reply({ content: '❌ لا تملك صلاحية حذف التذاكر.', flags: MessageFlags.Ephemeral });
    const why = String(reason || '').trim() || 'بدون سبب';
    // تذكرة لم تُغلق بعد: احفظ السجل (الملف + معلومات التذكرة بالسبب) ثم احذف
    if (!t.closed) return finishTicketClose(interaction, why, { deleteAfter: true });
    // تذكرة مغلقة سابقاً (سجلها أُرسل وقت الإغلاق): حذف مباشر مع تسجيل السبب
    await interaction.reply({ content: '🗑️ سيتم حذف التذكرة خلال 3 ثوانٍ...\n📝 السبب: ' + why });
    t.deleted = true;
    saveAll();
    const ch = interaction.channel;
    setTimeout(async () => {
        try { await ch.delete('حذف تذكرة #' + t.ticketNumber + ' — ' + why.slice(0, 200)); } catch {}
        delete activeTickets[ch.id];
        saveAll();
    }, 3000);
}


async function handleTicketRename(interaction) {
    const t = activeTickets[interaction.channel.id];
    if (!t || t.closed) return interaction.reply({ content: '❌ هذه ليست تذكرة نشطة.', flags: MessageFlags.Ephemeral });
    if (!hasTicketPermission(interaction.member, 'rename', t)) return interaction.reply({ content: '❌ لا تملك صلاحية تغيير اسم التذكرة.', flags: MessageFlags.Ephemeral });
    const modal = new ModalBuilder().setCustomId('ticket_rename_modal').setTitle('تغيير اسم التذكرة');
    modal.addComponents(new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('name').setLabel('الاسم الجديد').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(90)
    ));
    await interaction.showModal(modal);
}

async function handleTicketSummonOwner(interaction) {
    const t = activeTickets[interaction.channel.id];
    if (!t || t.closed) return interaction.reply({ content: '❌ هذه ليست تذكرة نشطة.', flags: MessageFlags.Ephemeral });
    if (!hasTicketPermission(interaction.member, 'summon', t)) return interaction.reply({ content: '❌ لا تملك صلاحية استدعاء صاحب التذكرة.', flags: MessageFlags.Ephemeral });
    try {
        const u = await client.users.fetch(t.ownerId);
        const gIcon = interaction.guild.iconURL?.({ size: 128 });
        const summonEmb = new EmbedBuilder().setColor(BLUE).setTitle('📢 استدعاء')
            .setDescription('نفيدك بأن فريق الدعم يطلب حضورك في تذكرتك **#' + t.ticketNumber + '** في **' + interaction.guild.name + '**.\nيرجى المراجعة والرد في أقرب وقت.')
            .addFields(
                { name: '🎫 رقم التذكرة', value: '#' + t.ticketNumber, inline: true },
                { name: '📂 القسم', value: t.departmentName || '-', inline: true },
                { name: '👮 بواسطة', value: '<@' + interaction.user.id + '>', inline: true }
            )
            .setFooter({ text: interaction.guild.name, ...(gIcon ? { iconURL: gIcon } : {}) })
            .setTimestamp();
        if (gIcon) summonEmb.setThumbnail(gIcon);
        const linkRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel('فتح التذكرة').setEmoji(tEmo('ticket'))
                .setURL('https://discord.com/channels/' + interaction.guild.id + '/' + interaction.channel.id)
        );
        await u.send({ embeds: [summonEmb], components: [linkRow] });
        await interaction.reply({ content: `✅ تم إرسال استدعاء لصاحب التذكرة.`, flags: MessageFlags.Ephemeral });
    } catch {
        await interaction.reply({ content: '⚠️ تعذّر إرسال رسالة خاصة لصاحب التذكرة.', flags: MessageFlags.Ephemeral });
    }
}

/** إرسال طلب تقييم الإدارة لصاحب التذكرة (في الخاص أولاً) */
async function handleTicketRateAdmin(interaction) {
    const t = activeTickets[interaction.channel.id];
    if (!t || t.closed) return interaction.reply({ content: '❌ هذه ليست تذكرة نشطة.', flags: MessageFlags.Ephemeral });
    if (!hasTicketPermission(interaction.member, 'rate', t)) return interaction.reply({ content: '❌ لا تملك صلاحية طلب التقييم.', flags: MessageFlags.Ephemeral });

    const rateStaff = t.claimedBy || interaction.user.id;
    if (!t.ownerId) return interaction.reply({ content: '❌ لا يوجد صاحب لهذه التذكرة.', flags: MessageFlags.Ephemeral });

    const reqPayload = buildRatingRequest(
        Object.assign({}, t, { claimedBy: rateStaff }),
        interaction.guild,
        t.ownerId
    );

    let dmOk = false;
    try {
        const owner = await client.users.fetch(t.ownerId);
        await owner.send(reqPayload);
        dmOk = true;
        console.log('[rating] تم إرسال تقييم التذكرة في الخاص لـ ' + t.ownerId);
    } catch (e) {
        console.error('[rating] فشل الخاص:', e.message);
    }

    if (dmOk) {
        await interaction.reply({ content: '✅ تم إرسال طلب **تقييم التذكرة والإدارة** لصاحب التذكرة في الخاص.', flags: MessageFlags.Ephemeral });
    } else {
        // fallback: أرسل في الروم إذا الخاص فشل
        try {
            await interaction.channel.send(Object.assign({
                content: '<@' + t.ownerId + '> ⭐ طلب تقييم الإدارة (تقييم التذكرة):'
            }, reqPayload));
            await interaction.reply({ content: '⚠️ الرسائل الخاصة مغلقة لدى صاحب التذكرة، تم إرسال طلب التقييم داخل التذكرة.', flags: MessageFlags.Ephemeral });
        } catch (e2) {
            await interaction.reply({ content: '❌ تعذّر إرسال طلب التقييم (الرسائل الخاصة مغلقة ولا يوجد روم بديل).', flags: MessageFlags.Ephemeral });
        }
    }
}


let readyHandled = false;
async function onBotReady() {
    if (readyHandled) return;
    readyHandled = true;
    if (startupWatchdog) clearTimeout(startupWatchdog);
    startupWatchdog = null;
    console.log(`✅ تم الدخول: ${client.user.tag} (${client.user.id})`);
    client.user.setPresence({ status: 'online', activities: [{ name: config.bot?.activity?.text || 'نظام الرقابة', type: ActivityType.Watching }] });

    // تأكد أن البوت داخل السيرفر المحدد
    const guild = client.guilds.cache.get(SERVER_ID) || await client.guilds.fetch(SERVER_ID).catch(() => null);
    if (!guild) {
        console.error('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.error('❌ البوت ليس عضواً في السيرفر المحدد في config.json');
        console.error(`Guild ID: ${SERVER_ID}`);
        console.error('ادخل البوت للسيرفر أولاً ثم أعد التشغيل');
        console.error('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    } else {
        console.log(`[guild] ${guild.name} (${guild.id})`);
        guild.members.fetch().then(ms => console.log(`[guild] تم تحميل ${ms.size} عضو`)).catch(e => console.warn('[guild] تعذّر تحميل الأعضاء:', e.message));
        // تهيئة وقت الفويس للأعضاء الموجودين حالياً في رومات صوتية
        try {
            let voiceInit = 0;
            guild.channels.cache.filter(c => c.isVoiceBased?.() || c.type === 2 || c.type === 13).forEach(ch => {
                ch.members?.forEach(mem => {
                    if (mem.user.bot) return;
                    if (guild.afkChannelId && ch.id === guild.afkChannelId) return;
                    const st = ensureStats(mem.id);
                    if (!st.joinedAt) { st.joinedAt = Date.now(); voiceInit++; }
                });
            });
            if (voiceInit) console.log(`[stats] تمت تهيئة وقت الفويس لـ ${voiceInit} عضو متصل حالياً`);
        } catch (e) { console.warn('[stats] init voice:', e.message); }
    }

    // تسجيل أوامر السلاش على السيرفر (تظهر فوراً)
    const appId = client.user.id;
    const rest = new REST({ version: '10' }).setToken(BOT_TOKEN);
    try {
        // أوامر عامة قديمة تسبب ظهور أوامر مكررة وفشل "الأمر قديم" → نحذفها (البوت يستخدم أوامر السيرفر فقط)
        try {
            const globals = await rest.get(Routes.applicationCommands(appId));
            if (Array.isArray(globals) && globals.length) {
                await rest.put(Routes.applicationCommands(appId), { body: [] });
                console.log('[slash] 🧹 تم حذف ' + globals.length + ' أمر عام مكرر');
            }
        } catch (ge) { console.warn('[slash] تعذّر فحص الأوامر العامة:', ge.message); }

        // لا نعيد تسجيل الأوامر إلا إذا تغيّرت (إعادة التسجيل بلا داعٍ تجعل ديسكورد يعرض "الأمر قديم" أول مرة)
        const hashFile = path.join(DATA_DIR, 'commands.hash');
        const newHash = require('crypto').createHash('sha256').update(JSON.stringify(slashCommands)).digest('hex');
        let oldHash = ''; try { oldHash = fs.readFileSync(hashFile, 'utf8').trim(); } catch {}
        let existing = [];
        try { existing = await rest.get(Routes.applicationGuildCommands(appId, SERVER_ID)); } catch {}
        const same = oldHash === newHash && Array.isArray(existing) && existing.length === slashCommands.length;
        if (same) {
            console.log('[slash] ✅ الأوامر محدّثة مسبقاً (' + existing.length + ' أمر) — لا حاجة لإعادة التسجيل');
        } else {
            console.log(`[slash] جاري تسجيل ${slashCommands.length} أمر على السيرفر ${SERVER_ID}...`);
            let data, bulkOk = true;
            try { data = await rest.put(Routes.applicationGuildCommands(appId, SERVER_ID), { body: slashCommands }); }
            catch (putErr) {
                bulkOk = false;
                console.error('[slash] ⚠️ التسجيل الجماعي فشل: ' + putErr.message + (putErr.rawError ? ' ' + JSON.stringify(putErr.rawError).slice(0, 400) : ''));
                console.error('[slash] سأسجل الأوامر واحداً واحداً...');
                data = [];
                for (const cmd of slashCommands) {
                    try { data.push(await rest.post(Routes.applicationGuildCommands(appId, SERVER_ID), { body: cmd })); }
                    catch (ce) { console.error('[slash] ❌ فشل الأمر /' + cmd.name + ': ' + ce.message + (ce.rawError ? ' ' + JSON.stringify(ce.rawError).slice(0, 400) : '')); }
                }
            }
            if (bulkOk) { try { fs.writeFileSync(hashFile, newHash); } catch {} }
            console.log(`[slash] ✅ تم تسجيل ${Array.isArray(data) ? data.length : slashCommands.length} أمر بنجاح`);
        }
        console.log('[slash] الأوامر: ' + slashCommands.map(c => '/' + c.name).join(' · '));
        if (config.bot?.singleCommand === false && !slashCommands.some(c => c.name === 'tickets')) console.error('[slash] ⚠️ أمر /tickets غير موجود: تأكد أن features/tickets.js موجود وأن features/index.js فيه \'tickets\'');
    } catch (e) {
        console.error('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.error('[slash] ❌ فشل تسجيل أوامر السلاش');
        console.error('[slash] السبب:', e.message);
        if (e.code) console.error('[slash] code:', e.code);
        if (e.rawError) console.error('[slash] details:', JSON.stringify(e.rawError).slice(0, 400));
        if (/Missing Access|50001/i.test(String(e.message) + String(e.code))) {
            console.error('');
            console.error('المشكلة: البوت ما عنده صلاحية applications.commands');
            console.error('الحل: اطلع البوت من السيرفر وأعد دعوته بهذا الرابط:');
            console.error(`https://discord.com/api/oauth2/authorize?client_id=${appId}&permissions=8&scope=bot%20applications.commands`);
        }
        if (/Unknown Guild|50055/i.test(String(e.message))) {
            console.error('السيرفر غير موجود أو البوت ليس عضواً فيه');
        }
        if (/invalid token|401/i.test(String(e.message))) {
            console.error('التوكن غير صالح — اعمل Reset Token من Developer Portal');
        }
        console.error('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    }
    setInterval(() => {
        const every = (getMod().clockPointsEveryMinutes || 50) * 60000;
        const pts = getMod().clockPointsAmount || 2;
        if (pts <= 0) return;
        for (const [uid, c] of Object.entries(staffClock)) {
            if (!c.in) continue;
            if (!c.lastPointAt) c.lastPointAt = c.in;
            if (Date.now() - c.lastPointAt >= every) { c.lastPointAt = Date.now(); c.points = (c.points || 0) + pts; saveAll(); }
        }
    }, 60000);
    // انتهاء الباند المؤقت
    setInterval(async () => {
        try {
            const banRoleId = allBanRoleIds()[0];
            const g = client.guilds.cache.get(SERVER_ID);
            if (!banRoleId || !g) return;
            for (const [uid, logs] of Object.entries(memberLogs)) {
                for (const l of logs) {
                    if (l.type === 'باند مؤقت' && l.active && l.endsAt && l.endsAt <= Date.now()) {
                        l.active = false;
                        const m = await g.members.fetch(uid).catch(() => null);
                        if (m && heldBanRole(m)) await liftBanRoles(m, heldBanRole(m), 'انتهاء الباند المؤقت').catch(() => {});
                        saveAll();
                        const u = await client.users.fetch(uid).catch(() => null);
                        if (u) await sendActionDM(u, g, 'فك باند', 'انتهاء مدة الباند المؤقت', null);
                    }
                }
            }
        } catch {}
    }, 60000);
}
client.once('clientReady', onBotReady);
client.once('ready', onBotReady);

client.on('guildMemberRemove', async (member) => {
    try {
        if (member.guild.id !== SERVER_ID) return;
        features.onMemberRemove(member);
        const roles = member.roles?.cache ? [...member.roles.cache.values()].filter(r => r.id !== member.guild.id).sort((a, b) => b.position - a.position) : [];
        const rec = {
            roleIds: roles.filter(r => !r.managed).map(r => r.id),
            roleNames: roles.map(r => r.name),
            tag: member.user?.username,
            nick: member.nickname || member.displayName || member.user?.globalName || member.user?.username,
            leftAt: Date.now()
        };
        leftMemberRoles[member.id] = rec;
        saveAll();
        await sendLog(member.guild, 'leave', buildMemberLeaveEmbed(member.user, rec));
    } catch (e) { console.error('[leave]', e.message); }
});

client.on('guildMemberAdd', async (member) => {
    try {
        if (member.guild.id !== SERVER_ID) return;
        features.onMemberAdd(member);
        const rec = leftMemberRoles[member.id];
        if (!rec) {
            const e = new EmbedBuilder().setColor(BLUE).setTitle('📥 انضمام عضو جديد')
                .setDescription('**الحساب:** <@' + member.id + '> (`' + member.user.username + '`)\n**المعرف:** `' + member.id + '`')
                .setFooter({ text: 'معرف العضو: ' + member.id }).setTimestamp();
            try { e.setThumbnail(member.user.displayAvatarURL({ size: 128 })); } catch {}
            return sendLog(member.guild, 'join', e);
        }
        delete leftMemberRoles[member.id];
        const within = Date.now() - (rec.leftAt || 0) <= 24 * 3600000;
        const restored = []; let failed = 0;
        if (within) {
            for (const id of rec.roleIds || []) {
                const role = member.guild.roles.cache.get(id);
                if (!role) continue;
                try { await member.roles.add(id, 'عودة خلال 24 ساعة'); restored.push(role.name); } catch { failed++; }
            }
            if (rec.nick && rec.nick !== member.user.username) { try { await member.setNickname(rec.nick, 'عودة خلال 24 ساعة'); } catch {} }
        }
        saveAll();
        await sendLog(member.guild, 'join', buildMemberReturnEmbed(member.user, rec, within, restored, failed));
    } catch (e) { console.error('[join]', e.message); }
});

client.on('messageCreate', async (msg) => {
    // منع السبام: يفحص كل الرسائل (المستخدمين والبوتات والويب هوك)
    try { if (msg.guild && await features.onRawMessage(msg)) return; } catch (e) { console.error('[antispam]', e.message); }
    if (msg.author.bot || !msg.guild) return;

    // احتساب رسائل الشات (لجميع الأعضاء)
    try {
        const st = ensureStats(msg.author.id);
        st.messages = (st.messages || 0) + 1;
    } catch {}

    // الأنظمة المتقدمة: الخط • الردود التلقائية • المستويات
    try { if (await features.onMessage(msg)) return; } catch (e) { console.error('[features]', e.message); }

    // أوامر الإحصائيات (حسابي / توب فويس / توب شات) — تعمل فقط في الروم المحدد
    if (statsGate(msg)) {
        const cfg = getStatsCfg();
        const raw = msg.content.trim().replace(/^[-ـ]+/, '').trim();
        const lower = raw.toLowerCase().replace(/\s+/g, ' ');
        const parts = lower.split(/\s+/);
        const cmd = (parts[0] || '').replace(/\s+/g, '');
        const arg = (parts[1] || '').replace(/\s+/g, '');

        try {
            if (cmd === cfg.account) {
                return await cmdStatsAccount(msg);
            }
            if (cmd === cfg.top) {
                if (!arg) return await cmdStatsTopHelp(msg);
                if (arg === cfg.topvoice || arg === 'فويس' || arg === 'voice') return await cmdStatsTopVoice(msg);
                if (arg === cfg.topchat || arg === 'شات' || arg === 'chat') return await cmdStatsTopChat(msg);
                return msg.reply({ embeds: [new EmbedBuilder().setColor(0xED4245)
                    .setDescription('❌ اكتب **' + cfg.topvoice + '** أو **' + cfg.topchat + '** بعد **-' + cfg.top + '**')] });
            }
        } catch (e) {
            console.error('[stats]', e);
            try { await msg.reply({ content: '❌ حدث خطأ: ' + e.message }); } catch {}
            return;
        }
    }

    const m = msg.content.trim().match(/^[-ـ]?(\S+)(?:\s+([\s\S]+))?$/i);
    if (!m) return;
    const h = CMDS[m[1].toLowerCase()];
    if (!h) return;
    if (features.isCommandDisabled(m[1].toLowerCase())) return;
    try { await h(msg, m[2] || ''); } catch (e) { console.error(e); try { await msg.reply({ content: '❌ حدث خطأ غير متوقع: ' + e.message }); } catch {} }
});

// أوامر الإعدادات والمعلومات تُؤجَّل (إن تأخرت) كرد مخفي، والباقي كرد ظاهر
const STATUS_COLORS = { '✅': BLUE, '❌': BLUE, '⚠️': BLUE, 'ℹ️': BLUE, '🔄': BLUE };
function niceStatus(opts) {
    // يحوّل رسائل الحالة النصية (✅ ❌ ⚠️) إلى إيمبد أنيق موحّد
    if (opts.embeds || opts.components || opts.files || typeof opts.content !== 'string') return opts;
    const m = opts.content.match(/^(✅|❌|⚠️|ℹ️|🔄)\s*([\s\S]+)$/);
    if (!m || opts.content.length > 3800) return opts;
    opts.embeds = [new EmbedBuilder().setColor(STATUS_COLORS[m[1]]).setDescription(((k) => { try { return features.H.E(k) || m[1]; } catch { return m[1]; } })({ '✅': 'ui.ok', '❌': 'ui.err', '⚠️': 'ui.warn', 'ℹ️': 'ui.info', '🔄': 'ui.load' }[m[1]]) + '  ' + m[2])];
    delete opts.content;
    return opts;
}
const EPHEMERAL_CMDS = new Set(['ping', 'help', 'myrank', 'ticketranks', 'setmodlogs', 'setadmin', 'botperms', 'setbotrole', 'setrole', 'setclockpoints', 'setpresence', 'clockpanel', 'panel', 'setticket', 'testrating', 'setratingchannel', 'maxtickets', 'dept', 'system', 'setsupportvoice', 'staffpoints', 'rating', 'ticketstats', 'setrewards', 'setstats', 'setstatscmds']);
features.ephemeralCommands.forEach(c => EPHEMERAL_CMDS.add(c));

client.on('interactionCreate', async (i) => {
    let autoDefer = null;
    // ===== غلاف آمن: يمنع أخطاء "التفاعل فشل" و"Interaction already acknowledged" =====
    if (!i.isAutocomplete() && typeof i.reply === 'function') {
        const origReply = i.reply.bind(i);
        i.reply = async (o) => {
            clearTimeout(autoDefer);
            const opts = (typeof o === 'string') ? { content: o } : { ...o };
            niceStatus(opts);
            if (i.deferred && !i.replied) { delete opts.flags; delete opts.ephemeral; return i.editReply(opts); }
            if (i.replied || i.deferred) return i.followUp(opts);
            return origReply(opts);
        };
        if (typeof i.showModal === 'function') { const os = i.showModal.bind(i); i.showModal = async (m) => { clearTimeout(autoDefer); return os(m); }; }
        if (typeof i.update === 'function') { const ou = i.update.bind(i); i.update = async (o) => { clearTimeout(autoDefer); return ou(o); }; }
        // أمر سلاش أو نافذة: إن لم يُرد خلال 2.2 ثانية نؤجّل الرد تلقائياً قبل أن تنتهي مهلة ديسكورد (3 ثوان)
        if (i.isChatInputCommand?.() || i.isModalSubmit?.()) {
            autoDefer = setTimeout(async () => {
                if (i.replied || i.deferred) return;
                try {
                    const eph = i.isChatInputCommand?.() && EPHEMERAL_CMDS.has(i.commandName);
                    await i.deferReply(eph ? { flags: MessageFlags.Ephemeral } : {});
                } catch {}
            }, 2200);
        }
    }
    try {
        if (i.isAutocomplete()) {
            if (['dept', 'panel', 'system'].includes(i.commandName)) {
                const f = i.options.getFocused(true);
                const q = String(f.value || '').toLowerCase();
                if (f.name === 'system') {
                    const all = [...(i.commandName === 'system' ? [] : [{ id: 'main', name: 'الرئيسي' }]), ...getSystems()];
                    return i.respond(all.filter(x => x.name.toLowerCase().includes(q)).slice(0, 25).map(x => ({ name: ('🎫 ' + x.name).slice(0, 100), value: x.id })));
                }
                const list = (config.departments || []).filter(d => d.name.toLowerCase().includes(q)).slice(0, 25)
                    .map(d => ({ name: `${d.emoji || ''} ${d.name}`.trim().slice(0, 100), value: d.id }));
                return i.respond(list);
            }
            return;
        }
        if ((i.isStringSelectMenu() || i.isRoleSelectMenu() || i.isButton()) && i.customId.startsWith('bp_')) return handleBotPermsComponent(i);
        if (i.isChatInputCommand()) {
            if (await features.handleSlash(i)) return;
            const n = i.commandName;
            if (n === 'ping') return i.reply({ content: `🏓 زمن الاستجابة: **${client.ws.ping}ms**`, flags: MessageFlags.Ephemeral });
            if (n === 'help') {
                const hg = i.guild; const hI = hg?.iconURL?.({ size: 256 });
                const hEmb = new EmbedBuilder().setColor(BLUE)
                    .setAuthor({ name: (hg?.name || 'البوت'), ...(hI ? { iconURL: hI } : {}) })
                    .setTitle('📚 دليل الأوامر')
                    .setDescription('جميع أوامر البوت مرتبة حسب النظام. الأوامر التي تبدأ بـ `-` تُكتب في الشات، والتي تبدأ بـ `/` أوامر سلاش.')
                    .addFields(
                        { name: '🕐 الدوام والنقاط', value: '`-تسجيلدخول` `-تسجيلخروج` `-وقتي` `-لوحةوقت` `-نقاط`\n`/staffpoints` النقاط والإعداد\n`/rating` تقييمات إداري' },
                        { name: '🎫 التذاكر', value: '`/tickets` قائمة التذاكر (اللوحات • الأقسام • الإعدادات • الصلاحيات)\n`/ticketstats` الإحصائيات\n`/testrating`' },
                        { name: '💰 المكافآت', value: '`/setrewards` إعداد النظام (الروم + المبلغ + المدة)\nفي الروم المحدد اكتب: `مكافأة` `توب` `معلومات`' },
                        { name: '📊 الإحصائيات', value: '`/setstats` تحديد روم الأوامر\n`/setstatscmds` تغيير أسماء الأوامر\nفي الروم: `حسابي` `توب فويس` `توب شات`' },
                        { name: '👋 الترحيب والمغادرة', value: '`/welcomesettings` قائمة الترحيب والصورة والمغادرة\n`/testwelcome` ترحيب تجريبي' },
                        { name: '🧩 الإيمبد والردود', value: '`/embed` صانع الإيمبد\n`/autoreply` الردود التلقائية\n`/setline` أمر الخط' },
                        { name: '🏷️ الرتب والمستويات', value: '`/selfroles` الرتب القابلة للأخذ\n`/levels` نظام المستويات • `/rank` `/leveltop`' },
                        { name: '🔊 الرومات المؤقتة', value: '`/tempvoice` إعدادات الرومات الصوتية المؤقتة\n`/cmdmanager` إدارة أوامر الشات' },
                        { name: '⚙️ الإعدادات', value: '`/setadmin` `/botperms` `/setbotrole`\n`/setclockpoints` `/setpresence` `/clockpanel`' }
                    )
                    .setFooter({ text: 'الإدارة العليا تستخدم كل الأوامر • الرتب الأخرى حسب /botperms' });
                if (hI) hEmb.setThumbnail(hI);
                return i.reply({ embeds: [hEmb], flags: MessageFlags.Ephemeral });
            }
            if (n === 'panel') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
                const sysId = i.options.getString('system') || 'main';
                if (sysId !== 'main' && !getSystem(sysId)) return i.reply({ content: '❌ النظام غير موجود، اختره من القائمة.', flags: MessageFlags.Ephemeral });
                const panelMsg = await i.channel.send(buildPanelMessage(sysId));
                if (!config.ticket) config.ticket = {};
                const pRef = { channelId: panelMsg.channelId, messageId: panelMsg.id };
                if (sysId === 'main') config.ticket.panelRef = pRef; else getSystem(sysId).panelRef = pRef;
                saveConfig();
                return i.reply({ content: '✅ تم إرسال لوحة التذاكر', flags: MessageFlags.Ephemeral });
            }
            if (n === 'setticket') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
                if (!config.ticket) config.ticket = {};
                const changes = [];
                const oc = i.options.getChannel('open_category');
                const cc = i.options.getChannel('closed_category');
                const logs = i.options.getChannel('logs');
                const role = i.options.getRole('support_role');
                const banner = i.options.getString('banner');
                const color = i.options.getString('color');
                const rules = i.options.getString('rules');
                if (oc) { config.ticket.openCategoryId = oc.id; changes.push('التصنيف المفتوح: ' + oc.name); }
                if (cc) { config.ticket.closedCategoryId = cc.id; changes.push('التصنيف المغلق: ' + cc.name); }
                if (logs) { config.ticket.logsChannelId = logs.id; changes.push('لوق: ' + logs.toString()); }
                if (role) { if (!config.roles) config.roles = {}; config.roles.support = role.id; changes.push('رتبة دعم: ' + role.name); }
                if (banner) { if (!config.ticket.panel) config.ticket.panel = {}; config.ticket.panel.banner = banner; changes.push('صورة اللوحة'); }
                if (color) { if (!config.ticket.panel) config.ticket.panel = {}; let c = color.trim(); if (!c.startsWith('#')) c = '#' + c; config.ticket.panel.color = c; changes.push('لون: ' + c); }
                const pTitle = i.options.getString('title');
                const pDesc = i.options.getString('description');
                const welcome = i.options.getString('welcome');
                if (!config.ticket.panel) config.ticket.panel = {};
                if (pTitle) { config.ticket.panel.title = pTitle.trim().slice(0, 200); changes.push('عنوان اللوحة'); }
                if (pDesc) { config.ticket.panel.description = pDesc.replace(/\\n/g, '\n').slice(0, 3000); changes.push('الوصف أعلى اللوحة'); }
                if (rules) { config.ticket.rulesText = rules.replace(/\\n/g, '\n'); config.ticket.panel.rules = config.ticket.rulesText.slice(0, 1000); changes.push('نص القوانين'); }
                if (welcome) { config.ticket.welcome = welcome.replace(/\\n/g, '\n').slice(0, 1500); changes.push('رسالة الترحيب داخل التذكرة'); }
                const tImg = i.options.getString('ticket_image');
                const tLogo = i.options.getString('ticket_logo');
                const tColor = i.options.getString('ticket_color');
                if (!config.ticket.embed) config.ticket.embed = {};
                if (tImg) { config.ticket.embed.image = tImg.trim(); changes.push('صورة داخل التذكرة'); }
                if (tLogo) { config.ticket.embed.logo = tLogo.trim(); changes.push('لوجو التذكرة'); }
                if (tColor) { let c2 = tColor.trim(); if (!c2.startsWith('#')) c2 = '#' + c2; config.ticket.embed.color = c2; changes.push('لون داخل التذكرة: ' + c2); }
                const maxT = i.options.getInteger('max_tickets');
                if (maxT != null) { config.ticket.maxTickets = maxT; changes.push('حد التذاكر لكل عضو: ' + maxT); }
                const reqReason = i.options.getBoolean('require_reason');
                if (reqReason != null) {
                    config.ticket.requireReason = reqReason;
                    changes.push(reqReason ? 'فتح التذكرة **يتطلب سبب**' : 'فتح التذكرة **بدون سبب**');
                }
                saveConfig();
                await refreshTicketPanel(i.guild);
                return i.reply({ content: changes.length ? '✅ ' + changes.join('\n') : '⚠️ لم يتم تغيير أي إعداد.', flags: MessageFlags.Ephemeral });
            }
            if (n === 'testrating') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
                try {
                    await i.user.send(buildRatingRequest({ ticketNumber: 'TEST', claimedBy: i.user.id, departmentName: 'تجربة' }, i.guild, i.user.id));
                    return i.reply({ content: '✅ أرسلت لك رسالة التقييم في الخاص.', flags: MessageFlags.Ephemeral });
                } catch (e) {
                    return i.reply({ content: '❌ تعذّر إرسال رسالة خاصة لك: ' + e.message + '\nيرجى تفعيل الرسائل الخاصة من إعدادات الخصوصية للسيرفر.', flags: MessageFlags.Ephemeral });
                }
            }
            if (n === 'setratingchannel') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
                if (!config.ticket) config.ticket = {};
                const rch = i.options.getChannel('channel');
                config.ticket.ratingChannelId = rch.id;
                saveConfig();
                return i.reply({ content: '✅ ستُرسل تقييمات الإداريين في الروم: ' + rch.toString(), flags: MessageFlags.Ephemeral });
            }
            if (n === 'maxtickets') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
                if (!config.ticket) config.ticket = {};
                const cnt = i.options.getInteger('count');
                config.ticket.maxTickets = cnt;
                saveConfig();
                return i.reply({ content: cnt === 0 ? '✅ صار العضو يقدر يفتح تذاكر **بدون حد**.' : '✅ الحد الأقصى للتذاكر المفتوحة لكل عضو: **' + cnt + '**', flags: MessageFlags.Ephemeral });
            }
            if (n === 'system') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
                if (!config.ticketSystems) config.ticketSystems = [];
                const sub = i.options.getSubcommand();
                const normColor = c => { let x = String(c).trim(); if (!x.startsWith('#')) x = '#' + x; return x; };
                const countD = id => (config.departments || []).filter(d => deptSystemId(d) === id).length;
                const fmtS = s => `🎫 **${s.name}** · ${countD(s.id)} قسم${s.openCategoryId ? ' · 📂 <#' + s.openCategoryId + '>' : ''}`;
                if (sub === 'list') {
                    const lines = ['🎫 **الرئيسي** · ' + countD('main') + ' قسم (يُضبط بـ /setticket)', ...config.ticketSystems.map(fmtS)];
                    return i.reply({ content: '📋 **أنظمة التذاكر:**\n' + lines.join('\n'), flags: MessageFlags.Ephemeral });
                }
                if (sub === 'add') {
                    if (config.ticketSystems.length >= 20) return i.reply({ content: '❌ بلغت الحد الأقصى للأنظمة (20).', flags: MessageFlags.Ephemeral });
                    const oc = i.options.getChannel('open_category'), cc = i.options.getChannel('closed_category'), col = i.options.getString('color');
                    const sNew = { id: 'sys_' + Date.now().toString(36), name: i.options.getString('name'), title: i.options.getString('title') || '', description: (i.options.getString('description') || '').replace(/\\n/g, '\n'), color: col ? normColor(col) : '', banner: i.options.getString('banner') || '', openCategoryId: oc ? oc.id : '', closedCategoryId: cc ? cc.id : '', panelRef: null };
                    config.ticketSystems.push(sNew);
                    saveConfig();
                    return i.reply({ content: '✅ تم إنشاء النظام: ' + fmtS(sNew) + '\n\n1️⃣ أضف أقسامه: `/dept add system:' + sNew.name + '`\n2️⃣ أرسل لوحته: `/panel system:' + sNew.name + '`', flags: MessageFlags.Ephemeral });
                }
                const sys = getSystem(i.options.getString('system'));
                if (!sys) return i.reply({ content: '❌ النظام غير موجود، اختره من القائمة. (النظام الرئيسي يُضبط بـ /setticket)', flags: MessageFlags.Ephemeral });
                if (sub === 'delete') {
                    const removed = countD(sys.id);
                    config.departments = (config.departments || []).filter(d => deptSystemId(d) !== sys.id);
                    config.ticketSystems = config.ticketSystems.filter(x => x.id !== sys.id);
                    if (sys.panelRef) { try { const ch = await i.guild.channels.fetch(sys.panelRef.channelId); const pm = await ch.messages.fetch(sys.panelRef.messageId); await pm.delete(); } catch {} }
                    saveConfig();
                    return i.reply({ content: '🗑️ تم حذف النظام **' + sys.name + '** و ' + removed + ' قسم.', flags: MessageFlags.Ephemeral });
                }
                const e = { name: i.options.getString('name'), title: i.options.getString('title'), description: i.options.getString('description'), color: i.options.getString('color'), banner: i.options.getString('banner'), oc: i.options.getChannel('open_category'), cc: i.options.getChannel('closed_category') };
                if (!Object.values(e).some(Boolean)) return i.reply({ content: '⚠️ يرجى اختيار ما تريد تعديله.', flags: MessageFlags.Ephemeral });
                if (e.name) sys.name = e.name;
                if (e.title) sys.title = e.title;
                if (e.description) sys.description = e.description.replace(/\\n/g, '\n');
                if (e.color) sys.color = normColor(e.color);
                if (e.banner) sys.banner = e.banner;
                if (e.oc) sys.openCategoryId = e.oc.id;
                if (e.cc) sys.closedCategoryId = e.cc.id;
                saveConfig();
                await refreshTicketPanel(i.guild);
                return i.reply({ content: '✏️ تم تعديل النظام: ' + fmtS(sys), flags: MessageFlags.Ephemeral });
            }
            if (n === 'dept') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
                if (!config.departments) config.departments = [];
                const depts = config.departments;
                const sub = i.options.getSubcommand();
                const fmt = d => `${d.emoji || '📋'} **${d.name}**${d.description && d.description !== d.name ? ' — ' + d.description : ''}${d.roleId ? ' · <@&' + d.roleId + '>' : ''} · 🎫 ${getSystem(deptSystemId(d))?.name || 'الرئيسي'}${d.openCategoryId ? ' · 📂 <#' + d.openCategoryId + '>' : ''}`;
                if (sub === 'list') {
                    return i.reply({ content: depts.length ? '📋 **الأقسام:**\n' + depts.map((d, k) => `${k + 1}. ${fmt(d)}`).join('\n') : '⚠️ ما فيه أقسام. أضف قسم بـ `/dept add`', flags: MessageFlags.Ephemeral });
                }
                let msgText = '';
                if (sub === 'add') {
                    const sysId = i.options.getString('system') || 'main';
                    if (sysId !== 'main' && !getSystem(sysId)) return i.reply({ content: '❌ النظام غير موجود، اختره من القائمة.', flags: MessageFlags.Ephemeral });
                    if (depts.filter(x => deptSystemId(x) === sysId).length >= 25) return i.reply({ content: '❌ بلغت الحد الأقصى للأقسام في هذا النظام (25 قسماً).', flags: MessageFlags.Ephemeral });
                    const name = i.options.getString('name');
                    const role = i.options.getRole('role');
                    const dCat = i.options.getChannel('category'), dCCat = i.options.getChannel('closed_category');
                    const d = { id: 'dept_' + Date.now().toString(36), name, emoji: i.options.getString('emoji') || '📋', description: i.options.getString('description') || name, roleId: role ? role.id : '', systemId: sysId, openCategoryId: dCat ? dCat.id : '', closedCategoryId: dCCat ? dCCat.id : '' };
                    depts.push(d);
                    msgText = '✅ تمت إضافة القسم: ' + fmt(d);
                } else {
                    const d = depts.find(x => x.id === i.options.getString('dept'));
                    if (!d) return i.reply({ content: '❌ القسم غير موجود، يرجى اختياره من القائمة.', flags: MessageFlags.Ephemeral });
                    if (sub === 'delete') {
                        config.departments = depts.filter(x => x.id !== d.id);
                        msgText = '🗑️ تم حذف القسم: ' + fmt(d);
                    } else {
                        const nm = i.options.getString('name'), em = i.options.getString('emoji'), ds = i.options.getString('description'), rl = i.options.getRole('role');
                        const eSys = i.options.getString('system'), eCat = i.options.getChannel('category'), eCCat = i.options.getChannel('closed_category');
                        if (!nm && !em && !ds && !rl && !eSys && !eCat && !eCCat) return i.reply({ content: '⚠️ يرجى اختيار ما تريد تعديله (الاسم / الإيموجي / الوصف / الرتبة / النظام / التصنيف).', flags: MessageFlags.Ephemeral });
                        if (eSys) {
                            if (eSys !== 'main' && !getSystem(eSys)) return i.reply({ content: '❌ النظام غير موجود.', flags: MessageFlags.Ephemeral });
                            d.systemId = eSys;
                        }
                        if (eCat) d.openCategoryId = eCat.id;
                        if (eCCat) d.closedCategoryId = eCCat.id;
                        if (nm) d.name = nm;
                        if (em) d.emoji = em;
                        if (ds) d.description = ds;
                        if (rl) d.roleId = rl.id;
                        msgText = '✏️ تم تعديل القسم: ' + fmt(d);
                    }
                }
                saveConfig();
                const refreshed = await refreshTicketPanel(i.guild);
                return i.reply({ content: msgText + '\n' + (refreshed ? '🔄 تم تحديث قائمة اللوحة تلقائياً.' : 'ℹ️ أرسل `/panel` مرة أخرى لإظهار القائمة المحدّثة.'), flags: MessageFlags.Ephemeral });
            }
            if (n === 'clockpanel') {
                if (!isStaff(i.member, 'clock')) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
                const emb = new EmbedBuilder().setColor(BLUE).setDescription('نظام تسجيل الدخول والخروج للإدارة');
                const r1 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('clock_in_btn').setLabel('تسجيل دخول').setStyle(ButtonStyle.Success),
                    new ButtonBuilder().setCustomId('clock_out_btn').setLabel('تسجيل خروج').setStyle(ButtonStyle.Danger)
                );
                const r2 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('clock_admin_btn').setLabel('الإدارة').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('clock_staff_only').setLabel('للمسؤولين فقط').setStyle(ButtonStyle.Secondary).setDisabled(true)
                );
                await i.channel.send({ embeds: [emb], components: [r1, r2] });
                return i.reply({ content: '✅ تم تنفيذ الطلب بنجاح.', flags: MessageFlags.Ephemeral });
            }
            if (n === 'setsupportvoice') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
                if (!config.moderation) config.moderation = {};
                if (!Array.isArray(config.moderation.supportVoiceChannelIds)) {
                    config.moderation.supportVoiceChannelIds = config.moderation.supportVoiceChannelId
                        ? [config.moderation.supportVoiceChannelId] : [];
                }
                const addCh = i.options.getChannel('channel');
                const remCh = i.options.getChannel('remove');
                const doList = i.options.getBoolean('list');
                const changes = [];
                if (addCh) {
                    if (!config.moderation.supportVoiceChannelIds.includes(addCh.id)) {
                        config.moderation.supportVoiceChannelIds.push(addCh.id);
                        changes.push('➕ أُضيف: ' + addCh.toString());
                    } else {
                        changes.push('⚠️ موجود مسبقاً: ' + addCh.toString());
                    }
                }
                if (remCh) {
                    const before = config.moderation.supportVoiceChannelIds.length;
                    config.moderation.supportVoiceChannelIds = config.moderation.supportVoiceChannelIds.filter(id => id !== remCh.id);
                    if (config.moderation.supportVoiceChannelIds.length < before) changes.push('➖ حُذف: ' + remCh.toString());
                    else changes.push('⚠️ ما كان موجود: ' + remCh.toString());
                }
                // keep legacy single for compatibility
                config.moderation.supportVoiceChannelId = config.moderation.supportVoiceChannelIds[0] || '';
                saveConfig();
                const list = config.moderation.supportVoiceChannelIds.map(id => '<#' + id + '>').join('\n') || 'لا يوجد';
                if (doList || (!addCh && !remCh)) {
                    return i.reply({ content: '📋 **رومات الدعم الفني الصوتية:**\n' + list, flags: MessageFlags.Ephemeral });
                }
                return i.reply({ content: '✅ ' + changes.join('\n') + '\n\n📋 الحالي:\n' + list, flags: MessageFlags.Ephemeral });
            }
            if (n === 'staffpoints') {
                const action = i.options.getString('action');
                if (action === 'board') {
                    return i.reply({ embeds: [buildStaffPointsBoard()] });
                }
                if (action === 'me') {
                    const c = ensureClock(i.user.id);
                    const every = (getMod().clockPointsEveryMinutes || 50);
                    const vpts = (getMod().clockPointsAmount || 2);
                    const tpts = (getTicketCfg().claimPoints != null) ? getTicketCfg().claimPoints : 1;
                    return i.reply({ embeds: [new EmbedBuilder().setColor(BLUE).setTitle('📊 رصيد نقاطي').setThumbnail(i.user.displayAvatarURL({ size: 128 })).setDescription('<@' + i.user.id + '>')
                        .addFields(
                            { name: '🏆 إجمالي النقاط', value: '**' + (c.points || 0) + '**', inline: true },
                            { name: '🎫 تذاكر مستلمة', value: String(c.ticketsClaimed || 0), inline: true },
                            { name: '📆 وقت أسبوعي', value: fmtDur(c.totalMsWeek || 0), inline: true },
                            { name: '📌 نظام النقاط', value: 'تذكرة = **' + tpts + '** نقطة\nكل **' + every + '** دقيقة فويس = **' + vpts + '** نقطة', inline: false }
                        )], flags: MessageFlags.Ephemeral });
                }
                if (action === 'member') {
                    if (!isStaff(i.member, 'stats')) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
                    const target = i.options.getUser('member');
                    if (!target) return i.reply({ content: '❌ يرجى تحديد العضو.', flags: MessageFlags.Ephemeral });
                    const c = ensureClock(target.id);
                    return i.reply({ embeds: [new EmbedBuilder().setColor(BLUE).setTitle('📊 رصيد نقاط عضو').setThumbnail(target.displayAvatarURL({ size: 128 }))
                        .addFields(
                            { name: 'العضو', value: '<@' + target.id + '>', inline: true },
                            { name: 'النقاط', value: '**' + (c.points || 0) + '**', inline: true },
                            { name: 'تذاكر', value: String(c.ticketsClaimed || 0), inline: true },
                            { name: '📆 وقت أسبوعي', value: fmtDur(c.totalMsWeek || 0), inline: true }
                        )] });
                }
                if (action === 'setup') {
                    if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
                    if (!config.moderation) config.moderation = {};
                    if (!config.ticket) config.ticket = {};
                    const changes = [];
                    const vc = i.options.getChannel('support_voice');
                    const tp = i.options.getInteger('ticket_points');
                    const vm = i.options.getInteger('voice_minutes');
                    const vp = i.options.getInteger('voice_points');
                    const ex = i.options.getInteger('exempt_minutes');
                    if (ex != null) { config.moderation.presenceExemptMinutes = ex; changes.push(ex > 0 ? ('إعفاء من التحقق بعد ' + ex + ' دقيقة') : 'تم تعطيل الإعفاء من التحقق'); }
                    if (vc) {
                        if (!Array.isArray(config.moderation.supportVoiceChannelIds)) config.moderation.supportVoiceChannelIds = [];
                        if (!config.moderation.supportVoiceChannelIds.includes(vc.id)) config.moderation.supportVoiceChannelIds.push(vc.id);
                        config.moderation.supportVoiceChannelId = vc.id;
                        changes.push('روم الفويس: ' + vc.toString());
                    }
                    if (tp != null) { config.ticket.claimPoints = tp; changes.push('نقاط التذكرة: ' + tp); }
                    if (vm != null) { config.moderation.clockPointsEveryMinutes = vm; changes.push('كل ' + vm + ' دقيقة فويس'); }
                    if (vp != null) { config.moderation.clockPointsAmount = vp; changes.push('نقاط الفويس: ' + vp); }
                    saveConfig();
                    if (!changes.length) {
                        const every = config.moderation.clockPointsEveryMinutes || 50;
                        const vpts = config.moderation.clockPointsAmount || 2;
                        const tpts = config.ticket.claimPoints != null ? config.ticket.claimPoints : 1;
                        const svc = getSupportVoiceIds().map(id => '<#' + id + '>').join(', ') || 'غير محدد';
                        return i.reply({ content: '⚙️ **الإعداد الحالي**\nروم الدعم: ' + svc + '\nتذكرة = ' + tpts + ' نقطة\nكل ' + every + ' دقيقة فويس = ' + vpts + ' نقطة\nالإعفاء من التحقق بعد ' + (getPresenceExemptMinutes() || 'معطّل') + ' دقيقة\n\nللتعديل مرر الخيارات مع action:إعداد', flags: MessageFlags.Ephemeral });
                    }
                    return i.reply({ content: '✅ تم حفظ الإعدادات:\n' + changes.map(x => '• ' + x).join('\n'), flags: MessageFlags.Ephemeral });
                }
            }
            if (n === 'setrewards') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
                if (!config.rewards) config.rewards = {};
                const rc = i.options.getChannel('channel');
                const rmin = i.options.getInteger('min');
                const rmax = i.options.getInteger('max');
                const rh = i.options.getInteger('hours');
                const rcur = i.options.getString('currency');
                const before = getRewardsCfg();
                const nMin = rmin != null ? rmin : before.min, nMax = rmax != null ? rmax : before.max;
                if (nMin > nMax) return i.reply({ content: '❌ أقل مبلغ (' + nMin + ') يجب ألا يكون أكبر من أعلى مبلغ (' + nMax + ').', flags: MessageFlags.Ephemeral });
                const ch = [];
                if (rc) { config.rewards.channelId = rc.id; ch.push('الروم'); }
                if (rmin != null) { config.rewards.min = rmin; ch.push('أقل مبلغ'); }
                if (rmax != null) { config.rewards.max = rmax; ch.push('أعلى مبلغ'); }
                if (rh != null) { config.rewards.hours = rh; ch.push('مدة المكافأة'); }
                if (rcur) { config.rewards.currency = rcur.trim().slice(0, 12); ch.push('العملة'); }
                if (ch.length) saveConfig();
                const c = getRewardsCfg();
                return i.reply({ embeds: [new EmbedBuilder().setColor(BLUE)
                    .setTitle(ch.length ? '✅ تم حفظ إعدادات المكافآت' : '⚙️ إعدادات المكافآت الحالية')
                    .addFields(
                        { name: '📍 الروم', value: c.channelId ? '<#' + c.channelId + '>' : '`غير محدد — حدده بـ /setrewards channel`', inline: false },
                        { name: '💰 مبلغ المكافأة', value: c.min === c.max ? '**' + fmtNum(c.min) + ' ' + c.currency + '** (ثابت)' : 'من **' + fmtNum(c.min) + '** إلى **' + fmtNum(c.max) + '** ' + c.currency, inline: true },
                        { name: '⏳ كل', value: '**' + c.hours + '** ساعة', inline: true }
                    )
                    .setFooter({ text: 'الأوامر في الروم: مكافأة • توب • معلومات' })], flags: MessageFlags.Ephemeral });
            }
            if (n === 'setstats') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
                if (!config.stats) config.stats = {};
                const sc = i.options.getChannel('channel');
                if (sc) {
                    config.stats.channelId = sc.id;
                    saveConfig();
                }
                const cfg = getStatsCfg();
                return i.reply({ embeds: [new EmbedBuilder().setColor(BLUE)
                    .setTitle(sc ? '✅ تم تحديد روم الإحصائيات' : '⚙️ إعدادات الإحصائيات الحالية')
                    .addFields(
                        { name: '📍 الروم', value: cfg.channelId ? '<#' + cfg.channelId + '>' : '`غير محدد — استخدم /setstats channel`', inline: false },
                        { name: '📌 الأوامر الحالية', value: '`-' + cfg.account + '` — إحصائياتك\n`-' + cfg.top + ' ' + cfg.topvoice + '` — توب الفويس\n`-' + cfg.top + ' ' + cfg.topchat + '` — توب الشات', inline: false }
                    )
                    .setFooter({ text: 'لتغيير أسماء الأوامر استخدم /setstatscmds' })], flags: MessageFlags.Ephemeral });
            }
            if (n === 'setstatscmds') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
                if (!config.stats) config.stats = {};
                const a = i.options.getString('account');
                const t = i.options.getString('top');
                const tv = i.options.getString('topvoice');
                const tc = i.options.getString('topchat');
                const changed = [];
                if (a) { config.stats.account = a.trim().replace(/\s+/g, '').slice(0, 20); changed.push('حسابي → ' + config.stats.account); }
                if (t) { config.stats.top = t.trim().replace(/\s+/g, '').slice(0, 20); changed.push('توب → ' + config.stats.top); }
                if (tv) { config.stats.topvoice = tv.trim().replace(/\s+/g, '').slice(0, 20); changed.push('فويس → ' + config.stats.topvoice); }
                if (tc) { config.stats.topchat = tc.trim().replace(/\s+/g, '').slice(0, 20); changed.push('شات → ' + config.stats.topchat); }
                if (changed.length) saveConfig();
                const cfg = getStatsCfg();
                return i.reply({ embeds: [new EmbedBuilder().setColor(BLUE)
                    .setTitle(changed.length ? '✅ تم تحديث أسماء الأوامر' : '⚙️ أسماء أوامر الإحصائيات الحالية')
                    .setDescription(changed.length ? changed.map(x => '• ' + x).join('\n') : null)
                    .addFields(
                        { name: 'حسابي', value: '`' + cfg.account + '`', inline: true },
                        { name: 'التوب', value: '`' + cfg.top + '`', inline: true },
                        { name: 'توب الفويس', value: '`' + cfg.top + ' ' + cfg.topvoice + '`', inline: true },
                        { name: 'توب الشات', value: '`' + cfg.top + ' ' + cfg.topchat + '`', inline: true }
                    )
                    .setFooter({ text: 'مثال: -' + cfg.top + ' ' + cfg.topvoice })], flags: MessageFlags.Ephemeral });
            }
            if (n === 'rating') {
                if (!isStaff(i.member, 'stats')) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
                const tg = i.options.getUser('member') || i.user;
                const list = staffRatings[tg.id] || [];
                if (!list.length) return i.reply({ content: 'ℹ️ لا توجد تقييمات مسجّلة لـ <@' + tg.id + '> حتى الآن.', flags: MessageFlags.Ephemeral });
                const avg = list.reduce((a, r) => a + r.stars, 0) / list.length;
                const dist = [5, 4, 3, 2, 1].map(k => '⭐'.repeat(k) + ' : **' + list.filter(r => r.stars === k).length + '**').join('\n');
                return i.reply({ embeds: [new EmbedBuilder().setColor(BLUE).setTitle('⭐ تقييمات الإداري')
                    .setDescription('<@' + tg.id + '>')
                    .addFields(
                        { name: 'المتوسط', value: '**' + avg.toFixed(2) + '** / 5', inline: true },
                        { name: 'عدد التقييمات', value: '**' + list.length + '**', inline: true },
                        { name: 'التوزيع', value: dist }
                    )], flags: MessageFlags.Ephemeral });
            }
            if (n === 'ticketstats') {
                if (!isStaff(i.member, 'stats')) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
                const all = Object.values(activeTickets);
                const open = all.filter(t => !t.closed);
                const unclaimed = open.filter(t => !t.claimedBy).length;
                const closed = all.filter(t => t.closed).length;
                return i.reply({ embeds: [new EmbedBuilder().setColor(BLUE).setTitle('📊 إحصائيات التذاكر')
                    .addFields(
                        { name: '🟢 مفتوحة', value: '**' + open.length + '**', inline: true },
                        { name: '🟡 بانتظار الاستلام', value: '**' + unclaimed + '**', inline: true },
                        { name: '🔴 مغلقة', value: '**' + closed + '**', inline: true },
                        { name: '🔢 إجمالي ما أُنشئ', value: '**' + Math.max(0, ticketCounter - 1000) + '**', inline: true }
                    )], flags: MessageFlags.Ephemeral });
            }
            if (n === 'myrank') {
                const c = ensureClock(i.user.id);
                const claimed = c.ticketsClaimed || 0;
                return i.reply({ embeds: [buildMyRankEmbed(i.user, claimed)], flags: MessageFlags.Ephemeral });
            }
            if (n === 'ticketranks') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة العليا.', flags: MessageFlags.Ephemeral });
                const action = i.options.getString('action');
                const claims = i.options.getInteger('claims');
                const role = i.options.getRole('role');
                const label = i.options.getString('label');
                const tc = getTicketCfg();
                if (!Array.isArray(tc.ranks) || !tc.ranks.length) tc.ranks = DEFAULT_TICKET_RANKS.map(r => ({ ...r }));
                if (action === 'view') {
                    return i.reply({ embeds: [buildRanksInfoEmbed()], flags: MessageFlags.Ephemeral });
                }
                if (action === 'post') {
                    await i.channel.send({ embeds: [buildRanksInfoEmbed()] });
                    return i.reply({ content: '✅ تم نشر لوحة شرح الترقيات في هذا الروم.', flags: MessageFlags.Ephemeral });
                }
                if (action === 'set') {
                    if (claims == null) return i.reply({ content: '⚠️ حدّد عدد الاستلامات (claims).', flags: MessageFlags.Ephemeral });
                    if (!role && !label) return i.reply({ content: '⚠️ حدّد الرتبة أو الاسم على الأقل.', flags: MessageFlags.Ephemeral });
                    let row = tc.ranks.find(r => r.claims === claims);
                    if (!row) { row = { claims, roleId: '', label: 'رتبة ' + claims }; tc.ranks.push(row); }
                    if (role) row.roleId = role.id;
                    if (label) row.label = label;
                    tc.ranks.sort((a, b) => a.claims - b.claims);
                    saveConfig();
                    return i.reply({ content: '✅ تم ربط **' + claims + '** استلام ← ' + (role ? '<@&' + role.id + '>' : ('`' + (row.label || '') + '`')), flags: MessageFlags.Ephemeral });
                }
                if (action === 'clear') {
                    if (claims == null) return i.reply({ content: '⚠️ حدّد عدد الاستلامات لمسحه.', flags: MessageFlags.Ephemeral });
                    const before = tc.ranks.length;
                    tc.ranks = tc.ranks.filter(r => r.claims !== claims);
                    if (tc.ranks.length === before) return i.reply({ content: '⚠️ ما فيه مستوى بهذا الرقم.', flags: MessageFlags.Ephemeral });
                    saveConfig();
                    return i.reply({ content: '✅ تم حذف مستوى **' + claims + '** استلام.', flags: MessageFlags.Ephemeral });
                }
                return i.reply({ content: '⚠️ إجراء غير معروف.', flags: MessageFlags.Ephemeral });
            }
            if (n === 'setmodlogs') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
                if (!config.moderation) config.moderation = {};
                if (!config.moderation.logs) config.moderation.logs = {};
                config.moderation.logs[i.options.getString('type')] = i.options.getChannel('channel').id;
                saveConfig();
                return i.reply({ content: `✅ تم تحديد روم اللوق بنجاح: ${i.options.getChannel('channel')}`, flags: MessageFlags.Ephemeral });
            }
            if (n === 'setadmin') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة العليا (أو لمن يملك صلاحية Administrator).', flags: MessageFlags.Ephemeral });
                if (!config.roles) config.roles = {};
                const role = i.options.getRole('role');
                let action = i.options.getString('action') || (role ? 'add' : 'list');
                if (action !== 'list' && !role) return i.reply({ content: '⚠️ اختر الرتبة مع هذا الإجراء.', flags: MessageFlags.Ephemeral });
                if (action === 'set') { config.roles.admin = role.id; config.roles.admins = []; }
                else if (action === 'add') {
                    if (!config.roles.admin) config.roles.admin = role.id;
                    else if (config.roles.admin !== role.id && !(config.roles.admins || []).includes(role.id)) config.roles.admins = [...(config.roles.admins || []), role.id];
                }
                else if (action === 'remove') {
                    if (config.roles.admin === role.id) config.roles.admin = (config.roles.admins || [])[0] || '';
                    config.roles.admins = (config.roles.admins || []).filter(r => r !== role.id && r !== config.roles.admin);
                }
                if (action !== 'list') saveConfig();
                const ids = adminRoleIds();
                const emb = new EmbedBuilder().setColor(BLUE)
                    .setTitle('👑 الإدارة العليا')
                    .setDescription(ids.length ? ids.map(r => '• <@&' + r + '>').join('\n') : 'لم تُحدد أي رتبة بعد.')
                    .addFields({ name: '🔐 ماذا تملك هذه الرتب؟', value: 'تتحكم بكل أوامر البوت، وترى التذاكر حتى بعد استلامها (باقي الموظفين تُسحب عنهم الرؤية فور الاستلام).' })
                    .setFooter({ text: 'للتحكم بصلاحيات رتب الموظفين استخدم /botperms' }).setTimestamp();
                return i.reply({ embeds: [emb], flags: MessageFlags.Ephemeral });
            }
            if (n === 'botperms') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة العليا فقط.', flags: MessageFlags.Ephemeral });
                const role = i.options.getRole('role');
                if (role) bpSessions.set(i.user.id, [role.id]); else bpSessions.delete(i.user.id);
                return i.reply({ ...buildBotPermsPanel(i.guild, i.user.id), flags: MessageFlags.Ephemeral });
            }
            if (n === 'setbotrole') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة العليا فقط.', flags: MessageFlags.Ephemeral });
                const role = i.options.getRole('role');
                const keys = ['view_tickets', 'claim', 'close', 'delete', 'rename', 'summon', 'rate'];
                if (!config.ticket) config.ticket = {};
                if (!config.ticket.staffRolePermissions) config.ticket.staffRolePermissions = {};
                const oldPerms = config.ticket.staffRolePermissions[role.id] || {};
                const updates = {};
                const getBool = key => i.options.getBoolean(key);
                for (const key of keys) { const value = getBool(key); if (value !== null) updates[key] = value; }
                const supplied = Object.keys(updates).length > 0;
                if (supplied) config.ticket.staffRolePermissions[role.id] = { ...oldPerms, ...updates };
                else if (!config.ticket.staffRolePermissions[role.id]) config.ticket.staffRolePermissions[role.id] = { view_tickets: true, claim: true, close: true, delete: false, rename: true, summon: true, rate: true };
                saveConfig();
                const perms = config.ticket.staffRolePermissions[role.id];
                const labels = { view_tickets: 'رؤية غير المستلمة', claim: 'استلام', close: 'إغلاق', delete: 'حذف', rename: 'تغيير الاسم', summon: 'استدعاء العضو', rate: 'طلب تقييم' };
                const lines = keys.map(k => `${perms[k] === true ? '✅' : '❌'} ${labels[k]}`).join('\n');
                return i.reply({ content: `✅ صلاحيات ${role}:\n${lines}\n\nللتحكم الكامل (رقابة • دوام • إحصائيات) استخدم `/botperms` — وهو أسهل بقائمة تفاعلية.`, flags: MessageFlags.Ephemeral });
            }
            if (n === 'setrole') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
                if (!config.roles) config.roles = {};
                const type = i.options.getString('type');
                const role = i.options.getRole('role');
                config.roles[type] = role.id;
                saveConfig();
                const rn = { summon: 'الاستدعاء', activation: 'التفعيل', banned: 'الباند', tempban: 'الباند المؤقت', permban: 'الباند النهائي' }; return i.reply({ content: `✅ تم تحديد رتبة **${rn[type] || type}**: ${role}`, flags: MessageFlags.Ephemeral });
            }
            if (n === 'setclockpoints') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
                if (!config.moderation) config.moderation = {};
                config.moderation.clockPointsEveryMinutes = i.options.getInteger('minutes');
                config.moderation.clockPointsAmount = i.options.getInteger('points');
                saveConfig();
                return i.reply({ content: `✅ تم تحديث نظام النقاط: كل **${config.moderation.clockPointsEveryMinutes}** دقيقة = **${config.moderation.clockPointsAmount}** نقطة`, flags: MessageFlags.Ephemeral });
            }
            if (n === 'setpresence') {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
                if (!config.moderation) config.moderation = {};
                const mins = i.options.getInteger('minutes');
                const ded = i.options.getInteger('deduct');
                const changes = [];
                if (mins != null) {
                    config.moderation.presenceMinutes = mins;
                    changes.push('وقت التحقق: **' + mins + '** دقيقة');
                }
                if (ded != null) {
                    config.moderation.presenceDeductPoints = ded;
                    changes.push('خصم النقاط: **' + ded + '** نقطة');
                }
                saveConfig();
                if (!changes.length) {
                    const m = config.moderation.presenceMinutes != null ? config.moderation.presenceMinutes : 15;
                    const d = config.moderation.presenceDeductPoints != null ? config.moderation.presenceDeductPoints : 2;
                    return i.reply({ content: '⚙️ **إعداد التحقق من التواجد**\nيُرسل التحقق بعد **' + m + '** دقيقة من تسجيل الدخول\nعند عدم الرد يُخصم **' + d + '** نقطة', flags: MessageFlags.Ephemeral });
                }
                return i.reply({ content: '✅ ' + changes.join('\n'), flags: MessageFlags.Ephemeral });
            }
            return;
        }
        if (await features.handleComponent(i)) return;
        if (i.isStringSelectMenu() && (i.customId === 'ticket_open' || i.customId.startsWith('ticket_open:'))) {
            const menuSys = i.customId.includes(':') ? i.customId.split(':')[1] : 'main';
            // رجّع القائمة لوضعها الأصلي عشان يقدر يفتح تذكرة ثانية من نفس القسم
            try { const pm = buildPanelMessage(menuSys); i.message?.edit({ components: pm.components, flags: pm.flags }).catch(() => {}); } catch {}
            const deptId = i.values[0];
            const tcfg = getTicketCfg();
            if (tcfg.requireReason) {
                const modal = new ModalBuilder().setCustomId('ticket_open_reason_' + deptId).setTitle('سبب فتح التذكرة');
                modal.addComponents(new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('reason').setLabel('اكتب سبب فتح التذكرة').setStyle(TextInputStyle.Paragraph).setRequired(true).setPlaceholder('مثال: مشكلة في التفعيل / استفسار...')
                ));
                return i.showModal(modal);
            }
            return openTicket(i, deptId);
        }
        if (i.isStringSelectMenu() && i.customId.startsWith('censor_')) {
            if (!isStaff(i.member, 'mod')) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
            const uid = i.customId.replace('censor_', '');
            const act = i.values[0];
            if (act === 'warn') {
                const row = new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('warnmenu_' + uid).setPlaceholder('⚠️ اختر مستوى التحذير')
                    .addOptions({ label: 'التحذير الأول', value: 'warn1', description: 'يبقى فعّالاً 7 أيام', emoji: '🟡' }, { label: 'التحذير الثاني', value: 'warn2', description: 'يبقى فعّالاً 14 يوماً', emoji: '🟠' }, { label: 'التحذير الثالث', value: 'warn3', description: 'يبقى فعّالاً 21 يوماً', emoji: '🔴' }));
                return i.reply({ content: '⚠️ **اختر مستوى التحذير:**', components: [row], flags: MessageFlags.Ephemeral });
            }
            if (act === 'ban') {
                const row = new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('banmenu_' + uid).setPlaceholder('🚫 اختر نوع الإجراء')
                    .addOptions({ label: 'باند مؤقت', value: 'temp', description: 'حظر لمدة محددة', emoji: '⏳' }, { label: 'باند نهائي', value: 'perm', description: 'حظر دائم', emoji: '🚫' }, { label: 'فك باند', value: 'unban', description: 'إعادة العضو ورتبه', emoji: '✅' }));
                return i.reply({ content: '**اختر الإجراء المطلوب:**', components: [row], flags: MessageFlags.Ephemeral });
            }
            const titles = { summon: 'سبب الاستدعاء', unsummon: 'سبب إلغاء الاستدعاء', activation: 'سبب سحب التفعيل' };
            const modal = new ModalBuilder().setCustomId('censor_' + act + '_' + uid).setTitle(titles[act] || 'السبب');
            modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('reason').setLabel('السبب').setStyle(TextInputStyle.Paragraph).setRequired(act !== 'unsummon')));
            return i.showModal(modal);
        }
        if (i.isStringSelectMenu() && i.customId.startsWith('warnmenu_')) {
            const uid = i.customId.replace('warnmenu_', '');
            const level = i.values[0];
            const days = level === 'warn1' ? 7 : level === 'warn2' ? 14 : 21;
            const modal = new ModalBuilder().setCustomId(`warnmodal_${uid}_${level}_${days}`).setTitle('سبب التحذير');
            modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('reason').setLabel('السبب').setStyle(TextInputStyle.Paragraph).setRequired(true).setPlaceholder('اكتب سبب التحذير بوضوح')));
            return i.showModal(modal);
        }
        if (i.isStringSelectMenu() && i.customId.startsWith('banmenu_')) {
            const uid = i.customId.replace('banmenu_', '');
            const type = i.values[0];
            const modal = new ModalBuilder().setCustomId(`banmodal_${uid}_${type}`).setTitle(type === 'unban' ? 'فك باند' : type === 'temp' ? 'باند مؤقت' : 'باند نهائي');
            const comps = [new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('reason').setLabel('السبب').setStyle(TextInputStyle.Paragraph).setRequired(type !== 'unban'))];
            if (type === 'temp') comps.push(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('duration').setLabel('المدة').setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder('مثال: 7 يوم، 12 ساعة')));
            modal.addComponents(...comps);
            return i.showModal(modal);
        }
        if (i.isButton() && i.customId.startsWith('rtop_')) {
            const [, pg, owner] = i.customId.split('_');
            if (owner !== i.user.id) return i.reply({ content: '❌ هذه الأزرار لصاحب الأمر فقط، اكتب `توب` للحصول على قائمتك.', flags: MessageFlags.Ephemeral });
            const p = buildTopPage(parseInt(pg, 10) || 1);
            return i.update({ embeds: [p.embed], components: p.pages > 1 ? [topButtons(p.page, p.pages, owner)] : [] });
        }
        if (i.isButton() && i.customId.startsWith('sijill_')) {
            if (!isStaff(i.member, 'mod')) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
            const p = i.customId.split('_');
            const act = p[1], uid = p[2]; let page = parseInt(p[3], 10) || 1;
            const u = await client.users.fetch(uid).catch(() => null);
            if (!u) return i.reply({ content: '❌ تعذّر تحديد العضو المطلوب.', flags: MessageFlags.Ephemeral });
            const logs = getLogs(uid);
            let total = Math.max(1, Math.ceil(logs.length / LOGS_PER_PAGE));
            if (act === 'prev') page = Math.max(1, page - 1);
            if (act === 'next') page = Math.min(total, page + 1);
            return i.update({ embeds: [buildSijill(u, logs, page, total)], components: sijillBtns(uid, page, total) });
        }
        if (i.isStringSelectMenu() && i.customId === 'ticket_actions') {
            const v = i.values[0];
            if (v === 'unclaim') return handleTicketUnclaim(i);
            if (v === 'summon') return handleTicketSummonOwner(i);
            if (v === 'rate_admin') return handleTicketRateAdmin(i);
            if (v === 'close') return handleTicketClose(i);
            if (v === 'delete') return handleTicketDelete(i);
            if (v === 'rename') return handleTicketRename(i);
        }
        if (i.isButton() && i.customId === 'ticket_claim') return handleTicketClaim(i);
        if (i.isButton() && i.customId === 'ticket_unclaim') return handleTicketUnclaim(i);
        if (i.isButton() && i.customId === 'ticket_settings') return handleTicketSettings(i);
        if (i.isButton() && i.customId === 'ticket_close') return handleTicketClose(i);
        if (i.isButton() && i.customId === 'ticket_rename') return handleTicketRename(i);
        if (i.isButton() && i.customId === 'ticket_summon_owner') return handleTicketSummonOwner(i);
        if (i.isButton() && i.customId === 'ticket_delete') return handleTicketDelete(i);
        // ── التقييم الجديد: زر «تقييم» ← اختيار النجوم ← نافذة الفيدباك ──
        if (i.isButton() && i.customId.startsWith('rate_open_')) {
            const [, , tn, staffId, ownerId] = i.customId.split('_');
            if (ownerId && ownerId !== '0' && i.user.id !== ownerId) return i.reply({ content: '❌ هذا التقييم مخصص لصاحب التذكرة فقط.', flags: MessageFlags.Ephemeral });
            if ((staffRatings[staffId] || []).some(r => String(r.ticket) === String(tn) && r.by === i.user.id)) {
                return i.update({ components: [V2.container([V2.text('## ✅ تم تقييم هذه التذكرة مسبقاً'), V2.text('شكراً لك، لا يمكن تقييم نفس التذكرة أكثر من مرة.')], V2.NAVY)], flags: V2.IS_V2 });
            }
            const starMenu = new StringSelectMenuBuilder()
                .setCustomId('rate_star_' + tn + '_' + staffId + '_' + (ownerId || '0') + '_' + i.message.id)
                .setPlaceholder('اختر عدد النجوم ⭐')
                .addOptions(
                    { label: 'ممتاز', description: '5 نجوم', value: '5', emoji: tEmo('star5') },
                    { label: 'جيد جداً', description: '4 نجوم', value: '4', emoji: tEmo('star4') },
                    { label: 'جيد', description: '3 نجوم', value: '3', emoji: tEmo('star3') },
                    { label: 'مقبول', description: 'نجمتان', value: '2', emoji: tEmo('star2') },
                    { label: 'ضعيف', description: 'نجمة واحدة', value: '1', emoji: tEmo('star1') }
                );
            return i.reply({ content: 'كم تعطي الإداري؟', components: [new ActionRowBuilder().addComponents(starMenu)], flags: MessageFlags.Ephemeral });
        }
        if (i.isStringSelectMenu() && i.customId.startsWith('rate_star_')) {
            const [, , tn, staffId, ownerId, origId] = i.customId.split('_');
            const stars = Math.min(5, Math.max(1, parseInt(i.values[0], 10) || 5));
            const m = new ModalBuilder().setCustomId('rate_fb_' + tn + '_' + staffId + '_' + (ownerId || '0') + '_' + origId + '_' + stars).setTitle('ملاحظتك على الخدمة');
            m.addComponents(new ActionRowBuilder().addComponents(
                new TextInputBuilder().setCustomId('feedback').setLabel('الفيدباك (اختياري)').setStyle(TextInputStyle.Paragraph).setRequired(false).setMaxLength(500).setPlaceholder('اكتب رأيك في الخدمة...')
            ));
            return i.showModal(m);
        }
        if (i.isStringSelectMenu() && i.customId.startsWith('rate_sel_')) {
            const parts = i.customId.split('_'); // rate_sel_ticket_staff_guild
            const ticketNum = parts[2], staffId = parts[3], guildId = parts[4], rateOwner = parts[5];
            if (rateOwner && i.user.id !== rateOwner) return i.reply({ content: '❌ هذا التقييم مخصص لصاحب التذكرة فقط.', flags: MessageFlags.Ephemeral });
            if ((staffRatings[staffId] || []).some(r => String(r.ticket) === String(ticketNum) && r.by === i.user.id)) {
                return i.update({ embeds: [new EmbedBuilder().setColor(BLUE).setTitle('✅ تم تقييم هذه التذكرة مسبقاً').setDescription('شكراً لك، لا يمكن تقييم نفس التذكرة أكثر من مرة.')], components: [] });
            }
            const stars = Math.min(5, Math.max(1, parseInt(i.values[0], 10) || 5));
            const g = client.guilds.cache.get(guildId) || null;
            await i.update({ content: '✅ شكراً لتقييمك ⭐', embeds: [], components: [] });
            return recordRating(staffId, i.user.id, ticketNum, stars, g);
        }
        if (i.isButton() && i.customId.startsWith('rate_')) {
            const parts = i.customId.split('_');
            const stars = parseInt(parts[3], 10) || 5;
            const g = client.guilds.cache.get(SERVER_ID) || null;
            await i.update({ content: '✅ شكراً لتقييمك ⭐', embeds: [], components: [] });
            return recordRating(parts[2], i.user.id, parts[1], stars, g);
        }
        if (i.isButton() && i.customId === 'presence_yes') {
            const uid = i.user.id;
            const p = presencePending[uid];
            const member = i.guild ? await i.guild.members.fetch(uid).catch(() => null) : null;
            // التفاعل غالباً من الخاص — guild قد يكون null
            let guild = i.guild;
            if (!guild && p?.guildId) guild = client.guilds.cache.get(p.guildId) || await client.guilds.fetch(p.guildId).catch(() => null);
            const gm = guild ? await guild.members.fetch(uid).catch(() => null) : null;
            const inVoice = isSupportVoice(member?.voice?.channelId) || isSupportVoice(gm?.voice?.channelId);
            if (inVoice) {
                const wasAfk = !!(p && p.isAfkCheck);
                if (p?.timeout) clearTimeout(p.timeout);
                delete presencePending[uid];
                if (wasAfk) {
                    // تحقق دوري ناجح → أعد جدولة تحقق بعد 15 دقيقة ثانية
                    if (guild) scheduleAfkCheck(uid, guild.id);
                    const emb = new EmbedBuilder().setColor(BLUE).setTitle('✅ تم التأكيد')
                        .setDescription('<@' + uid + '> أكد تواجده (تحقق بعد 15 دقيقة).')
                        .setTimestamp();
                    if (guild) await sendLog(guild, 'clock', emb);
                    return i.reply({ content: '✅ تم التأكيد — شكراً لك. سيتم التحقق مرة أخرى بعد 15 دقيقة.', flags: MessageFlags.Ephemeral });
                }
                clearAfkCheck(uid);
                const emb = new EmbedBuilder().setColor(BLUE).setTitle('✅ تم التأكيد')
                    .setDescription('<@' + uid + '> أكد تواجده وهو داخل الروم الصوتي، وعاد للخدمة.')
                    .setTimestamp();
                if (guild) await sendLog(guild, 'clock', emb);
                return i.reply({ content: '✅ تم التأكيد — شكراً لك.', flags: MessageFlags.Ephemeral });
            }
            // أكد وهو لسه برا الفويس
            const emb = new EmbedBuilder().setColor(BLUE).setTitle('⚠️ أكد لكنه خارج الفويس')
                .setDescription(`<@${uid}> ضغط «نعم أنا هنا» لكنه **غير متواجد** في روم صوتي.`)
                .setTimestamp();
            if (guild) await sendLog(guild, 'clock', emb);
            return i.reply({ content: '⚠️ تم استلام التأكيد، لكنك لست داخل روم صوتي حالياً. يرجى الدخول إلى الروم الصوتي لمتابعة دوامك.', flags: MessageFlags.Ephemeral });
        }
        if (i.isButton() && (i.customId === 'clock_in_btn' || i.customId === 'clock_out_btn' || i.customId === 'clock_admin_btn')) {
            if (!isStaff(i.member, 'clock')) return i.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', flags: MessageFlags.Ephemeral });
            if (i.customId === 'clock_in_btn') {
                if (!i.member.voice?.channelId) return i.reply({ content: '❌ يجب أن تكون داخل روم صوتي أولاً.', flags: MessageFlags.Ephemeral });
                const c = ensureClock(i.user.id);
                if (c.in) return i.reply({ content: '⚠️ لديك تسجيل دخول نشط بالفعل.', flags: MessageFlags.Ephemeral });
                c.in = Date.now(); c.lastPointAt = Date.now(); saveAll();
                scheduleAfkCheck(i.user.id, i.guild.id);
                const emb = buildClockInEmbed(i.user.id, i.member.voice.channelId, false);
                await i.reply({ embeds: [confirmEmbed(emb)], flags: MessageFlags.Ephemeral });
                return sendLog(i.guild, 'clock', emb);
            }
            if (i.customId === 'clock_out_btn') {
                clearAfkCheck(i.user.id);
                const c = ensureClock(i.user.id);
                if (!c.in) return i.reply({ content: '⚠️ لست مسجّل الدخول حالياً.', flags: MessageFlags.Ephemeral });
                const elapsed = Date.now() - c.in;
                c.totalMsToday = (c.totalMsToday || 0) + elapsed; c.totalMsWeek = (c.totalMsWeek || 0) + elapsed; c.in = null; saveAll();
                const emb = buildClockOutLog(i.user.id, elapsed);
                await i.reply({ embeds: [confirmEmbed(emb)], flags: MessageFlags.Ephemeral });
                try {
        const mins = Math.floor(elapsed / 60000);
        await i.user.send({ embeds: [buildClockOutDM('الدعم الفني', elapsed, c.totalMsToday || 0, c.totalMsWeek || 0, false)] });
    } catch {}
                return sendLog(i.guild, 'clock', emb);
            }
            const c = ensureClock(i.user.id);
            return i.reply({ embeds: [buildMyTimeEmbed(c, i.user)], flags: MessageFlags.Ephemeral });
        }
        if (i.isModalSubmit()) {
            const id = i.customId;
            if (id.startsWith('rate_fb_')) {
                const [, , tn, staffId, ownerId, origId, starsRaw] = id.split('_');
                const stars = Math.min(5, Math.max(1, parseInt(starsRaw, 10) || 5));
                const feedback = (i.fields.getTextInputValue('feedback') || '').trim();
                const g = client.guilds.cache.get(SERVER_ID) || null;
                if ((staffRatings[staffId] || []).some(r => String(r.ticket) === String(tn) && r.by === i.user.id)) {
                    return i.reply({ content: '✅ تم تقييم هذه التذكرة مسبقاً.', flags: MessageFlags.Ephemeral });
                }
                await i.reply({ content: '✅ تم إرسال تقييمك، شكراً لك 💙', flags: MessageFlags.Ephemeral }).catch(() => {});
                try { const orig = await i.channel.messages.fetch(origId); await orig.edit(buildRatingThanks(staffId, stars, g, feedback)); } catch (e) { console.error('[rating] تعديل رسالة الطلب:', e.message); }
                return recordRating(staffId, i.user.id, tn, stars, g, feedback);
            }
            if (id === 'ticket_delete_modal') {
                return finishTicketDelete(i, i.fields.getTextInputValue('reason'));
            }
            if (id === 'ticket_close_modal') {
                const reason = i.fields.getTextInputValue('reason') || 'تم الإغلاق';
                return finishTicketClose(i, reason);
            }
            if (id.startsWith('ticket_open_reason_')) {
                const deptId = id.replace('ticket_open_reason_', '');
                const reason = i.fields.getTextInputValue('reason') || '';
                return openTicket(i, deptId, reason);
            }
            if (id === 'ticket_rename_modal') {
                const currentTicket = activeTickets[i.channel.id];
                if (!currentTicket || !hasTicketPermission(i.member, 'rename', currentTicket)) return i.reply({ content: '❌ لا تملك صلاحية تغيير اسم التذكرة.', flags: MessageFlags.Ephemeral });
                const name = i.fields.getTextInputValue('name');
                try {
                    const oldName = i.channel.name;
                    await i.channel.setName(name.slice(0, 100));
                    await i.reply({ content: '✅ تم تغيير اسم التذكرة إلى: ' + name, flags: MessageFlags.Ephemeral });
                    const tt = activeTickets[i.channel.id];
                }
                catch (e) { await i.reply({ content: '❌ ' + e.message, flags: MessageFlags.Ephemeral }); }
                return;
            }
            if (id.startsWith('warnmodal_')) {
                const [, uid, level, daysS] = id.split('_');
                const days = parseInt(daysS, 10) || 7;
                const reason = i.fields.getTextInputValue('reason');
                const u = await client.users.fetch(uid).catch(() => null);
                if (!u) return i.reply({ content: '❌ تعذّر تحديد العضو المطلوب.', flags: MessageFlags.Ephemeral });
                const label = level === 'warn1' ? 'تحذير 1' : level === 'warn2' ? 'تحذير 2' : 'تحذير 3';
                const e = addLog(uid, { type: label, reason, modId: i.user.id, modTag: i.user.username, duration: days + ' يوم', durationMs: days * 86400000, endsAt: Date.now() + days * 86400000, active: true });
                const emb = actionEmbed(label, u, i.user, reason, { caseId: e.id, duration: days + ' يوم' });
                await i.reply({ embeds: [confirmEmbed(emb)] });
                await sendActionDM(u, i.guild, label, reason, i.user, { duration: days + ' يوم' });
                return sendLog(i.guild, 'warn', emb);
            }
            if (id.startsWith('banmodal_')) {
                const parts = id.split('_');
                const uid = parts[1], type = parts[2];
                let reason = 'بدون سبب'; try { reason = i.fields.getTextInputValue('reason') || reason; } catch {}
                const u = await client.users.fetch(uid).catch(() => null);
                if (!u) return i.reply({ content: '❌ تعذّر تحديد العضو المطلوب.', flags: MessageFlags.Ephemeral });
                if (type === 'unban') {
                    try {
                        const memU = allBanRoleIds().length ? await i.guild.members.fetch(uid).catch(() => null) : null;
                        if (memU && heldBanRole(memU)) await liftBanRoles(memU, heldBanRole(memU), reason);
                        else await i.guild.members.unban(uid, reason);
                    } catch (e) { return i.reply({ content: '❌ ' + e.message, flags: MessageFlags.Ephemeral }); }
                    const e = addLog(uid, { type: 'فك باند', reason, modId: i.user.id, modTag: i.user.username });
                    getLogs(uid).forEach(l => { if ((l.type || '').includes('باند') && l.active) l.active = false; });
                    saveAll();
                    const emb = actionEmbed('فك باند', u, i.user, reason, { caseId: e.id });
                    await i.reply({ embeds: [confirmEmbed(emb)] }); return sendLog(i.guild, 'unban', emb);
                }
                let dur = null; if (type === 'temp') try { dur = i.fields.getTextInputValue('duration'); } catch {}
                const ms = type === 'temp' ? parseDur(dur) : 0;
                const banRoleId = pickBanRole(type);
                if (!banRoleId) return i.reply({ content: '❌ لم يتم تحديد رتبة الباند. استخدم: `/setrole type:' + (type === 'temp' ? 'باند مؤقت' : type === 'perm' ? 'باند نهائي' : 'باند') + '`', flags: MessageFlags.Ephemeral });
                const mem = await i.guild.members.fetch(uid).catch(() => null);
                if (!mem) return i.reply({ content: '❌ هذا العضو غير موجود في السيرفر.', flags: MessageFlags.Ephemeral });
                try { await applyBanRoles(mem, banRoleId, reason); } catch (e) { return i.reply({ content: '❌ ' + e.message, flags: MessageFlags.Ephemeral }); }
                const banType = type === 'temp' ? 'باند مؤقت' : 'باند نهائي';
                const e = addLog(uid, { type: banType, reason, modId: i.user.id, modTag: i.user.username, duration: dur || 'دائم', durationMs: ms, endsAt: ms ? Date.now() + ms : null, active: true });
                const emb = actionEmbed(banType, u, i.user, reason, { caseId: e.id, duration: dur || 'دائم' });
                await i.reply({ embeds: [confirmEmbed(emb)] });
                await sendActionDM(u, i.guild, banType, reason, i.user, { duration: type === 'temp' ? (dur || '') : '' });
                return sendLog(i.guild, type === 'perm' ? 'permban' : 'ban', emb);
            }
            if (id.startsWith('censor_summon_') || id.startsWith('censor_unsummon_') || id.startsWith('censor_activation_')) {
                const act = id.startsWith('censor_summon_') ? 'summon' : id.startsWith('censor_unsummon_') ? 'unsummon' : 'activation';
                const uid = id.replace('censor_' + act + '_', '');
                let reason = act; try { reason = i.fields.getTextInputValue('reason') || reason; } catch {}
                const u = await client.users.fetch(uid).catch(() => null);
                if (!u) return i.reply({ content: '❌ تعذّر تحديد العضو المطلوب.', flags: MessageFlags.Ephemeral });
                const m = await i.guild.members.fetch(uid).catch(() => null);
                if (!m) return i.reply({ content: '❌ هذا العضو غير موجود في السيرفر.', flags: MessageFlags.Ephemeral });
                if (act === 'summon') {
                    savedRoles[uid] = m.roles.cache.filter(r => r.id !== i.guild.id).map(r => r.id);
                    if (!config.roles?.summon) return i.reply({ content: '❌ حدد رتبة الاستدعاء: `/setrole type:استدعاء role:@الرتبة`', flags: MessageFlags.Ephemeral });
                    try { await m.roles.set([config.roles.summon], 'استدعاء إدارة'); } catch (e) {
                        const tip = /Missing Permissions|50013/i.test(e.message) ? '\n⚠️ ارفع رتبة البوت فوق رتب العضو + Manage Roles' : '';
                        return i.reply({ content: '❌ فشل سحب الرتب: ' + e.message + tip, flags: MessageFlags.Ephemeral });
                    }
                    const e = addLog(uid, { type: 'استدعاء', reason, modId: i.user.id, modTag: i.user.username });
                    accountingLogs.push({ id: e.id, type: 'استدعاء', reason, modId: i.user.id, modTag: i.user.username, targetId: uid, targetTag: u.username, date: Date.now() });
                    saveAll();
                    const emb = actionEmbed('استدعاء', u, i.user, reason, { caseId: e.id });
                    await i.reply({ embeds: [confirmEmbed(emb)] });
                    await sendActionDM(u, i.guild, 'استدعاء', reason, i.user);
                    return sendLog(i.guild, 'summon', emb);
                }
                if (act === 'unsummon') {
                    try {
                        if (savedRoles[uid]?.length) await m.roles.set(savedRoles[uid], 'إلغاء');
                        else if (config.roles?.summon) await m.roles.remove(config.roles.summon, 'إلغاء');
                        delete savedRoles[uid];
                    } catch (e) { return i.reply({ content: '❌ ' + e.message, flags: MessageFlags.Ephemeral }); }
                    const e = addLog(uid, { type: 'إلغاء استدعاء', reason, modId: i.user.id, modTag: i.user.username });
                    accountingLogs.push({ id: e.id, type: 'إلغاء استدعاء', reason, modId: i.user.id, modTag: i.user.username, targetId: uid, targetTag: u.username, date: Date.now() });
                    saveAll();
                    const emb = actionEmbed('إلغاء استدعاء', u, i.user, reason, { caseId: e.id });
                    await i.reply({ embeds: [confirmEmbed(emb)] });
                    await sendActionDM(u, i.guild, 'إلغاء استدعاء', reason, i.user);
                    return sendLog(i.guild, 'unsummon', emb);
                }
                savedRoles[uid] = m.roles.cache.filter(r => r.id !== i.guild.id).map(r => r.id);
                try { await m.roles.set([], 'سحب تفعيل'); } catch (e) {
                    const tip = /Missing Permissions|50013/i.test(e.message) ? '\n⚠️ ارفع رتبة البوت + Manage Roles' : '';
                    return i.reply({ content: '❌ فشل سحب الرتب: ' + e.message + tip, flags: MessageFlags.Ephemeral });
                }
                const e = addLog(uid, { type: 'سحب تفعيل', reason, modId: i.user.id, modTag: i.user.username });
                accountingLogs.push({ id: e.id, type: 'سحب تفعيل', reason, modId: i.user.id, modTag: i.user.username, targetId: uid, targetTag: u.username, date: Date.now() });
                saveAll();
                const emb = actionEmbed('سحب تفعيل', u, i.user, reason, { caseId: e.id });
                await i.reply({ embeds: [confirmEmbed(emb)] });
                await sendActionDM(u, i.guild, 'سحب تفعيل', reason, i.user);
                return sendLog(i.guild, 'activation', emb);
            }
        }
    } catch (e) {
        clearTimeout(autoDefer);
        // 10062 = انتهت مهلة التفاعل، 40060 = تم الرد مسبقاً (غالباً نسختان من البوت تعملان معاً)
        if (e && (e.code === 10062 || e.code === 40060)) {
            console.warn('[interaction] ' + e.code + ' — ' + e.message + ' (تأكد أن نسخة واحدة فقط من البوت تعمل)');
        } else {
            console.error(e);
            try { await i.reply({ content: '❌ حدث خطأ أثناء تنفيذ الطلب: ' + (e && e.message ? e.message : e), flags: MessageFlags.Ephemeral }); } catch {}
        }
    } finally {
        clearTimeout(autoDefer);
    }
});

client.on('voiceStateUpdate', async (oldS, newS) => {
    try {
        const uid = newS.id || oldS.id;
        if (!uid) return;

        // ── تتبع وقت الفويس العام (لجميع الأعضاء) ──
        try {
            const st = ensureStats(uid);
            const leftOrSwitch = oldS.channelId && (!newS.channelId || oldS.channelId !== newS.channelId);
            if (leftOrSwitch && st.joinedAt) {
                st.voiceMs = (st.voiceMs || 0) + (Date.now() - st.joinedAt);
                st.joinedAt = null;
            }
            const joinedOrSwitch = newS.channelId && (!oldS.channelId || oldS.channelId !== newS.channelId);
            if (joinedOrSwitch) {
                // نتجاهل روم الـ AFK إن وجد
                const isAfk = newS.guild?.afkChannelId && newS.channelId === newS.guild.afkChannelId;
                if (!isAfk) st.joinedAt = Date.now();
            }
        } catch (e) { console.error('[stats-voice]', e.message); }

        // رجع للفويس وهو عنده تحقق معلّق → نسجّل رجوعه
        if (!oldS.channelId && newS.channelId && presencePending[uid] && (getSupportVoiceIds().length === 0 || isSupportVoice(newS.channelId))) {
            const p = presencePending[uid];
            if (p.timeout) clearTimeout(p.timeout);
            delete presencePending[uid];
            const emb = new EmbedBuilder().setColor(BLUE).setTitle('✅ عاد للخدمة')
                .setDescription(`<@${uid}> عاد إلى الروم الصوتي بعد التحقق من التواجد.`)
                .setTimestamp();
            await sendLog(newS.guild, 'clock', emb);
            return;
        }

        // دخول روم الدعم الفني الصوتي → تسجيل دخول تلقائي (للإدارة فقط)
        {
            if (isSupportVoice(newS.channelId) && !isSupportVoice(oldS.channelId)) {
                const mem0 = newS.member || await newS.guild.members.fetch(uid).catch(() => null);
                if (mem0 && isStaff(mem0, 'clock')) {
                    const c0 = ensureClock(uid);
                    if (!c0.in) {
                        c0.in = Date.now(); c0.lastPointAt = Date.now(); saveAll();
                        scheduleAfkCheck(uid, newS.guild.id);
                        const inEmb = buildClockInEmbed(uid, newS.channelId, true);
                        await sendLog(newS.guild, 'clock', inEmb);
                        try {
                            const du = await client.users.fetch(uid);
                            await du.send({ embeds: [new EmbedBuilder().setColor(BLUE).setTitle('🟢 تم تسجيل دخولك').setDescription('تم تسجيل دخولك تلقائياً في الدعم الفني عند دخولك الروم الصوتي. سيتم احتساب وقتك حتى تغادر.').setTimestamp()] });
                        } catch {}
                    }
                }
            }
        }

        // طلع من روم الدعم وهو مسجل دخول → تحقق تواجد (مو خروج فوري)
        const leftVoice = isSupportVoice(oldS.channelId) && !isSupportVoice(newS.channelId);
        if (leftVoice && staffClock[uid]?.in) {
            const c = staffClock[uid];
            const minutes = Math.max(1, Math.floor((Date.now() - c.in) / 60000));

            // ألغ أي تحقق سابق
            if (presencePending[uid]?.timeout) clearTimeout(presencePending[uid].timeout);

            // وصل لحد الإعفاء → لا رسالة تحقق ولا تنبيه ولا خصم، يُسجَّل خروجه بهدوء
            if (isPresenceExempt(uid)) {
                delete presencePending[uid];
                const elapsedX = Date.now() - c.in;
                c.totalMsToday = (c.totalMsToday || 0) + elapsedX;
                c.totalMsWeek = (c.totalMsWeek || 0) + elapsedX;
                c.in = null;
                clearAfkCheck(uid);
                saveAll();
                await sendLog(oldS.guild, 'clock', buildClockOutLog(uid, elapsedX));
                return;
            }

            try {
                const u = await client.users.fetch(uid);
                await u.send({ embeds: [buildPresenceEmbed(minutes)], components: [presenceButton()] });
            } catch {
                // ما يقدر يرسل خاص → نبلّغ الإدارة مباشرة
                const emb = new EmbedBuilder().setColor(BLUE).setTitle('⚠️ لم يرد على رسالة التحقق')
                    .setDescription(`<@${uid}> غادر الروم الصوتي وتعذّر إرسال رسالة خاصة له.\nكان مسجّل الدخول منذ **${minutes}** دقيقة.`)
                    .setTimestamp();
                await sendLog(oldS.guild, 'clock', emb);
                return;
            }

            let leftChannelName = 'غير معروف';
            try {
                const ch = oldS.channel || await oldS.guild.channels.fetch(oldS.channelId).catch(() => null);
                if (ch) leftChannelName = ch.name;
            } catch {}
            const leaveWaitMs = ((getMod().presenceMinutes != null ? getMod().presenceMinutes : 15) * 60 * 1000);
            const leaveDeduct = (getMod().presenceDeductPoints != null) ? getMod().presenceDeductPoints : 2;
            presencePending[uid] = {
                guildId: oldS.guild.id,
                leftAt: Date.now(),
                minutes,
                channelName: leftChannelName,
                isLeaveCheck: true,
                timeout: setTimeout(async () => {
                    try {
                        if (!presencePending[uid]) return;
                        delete presencePending[uid];
                        const member = await oldS.guild.members.fetch(uid).catch(() => null);
                        const inVoice = isSupportVoice(member?.voice?.channelId);
                        if (inVoice) {
                            const emb = new EmbedBuilder().setColor(BLUE).setTitle('✅ عاد للخدمة')
                                .setDescription('<@' + uid + '> عاد إلى الروم الصوتي (دون الضغط على زر التأكيد).')
                                .setTimestamp();
                            await sendLog(oldS.guild, 'clock', emb);
                            return;
                        }
                        // خروج فعلي + خصم نقاط + تنبيه
                        const elapsed = Date.now() - c.in;
                        c.totalMsToday = (c.totalMsToday || 0) + elapsed;
                        c.totalMsWeek = (c.totalMsWeek || 0) + elapsed;
                        c.in = null;
                        const beforePts = c.points || 0;
                        c.points = Math.max(0, beforePts - leaveDeduct);
                        clearAfkCheck(uid);
                        saveAll();
                        let chName = 'غير معروف';
                        try {
                            const ch = oldS.channel || await oldS.guild.channels.fetch(oldS.channelId).catch(() => null);
                            if (ch) chName = ch.name;
                        } catch {}
                        const logEmb = buildSupportLeaveLog(uid, chName, elapsed, c.totalMsToday, c.totalMsWeek);
                        await sendLog(oldS.guild, 'clock', logEmb);
                        if (leaveDeduct > 0) {
                            const dedEmb = new EmbedBuilder().setColor(BLUE).setTitle('⚠️ خصم نقاط — لم يؤكد التواجد')
                                .setDescription('<@' + uid + '> غادر الروم الصوتي ولم يؤكد تواجده.\nتم خصم **' + leaveDeduct + '** نقطة. (كان: ' + beforePts + ' → صار: ' + c.points + ')')
                                .setTimestamp();
                            await sendLog(oldS.guild, 'clock', dedEmb);
                        }
                        try {
                            const u = await client.users.fetch(uid);
                            await u.send({ embeds: [buildAutoClockOutEmbed(uid, chName, elapsed, c.totalMsToday, c.totalMsWeek)] });
                        } catch {}
                    } catch {}
                }, leaveWaitMs)
            };
        }
    } catch {}
});

let __shuttingDown = false;
function gracefulShutdown(sig) {
    if (__shuttingDown) return;
    __shuttingDown = true;
    console.log('[shutdown] ' + sig + ' — حفظ البيانات وإغلاق الاتصال...');
    try { saveAll(); } catch (e) { console.error('[shutdown] save:', e.message); }
    try { client.destroy(); } catch {}
    setTimeout(() => process.exit(0), 1500).unref();
}
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

process.on('unhandledRejection', err => {
    console.error('[process] Unhandled promise rejection:', err?.stack || err);
});
client.on('debug', m => { if (/Heartbeat|heartbeat/.test(m) && !/Acknowledged/.test(m)) return; console.log('[debug] ' + String(m).replace(BOT_TOKEN, '***').slice(0, 200)); });
process.on('uncaughtException', err => { console.error('[process] Uncaught exception:', err?.stack || err); });

async function preflight() {
    // 1) هل الاستضافة توصل لديسكورد؟ 2) هل التوكن صحيح؟ 3) هل Intents مفعلة؟
    try {
        const r = await fetch('https://discord.com/api/v10/users/@me', { headers: { Authorization: 'Bot ' + BOT_TOKEN } });
        if (r.status === 200) {
            const u = await r.json();
            console.log(`[preflight] ✅ التوكن صحيح — البوت: ${u.username} (${u.id})`);
            if (u.id !== BOT_ID) console.error(`[preflight] ❌ clientId في config.json (${BOT_ID}) لا يطابق البوت صاحب التوكن (${u.id}) — عدّله`);
        } else if (r.status === 401) {
            console.error('[preflight] ❌ التوكن مرفوض (401): انسخ توكن جديد من Developer Portal > Bot > Reset Token');
            process.exit(1);
        } else {
            console.error('[preflight] ⚠️ رد غير متوقع من ديسكورد: HTTP ' + r.status + ' ' + (await r.text()).slice(0, 200));
        }
    } catch (e) {
        console.error('[preflight] ❌ الاستضافة لا تستطيع الوصول إلى discord.com:', e.cause?.code || e.message);
    }
    try {
        const r = await fetch('https://discord.com/api/v10/applications/@me', { headers: { Authorization: 'Bot ' + BOT_TOKEN } });
        if (r.status === 200) {
            const a = await r.json();
            const f = a.flags || 0;
            const members = !!(f & ((1 << 14) | (1 << 15)));
            const content = !!(f & ((1 << 18) | (1 << 19)));
            console.log(`[preflight] Server Members Intent: ${members ? '✅ مفعل' : '❌ مطفي'} | Message Content Intent: ${content ? '✅ مفعل' : '❌ مطفي'}`);
            if (!members || !content) console.error('[preflight] ❌ فعّل Intents: Developer Portal > Bot > Privileged Gateway Intents (SERVER MEMBERS + MESSAGE CONTENT) ثم Save');
        }
    } catch {}
}

(async () => {
    console.log('[startup] Running preflight checks...');
    await preflight();
    let attempt = 0;
    while (!readyHandled) {
        attempt++;
        console.log(`[startup] Connecting to Discord Gateway... (attempt ${attempt})`);
        try {
            await Promise.race([
                client.login(BOT_TOKEN),
                new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 90000))
            ]);
            // انتظر ready
            for (let i = 0; i < 60 && !readyHandled; i++) await new Promise(r => setTimeout(r, 1000));
            if (readyHandled) break;
            console.error('[startup] لم يصل حدث الجاهزية — ستُعاد المحاولة بعد 60 ثانية (غالباً IP الاستضافة محظور مؤقتاً)');
        } catch (err) {
            const message = String(err?.message || err);
            console.error('[startup] فشل الاتصال:', message);
            if (/disallowed intents|4014/i.test(message)) { console.error('[startup] فعّل SERVER MEMBERS + MESSAGE CONTENT Intents من Developer Portal ثم أعد التشغيل'); process.exit(1); }
            if (/invalid token|tokeninvalid/i.test(message)) { console.error('[startup] التوكن غير صحيح — قم بعمل Reset Token'); process.exit(1); }
        }
        try { client.destroy(); } catch {}
        await new Promise(r => setTimeout(r, 60000));
    }
})();
