# v3.23.0
- جديد: `/logs` (25 نوع سجل إداري وعام) + `setlog!` و`detlog!`
- جديد: `/colors` + `color!` و`colors!` (11 مجموعة ألوان، صورة قائمة، شكل وخلفية)
- جديد: أوامر الشات `hide!` `unhide!` `lock!` `unlock!` `slowmode!` `setvoice!` وتظهر في `/cmdmanager`
- جديد: `setvoice!` تثبيت البوت في روم صوتي ويعود تلقائياً إذا انقطع
- تغيير: صلاحيات الاتصال الجديدة (GuildMessageReactions + GuildExpressions) وPartials للتفاعلات
- موجود مسبقاً ومطابق للصور: `/giveaway` `/feel` `/schedule` `/autoreply`

