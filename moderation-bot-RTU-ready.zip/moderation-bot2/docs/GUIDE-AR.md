# الدليل الكامل: من الصفر إلى بوت يشتغل 24 ساعة

## الفكرة العامة (اقرأها مرة)

1. **Discord Developer Portal** = تسوي فيه "هوية" البوت وتاخذ التوكن.
2. **GitHub** = مخزن الكود فقط (نسخة احتياطية + تحديثات). **GitHub ما يشغّل البوت 24 ساعة.**
3. **الاستضافة** = الجهاز اللي يشغّل البوت فعلياً (لوحة Pterodactyl أو VPS).
4. **التوكن** = كلمة سر البوت. يروح في الاستضافة فقط، ولا يدخل GitHub أبداً.

---

## المرحلة 1: إنشاء البوت في ديسكورد

1. ادخل https://discord.com/developers/applications واضغط **New Application**.
2. من القائمة اليسار: **Bot**.
3. نزّل لتحت لقسم **Privileged Gateway Intents** وفعّل:
   - ✅ **SERVER MEMBERS INTENT**
   - ✅ **MESSAGE CONTENT INTENT**
   - ثم **Save Changes**. (بدونهم البوت يتوقف بخطأ 4014.)
4. اضغط **Reset Token** ← انسخ التوكن واحفظه في مكان خاص (يظهر مرة وحدة).
5. من **General Information** انسخ **Application ID** (هو `clientId`).
6. في ديسكورد: الإعدادات ← Advanced ← فعّل **Developer Mode**. كليك يمين على اسم السيرفر ← **Copy Server ID** (هو `guildId`).
7. افتح `config.json` وتأكد:
   - `bot.clientId` = Application ID
   - `bot.guildId` = Server ID
   - **اترك** `bot.token` كما هو (لا تكتب التوكن هنا).
8. دعوة البوت: **OAuth2 ← URL Generator**:
   - Scopes: `bot` + `applications.commands`
   - Permissions: الأسهل **Administrator**، أو على الأقل: Manage Roles, Manage Channels, Move Members, Manage Messages, Send Messages, Embed Links, Attach Files, Connect, Speak, Kick, Ban, Moderate Members.
   - انسخ الرابط في الأسفل وافتحه واختر السيرفر.
9. **مهم:** من إعدادات السيرفر ← Roles اسحب رتبة البوت **فوق** كل الرتب اللي بيمنحها أو يديرها.

---

## المرحلة 2: GitHub

1. سجل في https://github.com ثم **New repository**.
2. الاسم مثلاً `moderation-bot`، واختر **Private** (مهم جداً).
3. فك ضغط الملف على جهازك، ثم في المستودع: **Add file ← Upload files**، واسحب **محتويات المجلد** (مو الزيب نفسه، ومو المجلد الخارجي).
   - تأكد أنه ظاهر عندك: `index.js`, `package.json`, `config.json`, `features/`, `assets/`, `Dockerfile`, `.gitignore`...
   - الملفات اللي تبدأ بنقطة (`.gitignore`, `.github`) قد تكون مخفية عندك؛ فعّل إظهار الملفات المخفية.
4. اكتب رسالة مثل `first upload` واضغط **Commit changes**.
5. **ممنوع ترفع:** `.env`, أي ملف فيه التوكن, مجلد `data/` الحي.
6. بعد كل رفع، تبويب **Actions** يفحص الكود تلقائياً (علامة ✅ خضراء = سليم).

> لو التوكن تسرّب لأي مكان: Developer Portal ← Bot ← **Reset Token** فوراً.

---

## المرحلة 3: التشغيل 24 ساعة

اختر واحد من الطريقتين:

### الطريقة أ: لوحة استضافة (Pterodactyl / Egg Node.js)

1. ارفع ملفات المشروع إلى `/home/container` بحيث `index.js` و`package.json` في الجذر.
2. من **Startup**:
   - `STARTUP_FILE` = `index.js`
   - الأمر: `if [ -f package.json ]; then npm install --no-fund --no-audit; fi && exec node ${STARTUP_FILE}`
   - Node.js نسخة 18 أو أعلى (يفضل 22).
3. من **Startup ← Variables** (أو Environment) أضف: `DISCORD_TOKEN` = توكنك.
4. شغّل. لازم يظهر في اللوق:
   - `[preflight] ✅ التوكن صحيح`
   - `Server Members Intent: ✅ مفعل | Message Content Intent: ✅ مفعل`
   - `✅ تم الدخول`
   - `[slash] ✅ تم تسجيل ... أمر`

### الطريقة ب: VPS (الأقوى والأكثر احترافية)

على Ubuntu، بعد الدخول بـ SSH:

```bash
# 1) تثبيت Docker
curl -fsSL https://get.docker.com | sh

# 2) تنزيل المشروع (مستودع Private يحتاج Personal Access Token أو SSH key)
git clone https://github.com/USERNAME/moderation-bot.git
cd moderation-bot

# 3) ملف الأسرار
cp .env.example .env
nano .env          # اكتب DISCORD_TOKEN=التوكن  ثم Ctrl+O, Enter, Ctrl+X

# 4) تشغيل
docker compose up -d --build
docker compose logs -f     # شوف اللوق (Ctrl+C للخروج، البوت يبقى شغال)
```

التحديث لاحقاً: `git pull && docker compose up -d --build`
الإيقاف: `docker compose down` (البيانات محفوظة في volume).

بديل بدون Docker: ثبّت Node 22 و ffmpeg، ثم `npm install` ثم `pm2 start ecosystem.config.js && pm2 save && pm2 startup`.

---

## المرحلة 4: إعداد البوت من ديسكورد (بالترتيب)

اكتب الأوامر في أي روم (تظهر لك أنت فقط):

1. `/setadmin` ← حدد رتبة الإدارة العليا.
2. `/setbotrole` أو `/botperms` ← حدد رتب الموظفين وصلاحياتها (رؤية/استلام/إغلاق التذاكر، الرقابة، الدوام، الإحصائيات).
3. `/setticket` ← روم اللوق (`logs`)، الكاتيجوري المفتوح والمغلق، العنوان والوصف والقوانين والترحيب واللوجو.
4. (v3.22) صور اللوحة والتذكرة: من `/tickets` ← اللوحة ← **المظهر** (صورة علوية + سفلية + صغيرة)، ومن الإعدادات العامة ← **مظهر التذكرة** (علوية + سفلية). ألصق رابط الصورة وسيحفظها البوت محلياً.
4. أقسام التذاكر موجودة في `config.json` تحت `departments` (الدعم الفني، طلب رتبة، شكاوى...). عدّل الاسم والوصف والرتبة المسؤولة (`roleId`) حسب سيرفرك.
5. `/waitroom` ← روم الانتظار والإعلان الصوتي.
6. `/welcomesettings` ← الترحيب والصورة، وجرّب `/testwelcome`.
7. `/levels`, `/radio`, `/athkar`, `/tempvoice`, `/selfroles`, `/apply`, `/streams`, `/organize` ← حسب ما تحتاج.
8. `/help` ← قائمة كل الأوامر.

---

## ما تحط وما ما تحط (خلاصة)

| ✅ تحط | ❌ ما تحط |
|---|---|
| التوكن في `DISCORD_TOKEN` (الاستضافة / `.env`) | التوكن في `config.json` أو GitHub أو شات |
| `clientId` و`guildId` في `config.json` | بيانات `data/` الحية في GitHub |
| المستودع Private | تشغيل نسختين من البوت |
| رتبة البوت فوق الرتب | صلاحيات ناقصة ثم تتعجب ليش ما يشتغل |

## النسخ الاحتياطي

- البوت يحفظ نسخة من `data/` كل 6 ساعات (آخر 10 نسخ).
- ملفات الحالة: **`data/`** و**`config.json`** (فيه إعداداتك المحفوظة). خذ منهم نسخة قبل أي تحديث.
- مع Docker كلها في volume `bot-storage`؛ نسخة يدوية:
  `docker run --rm -v moderation-bot_bot-storage:/s -v $PWD:/b alpine tar czf /b/backup.tgz -C /s .`
  (اسم الـ volume يتبع اسم مجلد المشروع؛ تحقق منه بـ `docker volume ls`).

## حل المشاكل

| المشكلة | الحل |
|---|---|
| `4014 / disallowed intents` | فعّل Server Members + Message Content ثم Save |
| `التوكن مرفوض 401` | Reset Token وحط الجديد |
| الأوامر ما تظهر | تأكد من `applications.commands` في الدعوة، و`guildId` صحيح، وانتظر دقيقة |
| ما يعطي رتب | ارفع رتبة البوت فوقها + Manage Roles |
| الأمر "لم يستجب" | غالباً نسختين شغالين؛ أوقف الثانية |
| الصوت لا يعمل | يحتاج Connect + Speak و ffmpeg (موجود في Docker) |
| `MODULE_NOT_FOUND` | شغّل `npm install` |


---

## الأنظمة الجديدة (v3.22) — كيف تشغّلها

### الذكاء الاصطناعي `/ai`
1. أنشئ مفتاحاً من https://console.anthropic.com وضعه في `ANTHROPIC_API_KEY` (في لوحة الاستضافة أو `.env`)، **مو في الملفات**.
2. شغّل `/ai` ← زر **تشغيل** ← اختر روم المحادثة (يرد على كل رسالة فيه) أو اتركه فاضي ليرد عند المنشن فقط.
3. جرّب: «السلام عليكم» • «شغّل سورة الكهف» • «شغّل أغنية كذا» • «اطلع برا الروم».
4. للأوامر الصوتية: ادخل روم صوتي أولاً، والبوت يحتاج صلاحيات Connect و Speak.
5. تقدر تحدد رتباً معينة للتحكم الصوتي من نفس القائمة.

### يوتيوب والقرآن `/music`
- القرآن: `/music type:القرآن query:الكهف reciter:العفاسي` (المصدر mp3quran.net).
- يوتيوب يعتمد على مكتبتي `youtube-sr` و`@distube/ytdl-core` وتحتاج ffmpeg. يوتيوب يغيّر حمايته من وقت لآخر، فلو توقف التشغيل نفّذ: `npm update @distube/ytdl-core`.
- تنبيه: تشغيل يوتيوب داخل البوتات يخالف شروط يوتيوب، فاستخدمه على مسؤوليتك.

### منع السبام `/antispam`
`تشغيل` ← اختر العقوبة ← قناة السجلات ← **قناة الفحص** (فخ: أي رسالة فيها = عقوبة، وسيجهز البوت صلاحياتها). البوت يحتاج Manage Messages و Moderate Members (والطرد/الحظر إن اخترتهما).

### القيف اوي `/giveaway`
اختر روم الإرسال ← **إنشاء** ← اكتب الجائزة والفائزين والمدة (`30m` `2h` `1d`). **المظهر والقالب** يغيّر النص والصورة والأزرار.

### الفضفضة `/feel`
اختر الرومات وشغّلها. البوت يحتاج Manage Messages لحذف الرسالة الأصلية.

### جدولة التوب `/schedule`
**جدولة جديدة** ← النوع (كتابي/صوتي) ← الفترة ← الروم ← تأكيد. وقت الإرسال والتوقيت من «الساعة والتوقيت».

> بعد أول تشغيل بالنسخة الجديدة نفّذ `npm install` (لتثبيت youtube-sr و ytdl-core وتحديث discord.js).


---

## إضافات v3.23

### السجلات `/logs`
- **إدارية:** القنوات • السيرفر • البوتات • الرتب • إعطاء/سحب الرتب • الباند • الطرد • التايم اوت • الإيموجي • الملصقات • السحب والطرد الصوتي • ميوت/ديفن • الحذف الجماعي.
- **عامة:** الرسائل • الصور • رسائل البوتات • دخول/خروج • الروابط • دخول/خروج صوتي • التنقل الصوتي • كتم النفس • الأسماء • الحسابات • التفاعلات.
- من `/logs` فعّل المطلوب، وحدد روم الإدارية وروم العامة، أو اضغط **إنشاء الرومات تلقائياً** (أو اكتب `setlog!`). `detlog!` يحذفها.
- يحتاج البوت صلاحية **View Audit Log** ليعرف من نفّذ العملية (بدونها يسجل الحدث بدون اسم المنفّذ).
- فعّل في بوابة المطورين: Server Members + Message Content (موجودان أصلاً).

### الألوان `/colors`
1. اختر مجموعة ألوان (11 مجموعة) وسينشئ البوت الرتب تلقائياً (`color 1`، `color 2`...).
2. ارفع رتبة البوت فوق رتب الألوان، وارفع رتب الألوان فوق أي رتبة ملونة أخرى لتظهر.
3. الأعضاء: `colors!` تعرض القائمة بصورة وقائمة اختيار، `color! 3` يغيّر اللون، `color! 0` يزيله.
4. من القائمة غيّر العنوان والشكل (مربعة/دائرية) والخلفية (شفافة/داكنة) وأرسل القائمة بزر.

### أوامر الشات بنمط `!`
`hide!` `unhide!` `lock!` `unlock!` `slowmode! 5` `setlog!` `detlog!` `setvoice!` (يثبّت البوت في روم صوتي 24 ساعة، و`setvoice! off` للإلغاء) `color!` `colors!`.
كلها تظهر في `/cmdmanager` ويمكن إيقاف أي أمر منها.

### الرد التلقائي
موجود في `/autoreply`: تطابق تام / يحتوي على / يبدأ بـ، مع رتب وشاتات مسموحة ومحظورة لكل رد.
