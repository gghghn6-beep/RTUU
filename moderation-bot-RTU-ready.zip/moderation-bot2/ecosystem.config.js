// تشغيل بـ PM2 على VPS:  pm2 start ecosystem.config.js && pm2 save
module.exports = {
  apps: [{
    name: 'moderation-bot',
    script: 'index.js',
    instances: 1,            // مهم: نسخة واحدة فقط
    autorestart: true,
    max_memory_restart: '500M',
    restart_delay: 5000,
    kill_timeout: 10000,
    env: { NODE_ENV: 'production' }
  }]
};
