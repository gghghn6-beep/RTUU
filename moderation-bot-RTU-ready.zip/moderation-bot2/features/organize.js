'use strict';
// ═══ organize.js — نظام التنظيم: تنظيم الشات والسيرفر ═══
// /organize  → لوحة إدارة بخمس تبويبات:
//   🛡️ قواعد الرومات   (صور فقط • كتابة فقط • روابط فقط • بدون روابط • بدون دعوات)
//   📌 رسائل ثابتة      (تبقى آخر الروم دايماً)
//   🧹 تنظيف تلقائي    (يحذف الرسائل القديمة من روم معيّن)
//   ⚡ تلقائيات         (ثريد تلقائي + تفاعلات تلقائية على كل رسالة)
//   📋 تقرير السيرفر   (يفحص التنظيم والصلاحيات ويعطيك درجة)
module.exports = (H) => {
const { D, EPH, BLUE, row, btn, strSel, chSel, roleSel, input, modal, embed, cut, rid, isUrl, session, adminOnly, update, chTxt, getTextChannel, isAdmin, client, SERVER_ID } = H;
const db = H.db;
const { ButtonStyle, EmbedBuilder } = D;

const MAX_PER_KIND = 25;
const GREEN = 0x57F287, RED = 0xED4245, YELLOW = 0xFEE75C;

// ───── التخزين ─────
function O() {
    const o = (db.organize = db.organize || {});
    for (const k of ['rules', 'stickies', 'cleans', 'autos']) o[k] = Array.isArray(o[k]) ? o[k] : [];
    o.logChannelId = o.logChannelId || '';
    return o;
}
const E = () => { const e = new EmbedBuilder(); e.toJSON = function () { return { ...this.data }; }; return e; };
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const normColor = (c) => { const m = /^#?([0-9a-f]{6})$/i.exec(String(c || '').trim()); return m ? '#' + m[1].toLowerCase() : null; };
const fill = (t, v) => String(t).replace(/[\{\[]\s*(user|text|channel)\s*[\}\]]/gi, (m, k) => (v[k.toLowerCase()] != null ? v[k.toLowerCase()] : m));

const MODES = {
    media: { label: '📷 صور وملفات فقط', desc: 'يحذف أي رسالة بدون صورة أو ملف', notice: 'هذا الروم مخصص للصور والملفات فقط 📷' },
    nomedia: { label: '💬 كتابة فقط', desc: 'يحذف الرسائل اللي فيها صور أو ملفات', notice: 'هذا الروم للكتابة فقط، ممنوع الصور والملفات 💬' },
    links: { label: '🔗 روابط فقط', desc: 'يحذف أي رسالة ما فيها رابط', notice: 'هذا الروم مخصص للروابط فقط 🔗' },
    nolinks: { label: '🚫 بدون روابط', desc: 'يحذف أي رسالة فيها رابط', notice: 'ممنوع إرسال الروابط في هذا الروم 🚫' },
    noinvites: { label: '🚫 بدون دعوات سيرفرات', desc: 'يحذف روابط دعوات ديسكورد فقط', notice: 'ممنوع نشر دعوات السيرفرات 🚫' }
};
const DURS = [[5, '5 دقائق'], [15, '15 دقيقة'], [30, '30 دقيقة'], [60, 'ساعة'], [180, '3 ساعات'], [360, '6 ساعات'], [720, '12 ساعة'], [1440, '24 ساعة'], [4320, '3 أيام'], [10080, '7 أيام']];
const durLabel = (m) => { const d = DURS.find(x => x[0] === m); return d ? d[1] : m + ' دقيقة'; };

// ───── كشف المخالفات ─────
const LINK_RE = /(https?:\/\/|www\.)\S+|discord\.gg\/\S+|discord(?:app)?\.com\/invite\/\S+/i;
const INVITE_RE = /discord\.gg\/\S+|discord(?:app)?\.com\/invite\/\S+/i;
const MEDIA_URL_RE = /https?:\/\/\S+\.(png|jpe?g|gif|webp|bmp|mp4|mov|webm|mkv|avi)(\?\S*)?/i;
const MEDIA_HOST_RE = /https?:\/\/(?:www\.)?(tenor\.com|giphy\.com|imgur\.com|i\.redd\.it|media\.discordapp\.net|cdn\.discordapp\.com)\/\S+/i;
function hasMedia(msg) {
    if (msg.attachments && msg.attachments.size > 0) return true;
    for (const e of (msg.embeds || [])) { const t = e.type || (e.data && e.data.type); if (e.image || e.video || t === 'image' || t === 'gifv' || t === 'video') return true; }
    const c = msg.content || '';
    return MEDIA_URL_RE.test(c) || MEDIA_HOST_RE.test(c);
}
function violates(msg, mode) {
    const c = msg.content || '';
    if (mode === 'media') return !hasMedia(msg);
    if (mode === 'nomedia') return hasMedia(msg);
    if (mode === 'links') return !LINK_RE.test(c);
    if (mode === 'nolinks') return LINK_RE.test(c);
    if (mode === 'noinvites') return INVITE_RE.test(c);
    return false;
}
function bypassed(member, rule) {
    try {
        if (!member) return false;
        if (isAdmin(member)) return true;
        return rule.bypassRoles.some(r => member.roles.cache.has(r));
    } catch { return false; }
}
const noticeAt = new Map();
const pruneNotices = () => { if (noticeAt.size > 1000) { const old = Date.now() - 3600000; for (const [k, t] of noticeAt) if (t < old) noticeAt.delete(k); } };
async function punish(msg, rule) {
    try { await msg.delete(); } catch { return false; }
    const o = O();
    const now = Date.now(); const k = msg.author.id + ':' + rule.channelId; pruneNotices();
    if (rule.notice && now - (noticeAt.get(k) || 0) > 10000) {
        noticeAt.set(k, now);
        try {
            const text = fill(rule.noticeText || MODES[rule.mode].notice, { user: '<@' + msg.author.id + '>', channel: '<#' + rule.channelId + '>' });
            const n = await msg.channel.send({ content: '<@' + msg.author.id + '> ' + cut(text, 500), allowedMentions: { users: [msg.author.id] } });
            const t = setTimeout(() => { try { n.delete().catch(() => {}); } catch {} }, 7000); if (t.unref) t.unref();
        } catch {}
    }
    if (o.logChannelId) {
        try {
            const ch = await getTextChannel(msg.guild, o.logChannelId);
            if (ch) {
                const e = E().setColor(RED).setAuthor({ name: cut((msg.author.username || 'عضو') + ' • رسالة محذوفة', 256), iconURL: msg.author.displayAvatarURL ? msg.author.displayAvatarURL({ size: 64 }) : undefined })
                    .setDescription(cut(msg.content || '`بدون نص`', 1500))
                    .addFields({ name: '👤 العضو', value: '<@' + msg.author.id + '>', inline: true }, { name: '📍 الروم', value: '<#' + rule.channelId + '>', inline: true }, { name: '📜 القاعدة', value: MODES[rule.mode].label, inline: true })
                    .setFooter({ text: 'نظام التنظيم' });
                await ch.send({ embeds: [e], allowedMentions: { parse: [] } });
            }
        } catch {}
    }
    return true;
}

// ───── رسائل ثابتة ─────
const stTimers = new Map();
function stickyPayload(st) {
    const e = E().setColor(parseInt((normColor(st.color) || '#0A3A8C').slice(1), 16)).setTitle(cut(st.title || '📌 تنبيه مهم', 256)).setDescription(cut(st.text || '—', 4000))
        .setFooter({ text: cut(st.footer || '📌 رسالة ثابتة', 200) });
    if (isUrl(st.image)) e.setImage(st.image.trim());
    return { embeds: [e], allowedMentions: { parse: [] } };
}
async function repostSticky(st, force) {
    const guild = client.guilds && client.guilds.cache && client.guilds.cache.get(SERVER_ID);
    const ch = guild && await getTextChannel(guild, st.channelId);
    if (!ch) throw new Error('الروم غير موجود أو البوت ما يشوفه');
    if (!force && st.lastMsgId && ch.lastMessageId === st.lastMsgId) return;
    if (st.lastMsgId) { try { const m = await ch.messages.fetch(st.lastMsgId); await m.delete(); } catch {} }
    const sent = await ch.send(stickyPayload(st));
    st.lastMsgId = sent.id; H.save();
}
function scheduleSticky(channelId) {
    const st = O().stickies.find(x => x.enabled && x.channelId === channelId);
    if (!st) return;
    clearTimeout(stTimers.get(channelId));
    const t = setTimeout(() => { repostSticky(st).catch(e => console.error('[organize:sticky]', e.message)); }, 4000);
    if (t.unref) t.unref();
    stTimers.set(channelId, t);
}

// ───── التنظيف التلقائي ─────
async function cleanableMessages(ch, cl) {
    const msgs = await ch.messages.fetch({ limit: 100 });
    const st = O().stickies.find(x => x.channelId === cl.channelId);
    const cutoff = Date.now() - cl.maxAgeMin * 60000;
    return [...msgs.values()].filter(m => m.createdTimestamp < cutoff && !(cl.keepPinned && m.pinned) && !(st && st.lastMsgId === m.id));
}
async function cleanOnce(cl) {
    const guild = client.guilds && client.guilds.cache && client.guilds.cache.get(SERVER_ID);
    const ch = guild && await getTextChannel(guild, cl.channelId);
    if (!ch) return 0;
    let total = 0;
    for (let pass = 0; pass < 3; pass++) {
        const list = await cleanableMessages(ch, cl);
        if (!list.length) break;
        const young = list.filter(m => Date.now() - m.createdTimestamp < 13.5 * 86400000);
        const old = list.filter(m => Date.now() - m.createdTimestamp >= 13.5 * 86400000);
        try { if (young.length >= 2) await ch.bulkDelete(young, true); else for (const m of young) await m.delete(); } catch {}
        for (const m of old.slice(0, 5)) { try { await m.delete(); } catch {} await sleep(500); }
        total += young.length + Math.min(old.length, 5);
        if (list.length < 100) break;
    }
    return total;
}
let cleaning = false;
async function cleanTick() {
    if (cleaning) return; cleaning = true;
    try {
        if (client.isReady && !client.isReady()) return;
        for (const cl of O().cleans) {
            if (!cl.enabled) continue;
            try { await cleanOnce(cl); } catch (e) { console.error('[organize:clean]', e.message); }
            await sleep(800);
        }
    } finally { cleaning = false; }
}
const cleanTimer = setInterval(() => { cleanTick().catch(() => {}); }, 60000); if (cleanTimer.unref) cleanTimer.unref();

// ───── التلقائيات (تفاعلات + ثريد) ─────
async function runAuto(msg, au) {
    for (const em of au.reactions) { try { await msg.react(em); } catch {} }
    if (au.thread) {
        try {
            const name = fill(au.threadName || '[user] • نقاش', { user: (msg.member && msg.member.displayName) || msg.author.username || 'عضو', text: cut((msg.content || '').replace(/\s+/g, ' '), 40) || 'نقاش' });
            await msg.startThread({ name: cut(name, 100), autoArchiveDuration: 1440 });
        } catch {}
    }
}

// ───── استقبال الرسائل ─────
async function onMessage(msg) {
    if (!msg.guild || msg.guild.id !== SERVER_ID || !msg.author) return false;
    if (client.user && msg.author.id === client.user.id) return false;
    const o = O();
    // 1) قواعد الرومات
    if (!msg.author.bot && !msg.webhookId) {
        const rule = o.rules.find(r => r.enabled && r.channelId === msg.channelId);
        if (rule && !bypassed(msg.member, rule) && violates(msg, rule.mode)) { if (await punish(msg, rule)) return true; }
    }
    // 2) تلقائيات
    if (!msg.author.bot) { const au = o.autos.find(x => x.enabled && x.channelId === msg.channelId); if (au) runAuto(msg, au).catch(() => {}); }
    // 3) رسالة ثابتة
    scheduleSticky(msg.channelId);
    return false;
}

// ───── تقرير السيرفر ─────
const snowTime = (id) => { try { return Number((BigInt(id) >> 22n) + 1420070400000n); } catch { return 0; } };
async function buildReport(guild) {
    let fetched = true;
    try { await Promise.race([guild.members.fetch(), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 8000))]); } catch { fetched = false; }
    const all = [...guild.channels.cache.values()];
    const cats = all.filter(c => c.type === 4);
    const text = all.filter(c => c.type === 0 || c.type === 5);
    const voice = all.filter(c => c.type === 2 || c.type === 13);
    const loose = all.filter(c => c.type !== 4 && !c.parentId && !(c.isThread && c.isThread()));
    const emptyCats = cats.filter(c => !all.some(x => x.parentId === c.id));
    const inactive = text.filter(c => !c.lastMessageId || Date.now() - snowTime(c.lastMessageId) > 30 * 86400000);
    const everyone = guild.roles.everyone;
    const roles = [...guild.roles.cache.values()].filter(r => r.id !== guild.id && !r.managed);
    const emptyRoles = fetched ? roles.filter(r => r.members && r.members.size === 0) : [];
    const adminRoles = roles.filter(r => r.permissions.has('Administrator'));
    const me = guild.members.me;
    const above = me ? roles.filter(r => r.position >= me.roles.highest.position) : [];
    const risky = ['Administrator', 'MentionEveryone', 'ManageGuild', 'ManageRoles', 'ManageChannels', 'ManageMessages', 'BanMembers', 'KickMembers'].filter(p => everyone.permissions.has(p));
    const needed = [['ManageMessages', 'حذف الرسائل (قواعد/تنظيف)'], ['ManageChannels', 'إدارة الرومات'], ['ManageRoles', 'إعطاء الرتب'], ['ManageThreads', 'الثريدات التلقائية'], ['EmbedLinks', 'إرسال الإمبد'], ['AddReactions', 'التفاعلات التلقائية'], ['ReadMessageHistory', 'قراءة السجل'], ['SendMessages', 'إرسال الرسائل']];
    const missing = me ? needed.filter(([p]) => !me.permissions.has(p)) : needed;
    let score = 100;
    score -= Math.min(15, loose.length * 2); score -= Math.min(10, emptyCats.length * 3); score -= Math.min(10, Math.floor(inactive.length / 2));
    score -= Math.min(15, emptyRoles.length); score -= adminRoles.length > 3 ? 5 : 0; score -= risky.length ? 20 : 0; score -= Math.min(20, missing.length * 4);
    score = clamp(score, 0, 100);
    const list = (arr, f, n = 8) => arr.length ? arr.slice(0, n).map(f).join('\n') + (arr.length > n ? '\n… و' + (arr.length - n) + ' أخرى' : '') : '✅ لا يوجد';
    const color = score >= 80 ? GREEN : (score >= 60 ? YELLOW : RED);
    const e = E().setColor(color).setTitle('📋 تقرير تنظيم السيرفر').setAuthor({ name: cut(guild.name, 100) })
        .setDescription('**درجة التنظيم: ' + score + '/100**\n' + '▰'.repeat(Math.round(score / 10)) + '▱'.repeat(10 - Math.round(score / 10)) + '\n\n' +
            '📂 **' + cats.length + '** قسم • 💬 **' + text.length + '** روم كتابي • 🔊 **' + voice.length + '** روم صوتي • 🏷️ **' + roles.length + '** رتبة')
        .addFields(
            { name: '📌 رومات بدون قسم (' + loose.length + ')', value: cut(list(loose, c => '• <#' + c.id + '>'), 1000), inline: false },
            { name: '📂 أقسام فاضية (' + emptyCats.length + ')', value: cut(list(emptyCats, c => '• ' + cut(c.name, 40)), 1000), inline: true },
            { name: '💤 رومات خاملة +30 يوم (' + inactive.length + ')', value: cut(list(inactive, c => '• <#' + c.id + '>', 6), 1000), inline: true },
            { name: '🏷️ رتب بدون أعضاء (' + emptyRoles.length + ')' + (fetched ? '' : ' ⚠️'), value: fetched ? cut(list(emptyRoles, r => '• ' + cut(r.name, 40)), 1000) : 'تعذّر جلب الأعضاء، النتيجة تقديرية', inline: false },
            { name: '🛡️ رتب فيها صلاحية Administrator (' + adminRoles.length + ')', value: cut(list(adminRoles, r => '• ' + cut(r.name, 40), 6), 1000), inline: true },
            { name: '⬆️ رتب أعلى من رتبة البوت (' + above.length + ')', value: cut(list(above, r => '• ' + cut(r.name, 40), 6), 1000), inline: true },
            { name: '⚠️ صلاحيات خطرة على @everyone', value: risky.length ? risky.map(p => '• `' + p + '`').join('\n') : '✅ لا يوجد', inline: false },
            { name: '🤖 صلاحيات ناقصة على البوت (' + missing.length + ')', value: missing.length ? cut(missing.map(([p, d]) => '• `' + p + '` — ' + d).join('\n'), 1000) : '✅ كاملة', inline: false })
        .setFooter({ text: 'نظام التنظيم • ' + new Date().toISOString().slice(0, 10) });
    return e;
}

// ───── لوحة الإدارة ─────
const KINDS = {
    r: { key: 'rules', page: 'rules' }, s: { key: 'stickies', page: 'sticky' }, c: { key: 'cleans', page: 'clean' }, a: { key: 'autos', page: 'auto' }
};
const sess = (i) => session(i, 'og', () => ({ page: 'rules', sel: '', confirm: false }));
const stateIcon = (x) => x.enabled ? '🟢' : '⏸️';
const lineOf = {
    rules: (x) => stateIcon(x) + ' <#' + x.channelId + '> — ' + MODES[x.mode].label,
    stickies: (x) => stateIcon(x) + ' <#' + x.channelId + '> — ' + cut(x.title, 40),
    cleans: (x) => stateIcon(x) + ' <#' + x.channelId + '> — كل رسالة أقدم من ' + durLabel(x.maxAgeMin),
    autos: (x) => stateIcon(x) + ' <#' + x.channelId + '> — ' + ([x.thread ? '🧵 ثريد' : '', x.reactions.length ? x.reactions.map(r => /:/.test(r) ? '🔹' : r).join('') : ''].filter(Boolean).join(' • ') || '—')
};
function buildPanel(i) {
    const o = O(); const s = sess(i);
    const nav = row(
        btn('og:nav:rules', 'القواعد', '🛡️', s.page === 'rules' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        btn('og:nav:sticky', 'ثابتة', '📌', s.page === 'sticky' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        btn('og:nav:clean', 'تنظيف', '🧹', s.page === 'clean' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        btn('og:nav:auto', 'تلقائيات', '⚡', s.page === 'auto' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        btn('og:nav:report', 'التقرير', '📋', s.page === 'report' ? ButtonStyle.Primary : ButtonStyle.Secondary));

    if (s.page === 'report') {
        const e = embed().setTitle('📋 تقرير تنظيم السيرفر').setDescription('اضغط **تحديث التقرير** يفحص الأقسام والرومات والرتب وصلاحيات البوت ويعطيك درجة وملاحظات.');
        return { embeds: [e], components: [nav, row(btn('og:rep', 'تحديث التقرير', '🔄', ButtonStyle.Success))] };
    }
    const pageKind = Object.keys(KINDS).find(k => KINDS[k].page === s.page);
    const key = KINDS[pageKind].key;
    const items = o[key];
    const it = items.find(x => x.id === s.sel);
    const addSel = row(chSel('og:' + pageKind + 'add', 'اختر روم لإضافته…', { min: 1, max: 1 }));
    const listSel = items.length ? row(strSel('og:' + pageKind + 'sel', 'اختر عنصراً لتعديله…', items.map(x => ({ label: cut(('#' + ((client.channels && client.channels.cache && client.channels.cache.get(x.channelId) && client.channels.cache.get(x.channelId).name) || x.channelId)), 90), value: x.id, description: cut(key === 'rules' ? MODES[x.mode].label : (key === 'cleans' ? durLabel(x.maxAgeMin) : (x.enabled ? 'يعمل' : 'متوقف')), 100) })))) : null;

    if (s.page === 'rules') {
        if (!it) {
            const e = embed().setTitle('🛡️ قواعد الرومات').setDescription('حدد نوع المحتوى المسموح في كل روم، والبوت يحذف المخالف فوراً ويرسل تنبيه مؤقت للعضو. الإدارة وأي رتبة تستثنيها ما تنحذف رسائلها.')
                .addFields({ name: 'القواعد (' + items.length + '/' + MAX_PER_KIND + ')', value: items.length ? cut(items.map(lineOf.rules).join('\n'), 1000) : '`لا توجد قواعد — اختر روم من الأسفل`' },
                    { name: '📜 لوق الحذف', value: chTxt(o.logChannelId), inline: true });
            const comps = [nav, addSel]; if (listSel) comps.push(listSel);
            comps.push(row(chSel('og:rlog', 'روم لوق الرسائل المحذوفة (اختياري)', { min: 0, max: 1, selected: o.logChannelId ? [o.logChannelId] : [] })));
            return { embeds: [e], components: comps };
        }
        const e = embed().setTitle('🛡️ قاعدة الروم').setDescription('<#' + it.channelId + '>')
            .addFields({ name: '📜 القاعدة', value: MODES[it.mode].label + '\n' + MODES[it.mode].desc, inline: false },
                { name: '🔌 الحالة', value: it.enabled ? '✅ تعمل' : '⏸️ متوقفة', inline: true }, { name: '🔔 التنبيه للعضو', value: it.notice ? '✅ مفعّل' : '⛔ متوقف', inline: true },
                { name: '👥 رتب مستثناة', value: it.bypassRoles.length ? it.bypassRoles.map(r => '<@&' + r + '>').join(' ') : '`الإدارة فقط`', inline: false },
                { name: '💬 نص التنبيه', value: cut(it.noticeText || MODES[it.mode].notice, 200), inline: false });
        return { embeds: [e], components: [nav,
            row(strSel('og:rmode', 'نوع القاعدة', Object.entries(MODES).map(([k, m]) => ({ label: m.label.replace(/^\S+\s/, ''), value: k, description: m.desc, default: k === it.mode })))),
            row(roleSel('og:rbyp', 'رتب مستثناة من القاعدة (اختياري)', { min: 0, max: 10, selected: it.bypassRoles })),
            row(btn('og:rnotice', it.notice ? 'إيقاف التنبيه' : 'تفعيل التنبيه', '🔔', ButtonStyle.Secondary), btn('og:rtxt', 'نص التنبيه', '✏️', ButtonStyle.Primary),
                btn('og:ren', it.enabled ? 'إيقاف' : 'تشغيل', it.enabled ? '⏸️' : '▶️', ButtonStyle.Secondary), btn('og:rdel', s.confirm ? 'تأكيد الحذف ⚠️' : 'حذف', '🗑️', ButtonStyle.Danger))] };
    }
    if (s.page === 'sticky') {
        if (!it) {
            const e = embed().setTitle('📌 الرسائل الثابتة').setDescription('رسالة تبقى دايماً آخر الروم: كل ما أحد كتب، البوت يحذف القديمة وينزلها من جديد تحت. مناسبة للقوانين والتنبيهات.')
                .addFields({ name: 'الرسائل (' + items.length + '/' + MAX_PER_KIND + ')', value: items.length ? cut(items.map(lineOf.stickies).join('\n'), 1000) : '`لا توجد — اختر روم من الأسفل`' });
            const comps = [nav, addSel]; if (listSel) comps.push(listSel);
            return { embeds: [e], components: comps };
        }
        const e = embed().setTitle('📌 ثابتة في الروم').setDescription('<#' + it.channelId + '>')
            .addFields({ name: '🧾 العنوان', value: cut(it.title, 200), inline: true }, { name: '🎨 اللون', value: '`' + (normColor(it.color) || '#0A3A8C') + '`', inline: true }, { name: '🔌 الحالة', value: it.enabled ? '✅ تعمل' : '⏸️ متوقفة', inline: true },
                { name: '💬 النص', value: cut(it.text, 800), inline: false }, { name: '🖼️ الصورة', value: it.image ? '✅ موجودة' : '`بدون`', inline: true });
        return { embeds: [e], components: [nav, row(btn('og:sedit', 'النص', '✏️', ButtonStyle.Primary), btn('og:slook', 'الصورة واللون', '🖼️', ButtonStyle.Primary), btn('og:spub', 'نشر الآن', '📤', ButtonStyle.Success),
            btn('og:sen', it.enabled ? 'إيقاف' : 'تشغيل', it.enabled ? '⏸️' : '▶️', ButtonStyle.Secondary), btn('og:sdel', s.confirm ? 'تأكيد الحذف ⚠️' : 'حذف', '🗑️', ButtonStyle.Danger))] };
    }
    if (s.page === 'clean') {
        if (!it) {
            const e = embed().setTitle('🧹 التنظيف التلقائي').setDescription('يحذف الرسائل الأقدم من مدة تحددها في روم معيّن كل دقيقة (مناسب لروم الأوامر أو الإعلانات المؤقتة).\n⚠️ الحذف نهائي، وكل عنصر يبدأ **متوقف** لين تفعّله بنفسك.')
                .addFields({ name: 'الرومات (' + items.length + '/' + MAX_PER_KIND + ')', value: items.length ? cut(items.map(lineOf.cleans).join('\n'), 1000) : '`لا توجد — اختر روم من الأسفل`' });
            const comps = [nav, addSel]; if (listSel) comps.push(listSel);
            return { embeds: [e], components: comps };
        }
        const e = embed().setTitle('🧹 تنظيف الروم').setDescription('<#' + it.channelId + '>')
            .addFields({ name: '⏱️ يحذف الأقدم من', value: durLabel(it.maxAgeMin), inline: true }, { name: '📌 المثبّتة', value: it.keepPinned ? '✅ تبقى' : '🗑️ تنحذف', inline: true }, { name: '🔌 الحالة', value: it.enabled ? '✅ يعمل' : '⏸️ متوقف', inline: true });
        return { embeds: [e], components: [nav,
            row(strSel('og:cage', 'احذف الرسائل الأقدم من…', DURS.map(([m, l]) => ({ label: l, value: String(m), default: m === it.maxAgeMin })))),
            row(btn('og:cprev', 'معاينة', '🔍', ButtonStyle.Secondary), btn('og:cpin', it.keepPinned ? 'المثبّتة تبقى' : 'المثبّتة تنحذف', '📌', ButtonStyle.Secondary),
                btn('og:cen', it.enabled ? 'إيقاف' : 'تشغيل', it.enabled ? '⏸️' : '▶️', it.enabled ? ButtonStyle.Secondary : ButtonStyle.Success), btn('og:cdel', s.confirm ? 'تأكيد الحذف ⚠️' : 'حذف', '🗑️', ButtonStyle.Danger))] };
    }
    // auto
    if (!it) {
        const e = embed().setTitle('⚡ التلقائيات').setDescription('على كل رسالة جديدة في الروم: يضيف تفاعلات (إيموجي) و/أو يفتح ثريد للنقاش. مناسب لرومات الصور والاقتراحات.')
            .addFields({ name: 'الرومات (' + items.length + '/' + MAX_PER_KIND + ')', value: items.length ? cut(items.map(lineOf.autos).join('\n'), 1000) : '`لا توجد — اختر روم من الأسفل`' });
        const comps = [nav, addSel]; if (listSel) comps.push(listSel);
        return { embeds: [e], components: comps };
    }
    const e = embed().setTitle('⚡ تلقائيات الروم').setDescription('<#' + it.channelId + '>')
        .addFields({ name: '🧵 ثريد تلقائي', value: it.thread ? '✅ مفعّل\n`' + cut(it.threadName, 60) + '`' : '⛔ متوقف', inline: true }, { name: '😀 التفاعلات', value: it.reactions.length ? it.reactions.join(' ') : '`بدون`', inline: true }, { name: '🔌 الحالة', value: it.enabled ? '✅ تعمل' : '⏸️ متوقفة', inline: true });
    return { embeds: [e], components: [nav, row(btn('og:ath', it.thread ? 'إيقاف الثريد' : 'تفعيل الثريد', '🧵', ButtonStyle.Secondary), btn('og:are', 'التفاعلات', '😀', ButtonStyle.Primary), btn('og:anm', 'اسم الثريد', '✏️', ButtonStyle.Primary),
        btn('og:aen', it.enabled ? 'إيقاف' : 'تشغيل', it.enabled ? '⏸️' : '▶️', ButtonStyle.Secondary), btn('og:adel', s.confirm ? 'تأكيد الحذف ⚠️' : 'حذف', '🗑️', ButtonStyle.Danger))] };
}
const refresh = (i) => update(i, buildPanel(i));

async function slash(i) {
    if (!(await adminOnly(i))) return;
    const s = sess(i); s.page = 'rules'; s.sel = ''; s.confirm = false;
    return i.reply({ ...buildPanel(i), flags: EPH });
}

function newEntry(kind, channelId) {
    const base = { id: rid(), channelId };
    if (kind === 'r') return { ...base, mode: 'media', bypassRoles: [], notice: true, noticeText: '', enabled: true };
    if (kind === 's') return { ...base, title: '📌 تنبيه مهم', text: 'اكتب هنا نص الرسالة الثابتة (زر ✏️ النص)', image: '', color: '#0A3A8C', footer: '', lastMsgId: '', enabled: false };
    if (kind === 'c') return { ...base, maxAgeMin: 1440, keepPinned: true, enabled: false };
    return { ...base, thread: false, threadName: '[user] • نقاش', reactions: [], enabled: true };
}
function parseEmojis(raw) {
    const out = [];
    for (const t of String(raw || '').split(/[\s,،]+/).filter(Boolean)) {
        const c = /^<a?:(\w{2,32}):(\d{15,25})>$/.exec(t);
        if (c) out.push(c[1] + ':' + c[2]);
        else if (/^[\p{Extended_Pictographic}\u{1F1E6}-\u{1F1FF}][\p{Extended_Pictographic}\uFE0F\u200D\u{1F3FB}-\u{1F3FF}\u{1F1E6}-\u{1F1FF}]*$/u.test(t)) out.push(t);
    }
    return out.slice(0, 5);
}

async function component(i) {
    if (!(await adminOnly(i))) return;
    const o = O(); const s = sess(i); const act = i.customId.split(':')[1];
    if (act !== 'rep' && !/del$/.test(act)) s.confirm = false;

    if (act === 'nav') { await i.deferUpdate(); const p = i.customId.split(':')[2]; s.page = ['rules', 'sticky', 'clean', 'auto', 'report'].includes(p) ? p : 'rules'; s.sel = ''; return i.editReply(buildPanel(i)); }
    if (act === 'rep') {
        await i.deferUpdate();
        const s2 = sess(i); s2.page = 'report';
        let e; try { e = await buildReport(i.guild); } catch (err) { e = E().setColor(RED).setTitle('❌ تعذّر إنشاء التقرير').setDescription(cut(err.message, 300)); }
        return i.editReply({ ...buildPanel(i), embeds: [e] });
    }
    if (act === 'rlog' && i.isChannelSelectMenu()) { await i.deferUpdate(); o.logChannelId = i.values[0] || ''; H.save(); return i.editReply(buildPanel(i)); }

    const kind = act[0]; const op = act.slice(1); const K = KINDS[kind];
    if (!K) return;
    const list = o[K.key]; const it = list.find(x => x.id === s.sel);

    // نوافذ
    if (i.isButton()) {
        if (kind === 'r' && op === 'txt' && it) return i.showModal(modal('ogm:rtxt', 'نص التنبيه', input('t', 'نص التنبيه [user] [channel]', { required: false, paragraph: true, max: 300, value: it.noticeText, placeholder: MODES[it.mode].notice })));
        if (kind === 's' && op === 'edit' && it) return i.showModal(modal('ogm:sedit', 'نص الرسالة الثابتة',
            input('title', 'العنوان', { required: true, max: 100, value: it.title }), input('text', 'النص', { required: true, paragraph: true, max: 2000, value: it.text }), input('footer', 'التذييل (اختياري)', { required: false, max: 100, value: it.footer })));
        if (kind === 's' && op === 'look' && it) return i.showModal(modal('ogm:slook', 'الصورة واللون',
            input('image', 'رابط صورة (اختياري)', { required: false, max: 300, value: it.image }), input('color', 'اللون (مثال: #0A3A8C)', { required: false, max: 7, value: it.color })));
        if (kind === 'a' && op === 're' && it) return i.showModal(modal('ogm:are', 'التفاعلات التلقائية', input('e', 'إيموجي مفصولة بمسافة (حد أقصى 5)', { required: false, max: 100, value: it.reactions.map(x => /:/.test(x) ? '' : x).join(' '), placeholder: '👍 ❤️ 🔥' })));
        if (kind === 'a' && op === 'nm' && it) return i.showModal(modal('ogm:anm', 'اسم الثريد', input('n', 'الاسم [user] [text]', { required: true, max: 80, value: it.threadName })));
        if (kind === 's' && op === 'pub' && it) {
            await i.deferReply({ flags: EPH });
            try { await repostSticky(it, true); return i.editReply({ content: '✅ نُشرت الرسالة الثابتة في <#' + it.channelId + '>' }); } catch (e) { return i.editReply({ content: '❌ ' + cut(e.message, 200) + '\nتأكد من صلاحيات البوت في الروم.' }); }
        }
        if (kind === 'c' && op === 'prev' && it) {
            await i.deferReply({ flags: EPH });
            try {
                const ch = await getTextChannel(i.guild, it.channelId); if (!ch) throw new Error('الروم غير موجود');
                const n = (await cleanableMessages(ch, it)).length;
                return i.editReply({ content: '🔍 من آخر 100 رسالة في <#' + it.channelId + '>: **' + n + '** رسالة أقدم من ' + durLabel(it.maxAgeMin) + ' وبتنحذف لو فعّلت التنظيف.' });
            } catch (e) { return i.editReply({ content: '❌ ' + cut(e.message, 200) }); }
        }
        await i.deferUpdate();
        if (it && op === 'en') it.enabled = !it.enabled;
        else if (it && kind === 'r' && op === 'notice') it.notice = !it.notice;
        else if (it && kind === 'c' && op === 'pin') it.keepPinned = !it.keepPinned;
        else if (it && kind === 'a' && op === 'th') it.thread = !it.thread;
        else if (it && op === 'del') { if (!s.confirm) s.confirm = true; else { o[K.key] = list.filter(x => x.id !== it.id); s.sel = ''; s.confirm = false; } }
        H.save();
        return i.editReply(buildPanel(i));
    }
    await i.deferUpdate();
    if (i.isChannelSelectMenu() && op === 'add') {
        const ch = i.values[0];
        const exist = list.find(x => x.channelId === ch);
        if (exist) s.sel = exist.id;
        else if (list.length < MAX_PER_KIND) { const n = newEntry(kind, ch); list.push(n); s.sel = n.id; }
    } else if (i.isStringSelectMenu() && op === 'sel') s.sel = i.values[0];
    else if (i.isStringSelectMenu() && kind === 'r' && op === 'mode' && it && MODES[i.values[0]]) it.mode = i.values[0];
    else if (i.isStringSelectMenu() && kind === 'c' && op === 'age' && it) it.maxAgeMin = clamp(parseInt(i.values[0], 10) || 1440, 5, 10080);
    else if (i.isRoleSelectMenu() && kind === 'r' && op === 'byp' && it) it.bypassRoles = i.values.slice(0, 10);
    H.save();
    return i.editReply(buildPanel(i));
}

async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const o = O(); const s = sess(i); const act = i.customId.split(':')[1];
    const kind = act[0]; const K = KINDS[kind]; if (!K) return;
    const it = o[K.key].find(x => x.id === s.sel); if (!it) return;
    const val = (n) => { try { return i.fields.getTextInputValue(n).trim(); } catch { return ''; } };
    const bad = (m) => i.reply({ content: '❌ ' + m, flags: EPH });
    if (act === 'rtxt') it.noticeText = val('t');
    else if (act === 'sedit') { it.title = val('title') || it.title; it.text = val('text') || it.text; it.footer = val('footer'); }
    else if (act === 'slook') {
        const img = val('image'), col = val('color');
        if (img && !isUrl(img)) return bad('رابط الصورة غير صحيح.');
        if (col && !normColor(col)) return bad('اللون لازم يكون بصيغة #0A3A8C');
        it.image = img; it.color = normColor(col) || '#0A3A8C';
    } else if (act === 'are') {
        const raw = val('e'); const em = parseEmojis(raw);
        if (raw && !em.length) return bad('ما لقيت إيموجي صحيحة. مثال: 👍 ❤️ 🔥');
        it.reactions = em;
    } else if (act === 'anm') it.threadName = val('n') || it.threadName;
    else return;
    H.save();
    return refresh(i);
}

const commands = [{ name: 'organize', description: 'تنظيم الشات والسيرفر: قواعد الرومات، رسائل ثابتة، تنظيف تلقائي، تلقائيات، تقرير (إدارة)' }];
return { prefix: 'og', commands, ephemeral: ['organize'], slash: { organize: slash }, component, modal: modalSubmit, onMessage,
    _t: { violates, hasMedia, buildReport, cleanOnce, cleanTick, stickyPayload, repostSticky, runAuto, parseEmojis, buildPanel } };
};
