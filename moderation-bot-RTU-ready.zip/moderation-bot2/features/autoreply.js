'use strict';
// ═══ الردود التلقائية: /autoreply — كلمات مفتاحية + صلاحيات متقدمة (رتب/رومات مسموحة ومحظورة) ═══
module.exports = (H) => {
const { D, BLUE, EPH, row, btn, strSel, chSel, roleSel, input, modal, embed, cut, rid, session, adminOnly, update, onOff, fillVars } = H;
const db = H.db;
const { ButtonStyle } = D;
const store = () => (db.autoreply = db.autoreply || { enabled: true, replies: [] });
const MATCH = { exact: 'تطابق تام', contains: 'يحتوي على', starts: 'يبدأ بـ' };
const MATCH_KEYS = Object.keys(MATCH);
const sess = (i) => session(i, 'ar', () => ({ sel: null, page: 'main' }));
const current = (i) => { const s = sess(i); return store().replies.find(r => r.id === s.sel) || null; };
const list = (a) => (a && a.length ? a.map(x => '<@&' + x + '>').join(' ') : '`الجميع`');
const clist = (a) => (a && a.length ? a.map(x => '<#' + x + '>').join(' ') : '`الكل`');

function buildPanel(i) {
    const st = store(); const s = sess(i);
    if (!st.replies.find(r => r.id === s.sel)) s.sel = st.replies[0] ? st.replies[0].id : null;
    const r = current(i);
    const e = embed().setTitle(s.page === 'perms' ? '🔐 الصلاحيات المتقدمة للرد' : '🤖 الردود التلقائية')
        .setDescription(s.page === 'perms'
            ? 'تحكّم بدقة من يقدر يفعّل هذا الرد وفين. اترك القائمة فاضية = الجميع/الكل.'
            : 'نظام ذكي يرد على الرسائل تلقائياً بناءً على كلمات مفتاحية. (' + st.replies.length + '/25)');
    e.addFields({ name: '🔌 النظام', value: onOff(st.enabled), inline: true });
    const rows = [];
    if (s.page === 'perms' && r) {
        e.addFields(
            { name: '✅ رتب مسموحة', value: list(r.roleWhite), inline: true }, { name: '⛔ رتب محظورة', value: list(r.roleBlack), inline: true },
            { name: '✅ شاتات مسموحة', value: clist(r.chanWhite), inline: true }, { name: '⛔ شاتات محظورة', value: clist(r.chanBlack), inline: true });
        rows.push(row(btn('ar:back', 'رجوع', '⬅️', ButtonStyle.Primary)));
        rows.push(row(roleSel('ar:rw', 'المسموح لهم (WhiteList) — رتب', { min: 0, max: 25, selected: r.roleWhite })));
        rows.push(row(roleSel('ar:rb', 'المحظورين (BlackList) — رتب', { min: 0, max: 25, selected: r.roleBlack })));
        rows.push(row(chSel('ar:cw', 'شاتات مسموحة (WhiteList)', { min: 0, max: 25, selected: r.chanWhite })));
        rows.push(row(chSel('ar:cb', 'شاتات محظورة (BlackList)', { min: 0, max: 25, selected: r.chanBlack })));
        return { embeds: [e], components: rows };
    }
    if (r) {
        e.addFields(
            { name: '🔑 الكلمة', value: '`' + cut(r.keyword, 100) + '` • ' + MATCH[r.match], inline: false },
            { name: '💬 الرد', value: cut(r.reply, 900) || '—', inline: false },
            { name: '⚙️ الخيارات', value: onOff(r.enabled) + ' • ' + (r.mode === 'send' ? 'رسالة جديدة' : 'رد على الرسالة') + (r.deleteTrigger ? ' • يحذف رسالة العضو' : ''), inline: false });
        rows.push(row(strSel('ar:pick', 'اختر الرد', st.replies.map(x => ({ label: (x.enabled ? '' : '⛔ ') + cut(x.keyword, 90), value: x.id, description: cut(x.reply, 90), default: x.id === r.id })))));
    } else e.addFields({ name: 'لا توجد ردود', value: 'اضغط **➕ رد جديد** للبدء.' });
    rows.push(row(btn('ar:new', 'رد جديد', '➕', ButtonStyle.Success, st.replies.length >= 25), btn('ar:edit', 'تعديل', '✏️', ButtonStyle.Primary, !r),
        btn('ar:match', 'المطابقة', '🔁', ButtonStyle.Secondary, !r), btn('ar:tog', r && r.enabled ? 'إيقاف' : 'تفعيل', '🔘', ButtonStyle.Secondary, !r), btn('ar:del', 'حذف', '🗑️', ButtonStyle.Danger, !r)));
    rows.push(row(btn('ar:perms', 'الصلاحيات', '🔐', ButtonStyle.Secondary, !r), btn('ar:mode', 'طريقة الرد', '💬', ButtonStyle.Secondary, !r),
        btn('ar:deltrig', 'حذف رسالة العضو', '🧹', ButtonStyle.Secondary, !r), btn('ar:sys', st.enabled ? 'إيقاف النظام' : 'تشغيل النظام', '🔌', st.enabled ? ButtonStyle.Danger : ButtonStyle.Success)));
    return { embeds: [e], components: rows };
}
const refresh = (i) => update(i, buildPanel(i));

async function slash(i) { if (!(await adminOnly(i))) return; sess(i).page = 'main'; return i.reply({ ...buildPanel(i), flags: EPH }); }

async function component(i) {
    if (!(await adminOnly(i))) return;
    const st = store(); const s = sess(i); const r = current(i); const a = i.customId.split(':')[1];
    if (i.isButton()) {
        if (a === 'new') return i.showModal(modal('arm:new', 'رد جديد',
            input('keyword', 'الكلمة المفتاحية', { required: true, max: 100, placeholder: 'مثال: السلام عليكم' }),
            input('reply', 'الرد  ({user} {server})', { required: true, paragraph: true, max: 1000, placeholder: 'اكتب رد البوت هنا...' })));
        if (a === 'edit' && r) return i.showModal(modal('arm:edit', 'تعديل الرد',
            input('keyword', 'الكلمة المفتاحية', { required: true, max: 100, value: r.keyword }),
            input('reply', 'الرد  ({user} {server})', { required: true, paragraph: true, max: 1000, value: r.reply })));
        await i.deferUpdate();
        if (a === 'back') s.page = 'main';
        else if (a === 'perms' && r) s.page = 'perms';
        else if (a === 'match' && r) r.match = MATCH_KEYS[(MATCH_KEYS.indexOf(r.match) + 1) % MATCH_KEYS.length];
        else if (a === 'tog' && r) r.enabled = !r.enabled;
        else if (a === 'mode' && r) r.mode = r.mode === 'send' ? 'reply' : 'send';
        else if (a === 'deltrig' && r) r.deleteTrigger = !r.deleteTrigger;
        else if (a === 'sys') st.enabled = !st.enabled;
        else if (a === 'del' && r) { st.replies = st.replies.filter(x => x.id !== r.id); s.sel = null; }
        H.save();
        return i.editReply(buildPanel(i));
    }
    await i.deferUpdate();
    if (i.isStringSelectMenu() && a === 'pick') s.sel = i.values[0];
    else if (r && i.isRoleSelectMenu()) { if (a === 'rw') r.roleWhite = [...i.values]; if (a === 'rb') r.roleBlack = [...i.values]; }
    else if (r && i.isChannelSelectMenu()) { if (a === 'cw') r.chanWhite = [...i.values]; if (a === 'cb') r.chanBlack = [...i.values]; }
    H.save();
    return i.editReply(buildPanel(i));
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const st = store(); const s = sess(i); const a = i.customId.split(':')[1];
    const kw = i.fields.getTextInputValue('keyword').trim(), rp = i.fields.getTextInputValue('reply').trim();
    if (!kw || !rp) return i.reply({ content: '❌ الكلمة والرد مطلوبين.', flags: EPH });
    if (a === 'new') {
        if (st.replies.length >= 25) return i.reply({ content: '❌ الحد الأقصى 25 رد.', flags: EPH });
        const r = { id: rid(), keyword: kw, match: 'exact', reply: rp, enabled: true, mode: 'reply', deleteTrigger: false, roleWhite: [], roleBlack: [], chanWhite: [], chanBlack: [] };
        st.replies.push(r); s.sel = r.id; s.page = 'main';
    } else { const r = current(i); if (r) { r.keyword = kw; r.reply = rp; } }
    H.save();
    return refresh(i);
}

const cooldown = new Map();
function norm(t) { return String(t || '').replace(/[\u064B-\u065F\u0670\u0640]/g, '').trim().toLowerCase(); }
async function onMessage(msg) {
    const st = db.autoreply;
    if (!st || !st.enabled || !st.replies.length || msg.author.bot || !msg.guild || !msg.content) return false;
    const text = norm(msg.content);
    for (const r of st.replies) {
        if (!r.enabled) continue;
        const kw = norm(r.keyword); if (!kw) continue;
        const ok = r.match === 'exact' ? text === kw : r.match === 'starts' ? text.startsWith(kw) : text.includes(kw);
        if (!ok) continue;
        const roles = msg.member ? [...msg.member.roles.cache.keys()] : [];
        if (r.roleWhite && r.roleWhite.length && !r.roleWhite.some(x => roles.includes(x))) continue;
        if (r.roleBlack && r.roleBlack.length && r.roleBlack.some(x => roles.includes(x))) continue;
        if (r.chanWhite && r.chanWhite.length && !r.chanWhite.includes(msg.channelId)) continue;
        if (r.chanBlack && r.chanBlack.includes(msg.channelId)) continue;
        const key = msg.author.id + ':' + r.id; const now = Date.now();
        if (cooldown.get(key) && now - cooldown.get(key) < 3000) continue;
        cooldown.set(key, now);
        const body = { content: cut(fillVars(r.reply, msg.member || msg.author), 2000), allowedMentions: { users: [msg.author.id], repliedUser: false } };
        if (r.mode === 'send') await msg.channel.send(body); else await msg.reply(body);
        if (r.deleteTrigger) { try { await msg.delete(); } catch {} }
        return false;
    }
    return false;
}

const commands = [{ name: 'autoreply', description: 'قائمة الردود التلقائية (كلمات مفتاحية + صلاحيات متقدمة)' }];
return { prefix: 'ar', commands, ephemeral: ['autoreply'], slash: { autoreply: slash }, component, modal: modalSubmit, onMessage, _buildPanel: buildPanel };
};
