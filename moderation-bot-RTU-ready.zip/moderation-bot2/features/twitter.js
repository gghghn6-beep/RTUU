'use strict';
/**
 * نظام سوشيال ميديا — لوحة بقائمة منسدلة
 * تقدر تضيف تويتر / انستقرام / سناب / أي منصة
 * العضو يختار من القائمة → يكتب النص + صورة → ينشر بالويبهوك باسم المنصة
 */
module.exports = (H) => {
const { D, client, isAdmin, SERVER_ID, save, EPH, row, btn, embed, cut, adminOnly, isUrl, fetchBuffer, path, fs } = H;
const { ButtonStyle, AttachmentBuilder, StringSelectMenuBuilder } = D;
const db = H.db;

const ASSETS = path.join(__dirname, '..', 'assets');
function readLogoFile(...names) {
    for (const n of names) {
        try { return fs.readFileSync(path.join(ASSETS, n)); } catch {}
    }
    return null;
}
const readXLogo = () => readLogoFile('x-logo.png', 'x-logo.jpg');
const readInstaLogo = () => readLogoFile('instagram.jpg', 'instagram.png');
const readSnapLogo = () => readLogoFile('snapchat.jpg', 'snapchat.png');

function logoForPlatform(p) {
    const n = ((p && (p.name || p.webhookName)) || '').toLowerCase();
    if (/instagram|انستا|انستقرام|إنستغرام/.test(n)) return readInstaLogo();
    if (/snap|سناب/.test(n)) return readSnapLogo();
    if (/twitter|تويتر|\bx\b/.test(n)) return readXLogo();
    return null;
}

const cfg = () => {
    const t = (db.twitter = db.twitter || {});
    t.panelImage = t.panelImage || t.image || '';
    t.panelThumb = t.panelThumb || '';
    t.platforms = Array.isArray(t.platforms) ? t.platforms : [];
    // ترحيل الإعداد القديم (قناة واحدة) إلى منصة تويتر
    if (!t.platforms.length && t.channelId) {
        t.platforms.push({
            id: 'x',
            name: 'تويتر / X',
            emoji: '🐦',
            channelId: t.channelId,
            webhookName: 'X'
        });
    }
    return t;
};

function rid() { return Math.random().toString(36).slice(2, 8); }

// ───── اللوحة العامة (نفس شكل الصورة الثانية) ─────
function publicPanel(guild) {
    const t = cfg();
    const e = embed()
        .setTitle('سوشيال ميديا')
        .setDescription('سوشيال ميديا لنشر اخبار السيرفر');

    if (isUrl(t.panelThumb)) e.setThumbnail(t.panelThumb);
    else {
        const logo = readXLogo();
        if (logo) e.setThumbnail('attachment://x-logo.png');
    }
    if (isUrl(t.panelImage)) e.setImage(t.panelImage);

    const icon = guild.iconURL?.({ size: 64 });
    e.setFooter({ text: guild.name, ...(icon ? { iconURL: icon } : {}) });

    const files = [];
    if (!isUrl(t.panelThumb) && readXLogo()) {
        files.push(new AttachmentBuilder(readXLogo(), { name: 'x-logo.png' }));
    }

    const platforms = t.platforms.filter(p => p.channelId);
    let components = [];
    if (platforms.length) {
        const menu = new StringSelectMenuBuilder()
            .setCustomId('tw:pick')
            .setPlaceholder('اختر المنصة...')
            .addOptions(platforms.slice(0, 25).map(p => ({
                label: cut(p.name, 100),
                value: p.id,
                emoji: p.emoji || undefined,
                description: cut('نشر في ' + p.name, 100)
            })));
        components = [row(menu)];
    } else {
        components = [row(btn('tw:none', 'لا توجد منصات مُعدّة', null, ButtonStyle.Secondary, true))];
    }

    return { embeds: [e], components, files };
}

// ───── لوحة الإدارة ─────
function adminPanel() {
    const t = cfg();
    const e = embed()
        .setTitle('📱 إدارة سوشيال ميديا')
        .setDescription('أضف منصات (تويتر، انستقرام، سناب...) وحدد روم كل واحدة، ثم انشر اللوحة.');

    e.addFields(
        { name: 'المنصات', value: t.platforms.length ? t.platforms.map(p => `${p.emoji || '•'} **${p.name}** → ${p.channelId ? '<#' + p.channelId + '>' : '`بدون روم`'}`).join('\n') : '`لا توجد منصات`', inline: false },
        { name: 'الصورة الكبيرة', value: isUrl(t.panelImage) ? '✅ محددة' : '`غير محددة`', inline: true },
        { name: 'الصورة الصغيرة', value: isUrl(t.panelThumb) ? '✅ محددة' : '`غير محددة`', inline: true }
    );

    const rows = [
        row(
            btn('tw:add', 'إضافة منصة', '➕', ButtonStyle.Success),
            btn('tw:edit', 'تعديل منصة', '✏️', ButtonStyle.Primary, !t.platforms.length),
            btn('tw:del', 'حذف منصة', '🗑️', ButtonStyle.Danger, !t.platforms.length)
        ),
        row(
            btn('tw:imgs', 'صور اللوحة', '🖼️', ButtonStyle.Secondary),
            btn('tw:pub', 'نشر اللوحة', '📤', ButtonStyle.Success, !t.platforms.some(p => p.channelId))
        )
    ];
    return { embeds: [e], components: rows };
}

// ───── أوامر السلاش ─────
async function slash(i) {
    if (!(await adminOnly(i))) return;
    return i.reply({ ...adminPanel(), flags: EPH });
}

// ───── مكونات (أزرار + قائمة) ─────
async function component(i) {
    const id = i.customId;

    // العضو يختار منصة من القائمة العامة
    if (id === 'tw:pick' && i.isStringSelectMenu()) {
        const pid = i.values[0];
        const t = cfg();
        const p = t.platforms.find(x => x.id === pid);
        if (!p || !p.channelId) return i.reply({ content: '❌ هذه المنصة غير جاهزة.', flags: EPH });
        return showPostModal(i, p);
    }

    // باقي الأزرار للإدارة فقط
    if (!(await adminOnly(i))) return;
    const t = cfg();

    if (id === 'tw:add') {
        return i.showModal(H.modal('twm:add', 'إضافة منصة جديدة',
            H.input('name', 'اسم المنصة', { required: true, max: 80, placeholder: 'تويتر / X' }),
            H.input('emoji', 'الإيموجي (اختياري)', { max: 40, placeholder: '🐦' }),
            H.input('webhook', 'اسم الويبهوك', { max: 80, placeholder: 'X', value: 'X' })
        ));
    }

    if (id === 'tw:edit') {
        if (!t.platforms.length) return i.reply({ content: '❌ لا توجد منصات.', flags: EPH });
        const menu = new StringSelectMenuBuilder()
            .setCustomId('tw:editsel')
            .setPlaceholder('اختر المنصة لتعديلها')
            .addOptions(t.platforms.map(p => ({ label: cut(p.name, 100), value: p.id, emoji: p.emoji || undefined })));
        return i.update({ embeds: [embed().setTitle('تعديل منصة').setDescription('اختر المنصة')], components: [row(menu)] });
    }

    if (id === 'tw:editsel' && i.isStringSelectMenu()) {
        const p = t.platforms.find(x => x.id === i.values[0]);
        if (!p) return i.reply({ content: '❌ المنصة غير موجودة.', flags: EPH });
        return i.showModal(H.modal('twm:edit:' + p.id, 'تعديل: ' + cut(p.name, 30),
            H.input('name', 'اسم المنصة', { required: true, max: 80, value: p.name }),
            H.input('emoji', 'الإيموجي', { max: 40, value: p.emoji || '' }),
            H.input('webhook', 'اسم الويبهوك', { max: 80, value: p.webhookName || p.name }),
            H.input('channel', 'آيدي الروم (أو اتركه فاضي)', { max: 30, value: p.channelId || '', placeholder: '123456789012345678' })
        ));
    }

    if (id === 'tw:del') {
        if (!t.platforms.length) return i.reply({ content: '❌ لا توجد منصات.', flags: EPH });
        const menu = new StringSelectMenuBuilder()
            .setCustomId('tw:delsel')
            .setPlaceholder('اختر المنصة لحذفها')
            .addOptions(t.platforms.map(p => ({ label: cut(p.name, 100), value: p.id, emoji: p.emoji || undefined })));
        return i.update({ embeds: [embed().setTitle('حذف منصة').setDescription('اختر المنصة')], components: [row(menu)] });
    }

    if (id === 'tw:delsel' && i.isStringSelectMenu()) {
        t.platforms = t.platforms.filter(x => x.id !== i.values[0]);
        save();
        return i.update(adminPanel());
    }

    if (id === 'tw:imgs') {
        return i.showModal(H.modal('twm:imgs', 'صور لوحة سوشيال ميديا',
            H.input('banner', 'رابط الصورة الكبيرة', { max: 500, value: t.panelImage, placeholder: 'https://... (اتركه فاضي للحذف)' }),
            H.input('thumb', 'رابط الصورة الصغيرة (الثامبنيل)', { max: 500, value: t.panelThumb, placeholder: 'https://... (اتركه فاضي للحذف)' })
        ));
    }

    if (id === 'tw:pub') {
        if (!t.platforms.some(p => p.channelId)) return i.reply({ content: '❌ أضف روم لمنصة واحدة على الأقل.', flags: EPH });
        await i.deferUpdate();
        const payload = publicPanel(i.guild);
        await i.channel.send(payload);
        return i.followUp({ content: '✅ تم نشر لوحة سوشيال ميديا في هذا الروم.', flags: EPH });
    }

    // تعيين روم منصة (من قائمة القنوات لو احتجنا)
    if (id.startsWith('tw:setch:') && i.isChannelSelectMenu()) {
        const pid = id.split(':')[2];
        const p = t.platforms.find(x => x.id === pid);
        if (p) {
            p.channelId = i.values[0];
            save();
        }
        return i.update(adminPanel());
    }
}

// ───── المودالات ─────
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const t = cfg();
    const cid = i.customId;

    if (cid === 'twm:add') {
        const name = i.fields.getTextInputValue('name').trim();
        const emoji = (i.fields.getTextInputValue('emoji') || '').trim();
        const webhookName = (i.fields.getTextInputValue('webhook') || name).trim() || name;
        if (!name) return i.reply({ content: '❌ الاسم مطلوب.', flags: EPH });
        const p = { id: rid(), name, emoji, channelId: '', webhookName };
        t.platforms.push(p);
        save();
        // بعد الإضافة نطلب اختيار الروم
        const chMenu = new D.ChannelSelectMenuBuilder()
            .setCustomId('tw:setch:' + p.id)
            .setPlaceholder('اختر روم النشر لهذه المنصة')
            .setChannelTypes(D.ChannelType.GuildText, D.ChannelType.GuildAnnouncement);
        return i.reply({
            content: `✅ تمت إضافة **${name}**. الآن اختر الروم:`,
            components: [row(chMenu)],
            flags: EPH
        });
    }

    if (cid.startsWith('twm:edit:')) {
        const pid = cid.split(':')[2];
        const p = t.platforms.find(x => x.id === pid);
        if (!p) return i.reply({ content: '❌ المنصة غير موجودة.', flags: EPH });
        p.name = i.fields.getTextInputValue('name').trim() || p.name;
        p.emoji = (i.fields.getTextInputValue('emoji') || '').trim();
        p.webhookName = (i.fields.getTextInputValue('webhook') || p.name).trim();
        const ch = (i.fields.getTextInputValue('channel') || '').trim();
        if (ch) p.channelId = ch;
        save();
        return i.reply({ ...adminPanel(), flags: EPH });
    }

    if (cid === 'twm:imgs') {
        const banner = i.fields.getTextInputValue('banner').trim();
        const thumb = i.fields.getTextInputValue('thumb').trim();
        if ((banner && !isUrl(banner)) || (thumb && !isUrl(thumb))) {
            return i.reply({ content: '❌ الرابط لازم يبدأ بـ https://', flags: EPH });
        }
        t.panelImage = banner;
        t.panelThumb = thumb;
        save();
        return i.reply({ ...adminPanel(), flags: EPH });
    }

    // نشر المحتوى (من العضو)
    if (cid.startsWith('twm:post:')) {
        return publish(i, cid.split(':')[2]);
    }
}

// ───── نافذة الكتابة ─────
async function showPostModal(i, platform) {
    const title = 'نشر في ' + cut(platform.name, 30);
    if (D.LabelBuilder && D.FileUploadBuilder) {
        try {
            const m = new D.ModalBuilder().setCustomId('twm:post:' + platform.id).setTitle(title);
            const text = new D.TextInputBuilder().setCustomId('text').setStyle(D.TextInputStyle.Paragraph).setRequired(false).setMaxLength(1800).setPlaceholder('اكتب الخبر هنا...');
            const file = new D.FileUploadBuilder().setCustomId('file').setRequired(false).setMinValues(0).setMaxValues(1);
            m.addLabelComponents(
                new D.LabelBuilder().setLabel('النص').setTextInputComponent(text),
                new D.LabelBuilder().setLabel('الصورة (اختياري)').setFileUploadComponent(file)
            );
            return await i.showModal(m);
        } catch (e) { console.error('[social] file upload modal failed:', e.message); }
    }
    return i.showModal(H.modal('twm:post:' + platform.id, title,
        H.input('text', 'النص', { paragraph: true, max: 1800, placeholder: 'اكتب الخبر هنا...' }),
        H.input('url', 'رابط الصورة (اختياري)', { max: 500, placeholder: 'https://...' })
    ));
}

// ───── النشر عبر ويبهوك ─────
async function getWebhook(ch, name, avatarBuf) {
    const hooks = await ch.fetchWebhooks().catch(() => null);
    let hook = hooks && hooks.find(h => h.owner?.id === client.user.id && h.name === name);
    if (!hook) {
        hook = await ch.createWebhook({
            name: name || 'Social',
            avatar: avatarBuf || undefined,
            reason: 'نظام سوشيال ميديا'
        });
    }
    return hook;
}

async function toAttachment(url) {
    const { buf, ct } = await fetchBuffer(url, 8 * 1024 * 1024);
    if (!/^image\//i.test(ct)) throw new Error('الملف المرفق مو صورة');
    const ext = (ct.split('/')[1] || 'png').split(';')[0].replace('jpeg', 'jpg');
    return new AttachmentBuilder(buf, { name: 'image.' + ext });
}

async function publish(i, platformId) {
    const t = cfg();
    const p = t.platforms.find(x => x.id === platformId);
    if (!p || !p.channelId) return i.reply({ content: '❌ المنصة غير جاهزة.', flags: EPH });

    const text = (() => { try { return i.fields.getTextInputValue('text').trim(); } catch { return ''; } })();
    let imgUrl = '';
    try {
        const f = i.fields.getUploadedFiles && i.fields.getUploadedFiles('file');
        const first = f && f.first && f.first();
        if (first) imgUrl = first.url;
    } catch {}
    if (!imgUrl) { try { imgUrl = i.fields.getTextInputValue('url').trim(); } catch {} }

    if (imgUrl && !isUrl(imgUrl)) return i.reply({ content: '❌ رابط الصورة لازم يبدأ بـ https://', flags: EPH });
    if (!text && !imgUrl) return i.reply({ content: '❌ اكتب نص أو أرفق صورة.', flags: EPH });

    await i.deferReply({ flags: EPH });
    const ch = await H.getTextChannel(i.guild, p.channelId);
    if (!ch) return i.editReply({ content: '❌ روم النشر غير موجود.' });

    let files = [];
    if (imgUrl) {
        try { files = [await toAttachment(imgUrl)]; }
        catch (e) { return i.editReply({ content: '❌ تعذّر تحميل الصورة: ' + cut(e.message, 150) }); }
    }

    try {
        const avatar = logoForPlatform(p);
        const hook = await getWebhook(ch, p.webhookName || p.name, avatar);
        const sent = await hook.send({
            username: p.webhookName || p.name,
            content: text || undefined,
            files,
            allowedMentions: { parse: [] }
        });

        // إعادة تعيين القائمة عشان تقدر تختار مرة ثانية بدون "اعادة الاختيار"
        try {
            if (i.message && i.message.editable) {
                await i.message.edit(publicPanel(i.guild));
            }
        } catch {}

        return i.editReply({ content: `✅ تم النشر في **${p.name}**: https://discord.com/channels/${i.guild.id}/${ch.id}/${sent.id}` });
    } catch (e) {
        const tip = /Missing Permissions|50013/i.test(e.message) ? '\n⚠️ البوت يحتاج صلاحية Manage Webhooks في روم النشر.' : '';
        return i.editReply({ content: '❌ فشل النشر: ' + cut(e.message, 150) + tip });
    }
}

const commands = [{
    name: 'twitter',
    description: 'إدارة لوحة سوشيال ميديا (تويتر • انستقرام • سناب...)'
}];

return {
    prefix: 'tw',
    commands,
    ephemeral: ['twitter'],
    slash: { twitter: slash },
    component,
    modal: modalSubmit
};
};
