'use strict';
/**
 * اختصارات الصورة والبانر بدون سلاش (بكلمة تحددها أنت):
 *   a            ← صورة بروفايلك
 *   a @عضو       ← صورة بروفايل العضو   (أو a ثم الـ ID)
 *   b @عضو       ← بانر العضو
 * تغيير الكلمة (للإدارة فقط):  -اختصار صورة س    /    -اختصار بانر ص
 * عرض الكلمات الحالية:        -اختصار
 */
module.exports = (H) => {
const { client, SERVER_ID, isAdmin, save, embed, cut } = H;
const db = H.db;

const cfg = () => {
    const a = (db.avatar = db.avatar || {});
    a.avatarTrigger = a.avatarTrigger || 'a';
    a.bannerTrigger = a.bannerTrigger || 'b';
    return a;
};

// تهدئة بسيطة عشان ما يتكرر الطلب (خفيف على الاستضافة)
const last = new Map();
function cooling(uid) {
    const now = Date.now();
    if (now - (last.get(uid) || 0) < 4000) return true;
    last.set(uid, now);
    if (last.size > 300) for (const [k, t] of last) if (now - t > 60000) last.delete(k);
    return false;
}

async function resolveTarget(msg, arg) {
    const men = msg.mentions.users.first();
    if (men) return men;
    const id = (arg || '').replace(/[<@!>]/g, '');
    if (/^\d{15,22}$/.test(id)) return client.users.fetch(id).catch(() => null);
    return null;
}

async function sendAvatar(msg, user) {
    const member = msg.guild.members.cache.get(user.id) || await msg.guild.members.fetch(user.id).catch(() => null);
    const src = member || user;
    const link = ext => src.displayAvatarURL({ extension: ext, size: 1024, forceStatic: true });
    const e = embed()
        .setAuthor({ name: user.username, iconURL: user.displayAvatarURL({ size: 64 }) })
        .setTitle('🖼️ صورة البروفايل')
        .setDescription(`[PNG](${link('png')}) • [JPG](${link('jpg')}) • [WEBP](${link('webp')})`)
        .setImage(src.displayAvatarURL({ size: 1024 }))
        .setFooter({ text: 'طلبها ' + msg.author.username });
    return msg.reply({ embeds: [e], allowedMentions: { repliedUser: false } });
}

async function sendBanner(msg, user) {
    const full = await client.users.fetch(user.id, { force: true }).catch(() => null);
    const url = full && full.bannerURL ? full.bannerURL({ size: 1024 }) : null;
    if (!url) return msg.reply({ content: '❌ **' + cut(user.username, 40) + '** ما عنده بانر.', allowedMentions: { repliedUser: false } });
    const e = embed()
        .setAuthor({ name: user.username, iconURL: user.displayAvatarURL({ size: 64 }) })
        .setTitle('🎞️ بانر البروفايل')
        .setImage(url)
        .setFooter({ text: 'طلبها ' + msg.author.username });
    return msg.reply({ embeds: [e], allowedMentions: { repliedUser: false } });
}

async function onMessage(msg) {
    if (!msg.guild || msg.guild.id !== SERVER_ID || msg.author.bot) return false;
    const text = (msg.content || '').trim();
    if (!text || text.length > 80) return false;
    const c = cfg();

    // تغيير الكلمات (للإدارة)
    const set = text.match(/^[-ـ]\s*اختصار(?:\s+(\S+))?(?:\s+(\S+))?$/);
    if (set) {
        if (!isAdmin(msg.member)) { await msg.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.' }).catch(() => {}); return true; }
        const kind = set[1], word = set[2];
        if (!kind) {
            await msg.reply({ content: `⚙️ **الاختصارات الحالية**\nالصورة: \`${c.avatarTrigger}\`\nالبانر: \`${c.bannerTrigger}\`\n\nللتغيير: \`-اختصار صورة س\` أو \`-اختصار بانر ص\``, allowedMentions: { repliedUser: false } }).catch(() => {});
            return true;
        }
        const isAv = /^(صورة|صوره|افتار|أفاتار|avatar)$/i.test(kind);
        const isBn = /^(بانر|banner)$/i.test(kind);
        if (!isAv && !isBn || !word) { await msg.reply({ content: '❌ الصيغة: `-اختصار صورة س` أو `-اختصار بانر ص`' }).catch(() => {}); return true; }
        if (word.length > 12 || /^[-\/<@#]/.test(word)) { await msg.reply({ content: '❌ الكلمة لازم تكون قصيرة (حتى 12 حرف) وما تبدأ بـ - أو / أو منشن.' }).catch(() => {}); return true; }
        const w = word.toLowerCase();
        if ((isAv && w === c.bannerTrigger.toLowerCase()) || (isBn && w === c.avatarTrigger.toLowerCase())) { await msg.reply({ content: '❌ هذي الكلمة مستخدمة للأمر الثاني.' }).catch(() => {}); return true; }
        if (isAv) c.avatarTrigger = word; else c.bannerTrigger = word;
        save();
        await msg.reply({ content: `✅ تم: ${isAv ? 'الصورة' : 'البانر'} صار بالكلمة \`${word}\``, allowedMentions: { repliedUser: false } }).catch(() => {});
        return true;
    }

    // الاستخدام: كلمة لوحدها أو كلمة + منشن/ID
    const parts = text.split(/\s+/);
    if (parts.length > 2) return false;
    const w = parts[0].toLowerCase();
    const isAv = w === c.avatarTrigger.toLowerCase();
    const isBn = w === c.bannerTrigger.toLowerCase();
    if (!isAv && !isBn) return false;
    if (cooling(msg.author.id)) return true;
    let user = msg.author;
    if (parts[1]) {
        user = await resolveTarget(msg, parts[1]);
        if (!user) { await msg.reply({ content: '❌ ما لقيت العضو، منشنه أو اكتب الـ ID.', allowedMentions: { repliedUser: false } }).catch(() => {}); return true; }
    }
    try { await (isAv ? sendAvatar(msg, user) : sendBanner(msg, user)); } catch (e) { console.error('[avatar]', e.message); }
    return true;
}

return { onMessage };
};
