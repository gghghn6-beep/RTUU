'use strict';
/**
 * /botprofile — تخصيص ملف البوت داخل هذا السيرفر فقط:
 *  • اللقب (Nickname) • الأفتار (1:1 — حتى 5MB) • البانر (16:9 — حتى 8MB) • العودة للمظهر الافتراضي
 *  الصيغ: PNG / JPG / WebP / GIF — الرفع من رابط أو كمرفق مع الأمر.
 */
module.exports = (H) => {
const { D, client, SERVER_ID, row, btn, input, modal, embed, cut, adminOnly, update, fetchBuffer, isUrl, EPH } = H;
const { ButtonStyle, Routes } = D;
const LIM = { avatar: 5 * 1048576, banner: 8 * 1048576 };

async function toData(url, max) {
    const { buf, ct } = await fetchBuffer(url, max);
    const t = String(ct.split(';')[0] || '').trim().toLowerCase();
    if (!/^image\/(png|jpe?g|gif|webp)$/.test(t)) throw new Error('الصيغة غير مدعومة، المسموح: PNG / JPG / WebP / GIF');
    return 'data:' + t + ';base64,' + buf.toString('base64');
}
const patchMe = (guildId, body) => client.rest.patch(Routes.guildMember(guildId, '@me'), { body });
const me = (g) => g.members.me;

function build(g) {
    const m = me(g);
    const av = m.avatar && m.displayAvatarURL ? m.displayAvatarURL({ size: 256 }) : null;
    const bn = m.bannerURL ? m.bannerURL({ size: 1024 }) : null;
    const e = embed().setTitle('🤖 بروفايل البوت في هذا السيرفر').setThumbnail(av || client.user.displayAvatarURL({ size: 256 }))
        .setDescription('خصّص مظهر البوت داخل **' + g.name + '** فقط، بدون التأثير على السيرفرات الأخرى.')
        .addFields({ name: '✏️ اللقب', value: m.nickname ? '`' + cut(m.nickname, 40) + '`' : '`الافتراضي`', inline: true },
            { name: '🖼️ الأفتار', value: av ? 'مخصص' : 'الافتراضي', inline: true }, { name: '🎞️ البانر', value: bn ? 'مخصص' : 'الافتراضي', inline: true },
            { name: '📐 المقاييس', value: 'الأفتار: **1:1** مربع (يوصى بـ 512×512) • الحد الأقصى **5MB**\nالبانر: **16:9** عريض (يوصى بـ 960×540) • الحد الأقصى **8MB**\nالصيغ: PNG • JPG • WebP • GIF (متحرك)' });
    if (bn) e.setImage(bn);
    return { embeds: [e], components: [row(btn('bf:nick', 'اللقب', '✏️', ButtonStyle.Primary), btn('bf:ava', 'الأفتار', '🖼️', ButtonStyle.Primary), btn('bf:ban', 'البانر', '🎞️', ButtonStyle.Primary), btn('bf:reset', 'المظهر الافتراضي', '♻️', ButtonStyle.Danger))] };
}
async function applyNick(g, v) { await me(g).setNickname(v || null, 'botprofile'); }
async function applyImg(g, kind, url) {
    if (!isUrl(url)) throw new Error('الرابط غير صحيح.');
    await patchMe(g.id, { [kind]: await toData(url, LIM[kind]) });
}
async function slash(i) {
    if (!(await adminOnly(i))) return;
    const nick = i.options.getString('nickname'); const av = i.options.getAttachment('avatar'); const bn = i.options.getAttachment('banner');
    if (nick == null && !av && !bn) return i.reply({ ...build(i.guild), flags: EPH });
    await i.deferReply({ flags: EPH });
    const done = [];
    try {
        if (nick != null) { await applyNick(i.guild, nick.trim()); done.push('اللقب'); }
        if (av) { await applyImg(i.guild, 'avatar', av.url); done.push('الأفتار'); }
        if (bn) { await applyImg(i.guild, 'banner', bn.url); done.push('البانر'); }
    } catch (e) { return i.editReply({ embeds: [embed().setDescription('❌  ' + cut(e.message, 200) + (done.length ? '\nتم قبل الخطأ: ' + done.join('، ') : ''))] }); }
    await i.guild.members.fetch(client.user.id).catch(() => {});
    return i.editReply(build(i.guild));
}
async function component(i) {
    if (!(await adminOnly(i))) return;
    const a = i.customId.split(':')[1];
    if (a === 'nick') return i.showModal(modal('bfm:nick', 'لقب البوت', input('v', 'اللقب (فارغ = الافتراضي)', { value: me(i.guild).nickname || '', max: 32, placeholder: 'مثال: RT System' })));
    if (a === 'ava') return i.showModal(modal('bfm:ava', 'أفتار البوت', input('v', 'رابط الصورة', { required: true, max: 500, placeholder: 'https://...' })));
    if (a === 'ban') return i.showModal(modal('bfm:ban', 'بانر البوت', input('v', 'رابط الصورة', { required: true, max: 500, placeholder: 'https://...' })));
    if (a === 'reset') {
        await i.deferUpdate();
        try { await patchMe(i.guild.id, { nick: null, avatar: null, banner: null }); } catch (e) { await i.followUp({ content: '❌ ' + cut(e.message, 150), flags: EPH }).catch(() => {}); }
        await i.guild.members.fetch(client.user.id).catch(() => {});
        return i.editReply(build(i.guild));
    }
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const a = i.customId.split(':')[1]; const v = i.fields.getTextInputValue('v').trim();
    await i.deferUpdate();
    try {
        if (a === 'nick') await applyNick(i.guild, v);
        else await applyImg(i.guild, a === 'ava' ? 'avatar' : 'banner', v);
    } catch (e) { await i.followUp({ content: '❌ ' + cut(e.message, 200), flags: EPH }).catch(() => {}); }
    await i.guild.members.fetch(client.user.id).catch(() => {});
    return i.editReply(build(i.guild));
}
const commands = [{
    name: 'botprofile', description: 'تخصيص اللقب والأفتار والبانر للبوت داخل هذا السيرفر (إدارة)', options: [
        { name: 'nickname', description: 'لقب البوت (اتركه فارغاً للافتراضي)', type: 3, required: false },
        { name: 'avatar', description: 'صورة الأفتار 1:1 (PNG/JPG/WebP/GIF حتى 5MB)', type: 11, required: false },
        { name: 'banner', description: 'صورة البانر 16:9 (PNG/JPG/WebP/GIF حتى 8MB)', type: 11, required: false }
    ]
}];
return { prefix: 'bf', commands, ephemeral: ['botprofile'], slash: { botprofile: slash }, component, modal: modalSubmit, _build: build };
};
