'use strict';
module.exports = (H) => {
const { D, path, fs, DATA_DIR, BLUE, isAdmin, save, fetchBuffer } = H;
const db = H.db;
const { EmbedBuilder, AttachmentBuilder, MessageFlags } = D;
// ───── أمر الخط ─────
function getLineCfg() {
    const l = db.line || {};
    return { word: l.word || '', file: l.file || '', channelIds: Array.isArray(l.channelIds) ? l.channelIds : [], deleteTrigger: l.deleteTrigger !== false };
}
async function handleLineTrigger(msg) {
    const l = getLineCfg();
    if (!l.word || !l.file || !l.channelIds.includes(msg.channelId)) return false;
    const txt = msg.content.trim().replace(/^[-ـ]+/, '').trim();
    if (txt !== l.word) return false;
    const full = path.join(DATA_DIR, l.file);
    if (!fs.existsSync(full)) return false;
    await msg.channel.send({ files: [new AttachmentBuilder(full)] });
    if (l.deleteTrigger) { try { await msg.delete(); } catch {} }
    return true;
}

async function setlineHandler(i) {
            {
                if (!isAdmin(i.member)) return i.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.', flags: MessageFlags.Ephemeral });
                if (!db.line) db.line = {};
                const l = db.line; const ch = [];
                const o = i.options;
                if (o.getBoolean('reset')) {
                    if (l.file) { try { fs.unlinkSync(path.join(DATA_DIR, l.file)); } catch {} }
                    db.line = {}; save();
                    return i.reply({ content: '🧹 تم مسح إعداد الخط بالكامل.', flags: MessageFlags.Ephemeral });
                }
                const word = o.getString('word'); if (word) { l.word = word.trim().replace(/^[-ـ]+/, '').slice(0, 50); ch.push('الكلمة'); }
                const img = o.getAttachment('image');
                if (img) {
                    if (!String(img.contentType || '').startsWith('image/')) return i.reply({ content: '❌ لازم ترفق صورة.', flags: MessageFlags.Ephemeral });
                    try {
                        const { buf } = await fetchBuffer(img.url, 8 * 1048576);
                        const ext = ((img.name || '').split('.').pop() || 'png').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 5) || 'png';
                        if (l.file) { try { fs.unlinkSync(path.join(DATA_DIR, l.file)); } catch {} }
                        l.file = 'line-image.' + ext;
                        fs.writeFileSync(path.join(DATA_DIR, l.file), buf);
                        ch.push('الصورة');
                    } catch (e) { return i.reply({ content: '❌ تعذّر تحميل الصورة: ' + e.message, flags: MessageFlags.Ephemeral }); }
                }
                const list = new Set(Array.isArray(l.channelIds) ? l.channelIds : []);
                for (const k of ['channel1', 'channel2', 'channel3', 'channel4', 'channel5']) {
                    const c = o.getChannel(k); if (c) { list.add(c.id); if (!ch.includes('الرومات')) ch.push('الرومات'); }
                }
                const rm = o.getChannel('remove_channel'); if (rm) { list.delete(rm.id); ch.push('إزالة روم'); }
                l.channelIds = [...list];
                const dm = o.getBoolean('delete_message'); if (dm != null) { l.deleteTrigger = dm; ch.push('حذف رسالة العضو'); }
                if (ch.length) save();
                const c = getLineCfg();
                const missing = [!c.word && 'الكلمة', !c.file && 'الصورة', !c.channelIds.length && 'روم واحد على الأقل'].filter(Boolean);
                const emb = new EmbedBuilder().setColor(missing.length ? 0xFEE75C : BLUE)
                    .setTitle(ch.length ? '✅ تم حفظ إعداد الخط' : '⚙️ إعداد الخط الحالي')
                    .addFields(
                        { name: '💬 الكلمة', value: c.word ? '`' + c.word + '`' : 'غير محددة', inline: true },
                        { name: '🗑️ حذف رسالة العضو', value: c.deleteTrigger ? 'نعم' : 'لا', inline: true },
                        { name: '📍 الرومات (' + c.channelIds.length + ')', value: c.channelIds.map(x => '<#' + x + '>').join(' ') || 'لا يوجد', inline: false }
                    );
                if (missing.length) emb.setDescription('⚠️ ما يشتغل لين تحدد: **' + missing.join('، ') + '**');
                const reply = { embeds: [emb], flags: MessageFlags.Ephemeral };
                if (c.file && fs.existsSync(path.join(DATA_DIR, c.file))) { reply.files = [new AttachmentBuilder(path.join(DATA_DIR, c.file), { name: c.file })]; emb.setImage('attachment://' + c.file); }
                return i.reply(reply);
            }
}
const commands = [
    { name: 'setline', description: 'أمر الخط: صورة خط + كلمة + عدة رومات', options: [
        { name: 'word', description: 'الكلمة اللي تنرسل فيها صورة الخط (مثل: خط)', type: 3, required: false },
        { name: 'image', description: 'صورة الخط', type: 11, required: false },
        { name: 'channel1', description: 'روم تشتغل فيه الكلمة (يُضاف للقائمة)', type: 7, required: false, channel_types: [0, 5, 11, 12] },
        { name: 'channel2', description: 'روم ثاني', type: 7, required: false, channel_types: [0, 5, 11, 12] },
        { name: 'channel3', description: 'روم ثالث', type: 7, required: false, channel_types: [0, 5, 11, 12] },
        { name: 'channel4', description: 'روم رابع', type: 7, required: false, channel_types: [0, 5, 11, 12] },
        { name: 'channel5', description: 'روم خامس', type: 7, required: false, channel_types: [0, 5, 11, 12] },
        { name: 'remove_channel', description: 'إزالة روم من القائمة', type: 7, required: false, channel_types: [0, 5, 11, 12] },
        { name: 'delete_message', description: 'حذف رسالة العضو بعد إرسال الخط (افتراضي: نعم)', type: 5, required: false },
        { name: 'reset', description: 'مسح إعداد الخط كله', type: 5, required: false }
    ]}
];
return { commands, ephemeral: ['setline'], slash: { setline: setlineHandler }, onMessage: handleLineTrigger };
};
