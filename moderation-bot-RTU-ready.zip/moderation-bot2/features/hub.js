'use strict';
/**
 * /setup — لوحة التحكم المركزية: أمر واحد لكل أنظمة البوت (بدون داشبورد)
 *  • أقسام الأنظمة → اختيار نظام يفتح قائمته الخاصة
 *  • 📣 قائمة الأوامر للناس: تصميم احترافي (صورة علوية • صغيرة • سفلية) + اختيار الأقسام الظاهرة + نشرها في أي روم
 *  • 👑 الإدارة العليا من نفس اللوحة
 */
module.exports = (H) => {
const { D, client, EPH, row, btn, strSel, chSel, roleSel, input, modal, embed, cut, adminOnly, update, session, save, getTextChannel, V2, IMG, isUrl, onOff, chTxt } = H;
const db = H.db;
const { ButtonStyle } = D;

// ───── كتالوج الأنظمة ─────
const GROUPS = [
    { id: 'support', emoji: '🎫', name: 'الدعم والتقديمات', systems: [
        { id: 'tickets', emoji: '🎫', name: 'التذاكر', desc: 'لوحات وأقسام • صورة علوية وسفلية وصغيرة • صلاحيات', cmd: 'tickets' },
        { id: 'apply', emoji: '📋', name: 'التقديمات', desc: 'أسئلة وأوراق وقبول/رفض • المسودات والطلبات محفوظة', cmd: 'apply' },
        { id: 'waitroom', emoji: '⏳', name: 'روم الانتظار', desc: 'طلبات الدعم الصوتي', cmd: 'waitroom' },
        { id: 'suggestions', emoji: '💡', name: 'الاقتراحات', desc: 'تصويت وثريد للنقاش', cmd: 'suggestions' },
        { id: 'ticketstats', emoji: '📈', name: 'إحصائيات التذاكر', desc: 'أداء الفريق', legacy: 'ticketstats' }
    ] },
    { id: 'protect', emoji: '🛡️', name: 'الحماية والسجلات', systems: [
        { id: 'antispam', emoji: '🛡️', name: 'منع السبام', desc: 'حمايات وقناة فخ وعقوبات واستثناءات', cmd: 'antispam' },
        { id: 'limits', emoji: '🔐', name: 'حدود الصلاحيات', desc: 'حماية من التخريب وقائمة بيضاء', cmd: 'limits' },
        { id: 'logs', emoji: '📜', name: 'السجلات', desc: '25 نوع سجل إداري وعام', cmd: 'logs' },
        { id: 'organize', emoji: '🗂️', name: 'تنظيم السيرفر', desc: 'قواعد الرومات وتنظيف تلقائي ورسائل ثابتة', cmd: 'organize' },
        { id: 'botperms', emoji: '🔑', name: 'صلاحيات الرتب في البوت', desc: 'من يستخدم أي أمر', legacy: 'botperms' },
        { id: 'adm', emoji: '👑', name: 'الإدارة العليا', desc: 'الرتب التي تتحكم بكل البوت', native: 'adm' }
    ] },
    { id: 'community', emoji: '👋', name: 'المجتمع والترحيب', systems: [
        { id: 'welcome', emoji: '👋', name: 'الترحيب والمغادرة', desc: 'صورة الترحيب والموضع والرسائل', cmd: 'welcomesettings' },
        { id: 'levels', emoji: '⭐', name: 'المستويات', desc: 'XP ومكافآت الرتب', cmd: 'levels' },
        { id: 'selfroles', emoji: '🏷️', name: 'الرتب الذاتية', desc: 'أزرار وقوائم رتب', cmd: 'selfroles' },
        { id: 'colors', emoji: '🎨', name: 'الألوان', desc: 'مجموعات ألوان للأعضاء', cmd: 'colors' },
        { id: 'giveaway', emoji: '🎉', name: 'القيف اوي', desc: 'مسابقات بقالب وأزرار', cmd: 'giveaway' },
        { id: 'feel', emoji: '💭', name: 'الفضفضة', desc: 'رسائل تتحول لإيمبد', cmd: 'feel' },
        { id: 'autoreply', emoji: '💬', name: 'الردود التلقائية', desc: 'كلمات مفتاحية', cmd: 'autoreply' },
        { id: 'line', emoji: '➖', name: 'أمر الخط', desc: 'صورة خط + كلمة', cmd: 'setline' },
        { id: 'tempvoice', emoji: '🔊', name: 'الرومات المؤقتة', desc: 'غرف صوتية خاصة', cmd: 'tempvoice' },
        { id: 'schedule', emoji: '📅', name: 'جدولة التوب', desc: 'توب تلقائي', cmd: 'schedule' },
        { id: 'streams', emoji: '📡', name: 'إشعارات البثوث', desc: 'يوتيوب • تيك توك • كيك', cmd: 'streams' },
        { id: 'athkar', emoji: '🕌', name: 'الأذكار', desc: 'ذكر عشوائي', cmd: 'athkar' },
        { id: 'radio', emoji: '📻', name: 'الراديو', desc: 'موجات بتردد', cmd: 'radio' }
    ] },
    { id: 'tools', emoji: '🤖', name: 'الذكاء والصوت والمظهر', systems: [
        { id: 'ai', emoji: '🤖', name: 'الذكاء الاصطناعي', desc: 'مساعد صوتي وشات', cmd: 'ai' },
        { id: 'music', emoji: '🎵', name: 'المشغّل الصوتي', desc: 'يوتيوب والقرآن', cmd: 'music' },
        { id: 'embed', emoji: '🧩', name: 'صانع الإيمبد', desc: 'تصميم ومعاينة وقوالب', cmd: 'embed' },
        { id: 'botprofile', emoji: '🪪', name: 'بروفايل البوت', desc: 'لقب وأفتار وبانر داخل السيرفر', cmd: 'botprofile' },
        { id: 'cmdmanager', emoji: '🧰', name: 'إدارة أوامر الشات', desc: 'تفعيل وإيقاف كل أمر', cmd: 'cmdmanager' },
        { id: 'clockpanel', emoji: '🕐', name: 'لوحة الدوام', desc: 'إرسال لوحة تسجيل الدخول', legacy: 'clockpanel' },
        { id: 'staffpoints', emoji: '🏅', name: 'نقاط الإداريين', desc: 'الترتيب والإعداد', legacy: 'staffpoints' }
    ] }
];
const ALL = GROUPS.flatMap(g => g.systems.map(s => ({ ...s, group: g.id })));

// ───── الإعدادات المحفوظة ─────
function pub() {
    const h = (db.hub = db.hub || {}); const p = (h.pub = h.pub || {});
    p.title = p.title == null ? '📚 قائمة الأوامر' : p.title;
    p.description = p.description == null ? 'اختر القسم من القائمة بالأسفل لعرض الأوامر المتاحة لك.' : p.description;
    p.color = p.color || '#0A3A8C';
    p.top = p.top || ''; p.bottom = p.bottom || ''; p.thumb = p.thumb || '';
    p.cats = Array.isArray(p.cats) ? p.cats : ['infocmds', 'roles'];
    p.channelId = p.channelId || ''; p.messageId = p.messageId || ''; p.msgChannelId = p.msgChannelId || '';
    return p;
}
const helpCats = () => (H.helpCats ? H.helpCats() : []);
const sess = (i) => session(i, 'hb', () => ({ view: 'home', cat: 'support', note: '' }));
const tick = (v) => (v ? '✅' : '—');

// ───── واجهة المدير ─────
function viewHome() {
    const e = embed().setTitle('🎛️ لوحة التحكم المركزية')
        .setDescription('كل أنظمة البوت تُدار من هنا بأمر واحد — بدون داشبورد.\nاختر **قسماً** لتفتح أنظمته، أو جهّز **قائمة الأوامر للناس** وانشرها.')
        .addFields(...GROUPS.map(g => ({ name: g.emoji + ' ' + g.name, value: g.systems.map(s => s.name).join(' • '), inline: false })));
    return { embeds: [e], components: [
        row(strSel('hb:cat', 'اختر القسم…', GROUPS.map(g => ({ label: g.name, value: g.id, emoji: g.emoji, description: g.systems.length + ' نظام' })))),
        row(btn('hb:pubview', 'قائمة الأوامر للناس', '📣', ButtonStyle.Primary), btn('hb:adm', 'الإدارة العليا', '👑', ButtonStyle.Secondary))
    ] };
}
function viewGroup(s) {
    const g = GROUPS.find(x => x.id === s.cat) || GROUPS[0];
    const e = embed().setTitle(g.emoji + ' ' + g.name).setDescription(g.systems.map(x => '▸ ' + x.emoji + ' **' + x.name + '**\n   ' + x.desc).join('\n'));
    return { embeds: [e], components: [
        row(strSel('hb:cat', 'تغيير القسم…', GROUPS.map(x => ({ label: x.name, value: x.id, emoji: x.emoji, default: x.id === g.id })))),
        row(strSel('hb:sys', 'افتح نظاماً…', g.systems.map(x => ({ label: x.name, value: x.id, emoji: x.emoji, description: cut(x.desc, 90) })))),
        row(btn('hb:home', 'الرئيسية', '🏠', ButtonStyle.Secondary))
    ] };
}
function viewAdm() {
    const c = H.getConfig() || {}; const cur = [c.roles && c.roles.admin, ...((c.roles && c.roles.admins) || [])].filter(Boolean);
    const e = embed().setTitle('👑 الإدارة العليا').setDescription('الرتب التي تستخدم **كل** أوامر البوت ولوحاته. اختر الرتب (حتى 10).\n⚠️ مستخدمو صلاحية Administrator في ديسكورد دائماً إدارة عليا.')
        .addFields({ name: 'الرتب الحالية', value: cur.length ? [...new Set(cur)].map(r => '<@&' + r + '>').join(' ') : '`غير محددة`' });
    return { embeds: [e], components: [row(roleSel('hb:admsel', 'اختر رتب الإدارة العليا…', { min: 0, max: 10, selected: [...new Set(cur)].slice(0, 10) })), row(btn('hb:home', 'الرئيسية', '🏠', ButtonStyle.Secondary))] };
}
function viewPub(s) {
    const p = pub(); const cats = helpCats();
    const e = embed().setTitle('📣 قائمة الأوامر للناس').setDescription('صمّم القائمة التي تظهر للأعضاء (بشكل احترافي) ثم انشرها في أي روم. الأعضاء يختارون القسم من القائمة فتظهر لهم أوامره بشكل خاص.' + (s.note ? '\n\n' + s.note : ''))
        .addFields({ name: '📝 العنوان', value: cut(p.title || '—', 200), inline: true }, { name: '🎨 اللون', value: '`' + p.color + '`', inline: true }, { name: '📍 روم النشر', value: chTxt(p.channelId), inline: true },
            { name: '🖼️ الصور', value: 'علوية ' + tick(p.top) + ' • صغيرة ' + tick(p.thumb) + ' • سفلية ' + tick(p.bottom) },
            { name: '📂 الأقسام الظاهرة (' + p.cats.length + ')', value: cut(p.cats.map(id => { const c = cats.find(x => x.id === id); return c ? c.emoji + ' ' + c.name : ''; }).filter(Boolean).join(' • ') || '`لا شيء — اختر من القائمة`', 1000) },
            { name: '📤 الحالة', value: p.messageId ? '✅ منشورة — <#' + p.msgChannelId + '>' : '⛔ غير منشورة' });
    const opts = cats.slice(0, 25).map(c => ({ label: c.name, value: c.id, emoji: c.emoji, description: cut(c.desc, 90), default: p.cats.includes(c.id) }));
    const rows = [];
    if (opts.length) rows.push(row(strSel('hb:pcats', 'الأقسام التي تظهر للناس…', opts, { min: 0, max: opts.length })));
    rows.push(row(chSel('hb:pch', 'روم نشر القائمة…', { selected: p.channelId ? [p.channelId] : [] })));
    rows.push(row(btn('hb:ptext', 'النص واللون', '✏️', ButtonStyle.Primary), btn('hb:pimg', 'الصور', '🖼️', ButtonStyle.Primary),
        btn('hb:ppub', p.messageId ? 'تحديث المنشورة' : 'نشر', '📤', ButtonStyle.Success, !p.channelId || !p.cats.length), btn('hb:home', 'الرئيسية', '🏠', ButtonStyle.Secondary)));
    return { embeds: [e], components: rows };
}
const build = (i) => { const s = sess(i); const n = s.note; const v = s.view === 'group' ? viewGroup(s) : s.view === 'adm' ? viewAdm() : s.view === 'pub' ? viewPub(s) : viewHome(); s.note = ''; if (n && s.view !== 'pub') v.embeds[0].setFooter({ text: n.replace(/[*_`]/g, '') }); return v; };

// ───── القائمة العامة (للناس) ─────
function publicMessage(g) {
    const p = pub(); const cats = helpCats().filter(c => p.cats.includes(c.id));
    const top = IMG.resolve(p.top), bottom = IMG.resolve(p.bottom), thumb = IMG.resolve(p.thumb);
    const kids = [];
    if (top) kids.push(V2.gallery([top.url]));
    const head = [p.title ? '# ' + cut(p.title, 250) : '', p.description ? cut(p.description, 1500) : ''].filter(Boolean).join('\n');
    if (head) kids.push(thumb ? V2.section([head], thumb.url) : V2.text(head));
    kids.push(V2.sep());
    kids.push(V2.text(cats.map(c => c.emoji + ' **' + c.name + '**\n-# ' + c.desc).join('\n\n') || '—'));
    kids.push(V2.sep());
    kids.push(row(strSel('hb:pub', 'اختر القسم لعرض أوامره…', cats.slice(0, 25).map(c => ({ label: c.name, value: c.id, emoji: c.emoji, description: cut(c.desc, 90) })))));
    if (bottom) kids.push(V2.gallery([bottom.url]));
    kids.push(V2.text('-# ' + (g ? g.name : '') + ' • قائمة الأوامر'));
    return { components: [V2.container(kids, V2.parseColor(p.color, V2.NAVY))], flags: V2.IS_V2, files: IMG.filesOf(p.top, p.bottom, p.thumb), allowedMentions: { parse: [] } };
}
async function publicPick(i) {
    const c = helpCats().find(x => x.id === i.values[0]);
    if (!c || !pub().cats.includes(c.id)) return i.reply({ content: '⛔ هذا القسم غير متاح.', flags: EPH });
    const body = c.items.map(x => '▸ **' + x.cmd + '**\n   ' + x.desc).join('\n\n');
    return i.reply({ embeds: [embed().setTitle(c.emoji + ' ' + c.name).setDescription(cut(c.desc + '\n\n' + body, 4000)).setFooter({ text: c.items.length + ' أمر' })], flags: EPH });
}
async function publish(i) {
    const p = pub(); const s = sess(i);
    const ch = await getTextChannel(i.guild, p.channelId);
    if (!ch) { s.note = '❌ روم النشر غير صالح.'; return; }
    if (p.messageId) { const oc = await getTextChannel(i.guild, p.msgChannelId || p.channelId); if (oc) { const m = await oc.messages.fetch(p.messageId).catch(() => null); if (m) await m.delete().catch(() => {}); } }
    try {
        const m = await ch.send(publicMessage(i.guild));
        p.messageId = m.id; p.msgChannelId = ch.id; save();
        s.note = '✅ تم النشر في <#' + ch.id + '>';
    } catch (e) { s.note = '❌ تعذّر النشر: ' + cut(e.message, 120); }
}

// ───── الأحداث ─────
async function slash(i) { if (!(await adminOnly(i))) return; const s = sess(i); s.view = 'home'; return i.reply({ ...build(i), flags: EPH }); }
async function component(i) {
    const a = i.customId.split(':')[1];
    if (a === 'pub') return publicPick(i);
    if (!(await adminOnly(i))) return;
    const s = sess(i); const p = pub();
    if (a === 'sys') {
        const sys = ALL.find(x => x.id === i.values[0]); if (!sys) return update(i, build(i));
        if (sys.native === 'adm') { s.view = 'adm'; return update(i, build(i)); }
        if (sys.legacy) { H.runLegacy(i, sys.legacy); return; }
        return H.runSlash(i, sys.cmd);
    }
    if (a === 'ptext') return i.showModal(modal('hbm:ptext', 'نص قائمة الأوامر', input('title', 'العنوان', { max: 200, value: p.title }), input('desc', 'الوصف', { paragraph: true, max: 1500, value: p.description }), input('color', 'اللون مثل #0A3A8C', { max: 7, value: p.color })));
    if (a === 'pimg') return i.showModal(modal('hbm:pimg', 'صور قائمة الأوامر', input('top', 'الصورة العلوية (رابط • فاضي = بدون)', { max: 500, value: p.top.startsWith('local:') ? '' : p.top, placeholder: 'https://...' }), input('thumb', 'الصورة الصغيرة بجانب العنوان', { max: 500, value: p.thumb.startsWith('local:') ? '' : p.thumb, placeholder: 'https://...' }), input('bottom', 'الصورة السفلية', { max: 500, value: p.bottom.startsWith('local:') ? '' : p.bottom, placeholder: 'https://...' })));
    await i.deferUpdate();
    if (a === 'cat') { s.cat = i.values[0]; s.view = 'group'; }
    else if (a === 'home') s.view = 'home';
    else if (a === 'adm') s.view = 'adm';
    else if (a === 'pubview') s.view = 'pub';
    else if (a === 'pcats') { p.cats = [...i.values]; save(); }
    else if (a === 'pch') { p.channelId = i.values[0] || ''; save(); }
    else if (a === 'ppub') await publish(i);
    else if (a === 'admsel') {
        const c = H.getConfig(); c.roles = c.roles || {}; c.roles.admins = [...i.values]; if (H.tk && H.tk.saveConfig) H.tk.saveConfig(); s.note = '✅ تم حفظ رتب الإدارة العليا.';
    }
    return i.editReply(build(i));
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const a = i.customId.split(':')[1]; const p = pub(); const s = sess(i); s.view = 'pub';
    await i.deferUpdate();
    if (a === 'ptext') {
        p.title = i.fields.getTextInputValue('title').trim(); p.description = i.fields.getTextInputValue('desc').trim();
        const col = i.fields.getTextInputValue('color').trim();
        if (/^#?[0-9a-f]{6}$/i.test(col)) p.color = col.startsWith('#') ? col : '#' + col; else if (col) s.note = '⚠️ اللون غير صحيح فبقي القديم.';
        save();
    } else if (a === 'pimg') {
        const errs = [];
        for (const [k, key] of [['top', 'hub-top'], ['thumb', 'hub-thumb'], ['bottom', 'hub-bottom']]) {
            const v = i.fields.getTextInputValue(k).trim();
            if (!v) { p[k] = ''; continue; }
            if (!isUrl(v)) { errs.push(k); continue; }
            try { p[k] = await IMG.store(v, key); } catch (e) { errs.push(k + ': ' + e.message); }
        }
        save(); if (errs.length) s.note = '⚠️ تعذّر حفظ: ' + errs.join(' • ');
    }
    return i.editReply(build(i));
}
const commands = [{ name: 'setup', description: 'لوحة التحكم المركزية: كل أنظمة البوت من أمر واحد (إدارة)' }];
return { prefix: 'hb', commands, ephemeral: ['setup'], slash: { setup: slash }, component, modal: modalSubmit, _build: build, _publicMessage: publicMessage };
};
