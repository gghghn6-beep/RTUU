'use strict';
/**
 * نظام منع السبام /antispam — أمر واحد بقائمة تحكم كاملة
 *  • قناة الفحص (فخّ السبامرز): أي رسالة فيها = عقوبة فورية
 *  • سبام الرسائل (سريعة/مكررة/منشن جماعي/تكرار أحرف)
 *  • سبام البوتات • الإيموجي • الصور • المرفقات • الويب هوك
 *  • عقوبة قابلة للاختيار • استثناءات • قنوات مراقبة • قناة سجلات • آخر الحالات
 */
module.exports = (H) => {
const { D, client, BLUE, isAdmin, SERVER_ID, save, EPH, row, btn, strSel, chSel, roleSel, input, modal, embed, cut, adminOnly, update, session, onOff, chTxt } = H;
const db = H.db;
const { ButtonStyle, ChannelType, PermissionFlagsBits, EmbedBuilder } = D;

// ───── الإعدادات ─────
const RULES = {
    messages: { label: 'سبام الرسائل', emoji: '💬', desc: 'الرسائل السريعة والمتكررة والمنشن الجماعي وتكرار الأحرف.',
        fields: [
            { k: 'count', l: 'عدد الرسائل المسموح', d: 6, min: 2, max: 30 },
            { k: 'seconds', l: 'خلال كم ثانية', d: 6, min: 2, max: 60 },
            { k: 'dups', l: 'تكرار نفس الرسالة (مرات)', d: 3, min: 2, max: 10 },
            { k: 'mentions', l: 'أقصى منشنات في رسالة', d: 6, min: 2, max: 30 },
            { k: 'chars', l: 'أقصى تكرار لحرف واحد', d: 18, min: 6, max: 100 }
        ] },
    bots: { label: 'سبام البوتات', emoji: '🤖', desc: 'البوتات التي تغرق الشات أو تكرر نفسها أو تمنشن بشكل جماعي.',
        fields: [{ k: 'count', l: 'عدد الرسائل المسموح', d: 6, min: 2, max: 30 }, { k: 'seconds', l: 'خلال كم ثانية', d: 8, min: 2, max: 60 }] },
    emoji: { label: 'سبام الإيموجي', emoji: '😀', desc: 'جدران الإيموجي ورسائل الإيموجي الكثيرة.',
        fields: [{ k: 'max', l: 'أقصى عدد إيموجي في الرسالة', d: 12, min: 3, max: 100 }] },
    images: { label: 'سبام الصور', emoji: '🖼️', desc: 'الصور الكثيرة أو إعادة إرسال الصورة نفسها مراراً.',
        fields: [{ k: 'count', l: 'عدد الصور المسموح', d: 4, min: 2, max: 30 }, { k: 'seconds', l: 'خلال كم ثانية', d: 10, min: 2, max: 60 }] },
    attachments: { label: 'سبام المرفقات', emoji: '📎', desc: 'الملفات الكثيرة (فيديو وصوت وأرشيف) أو تكرار الملف نفسه.',
        fields: [{ k: 'count', l: 'عدد الملفات المسموح', d: 5, min: 2, max: 30 }, { k: 'seconds', l: 'خلال كم ثانية', d: 10, min: 2, max: 60 }] },
    webhook: { label: 'سبام الويب هوك', emoji: '🪝', desc: 'الويب هوك الذي يغرق الشات أو يكرر الرسائل (يُحذف الويب هوك).',
        fields: [{ k: 'count', l: 'عدد الرسائل المسموح', d: 5, min: 2, max: 30 }, { k: 'seconds', l: 'خلال كم ثانية', d: 8, min: 2, max: 60 }] }
};
const PUNISH = {
    delete: { label: 'حذف الرسائل فقط', emoji: '🧹' },
    timeout: { label: 'كتم مؤقت (Timeout)', emoji: '🔇' },
    kick: { label: 'طرد', emoji: '👢' },
    ban: { label: 'حظر', emoji: '🔨' }
};

function cfg() {
    const a = (db.antispam = db.antispam || {});
    a.enabled = !!a.enabled;
    a.punishment = PUNISH[a.punishment] ? a.punishment : 'timeout';
    a.timeoutMinutes = Number.isFinite(a.timeoutMinutes) ? a.timeoutMinutes : 60;
    a.logChannelId = a.logChannelId || '';
    a.monitored = Array.isArray(a.monitored) ? a.monitored : [];
    a.exempt = a.exempt || {};
    for (const k of ['roles', 'channels', 'users']) a.exempt[k] = Array.isArray(a.exempt[k]) ? a.exempt[k] : [];
    a.check = a.check || {};
    a.check.channelId = a.check.channelId || '';
    a.check.messageId = a.check.messageId || '';
    a.check.show = a.check.show !== false;
    a.check.punishment = ['timeout', 'kick', 'ban'].includes(a.check.punishment) ? a.check.punishment : 'timeout';
    a.check.timeoutMinutes = Number.isFinite(a.check.timeoutMinutes) ? a.check.timeoutMinutes : 1440;
    a.rules = a.rules || {};
    for (const [rk, r] of Object.entries(RULES)) {
        const cur = (a.rules[rk] = a.rules[rk] || {});
        cur.on = cur.on !== false;
        for (const f of r.fields) cur[f.k] = Number.isFinite(cur[f.k]) ? cur[f.k] : f.d;
    }
    a.stats = a.stats || { punished: 0 };
    a.recent = Array.isArray(a.recent) ? a.recent : [];
    return a;
}

// ───── الكشف ─────
const hist = new Map();       // key -> [{ t, id, ch, sig, img, att, fileSig }]
const cooldown = new Map();   // key -> ts
const EMO_RE = /(?:\p{Extended_Pictographic}(?:\u200d\p{Extended_Pictographic})*)|<a?:\w+:\d+>/gu;
const IMG_EXT = /\.(png|jpe?g|gif|webp|bmp|avif)(\?|$)/i;
const norm = s => String(s || '').toLowerCase().replace(/[\s\u200b-\u200f~`'".,!?\-_*|]+/g, '').slice(0, 300);

function inspect(msg, key) {
    const now = Date.now();
    let imgCount = 0, attCount = 0; const fileSigs = [];
    for (const a of msg.attachments.values()) {
        const isImg = (a.contentType || '').startsWith('image/') || IMG_EXT.test(a.name || '');
        if (isImg) imgCount++; else attCount++;
        fileSigs.push((a.name || '') + ':' + (a.size || 0));
    }
    for (const e of msg.embeds || []) { if (e.type === 'image' || e.type === 'gifv') imgCount++; }
    const rec = { t: now, id: msg.id, ch: msg.channelId, sig: norm(msg.content), img: imgCount, att: attCount, fileSigs };
    let h = hist.get(key) || [];
    h = h.filter(x => now - x.t <= 60000);
    h.push(rec);
    hist.set(key, h);
    return { rec, h, now };
}
const within = (h, now, sec) => h.filter(x => now - x.t <= sec * 1000);

function detect(msg, key, kind) {
    const c = cfg(); const R = c.rules;
    const { rec, h, now } = inspect(msg, key);
    if (kind === 'webhook') {
        const r = R.webhook; if (!r.on) return null;
        const n = within(h, now, r.seconds).length;
        return n > r.count ? { rule: 'webhook', detail: n + ' رسالة خلال ' + r.seconds + ' ثانية' } : null;
    }
    if (kind === 'bot') {
        const r = R.bots; if (!r.on) return null;
        const n = within(h, now, r.seconds).length;
        if (n > r.count) return { rule: 'bots', detail: n + ' رسالة خلال ' + r.seconds + ' ثانية' };
        const mc = msg.mentions.users.size + msg.mentions.roles.size;
        if (R.messages.on && (mc >= R.messages.mentions || msg.mentions.everyone)) return { rule: 'bots', detail: 'منشن جماعي من بوت' };
        return null;
    }
    // عضو عادي
    const m = R.messages;
    if (m.on) {
        const n = within(h, now, m.seconds).length;
        if (n > m.count) return { rule: 'messages', detail: n + ' رسائل خلال ' + m.seconds + ' ثواني' };
        if (rec.sig.length >= 3) {
            const d = within(h, now, 30).filter(x => x.sig === rec.sig).length;
            if (d >= m.dups) return { rule: 'messages', detail: 'تكرار نفس الرسالة ' + d + ' مرات' };
        }
        const mc = msg.mentions.users.size + msg.mentions.roles.size;
        if (mc >= m.mentions) return { rule: 'messages', detail: 'منشن جماعي (' + mc + ')' };
        const rep = new RegExp('(.)\\1{' + (m.chars - 1) + ',}', 'su');
        if ((msg.content || '').length >= m.chars && rep.test(msg.content)) return { rule: 'messages', detail: 'تكرار الأحرف' };
    }
    const e = R.emoji;
    if (e.on && msg.content) { const n = (msg.content.match(EMO_RE) || []).length; if (n >= e.max) return { rule: 'emoji', detail: n + ' إيموجي في رسالة واحدة' }; }
    const im = R.images;
    if (im.on && rec.img) {
        const tot = within(h, now, im.seconds).reduce((a, x) => a + x.img, 0);
        if (tot > im.count) return { rule: 'images', detail: tot + ' صور خلال ' + im.seconds + ' ثواني' };
        const same = rec.fileSigs.length ? within(h, now, 30).filter(x => x.fileSigs.some(s => rec.fileSigs.includes(s))).length : 0;
        if (same >= 3) return { rule: 'images', detail: 'نفس الصورة ' + same + ' مرات' };
    }
    const at = R.attachments;
    if (at.on && rec.att) {
        const tot = within(h, now, at.seconds).reduce((a, x) => a + x.att, 0);
        if (tot > at.count) return { rule: 'attachments', detail: tot + ' ملفات خلال ' + at.seconds + ' ثواني' };
        const same = within(h, now, 30).filter(x => x.fileSigs.some(s => rec.fileSigs.includes(s))).length;
        if (same >= 3) return { rule: 'attachments', detail: 'نفس الملف ' + same + ' مرات' };
    }
    return null;
}

// ───── التنفيذ والسجلات ─────
let warnTimer = null;
function scheduleWarnRefresh(guild) {
    clearTimeout(warnTimer);
    warnTimer = setTimeout(() => refreshWarning(guild).catch(() => {}), 20000);
}
function warningEmbed(guild) {
    const c = cfg();
    return new EmbedBuilder().setColor(BLUE)
        .setTitle('⚠️ تحذير هام')
        .setDescription('**مهما كان لا تكتب في هذا الروم**\n\nهذا الروم مخصص **لمنع السبامرز ومعاقبتهم**.\nإذا تم إرسال رسالة هنا منك **سوف يتم معاقبتك فوراً**.')
        .addFields({ name: 'مجموع المعاقبات في هذا السيرفر', value: '**' + c.stats.punished + '**' })
        .setFooter({ text: 'نظام منع السبام' });
}
async function refreshWarning(guild) {
    const c = cfg(); const ck = c.check;
    if (!ck.channelId) return;
    const ch = await H.getTextChannel(guild, ck.channelId);
    if (!ch) return;
    let m = null;
    if (ck.messageId) m = await ch.messages.fetch(ck.messageId).catch(() => null);
    if (!ck.show) { if (m) await m.delete().catch(() => {}); ck.messageId = ''; save(); return; }
    if (m) await m.edit({ embeds: [warningEmbed(guild)] }).catch(() => {});
    else { const sent = await ch.send({ embeds: [warningEmbed(guild)] }).catch(() => null); ck.messageId = sent ? sent.id : ''; save(); }
}
async function sendLog(guild, e) {
    const c = cfg();
    const ch = await H.getTextChannel(guild, c.logChannelId);
    if (ch) await ch.send({ embeds: [e], allowedMentions: { parse: [] } }).catch(() => {});
}
function pushRecent(rec) { const c = cfg(); c.recent.unshift(rec); c.recent.length = Math.min(c.recent.length, 40); c.stats.punished++; save(); }

async function deleteRecent(guild, key, onlyChannel) {
    const h = hist.get(key) || [];
    const byCh = new Map();
    for (const x of h) { if (onlyChannel && x.ch !== onlyChannel) continue; if (!byCh.has(x.ch)) byCh.set(x.ch, []); byCh.get(x.ch).push(x.id); }
    for (const [chId, ids] of byCh) {
        const ch = guild.channels.cache.get(chId); if (!ch || !ch.bulkDelete) continue;
        await ch.bulkDelete(ids, true).catch(async () => { for (const id of ids) await ch.messages.delete(id).catch(() => {}); });
    }
    hist.delete(key);
}
async function applyPunishment(guild, user, member, action, minutes, reason) {
    try {
        if (action === 'timeout') { if (!member) return '⚠️ العضو غير موجود'; await member.timeout(Math.min(minutes, 40320) * 60000, reason); return '✅ كتم ' + minutes + ' دقيقة'; }
        if (action === 'kick') { if (!member) return '⚠️ العضو غير موجود'; await member.kick(reason); return '✅ طرد'; }
        if (action === 'ban') { await guild.members.ban(user.id, { reason, deleteMessageSeconds: 3600 }); return '✅ حظر'; }
        return '✅ حذف الرسائل';
    } catch (e) { return '❌ تعذّر التنفيذ: ' + cut(e.message, 100) + ' (تأكد أن رتبة البوت أعلى وعنده الصلاحية)'; }
}

async function handleHit(msg, key, hit, kind) {
    const c = cfg(); const guild = msg.guild; const user = msg.author;
    const last = cooldown.get(key) || 0;
    if (Date.now() - last < 8000) { await deleteRecent(guild, key, msg.channelId).catch(() => {}); return true; }
    cooldown.set(key, Date.now());
    const rule = RULES[hit.rule];
    await deleteRecent(guild, key);
    await msg.delete().catch(() => {});
    let resultTxt = '✅ حذف الرسائل';
    if (kind === 'webhook') {
        try {
            const whs = await msg.channel.fetchWebhooks();
            const wh = whs.get(msg.webhookId);
            if (wh) { await wh.delete('سبام ويب هوك'); resultTxt = '✅ حذف الويب هوك + الرسائل'; }
        } catch { resultTxt = '⚠️ حُذفت الرسائل (تعذّر حذف الويب هوك: يحتاج صلاحية Manage Webhooks)'; }
    } else {
        const member = msg.member || await guild.members.fetch(user.id).catch(() => null);
        const action = kind === 'bot' ? (c.punishment === 'delete' ? 'delete' : 'timeout') : c.punishment;
        resultTxt = await applyPunishment(guild, user, member, action, c.timeoutMinutes, 'منع السبام: ' + rule.label);
    }
    pushRecent({ t: Date.now(), userId: user.id, rule: hit.rule, detail: hit.detail, result: resultTxt, channelId: msg.channelId, kind });
    await sendLog(guild, new EmbedBuilder().setColor(BLUE).setTitle('🛡️ تم كشف سبام')
        .addFields(
            { name: 'العضو', value: '<@' + user.id + '> (`' + user.id + '`)', inline: true },
            { name: 'النوع', value: rule.emoji + ' ' + rule.label, inline: true },
            { name: 'الروم', value: '<#' + msg.channelId + '>', inline: true },
            { name: 'التفاصيل', value: hit.detail },
            { name: 'الإجراء', value: resultTxt }
        ).setTimestamp());
    scheduleWarnRefresh(guild);
    return true;
}

async function handleHoneypot(msg) {
    const c = cfg(); const guild = msg.guild; const user = msg.author; const key = 'hp:' + user.id;
    if (Date.now() - (cooldown.get(key) || 0) < 8000) { await msg.delete().catch(() => {}); return true; }
    cooldown.set(key, Date.now());
    await msg.delete().catch(() => {});
    let resultTxt;
    if (msg.webhookId) {
        try { const whs = await msg.channel.fetchWebhooks(); const wh = whs.get(msg.webhookId); if (wh) await wh.delete('قناة فحص السبام'); resultTxt = '✅ حذف الويب هوك'; }
        catch { resultTxt = '⚠️ تعذّر حذف الويب هوك'; }
    } else {
        const member = msg.member || await guild.members.fetch(user.id).catch(() => null);
        resultTxt = await applyPunishment(guild, user, member, c.check.punishment, c.check.timeoutMinutes, 'كتب في قناة فحص السبام');
    }
    pushRecent({ t: Date.now(), userId: user.id, rule: 'check', detail: 'كتب في قناة الفحص', result: resultTxt, channelId: msg.channelId, kind: 'check' });
    await sendLog(guild, new EmbedBuilder().setColor(BLUE).setTitle('🪤 عضو وقع في قناة الفحص')
        .addFields(
            { name: 'العضو', value: '<@' + user.id + '> (`' + user.id + '`)', inline: true },
            { name: 'الإجراء', value: resultTxt, inline: true },
            { name: 'الرسالة', value: cut(msg.content || '*(مرفق/بدون نص)*', 400) }
        ).setTimestamp());
    scheduleWarnRefresh(guild);
    return true;
}

function isExempt(msg, member) {
    const c = cfg(); const ex = c.exempt;
    if (msg.author.id === client.user.id) return true;
    if (ex.users.includes(msg.author.id)) return true;
    if (msg.webhookId && ex.users.includes(msg.webhookId)) return true;
    if (member) {
        if (isAdmin(member)) return true;
        if (member.permissions && member.permissions.has(PermissionFlagsBits.Administrator)) return true;
        if (member.roles && member.roles.cache.some(r => ex.roles.includes(r.id))) return true;
    }
    const ch = msg.channel;
    if (ex.channels.includes(msg.channelId) || (ch && ch.parentId && ex.channels.includes(ch.parentId))) return true;
    return false;
}

async function onRawMessage(msg) {
    if (!msg.guild || msg.guild.id !== SERVER_ID || msg.system) return false;
    const c = cfg();
    if (!c.enabled) return false;
    const member = msg.member;
    if (isExempt(msg, member)) return false;
    // قناة الفحص
    if (c.check.channelId && msg.channelId === c.check.channelId) return handleHoneypot(msg);
    // القنوات المراقبة (فاضي = كل القنوات)
    if (c.monitored.length) {
        const ch = msg.channel;
        if (!c.monitored.includes(msg.channelId) && !(ch && ch.parentId && c.monitored.includes(ch.parentId))) return false;
    }
    const kind = msg.webhookId ? 'webhook' : (msg.author.bot ? 'bot' : 'user');
    const key = kind === 'webhook' ? 'wh:' + msg.webhookId : msg.author.id;
    const hit = detect(msg, key, kind);
    if (!hit) return false;
    return handleHit(msg, key, hit, kind);
}

// ───── الواجهة ─────
const PAGES = [
    { v: 'home', l: 'عام', e: '⚙️', d: 'التفعيل والعقوبة وقناة السجلات' },
    ...Object.entries(RULES).map(([k, r]) => ({ v: k, l: r.label, e: r.emoji, d: r.desc.slice(0, 90) })),
    { v: 'check', l: 'قناة الفحص', e: '🪤', d: 'فخّ السبامرز: أي رسالة فيها = عقوبة' },
    { v: 'monitor', l: 'القنوات المراقبة', e: '👁️', d: 'فاضي = كل القنوات' },
    { v: 'exempt', l: 'الاستثناءات', e: '🔕', d: 'رتب وقنوات وبوتات مستثناة' },
    { v: 'logs', l: 'آخر الحالات', e: '📋', d: 'آخر حالات الكشف' }
];
const st = i => session(i, 'as', () => ({ page: 'home' }));
const navRow = cur => row(strSel('as:nav', 'اختر القسم...', PAGES.map(p => ({ label: p.l, value: p.v, emoji: p.e, description: p.d, default: p.v === cur }))));
const idList = (arr, fmt) => (arr.length ? arr.map(fmt).join(' ') : '`—`');

function view(s) {
    const c = cfg(); const page = s.page;
    const e = embed().setTitle('🛡️ نظام منع السبام');
    const comps = [navRow(page)];
    if (page === 'home') {
        e.setDescription('حماية السيرفر من السبام: الرسائل السريعة والمكررة، الإيموجي، الصور، المرفقات، البوتات، والويب هوك، مع **قناة فحص** تصطاد السبامرز.\nاختر قسماً من القائمة للتفصيل.')
            .addFields(
                { name: 'الحالة', value: onOff(c.enabled), inline: true },
                { name: 'العقوبة', value: PUNISH[c.punishment].emoji + ' ' + PUNISH[c.punishment].label + (c.punishment === 'timeout' ? ' (' + c.timeoutMinutes + ' د)' : ''), inline: true },
                { name: 'قناة السجلات', value: chTxt(c.logChannelId), inline: true },
                { name: 'قناة الفحص', value: chTxt(c.check.channelId), inline: true },
                { name: 'القنوات المراقبة', value: c.monitored.length ? c.monitored.length + ' قناة' : 'كل القنوات', inline: true },
                { name: 'مجموع المعاقبات', value: '**' + c.stats.punished + '**', inline: true },
                { name: 'الحمايات', value: Object.entries(RULES).map(([k, r]) => (c.rules[k].on ? '✅' : '⛔') + ' ' + r.label).join('\n') }
            );
        comps.push(row(strSel('as:pun', 'العقوبة عند كشف السبام', Object.entries(PUNISH).map(([k, p]) => ({ label: p.label, value: k, emoji: p.emoji, default: k === c.punishment })))));
        comps.push(row(chSel('as:log', 'قناة سجلات السبام (اختياري)', { min: 0, selected: c.logChannelId ? [c.logChannelId] : [] })));
        comps.push(row(btn('as:toggle', c.enabled ? 'إيقاف النظام' : 'تفعيل النظام', c.enabled ? '⛔' : '✅', c.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
            btn('as:tmo', 'مدة الكتم', '⏱️'), btn('as:reset', 'إعادة الضبط', '🔄', ButtonStyle.Secondary)));
    } else if (RULES[page]) {
        const r = RULES[page]; const cur = c.rules[page];
        e.setTitle(r.emoji + ' ' + r.label).setDescription(r.desc + '\n\nالحالة: ' + onOff(cur.on))
            .addFields(...r.fields.map(f => ({ name: f.l, value: '**' + cur[f.k] + '**', inline: true })));
        comps.push(row(btn('as:rtoggle', cur.on ? 'إيقاف هذه الحماية' : 'تفعيل هذه الحماية', cur.on ? '⛔' : '✅', cur.on ? ButtonStyle.Danger : ButtonStyle.Success), btn('as:redit', 'تعديل الأرقام', '✏️', ButtonStyle.Primary), btn('as:home', 'رجوع', '↩️')));
    } else if (page === 'check') {
        const ck = c.check;
        e.setTitle('🪤 قناة الفحص').setDescription('روم فخّ: أي رسالة تُكتب فيه تُحذف ويُعاقب صاحبها فوراً (مفيد ضد الحسابات المخترقة والبوتات السبام). يظهر فيه تحذير واضح للأعضاء. **الإدارة مستثناة.**')
            .addFields(
                { name: 'الروم', value: chTxt(ck.channelId), inline: true },
                { name: 'رسالة التحذير', value: ck.show ? '👁️ ظاهرة' : '🙈 مخفية', inline: true },
                { name: 'عقوبة الواقعين', value: PUNISH[ck.punishment].emoji + ' ' + PUNISH[ck.punishment].label + (ck.punishment === 'timeout' ? ' (' + ck.timeoutMinutes + ' د)' : ''), inline: true }
            );
        comps.push(row(chSel('as:chk', ck.channelId ? 'غيّر روم الفحص...' : 'اختر روم الفحص...', { min: 1, selected: ck.channelId ? [ck.channelId] : [] })));
        comps.push(row(strSel('as:cpun', 'عقوبة من يكتب في روم الفحص', ['timeout', 'kick', 'ban'].map(k => ({ label: PUNISH[k].label, value: k, emoji: PUNISH[k].emoji, default: k === ck.punishment })))));
        comps.push(row(btn('as:cshow', ck.show ? 'إخفاء التحذير' : 'إظهار التحذير', '👁️'), btn('as:cfix', 'إصلاح الصلاحيات', '🔧', ButtonStyle.Primary, !ck.channelId), btn('as:ctmo', 'مدة الكتم', '⏱️'), btn('as:crm', 'إزالة الروم', '🗑️', ButtonStyle.Danger, !ck.channelId)));
    } else if (page === 'monitor') {
        e.setTitle('👁️ القنوات المراقبة').setDescription('حدد القنوات التي تُطبَّق فيها الحمايات. **اتركها فاضية لمراقبة كل القنوات.** يمكن اختيار تصنيف كامل.')
            .addFields({ name: 'القنوات الحالية', value: idList(c.monitored, id => '<#' + id + '>') });
        comps.push(row(chSel('as:mon', 'اختر القنوات (حتى 25)...', { min: 0, max: 25, types: [ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildCategory, ChannelType.GuildVoice], selected: c.monitored.slice(0, 25) })));
        comps.push(row(btn('as:monclear', 'مراقبة كل القنوات', '🧹', ButtonStyle.Secondary, !c.monitored.length), btn('as:home', 'رجوع', '↩️')));
    } else if (page === 'exempt') {
        const ex = c.exempt;
        e.setTitle('🔕 الاستثناءات').setDescription('الرتب والقنوات والبوتات/الويب هوك المستثناة من كل الحمايات. الإدارة العليا وحاملو Administrator مستثنون تلقائياً.')
            .addFields(
                { name: 'رتب', value: idList(ex.roles, id => '<@&' + id + '>') },
                { name: 'قنوات / تصنيفات', value: idList(ex.channels, id => '<#' + id + '>') },
                { name: 'بوتات / مستخدمون', value: idList(ex.users, id => '<@' + id + '>') }
            );
        const um = new D.UserSelectMenuBuilder().setCustomId('as:exu').setPlaceholder('بوتات/مستخدمون مستثنون (حتى 10)').setMinValues(0).setMaxValues(10);
        try { if (ex.users.length) um.setDefaultUsers(ex.users.slice(0, 10)); } catch {}
        comps.push(row(roleSel('as:exr', 'رتب مستثناة (حتى 10)', { min: 0, max: 10, selected: ex.roles.slice(0, 10) })));
        comps.push(row(chSel('as:exc', 'قنوات/تصنيفات مستثناة (حتى 10)', { min: 0, max: 10, types: [ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildCategory, ChannelType.GuildVoice], selected: ex.channels.slice(0, 10) })));
        comps.push(row(um));
    } else if (page === 'logs') {
        e.setTitle('📋 آخر حالات الكشف');
        const list = c.recent.slice(0, 10).map(r => {
            const rl = r.rule === 'check' ? '🪤 قناة الفحص' : (RULES[r.rule] ? RULES[r.rule].emoji + ' ' + RULES[r.rule].label : r.rule);
            return '<t:' + Math.floor(r.t / 1000) + ':R> • <@' + r.userId + '> • **' + rl + '**\n> ' + cut(r.detail, 80) + ' — ' + cut(r.result, 60);
        });
        e.setDescription(list.length ? list.join('\n\n') : 'لا توجد حالات مسجلة بعد.').setFooter({ text: 'المجموع: ' + c.stats.punished + ' معاقبة' });
        comps.push(row(btn('as:home', 'رجوع', '↩️')));
    }
    return { embeds: [e], components: comps };
}

async function slash(i) {
    if (!(await adminOnly(i))) return;
    const s = st(i); s.page = 'home';
    return i.reply({ ...view(s), flags: EPH });
}

async function fixCheckChannel(guild) {
    const ck = cfg().check;
    const ch = await H.getTextChannel(guild, ck.channelId);
    if (!ch) return '❌ الروم غير موجود';
    try {
        await ch.permissionOverwrites.edit(guild.roles.everyone, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true, EmbedLinks: true });
        await ch.permissionOverwrites.edit(client.user.id, { ViewChannel: true, SendMessages: true, ManageMessages: true, EmbedLinks: true, ReadMessageHistory: true });
        await ch.setRateLimitPerUser(0).catch(() => {});
        return '✅ تم ضبط صلاحيات روم الفحص (الكل يشوف ويكتب، والبوت يدير الرسائل)';
    } catch (e) { return '❌ ' + cut(e.message, 120) + ' — تأكد أن البوت عنده Manage Channels'; }
}

async function component(i) {
    if (!(await adminOnly(i))) return;
    const s = st(i); const c = cfg();
    const a = i.customId.split(':')[1]; const vals = i.values || [];
    const go = page => { s.page = page; return update(i, view(s)); };
    const redraw = () => update(i, view(s));

    // نوافذ (قبل أي رد)
    if (a === 'redit' && RULES[s.page]) {
        const r = RULES[s.page]; const cur = c.rules[s.page];
        return i.showModal(modal('asm:rule', 'تعديل: ' + r.label, ...r.fields.map(f => input(f.k, f.l + ' (' + f.min + '-' + f.max + ')', { required: true, max: 4, value: String(cur[f.k]) }))));
    }
    if (a === 'tmo') return i.showModal(modal('asm:tmo', 'مدة الكتم', input('min', 'بالدقائق (1 - 40320)', { required: true, max: 5, value: String(c.timeoutMinutes) })));
    if (a === 'ctmo') return i.showModal(modal('asm:ctmo', 'مدة كتم قناة الفحص', input('min', 'بالدقائق (1 - 40320)', { required: true, max: 5, value: String(c.check.timeoutMinutes) })));

    if (a === 'nav') return go(vals[0]);
    if (a === 'home') return go('home');
    if (a === 'toggle') { c.enabled = !c.enabled; save(); return redraw(); }
    if (a === 'pun') { c.punishment = PUNISH[vals[0]] ? vals[0] : 'timeout'; save(); return redraw(); }
    if (a === 'log') { c.logChannelId = vals[0] || ''; save(); return redraw(); }
    if (a === 'reset') { const keep = { check: c.check, logChannelId: c.logChannelId, stats: c.stats, recent: c.recent }; db.antispam = { ...keep }; save(); return redraw(); }
    if (a === 'rtoggle' && RULES[s.page]) { c.rules[s.page].on = !c.rules[s.page].on; save(); return redraw(); }
    if (a === 'mon') { c.monitored = [...vals]; save(); return redraw(); }
    if (a === 'monclear') { c.monitored = []; save(); return redraw(); }
    if (a === 'exr') { c.exempt.roles = [...vals]; save(); return redraw(); }
    if (a === 'exc') { c.exempt.channels = [...vals]; save(); return redraw(); }
    if (a === 'exu') { c.exempt.users = [...vals]; save(); return redraw(); }
    if (a === 'cpun') { c.check.punishment = ['timeout', 'kick', 'ban'].includes(vals[0]) ? vals[0] : 'timeout'; save(); return redraw(); }
    if (a === 'chk') {
        await i.deferUpdate();
        const old = await H.getTextChannel(i.guild, c.check.channelId);
        if (old && c.check.messageId) { const m = await old.messages.fetch(c.check.messageId).catch(() => null); if (m) await m.delete().catch(() => {}); }
        c.check.channelId = vals[0]; c.check.messageId = ''; save();
        const note = await fixCheckChannel(i.guild);
        await refreshWarning(i.guild).catch(() => {});
        await i.editReply(view(s));
        return i.followUp({ content: note, flags: EPH });
    }
    if (a === 'cshow') { await i.deferUpdate(); c.check.show = !c.check.show; save(); await refreshWarning(i.guild).catch(() => {}); return i.editReply(view(s)); }
    if (a === 'cfix') { await i.deferUpdate(); const note = await fixCheckChannel(i.guild); await refreshWarning(i.guild).catch(() => {}); await i.editReply(view(s)); return i.followUp({ content: note, flags: EPH }); }
    if (a === 'crm') {
        await i.deferUpdate();
        const ch = await H.getTextChannel(i.guild, c.check.channelId);
        if (ch && c.check.messageId) { const m = await ch.messages.fetch(c.check.messageId).catch(() => null); if (m) await m.delete().catch(() => {}); }
        c.check.channelId = ''; c.check.messageId = ''; save();
        return i.editReply(view(s));
    }
}

async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const s = st(i); const c = cfg();
    const a = i.customId.split(':')[1];
    const bad = m => i.reply({ content: '❌ ' + m, flags: EPH });
    const done = () => (i.isFromMessage && i.isFromMessage() ? update(i, view(s)) : i.reply({ content: '✅ تم الحفظ.', flags: EPH }));
    if (a === 'rule') {
        const r = RULES[s.page]; if (!r) return bad('انتهت الجلسة، افتح /antispam من جديد.');
        const next = {};
        for (const f of r.fields) {
            const n = parseInt(i.fields.getTextInputValue(f.k), 10);
            if (!Number.isFinite(n) || n < f.min || n > f.max) return bad(f.l + ': اكتب رقماً من ' + f.min + ' إلى ' + f.max);
            next[f.k] = n;
        }
        Object.assign(c.rules[s.page], next); save(); return done();
    }
    if (a === 'tmo' || a === 'ctmo') {
        const n = parseInt(i.fields.getTextInputValue('min'), 10);
        if (!Number.isFinite(n) || n < 1 || n > 40320) return bad('اكتب رقماً من 1 إلى 40320 دقيقة (حد ديسكورد 28 يوماً).');
        if (a === 'tmo') c.timeoutMinutes = n; else c.check.timeoutMinutes = n;
        save(); return done();
    }
}

const commands = [{ name: 'antispam', description: 'نظام منع السبام: الحمايات وقناة الفحص والعقوبات والسجلات (إدارة)' }];
return { prefix: 'as', commands, ephemeral: ['antispam'], slash: { antispam: slash }, component, modal: modalSubmit, onRawMessage };
};
