'use strict';
/**
 * قائمة التذاكر /tickets — كل إعدادات التذاكر من قائمة واحدة (بدون أوامر سلاش كثيرة)
 * اللوحات (حتى 10) • الأقسام • التصنيفات • الإعدادات العامة • الإدارة العليا • الصلاحيات
 */
module.exports = (H) => {
const { D, EPH, row, btn, strSel, chSel, roleSel, input, modal, embed, cut, adminOnly, update, isUrl, session, chTxt, roleTxt } = H;
const { ButtonStyle, ChannelType } = D;
const T = () => H.tk;
const MAX_PANELS = 10;
const MAX_DEPTS = 25;

// ───── البيانات ─────
function conf() {
    const c = H.getConfig();
    c.ticket = c.ticket || {};
    c.ticket.panel = c.ticket.panel || {};
    c.ticketSystems = c.ticketSystems || [];
    c.departments = c.departments || [];
    c.roles = c.roles || {};
    c.moderation = c.moderation || {};
    return c;
}
const persist = () => T().saveConfig();
const panels = () => [{ id: 'main', name: 'اللوحة الرئيسية' }, ...conf().ticketSystems];
const pd = id => (id === 'main' ? conf().ticket.panel : conf().ticketSystems.find(s => s.id === id));
const pname = id => (id === 'main' ? 'اللوحة الرئيسية' : (pd(id) || {}).name || '—');
const pRef = id => (id === 'main' ? conf().ticket.panelRef : (pd(id) || {}).panelRef);
const setRef = (id, ref) => { if (id === 'main') conf().ticket.panelRef = ref; else if (pd(id)) pd(id).panelRef = ref; };
const deptsOf = id => conf().departments.filter(d => T().deptSystemId(d) === id);
function cats(id) {
    const c = conf(); const o = id === 'main' ? c.ticket : pd(id) || {};
    return { open: o.openCategoryId || '', closed: o.closedCategoryId || '' };
}
function setCat(id, which, val) {
    const o = id === 'main' ? conf().ticket : pd(id);
    if (o) o[which === 'open' ? 'openCategoryId' : 'closedCategoryId'] = val;
}
const st = i => session(i, 'tk', () => ({ view: 'home', panel: 'main', dept: null, confirm: null }));
const ok = (v, y = '✅ محدد', n = '`—`') => (v ? y : n);
const normColor = c => { let x = String(c || '').trim(); if (!x) return ''; if (!x.startsWith('#')) x = '#' + x; return /^#[0-9a-f]{6}$/i.test(x) ? x.toUpperCase() : null; };
const emojiTxt = d => d.emoji || '📋';
const fixPanel = s => { if (!pd(s.panel)) s.panel = 'main'; };
const refreshPanels = async i => { try { await T().refreshTicketPanel(i.guild); } catch {} };
// ───── الصور (تُحمَّل وتُحفظ محلياً حتى لا تنتهي صلاحية الرابط) ─────
const KEEP = '(محفوظة — اتركها كما هي)';
const imgShow = v => (!v ? '' : (String(v).startsWith('local:') ? KEEP : String(v)));
const hasImg = v => (v ? '✅ محددة' : '`—`');
/** يرجع القيمة الجديدة للإعداد: فاضي أو - = حذف • KEEP = بدون تغيير • رابط = تنزيل وحفظ */
async function applyImg(old, raw, key) {
    raw = String(raw || '').trim();
    if (raw === KEEP) return old || '';
    if (!raw || raw === '-') { if (old) H.IMG.remove(old); return ''; }
    const nv = await H.IMG.store(raw, key);
    if (old && old !== nv) H.IMG.remove(old);
    return nv;
}

// ───── الواجهات ─────
function homeView() {
    const ps = panels();
    const e = embed().setTitle('🎫 قائمة التذاكر')
        .setDescription('اختر لوحة من القائمة لإدارتها، أو أنشئ لوحة جديدة.\nكل لوحة لها أقسامها ونصوصها وصورها وتصنيفاتها.')
        .addFields({ name: 'اللوحات (' + ps.length + '/' + MAX_PANELS + ')', value: cut(ps.map((p, n) => `**${n + 1}.** ${p.name} · ${deptsOf(p.id).length} قسم · ${pRef(p.id) ? '<#' + pRef(p.id).channelId + '>' : '`غير منشورة`'}`).join('\n'), 1024) });
    return {
        embeds: [e],
        components: [
            row(strSel('tk:pick', 'اختر لوحة لإدارتها...', ps.map((p, n) => ({ label: (n + 1) + '. ' + p.name, value: p.id, emoji: '🎫', description: deptsOf(p.id).length + ' قسم' })))),
            row(btn('tk:newpanel', 'لوحة جديدة', '➕', ButtonStyle.Success, ps.length >= MAX_PANELS),
                btn('tk:general', 'الإعدادات العامة', '⚙️'),
                btn('tk:admins', 'الإدارة العليا', '👑'),
                btn('tk:perms', 'الصلاحيات', '🔐'),
                btn('tk:emojis', 'الإيموجيات', '😀'))
        ]
    };
}

function panelView(id) {
    const p = pd(id) || {}; const ref = pRef(id); const ds = deptsOf(id); const ct = cats(id);
    const e = embed().setTitle('🎫 ' + pname(id))
        .addFields(
            { name: 'العنوان', value: p.title ? cut(p.title, 100) : '`—`', inline: true },
            { name: 'الوصف', value: p.description ? cut(p.description, 100) : '`—`', inline: true },
            { name: 'اللون', value: p.color || '`افتراضي`', inline: true },
            { name: '🖼️ الصورة العلوية', value: hasImg(p.banner), inline: true },
            { name: '🖼️ الصورة السفلية', value: hasImg(p.bottomImage), inline: true },
            { name: '🔹 الصورة الصغيرة', value: hasImg(p.thumb), inline: true },
            { name: 'القوانين / الخطوات', value: ok(p.rules, '📜', '`—`') + ' / ' + ok(p.steps, '📌', '`—`'), inline: true },
            { name: '📂 التصنيفات', value: `المفتوحة: ${chTxt(ct.open)}\nالمغلقة: ${chTxt(ct.closed)}` },
            { name: '📍 اللوحة المنشورة', value: ref ? '<#' + ref.channelId + '>' : '`لم تُنشر بعد — اختر روم من القائمة بالأسفل`' },
            { name: 'الأقسام (' + ds.length + '/' + MAX_DEPTS + ')', value: cut(ds.map(d => `${emojiTxt(d)} **${d.name}**${d.roleId ? ' · <@&' + d.roleId + '>' : ''}`).join('\n') || '`لا توجد أقسام — اضغط ➕ قسم جديد`', 1024) }
        );
    const comps = [
        row(btn('tk:ptext', 'النص', '✏️', ButtonStyle.Primary), btn('tk:plook', 'المظهر', '🎨'), btn('tk:prules', 'القوانين والخطوات', '📜'), btn('tk:pcats', 'التصنيفات', '📂'))
    ];
    if (ds.length) comps.push(row(strSel('tk:dept', 'اختر قسماً لإدارته...', ds.map(d => ({ label: d.name, value: d.id, emoji: d.emoji || '📋', description: d.description || '' })))));
    comps.push(row(chSel('tk:send', ref ? 'انقل اللوحة لروم آخر...' : 'اختر الروم لنشر اللوحة فيه...')));
    comps.push(row(btn('tk:newdept', 'قسم جديد', '➕', ButtonStyle.Success, ds.length >= MAX_DEPTS), btn('tk:prefresh', 'تحديث اللوحة', '🔄', ButtonStyle.Secondary, !ref), btn('tk:pdel', 'حذف اللوحة', '🗑️', ButtonStyle.Danger, id === 'main'), btn('tk:home', 'رجوع', '↩️')));
    return { embeds: [e], components: comps };
}

function catsView(id) {
    const ct = cats(id);
    const e = embed().setTitle('📂 تصنيفات: ' + pname(id))
        .setDescription('التذكرة تُفتح داخل **التصنيف المفتوح** وتنتقل إلى **المغلق** عند الإغلاق.\nتقدر تخصص تصنيف لكل قسم من صفحة القسم نفسه.')
        .addFields({ name: 'المفتوح', value: chTxt(ct.open), inline: true }, { name: 'المغلق', value: chTxt(ct.closed), inline: true });
    const types = [ChannelType.GuildCategory];
    return { embeds: [e], components: [
        row(chSel('tk:poc', 'التصنيف المفتوح', { types, selected: ct.open ? [ct.open] : [] })),
        row(chSel('tk:pcc', 'التصنيف المغلق', { types, selected: ct.closed ? [ct.closed] : [] })),
        row(btn('tk:panel', 'رجوع', '↩️'))
    ] };
}

const findDept = s => conf().departments.find(d => d.id === s.dept);
function deptView(s) {
    const d = findDept(s);
    if (!d) return panelView(s.panel);
    const e = embed().setTitle(emojiTxt(d) + ' ' + d.name)
        .setDescription('رتبة القسم والإدارة العليا فقط هم اللي يشوفون تذاكر هذا القسم.')
        .addFields(
            { name: 'الوصف', value: d.description ? cut(d.description, 200) : '`—`' },
            { name: 'الرتبة', value: roleTxt(d.roleId), inline: true },
            { name: 'اللوحة', value: pname(T().deptSystemId(d)), inline: true },
            { name: 'التصنيف المفتوح', value: d.openCategoryId ? chTxt(d.openCategoryId) : '`من اللوحة`', inline: true },
            { name: 'التصنيف المغلق', value: d.closedCategoryId ? chTxt(d.closedCategoryId) : '`من اللوحة`', inline: true }
        );
    const types = [ChannelType.GuildCategory];
    return { embeds: [e], components: [
        row(btn('tk:dedit', 'البيانات', '✏️', ButtonStyle.Primary), btn('tk:drm', 'مسح الرتبة', '🧹', ButtonStyle.Secondary, !d.roleId), btn('tk:dcl', 'مسح التصنيفات', '📂', ButtonStyle.Secondary, !d.openCategoryId && !d.closedCategoryId), btn('tk:ddel', 'حذف', '🗑️', ButtonStyle.Danger), btn('tk:panel', 'رجوع', '↩️')),
        row(roleSel('tk:drole', 'رتبة القسم (تشوف تذاكره)', { selected: d.roleId ? [d.roleId] : [] })),
        row(chSel('tk:doc', 'تصنيف التذاكر المفتوحة لهذا القسم', { types, selected: d.openCategoryId ? [d.openCategoryId] : [] })),
        row(chSel('tk:dcc', 'تصنيف التذاكر المغلقة لهذا القسم', { types, selected: d.closedCategoryId ? [d.closedCategoryId] : [] }))
    ] };
}

function generalView() {
    const c = conf(); const t = c.ticket;
    const voice = Array.isArray(c.moderation.supportVoiceChannelIds) ? c.moderation.supportVoiceChannelIds : [];
    const e = embed().setTitle('⚙️ الإعدادات العامة للتذاكر')
        .addFields(
            { name: '📝 لوق التذاكر', value: chTxt(t.logsChannelId), inline: true },
            { name: '⭐ روم التقييمات', value: chTxt(t.ratingChannelId), inline: true },
            { name: '🔊 رومات الدعم الصوتي', value: voice.length ? voice.map(v => '<#' + v + '>').join(' ') : '`غير محدد`', inline: true },
            { name: '🔢 الحد لكل عضو', value: t.maxTickets > 0 ? String(t.maxTickets) : 'بلا حد', inline: true },
            { name: '❓ طلب السبب عند الفتح', value: t.requireReason ? '✅ نعم' : '⛔ لا', inline: true },
            { name: '🏷️ اسم التذكرة', value: '`' + (t.ticketNameFormat || '{number}-🎫') + '`', inline: true },
            { name: '🖼️ صور داخل التذكرة', value: 'علوية: ' + hasImg((t.embed || {}).topImage) + '  •  سفلية: ' + hasImg((t.embed || {}).image) },
            { name: '🧾 رسالة الترحيب', value: cut(t.welcome || '`—`', 300) }
        );
    return { embeds: [e], components: [
        row(btn('tk:welcome', 'الترحيب والاسم', '🧾', ButtonStyle.Primary), btn('tk:tlook', 'مظهر التذكرة', '🎨'), btn('tk:max', 'الحد', '🔢'), btn('tk:reason', t.requireReason ? 'السبب: يطلب' : 'السبب: لا يطلب', t.requireReason ? '✅' : '⛔'), btn('tk:home', 'رجوع', '↩️')),
        row(chSel('tk:logs', 'لوق التذاكر', { selected: t.logsChannelId ? [t.logsChannelId] : [] })),
        row(chSel('tk:rating', 'روم تقييمات الإداريين', { selected: t.ratingChannelId ? [t.ratingChannelId] : [] })),
        row(chSel('tk:svoice', 'رومات الدعم الصوتي (اختياري)', { types: [ChannelType.GuildVoice, ChannelType.GuildStageVoice], min: 0, max: 10, selected: voice.slice(0, 10) }))
    ] };
}

function adminsView() {
    const ids = T().adminRoleIds();
    const e = embed().setTitle('👑 الإدارة العليا')
        .setDescription('هذي الرتب لها **كل الصلاحيات** داخل البوت وتشوف كل التذاكر.\nأي رتبة ثانية تحدد صلاحياتها من زر **🔐 الصلاحيات** في القائمة الرئيسية.')
        .addFields({ name: 'الرتب الحالية', value: ids.length ? ids.map(r => '<@&' + r + '>').join(' ') : '`لا توجد — فقط أصحاب صلاحية Administrator`' });
    return { embeds: [e], components: [
        row(roleSel('tk:adminsel', 'اختر رتب الإدارة العليا (حتى 10)', { min: 0, max: 10, selected: ids.slice(0, 10) })),
        row(btn('tk:home', 'رجوع', '↩️'))
    ] };
}

function emojisView() {
    const list = T().emojis();
    const guild = H.client.guilds.cache.get(H.SERVER_ID);
    const srv = guild ? [...guild.emojis.cache.values()].slice(0, 25) : [];
    const e = embed().setTitle('😀 إيموجيات التذاكر')
        .setDescription('غيّر إيموجي أي زر أو خيار في التذاكر لإيموجي خاص بسيرفرك.\n**الطريقة:** اختر العنصر من القائمة، ثم اكتب اسم الإيموجي (مثل `ark`) أو الصقه. فاضي = الأصلي.\n\nوتقدر تستخدم إيموجيات السيرفر داخل أي نص (الترحيب، نصوص اللوحات) بكتابة `:الاسم:`.')
        .addFields({ name: 'الحالي', value: cut(list.map(x => `${T().tEmo(x.key)} ${x.label}`).join('\n'), 1024) });
    if (srv.length) e.addFields({ name: 'إيموجيات السيرفر', value: cut(srv.map(x => `${x} \`${x.name}\``).join('  '), 1024) });
    return { embeds: [e], components: [
        row(strSel('tk:emosel', 'اختر العنصر لتغيير إيموجيه...', list.map(x => ({ label: x.label, value: x.key, emoji: T().tEmo(x.key) })))),
        row(btn('tk:emoreset', 'إرجاع الكل للأصلي', '🔄', ButtonStyle.Danger), btn('tk:home', 'رجوع', '↩️'))
    ] };
}

function confirmView(s) {
    const what = s.confirm === 'panel' ? `اللوحة **${pname(s.panel)}** مع كل أقسامها ورسالتها المنشورة` : `القسم **${(findDept(s) || {}).name || ''}**`;
    return { embeds: [embed().setTitle('⚠️ تأكيد الحذف').setDescription('هل تريد حذف ' + what + '؟\nما يمكن التراجع عن هذا.')], components: [
        row(btn('tk:yes', 'نعم، احذف', '🗑️', ButtonStyle.Danger), btn('tk:no', 'إلغاء', '↩️'))
    ] };
}

function render(s) {
    fixPanel(s);
    switch (s.view) {
        case 'panel': return panelView(s.panel);
        case 'cats': return catsView(s.panel);
        case 'dept': return deptView(s);
        case 'general': return generalView();
        case 'admins': return adminsView();
        case 'emojis': return emojisView();
        case 'confirm': return confirmView(s);
        default: return homeView();
    }
}
const show = (i, s, view) => { s.view = view; return update(i, render(s)); };

// ───── الأمر ─────
async function slash(i) {
    if (!(await adminOnly(i))) return;
    const s = st(i); s.view = 'home'; s.panel = 'main'; s.dept = null;
    return i.reply({ ...homeView(), flags: EPH });
}

// ───── الأزرار والقوائم ─────
async function component(i) {
    if (!(await adminOnly(i))) return;
    const s = st(i); fixPanel(s);
    const a = i.customId.split(':')[1];
    const c = conf(); const t = c.ticket;
    const vals = i.values || [];

    // نوافذ الإدخال (لازم قبل أي رد)
    if (a === 'newpanel') return i.showModal(modal('tkm:newpanel', 'لوحة تذاكر جديدة', input('name', 'اسم اللوحة', { required: true, max: 50, placeholder: 'مثال: الرقابة' })));
    if (a === 'ptext') { const p = pd(s.panel) || {}; return i.showModal(modal('tkm:ptext', 'نص اللوحة', input('title', 'العنوان (فاضي = بدون)', { max: 200, value: p.title }), input('description', 'الوصف (فاضي = بدون)', { paragraph: true, max: 3000, value: p.description }))); }
    if (a === 'plook') { const p = pd(s.panel) || {}; return i.showModal(modal('tkm:plook', 'مظهر اللوحة', input('color', 'اللون مثل #0A3A8C', { max: 7, value: p.color }), input('banner', 'الصورة العلوية (رابط • فاضي = بدون)', { max: 500, value: imgShow(p.banner), placeholder: 'https://...' }), input('bottom', 'الصورة السفلية (رابط • فاضي = بدون)', { max: 500, value: imgShow(p.bottomImage), placeholder: 'https://...' }), input('thumb', 'الصورة الصغيرة بجانب العنوان', { max: 500, value: imgShow(p.thumb), placeholder: 'https://...' }))); }
    if (a === 'prules') { const p = pd(s.panel) || {}; return i.showModal(modal('tkm:prules', 'القوانين والخطوات', input('rules', 'القوانين (فاضي = بدون)', { paragraph: true, max: 1000, value: p.rules }), input('steps', 'طريقة فتح تذكرة (فاضي = بدون)', { paragraph: true, max: 1000, value: p.steps }))); }
    if (a === 'newdept') return i.showModal(modal('tkm:newdept', 'قسم جديد', input('name', 'اسم القسم', { required: true, max: 100 }), input('emoji', 'الإيموجي', { max: 80, placeholder: '🎫' }), input('description', 'الوصف (يظهر تحت اسم القسم)', { max: 100 })));
    if (a === 'dedit') { const d = findDept(s); if (!d) return show(i, s, 'panel'); return i.showModal(modal('tkm:dedit', 'بيانات القسم', input('name', 'اسم القسم', { required: true, max: 100, value: d.name }), input('emoji', 'الإيموجي', { max: 80, value: d.emoji }), input('description', 'الوصف', { max: 100, value: d.description }))); }
    if (a === 'welcome') return i.showModal(modal('tkm:welcome', 'الترحيب واسم التذكرة', input('welcome', 'رسالة الترحيب داخل التذكرة', { paragraph: true, max: 1500, value: t.welcome, placeholder: 'استخدم {user} لمنشن العضو' }), input('nameformat', 'اسم التذكرة (استخدم {number})', { max: 50, value: t.ticketNameFormat || '{number}-🎫' })));
    if (a === 'tlook') { const em = t.embed || {}; return i.showModal(modal('tkm:tlook', 'مظهر التذكرة', input('color', 'اللون مثل #0A3A8C', { max: 7, value: em.color }), input('top', 'الصورة العلوية داخل التذكرة', { max: 500, value: imgShow(em.topImage), placeholder: 'https://...' }), input('image', 'الصورة السفلية داخل التذكرة', { max: 500, value: imgShow(em.image), placeholder: 'https://...' }), input('logo', 'لوجو صغير بجانب العنوان (رابط)', { max: 500, value: em.logo, placeholder: 'https://...' }))); }
    if (a === 'max') return i.showModal(modal('tkm:max', 'الحد الأقصى للتذاكر', input('count', 'عدد التذاكر المفتوحة لكل عضو (0 = بلا حد)', { required: true, max: 3, value: t.maxTickets != null ? String(t.maxTickets) : '3' })));

    if (a === 'emosel') {
        s.emoKey = vals[0];
        const def = T().emojis().find(x => x.key === s.emoKey);
        const cur = (c.ticket.emojis || {})[s.emoKey] || '';
        return i.showModal(modal('tkm:emo', cut('إيموجي: ' + (def ? def.label : ''), 45), input('emoji', 'اسم الإيموجي أو الصقه (فاضي = الأصلي)', { max: 100, value: cur, placeholder: 'مثال: ark' })));
    }

    // الصلاحيات: تفتح لوحتها الجاهزة كرسالة مستقلة
    if (a === 'perms') return i.reply({ ...T().buildBotPermsPanel(i.guild, i.user.id), flags: EPH });

    // ─── تنقّل ───
    if (a === 'home') return show(i, s, 'home');
    if (a === 'panel') return show(i, s, 'panel');
    if (a === 'pick') { s.panel = vals[0]; return show(i, s, 'panel'); }
    if (a === 'general') return show(i, s, 'general');
    if (a === 'admins') return show(i, s, 'admins');
    if (a === 'emojis') return show(i, s, 'emojis');
    if (a === 'emoreset') { c.ticket.emojis = {}; persist(); return update(i, emojisView()); }
    if (a === 'pcats') return show(i, s, 'cats');
    if (a === 'dept') { s.dept = vals[0]; return show(i, s, 'dept'); }
    if (a === 'pdel') { s.confirm = 'panel'; return show(i, s, 'confirm'); }
    if (a === 'ddel') { s.confirm = 'dept'; return show(i, s, 'confirm'); }
    if (a === 'no') { return show(i, s, s.confirm === 'dept' ? 'dept' : 'panel'); }

    // ─── تنفيذ ───
    if (a === 'yes') {
        await i.deferUpdate();
        if (s.confirm === 'panel' && s.panel !== 'main') {
            const sys = pd(s.panel); const ref = sys && sys.panelRef;
            c.departments = c.departments.filter(d => T().deptSystemId(d) !== s.panel);
            c.ticketSystems = c.ticketSystems.filter(x => x.id !== s.panel);
            if (ref) { try { const ch = await i.guild.channels.fetch(ref.channelId); const m = await ch.messages.fetch(ref.messageId); await m.delete(); } catch {} }
            s.panel = 'main'; s.view = 'home';
        } else if (s.confirm === 'dept') {
            c.departments = c.departments.filter(d => d.id !== s.dept);
            s.dept = null; s.view = 'panel';
            await refreshPanels(i);
        }
        s.confirm = null; persist();
        return i.editReply(render(s));
    }
    if (a === 'send') {
        await i.deferUpdate();
        const ch = i.guild.channels.cache.get(vals[0]) || await i.guild.channels.fetch(vals[0]).catch(() => null);
        if (!ch || !ch.isTextBased()) return i.followUp({ content: '❌ هذا الروم غير صالح.', flags: EPH });
        let sent;
        try { sent = await ch.send(T().buildPanelMessage(s.panel)); }
        catch (e) { return i.followUp({ content: '❌ ما قدرت أرسل اللوحة هناك: ' + cut(e.message, 150) + '\nتأكد أن البوت عنده صلاحية Send Messages و Embed Links و Attach Files.', flags: EPH }); }
        const old = pRef(s.panel);
        if (old) { try { const och = await i.guild.channels.fetch(old.channelId); const om = await och.messages.fetch(old.messageId); await om.delete(); } catch {} }
        setRef(s.panel, { channelId: sent.channelId, messageId: sent.id });
        persist();
        return i.editReply(render(s));
    }
    if (a === 'prefresh') { await i.deferUpdate(); await refreshPanels(i); return i.editReply(render(s)); }

    if (a === 'poc' || a === 'pcc') { setCat(s.panel, a === 'poc' ? 'open' : 'closed', vals[0]); persist(); return update(i, catsView(s.panel)); }
    if (a === 'drole') { const d = findDept(s); if (d) { d.roleId = vals[0]; persist(); await refreshPanels(i); } return update(i, deptView(s)); }
    if (a === 'drm') { const d = findDept(s); if (d) { d.roleId = ''; persist(); } return update(i, deptView(s)); }
    if (a === 'doc' || a === 'dcc') { const d = findDept(s); if (d) { d[a === 'doc' ? 'openCategoryId' : 'closedCategoryId'] = vals[0]; persist(); } return update(i, deptView(s)); }
    if (a === 'dcl') { const d = findDept(s); if (d) { d.openCategoryId = ''; d.closedCategoryId = ''; persist(); } return update(i, deptView(s)); }

    if (a === 'logs') { t.logsChannelId = vals[0]; persist(); return update(i, generalView()); }
    if (a === 'rating') { t.ratingChannelId = vals[0]; persist(); return update(i, generalView()); }
    if (a === 'svoice') { c.moderation.supportVoiceChannelIds = [...vals]; persist(); return update(i, generalView()); }
    if (a === 'reason') { t.requireReason = !t.requireReason; persist(); return update(i, generalView()); }
    if (a === 'adminsel') { c.roles.admin = vals[0] || ''; c.roles.admins = vals.slice(1); persist(); return update(i, adminsView()); }
}

// ───── نتائج النوافذ ─────
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const s = st(i); fixPanel(s);
    const a = i.customId.split(':')[1];
    const c = conf(); const t = c.ticket;
    const get = k => { try { return i.fields.getTextInputValue(k).trim(); } catch { return ''; } };
    const bad = msg => i.reply({ content: '❌ ' + msg, flags: EPH });
    const back = view => (i.isFromMessage && i.isFromMessage() ? show(i, s, view) : i.reply({ content: '✅ تم الحفظ.', flags: EPH }));

    if (a === 'emo') {
        const r = T().parseEmoji(i.guild, get('emoji'));
        if (r.error) return bad(r.error);
        c.ticket.emojis = c.ticket.emojis || {};
        if (r.value) c.ticket.emojis[s.emoKey] = r.value; else delete c.ticket.emojis[s.emoKey];
        persist();
        return back('emojis');
    }
    if (a === 'newpanel') {
        if (c.ticketSystems.length + 1 >= MAX_PANELS) return bad('بلغت الحد الأقصى للوحات (' + MAX_PANELS + ').');
        const sys = { id: 'sys_' + Date.now().toString(36), name: get('name').slice(0, 50) || 'لوحة', title: '', description: '', color: '', banner: '', thumb: '', rules: '', steps: '', openCategoryId: '', closedCategoryId: '', panelRef: null };
        c.ticketSystems.push(sys); s.panel = sys.id; persist();
        return back('panel');
    }
    if (a === 'ptext') { const p = pd(s.panel); if (p) { p.title = get('title'); p.description = get('description').replace(/\\n/g, '\n'); persist(); await refreshPanels(i); } return back('panel'); }
    if (a === 'plook') {
        const col = normColor(get('color'));
        if (col === null) return bad('اللون لازم يكون مثل #0A3A8C');
        const p = pd(s.panel); if (!p) return back('panel');
        const fromMsg = i.isFromMessage && i.isFromMessage();
        if (fromMsg) await i.deferUpdate(); else await i.deferReply({ flags: EPH });
        try {
            p.banner = await applyImg(p.banner, get('banner'), 'tkp-top');
            p.bottomImage = await applyImg(p.bottomImage, get('bottom'), 'tkp-bot');
            p.thumb = await applyImg(p.thumb, get('thumb'), 'tkp-thumb');
        } catch (e) { return i.followUp({ content: '❌ ' + e.message, flags: EPH }); }
        p.color = col; persist(); await refreshPanels(i);
        return fromMsg ? show(i, s, 'panel') : i.editReply({ content: '✅ تم حفظ المظهر.' });
    }
    if (a === 'prules') { const p = pd(s.panel); if (p) { p.rules = get('rules').replace(/\\n/g, '\n'); p.steps = get('steps').replace(/\\n/g, '\n'); persist(); await refreshPanels(i); } return back('panel'); }
    if (a === 'newdept') {
        if (deptsOf(s.panel).length >= MAX_DEPTS) return bad('بلغت الحد الأقصى للأقسام في هذه اللوحة (' + MAX_DEPTS + ').');
        const er = T().parseEmoji(i.guild, get('emoji')); if (er.error) return bad(er.error);
        const d = { id: 'dept_' + Date.now().toString(36), name: get('name').slice(0, 100), emoji: er.value || '📋', description: get('description') || get('name').slice(0, 100), roleId: '', systemId: s.panel, openCategoryId: '', closedCategoryId: '' };
        c.departments.push(d); s.dept = d.id; persist(); await refreshPanels(i);
        return back('dept');
    }
    if (a === 'dedit') { const er = T().parseEmoji(i.guild, get('emoji')); if (er.error) return bad(er.error); const d = findDept(s); if (d) { d.name = get('name').slice(0, 100) || d.name; d.emoji = er.value || '📋'; d.description = get('description') || d.name; persist(); await refreshPanels(i); } return back('dept'); }
    if (a === 'welcome') { t.welcome = get('welcome').replace(/\\n/g, '\n'); t.ticketNameFormat = get('nameformat') || '{number}-🎫'; persist(); return back('general'); }
    if (a === 'tlook') {
        const col = normColor(get('color')); const logo = get('logo');
        if (col === null) return bad('اللون لازم يكون مثل #0A3A8C');
        if (logo && !isUrl(logo)) return bad('رابط اللوجو لازم يبدأ بـ https://');
        const fromMsg = i.isFromMessage && i.isFromMessage();
        if (fromMsg) await i.deferUpdate(); else await i.deferReply({ flags: EPH });
        t.embed = t.embed || {};
        try {
            t.embed.topImage = await applyImg(t.embed.topImage, get('top'), 'tkt-top');
            t.embed.image = await applyImg(t.embed.image, get('image'), 'tkt-bot');
        } catch (e) { return i.followUp({ content: '❌ ' + e.message, flags: EPH }); }
        t.embed.color = col || '#0A3A8C'; t.embed.logo = logo; persist();
        return fromMsg ? show(i, s, 'general') : i.editReply({ content: '✅ تم حفظ مظهر التذكرة (يُطبَّق على التذاكر الجديدة).' });
    }
    if (a === 'max') {
        const n = parseInt(get('count'), 10);
        if (!Number.isFinite(n) || n < 0 || n > 100) return bad('اكتب رقم من 0 إلى 100.');
        t.maxTickets = n; persist();
        return back('general');
    }
}

// بدون سلاش: اكتب  -اعدادات تذاكر  (أو -تذاكر) وتطلع القائمة، وتنحذف تلقائياً بعد 15 دقيقة
async function onMessage(msg) {
    if (!msg.guild || msg.guild.id !== H.SERVER_ID || msg.author.bot) return false;
    if (!/^[-ـ]\s*(?:(?:اعدادات|إعدادات)\s*(?:ال)?تذاكر|تذاكر|tickets)\s*$/i.test((msg.content || '').trim())) return false;
    if (!H.isAdmin(msg.member)) { await msg.reply({ content: '❌ هذا الأمر مخصص للإدارة فقط.' }).catch(() => {}); return true; }
    const s = st({ user: msg.author }); s.view = 'home'; s.panel = 'main'; s.dept = null;
    const sent = await msg.channel.send(homeView()).catch(() => null);
    await msg.delete().catch(() => {});
    if (sent) setTimeout(() => sent.delete().catch(() => {}), 15 * 60 * 1000);
    return true;
}

const commands = [
    { name: 'tickets', description: 'قائمة التذاكر: اللوحات والأقسام والإعدادات والصلاحيات' },
    { name: 'اعدادات_تذاكر', description: 'نفس أمر tickets (اسم عربي)' }
];
return { prefix: 'tk', commands, ephemeral: ['tickets', 'اعدادات_تذاكر'], slash: { tickets: slash, 'اعدادات_تذاكر': slash }, component, modal: modalSubmit, onMessage };
};
