'use strict';
// ═══ الرتب الذاتية (قابلة للأخذ): /selfroles — لوحات أزرار أو قائمة، ينشرها البوت ويدير الرتب ═══
module.exports = (H) => {
const { D, EPH, row, btn, strSel, chSel, roleSel, input, modal, embed, cut, rid, session, adminOnly, update, chTxt, getTextChannel } = H;
const db = H.db;
const { ButtonStyle } = D;
const store = () => (db.selfroles = db.selfroles || { panels: [] });
const sess = (i) => session(i, 'sp', () => ({ sel: null }));
const cur = (i) => { const s = sess(i); return store().panels.find(p => p.id === s.sel) || null; };
const TYPES = { buttons: 'أزرار', menu: 'قائمة منسدلة' };

function buildPanel(i) {
    const st = store(); const s = sess(i);
    if (!st.panels.find(p => p.id === s.sel)) s.sel = st.panels[0] ? st.panels[0].id : null;
    const p = cur(i);
    const e = embed().setTitle('🏷️ الرتب القابلة للأخذ')
        .setDescription('أنشئ لوحة، اختر الرتب (حتى 10) والروم، ثم اضغط **نشر**. الأعضاء ياخذون الرتبة بضغطة زر أو من قائمة.\nاللوحات: **' + st.panels.length + '/10**');
    if (p) e.addFields(
        { name: '🧾 اللوحة', value: '**' + cut(p.title, 100) + '**\n' + cut(p.description, 300), inline: false },
        { name: '🔘 النوع', value: TYPES[p.type], inline: true }, { name: '📍 الروم', value: chTxt(p.channelId), inline: true },
        { name: '📤 الحالة', value: p.messageId ? 'منشورة ✅' : 'غير منشورة', inline: true },
        { name: '🖼️ الصورة', value: H.isUrl(p.image) ? 'محددة ✅' : '`غير محددة`', inline: true },
        { name: '🎭 الرتب (' + p.roles.length + '/10)', value: p.roles.length ? p.roles.map(r => '<@&' + r + '>').join(' ') : '`لم تُحدد`', inline: false });
    else e.addFields({ name: 'لا توجد لوحات', value: 'اضغط **➕ لوحة جديدة** للبدء.' });
    const rows = [
        row(strSel('sp:pick', 'اختر لوحة', p ? st.panels.map(x => ({ label: cut(x.title, 90), value: x.id, description: TYPES[x.type] + ' • ' + x.roles.length + ' رتبة', default: x.id === p.id })) : [{ label: 'لا توجد لوحات', value: 'none' }], { disabled: !p })),
        row(btn('sp:new', 'لوحة جديدة', '➕', ButtonStyle.Success, st.panels.length >= 10), btn('sp:text', 'النص', '✏️', ButtonStyle.Primary, !p), btn('sp:type', 'النوع', '🔁', ButtonStyle.Secondary, !p),
            btn('sp:pub', p && p.messageId ? 'تحديث' : 'نشر', '📤', ButtonStyle.Success, !p), btn('sp:del', 'حذف', '🗑️', ButtonStyle.Danger, !p)),
        row(btn('sp:img', 'الصورة', '🖼️', ButtonStyle.Primary, !p)),
        row(roleSel('sp:roles', 'اختر الرتب (حتى 10)', { min: 1, max: 10, selected: p ? p.roles : [], disabled: !p })),
        row(chSel('sp:ch', 'اختر الروم اللي تنشر فيه اللوحة', { selected: p && p.channelId ? [p.channelId] : [], disabled: !p }))
    ];
    return { embeds: [e], components: rows };
}
const refresh = (i) => update(i, buildPanel(i));

function buildMessage(p, guild) {
    const e = embed().setTitle(cut(p.title, 256)).setDescription(cut(p.description, 4000));
    if (H.isUrl(p.image)) e.setImage(p.image);
    const roles = p.roles.map(id => guild.roles.cache.get(id)).filter(Boolean);
    let components = [];
    if (p.type === 'menu') {
        components = [row(strSel('rl:' + p.id + ':m', 'اختر رتبتك', roles.map(r => ({ label: r.name, value: r.id })), { min: 0, max: roles.length }))];
    } else {
        for (let k = 0; k < roles.length; k += 5) components.push(row(...roles.slice(k, k + 5).map(r => btn('rl:' + p.id + ':' + r.id, r.name, null, ButtonStyle.Secondary))));
    }
    return { embeds: [e], components };
}
async function publish(i, p) {
    if (!p.roles.length) return i.followUp({ content: '❌ اختر الرتب أولاً.', flags: EPH });
    const ch = await getTextChannel(i.guild, p.channelId);
    if (!ch) return i.followUp({ content: '❌ اختر الروم أولاً.', flags: EPH });
    const msg = buildMessage(p, i.guild);
    try {
        if (p.messageId && p.postedIn === ch.id) {
            const old = await ch.messages.fetch(p.messageId).catch(() => null);
            if (old) { await old.edit(msg); return i.followUp({ content: '✅ تم تحديث اللوحة.\n' + old.url, flags: EPH }); }
        }
        const sent = await ch.send(msg); p.messageId = sent.id; p.postedIn = ch.id; H.save();
        return i.followUp({ content: '✅ تم نشر اللوحة في <#' + ch.id + '>\n' + sent.url, flags: EPH });
    } catch (e) { return i.followUp({ content: '❌ فشل النشر: ' + e.message, flags: EPH }); }
}

async function slash(i) { if (!(await adminOnly(i))) return; return i.reply({ ...buildPanel(i), flags: EPH }); }

async function component(i) {
    if (!(await adminOnly(i))) return;
    const st = store(); const s = sess(i); const p = cur(i); const a = i.customId.split(':')[1];
    if (i.isButton()) {
        if (a === 'new') return i.showModal(modal('spm:new', 'لوحة جديدة', input('title', 'عنوان اللوحة', { required: true, max: 100, value: 'اختر رتبتك' }), input('description', 'وصف اللوحة', { required: true, paragraph: true, max: 1000, value: 'اضغط على الزر أو اختر من القائمة للحصول على الرتبة المطلوبة.' })));
        if (a === 'text' && p) return i.showModal(modal('spm:text', 'نص اللوحة', input('title', 'عنوان اللوحة', { required: true, max: 100, value: p.title }), input('description', 'وصف اللوحة', { required: true, paragraph: true, max: 1000, value: p.description })));
        if (a === 'img' && p) return i.showModal(modal('spm:img', 'صورة اللوحة', input('image', 'رابط الصورة (اتركه فاضي للحذف)', { max: 500, value: p.image, placeholder: 'https://...' })));
        await i.deferUpdate();
        if (a === 'type' && p) p.type = p.type === 'buttons' ? 'menu' : 'buttons';
        else if (a === 'del' && p) { st.panels = st.panels.filter(x => x.id !== p.id); s.sel = null; }
        else if (a === 'pub' && p) { H.save(); await i.editReply(buildPanel(i)); return publish(i, p); }
        H.save();
        return i.editReply(buildPanel(i));
    }
    await i.deferUpdate();
    if (i.isStringSelectMenu() && a === 'pick') s.sel = i.values[0];
    else if (p && i.isRoleSelectMenu() && a === 'roles') p.roles = [...i.values].slice(0, 10);
    else if (p && i.isChannelSelectMenu() && a === 'ch') p.channelId = i.values[0];
    H.save();
    return i.editReply(buildPanel(i));
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const st = store(); const s = sess(i); const a = i.customId.split(':')[1];
    if (a === 'img') {
        const p = cur(i); const url = i.fields.getTextInputValue('image').trim();
        if (url && !H.isUrl(url)) return i.reply({ content: '❌ الرابط لازم يبدأ بـ https://', flags: EPH });
        if (p) { p.image = url; H.save(); }
        return refresh(i);
    }
    const title = i.fields.getTextInputValue('title').trim(), description = i.fields.getTextInputValue('description').trim();
    if (a === 'new') {
        if (st.panels.length >= 10) return i.reply({ content: '❌ الحد الأقصى 10 لوحات.', flags: EPH });
        const p = { id: rid(), type: 'buttons', channelId: '', messageId: '', postedIn: '', title, description, roles: [] };
        st.panels.push(p); s.sel = p.id;
    } else { const p = cur(i); if (p) { p.title = title; p.description = description; } }
    H.save();
    return refresh(i);
}

// ───── تفاعل الأعضاء (عام) ─────
async function publicClick(i) {
    const [, pid, what] = i.customId.split(':');
    const p = store().panels.find(x => x.id === pid);
    await i.deferReply({ flags: EPH });
    if (!p) return i.editReply({ content: '❌ هذه اللوحة لم تعد موجودة.' });
    const member = i.member; const ok = (t) => i.editReply({ embeds: [embed().setDescription(t)] });
    try {
        if (i.isStringSelectMenu()) {
            const chosen = new Set(i.values); const added = [], removed = [];
            for (const rid2 of p.roles) {
                const has = member.roles.cache.has(rid2);
                if (chosen.has(rid2) && !has) { await member.roles.add(rid2); added.push(rid2); }
                else if (!chosen.has(rid2) && has) { await member.roles.remove(rid2); removed.push(rid2); }
            }
            return ok((added.length ? '✅ تمت إضافة: ' + added.map(x => '<@&' + x + '>').join(' ') + '\n' : '') + (removed.length ? '➖ تمت إزالة: ' + removed.map(x => '<@&' + x + '>').join(' ') : '') || 'لا تغيير.');
        }
        if (!p.roles.includes(what)) return i.editReply({ content: '❌ هذه الرتبة لم تعد ضمن اللوحة.' });
        if (member.roles.cache.has(what)) { await member.roles.remove(what); return ok('➖ تمت إزالة الرتبة <@&' + what + '>'); }
        await member.roles.add(what); return ok('✅ تمت إضافة الرتبة <@&' + what + '>');
    } catch (e) {
        return i.editReply({ content: '❌ ما قدرت أعدل رتبتك — تأكد أن رتبة البوت أعلى من هذه الرتبة ومعه صلاحية Manage Roles.' });
    }
}

const commands = [{ name: 'selfroles', description: 'قائمة الرتب القابلة للأخذ (أزرار / قائمة منسدلة)' }];
return { prefix: 'sp', commands, ephemeral: ['selfroles'], slash: { selfroles: slash }, component, modal: modalSubmit, _buildPanel: buildPanel, _buildMessage: buildMessage,
    // مسار عام للأزرار: يُسجَّل عبر extraPrefixes
    extra: { rl: publicClick } };
};
