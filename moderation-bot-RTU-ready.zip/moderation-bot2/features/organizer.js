'use strict';
// ═══ organizer.js — تنظيم السيرفر الاحترافي ═══
// /organize → لوحة وحدة تضبط فيها:
//   📜 سجلات السيرفر   (حذف/تعديل رسائل، دخول/خروج، رتب، باند، رومات، صوت…) كل نوع بروم
//   🛡️ تنظيم الشات      (سبام، تكرار، روابط، دعوات، كلمات ممنوعة، منشن، إيموجي، كابس) + عقوبات تصاعدية
//   📌 قواعد الرومات    (روم صور فقط / نص فقط / روابط فقط)
//   🚪 حماية الانضمام   (رتبة تلقائية، حد أدنى لعمر الحساب، تنبيه غارة)
//   🔕 الإعفاءات        (رتب ورومات ما تنطبق عليها القواعد)
module.exports = (H) => {
const { D, EPH, BLUE, row, btn, strSel, chSel, roleSel, input, modal, embed, cut, session, adminOnly, update, chTxt, getTextChannel, isAdmin, client, SERVER_ID } = H;
const db = H.db;
const { ButtonStyle, EmbedBuilder } = D;
const PF = D.PermissionFlagsBits || {};

// ───── ثوابت ─────
const RED = 0xED4245, GREEN = 0x57F287, YELLOW = 0xFEE75C, ORANGE = 0xFAA61A, BLURPLE = 0x0A3A8C, GREY = 0x99AAB5;
const AL = { MemberKick: 20, MemberBanAdd: 22, MemberBanRemove: 23, MemberUpdate: 24, MemberRoleUpdate: 25, MessageDelete: 72, MessageBulkDelete: 73, ChannelCreate: 10, ChannelDelete: 12, RoleCreate: 30, RoleDelete: 32, ...(D.AuditLogEvent || {}) };
const LOGCATS = {
    messages: { name: 'الرسائل', emoji: '🗑️', desc: 'حذف وتعديل الرسائل' },
    members: { name: 'الأعضاء', emoji: '👥', desc: 'دخول وخروج وتغيير الاسم والرتب' },
    moderation: { name: 'الإشراف', emoji: '🔨', desc: 'باند، تايم أوت، وإجراءات تنظيم الشات' },
    server: { name: 'السيرفر', emoji: '🧱', desc: 'إنشاء وحذف وتعديل الرومات والرتب' },
    voice: { name: 'الصوت', emoji: '🔊', desc: 'دخول وخروج ونقل الرومات الصوتية' }
};
const RULES = {
    spam: { name: 'سبام الرسائل', emoji: '💬', desc: 'رسائل كثيرة بوقت قصير', def: { count: 5, sec: 5 } },
    dup: { name: 'تكرار الرسالة', emoji: '🔁', desc: 'نفس الرسالة تتكرر', def: { count: 3, sec: 30 } },
    invite: { name: 'روابط الدعوات', emoji: '📨', desc: 'منع روابط سيرفرات ديسكورد', def: { allow: [] } },
    links: { name: 'الروابط', emoji: '🔗', desc: 'منع الروابط (مع قائمة سماح)', def: { allow: [] } },
    words: { name: 'كلمات ممنوعة', emoji: '🤬', desc: 'قائمة كلمات تحددها', def: { list: [] } },
    mention: { name: 'المنشن الجماعي', emoji: '📣', desc: 'منشن كثير بالرسالة', def: { max: 5 } },
    emoji: { name: 'إيموجي مزعج', emoji: '😵', desc: 'إيموجي كثير بالرسالة', def: { max: 10 } },
    caps: { name: 'الحروف الكبيرة', emoji: '🔠', desc: 'رسالة إنجليزية كلها كابس', def: { pct: 70, min: 12 } }
};
const MODES = { media: '🖼️ صور وميديا فقط', text: '💬 نص فقط (بدون ملفات وروابط)', links: '🔗 روابط فقط' };

// ───── التخزين ─────
function O() {
    const o = (db.organizer = db.organizer || {});
    o.logs = o.logs || {};
    o.logs.default = o.logs.default || '';
    o.logs.ignoreBots = o.logs.ignoreBots !== false;
    o.logs.cats = o.logs.cats || {};
    for (const k of Object.keys(LOGCATS)) o.logs.cats[k] = Object.assign({ on: true, ch: '' }, o.logs.cats[k]);
    o.chat = o.chat || {};
    o.chat.rules = o.chat.rules || {};
    for (const [k, v] of Object.entries(RULES)) o.chat.rules[k] = Object.assign({ on: false }, v.def, o.chat.rules[k]);
    o.chat.strikeLimit = Number.isFinite(o.chat.strikeLimit) ? o.chat.strikeLimit : 3;
    o.chat.strikeWindow = Number.isFinite(o.chat.strikeWindow) ? o.chat.strikeWindow : 10;
    o.chat.timeoutMin = Number.isFinite(o.chat.timeoutMin) ? o.chat.timeoutMin : 10;
    o.chat.notice = o.chat.notice !== false;
    o.chat.noticeSec = Number.isFinite(o.chat.noticeSec) ? o.chat.noticeSec : 6;
    o.chanRules = o.chanRules || {};
    o.join = o.join || {};
    o.join.role = o.join.role || '';
    o.join.minDays = Number.isFinite(o.join.minDays) ? o.join.minDays : 0;
    o.join.raid = Object.assign({ count: 0, sec: 15 }, o.join.raid);
    o.exemptRoles = Array.isArray(o.exemptRoles) ? o.exemptRoles : [];
    o.exemptChannels = Array.isArray(o.exemptChannels) ? o.exemptChannels : [];
    return o;
}

// ───── أدوات ─────
const E = () => { const e = new EmbedBuilder(); e.toJSON = function () { return { ...this.data }; }; return e; };
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const inGuild = (g) => g && g.id === SERVER_ID;
const tag = (u) => (u && (u.username || u.tag)) || 'غير معروف';
const av = (u, size = 64) => { try { return u && u.displayAvatarURL ? u.displayAvatarURL({ size }) : undefined; } catch { return undefined; } };
const ts = (ms, f = 'R') => '<t:' + Math.floor(ms / 1000) + ':' + f + '>';
const uLine = (u) => u ? '<@' + u.id + '>\n`' + cut(tag(u), 40) + '`' : '`غير معروف`';
const list = (arr, n = 12) => arr.length ? arr.slice(0, n).join(' ') + (arr.length > n ? ' …+' + (arr.length - n) : '') : '`لا شيء`';
const parseList = (raw) => String(raw || '').split(/[\n,،]+/).map(x => x.trim()).filter(Boolean);

async function who(guild, type, targetId, maxAge = 9000) {
    try {
        const logs = await guild.fetchAuditLogs({ type, limit: 6 });
        const e = logs.entries.find(x => x.target && x.target.id === targetId && Date.now() - x.createdTimestamp < maxAge);
        return e ? { user: e.executor, reason: e.reason || '' } : null;
    } catch { return null; }
}

// ───── السجلات ─────
async function logChannel(guild, cat) {
    const o = O(); const c = o.logs.cats[cat];
    if (!c || !c.on) return null;
    const id = c.ch || o.logs.default;
    return id ? getTextChannel(guild, id) : null;
}
async function sendLog(guild, cat, e) {
    try {
        const ch = await logChannel(guild, cat);
        if (ch) await ch.send({ embeds: [e], allowedMentions: { parse: [] } });
    } catch (err) { console.error('[organizer:log]', err.message); }
}
function logBase(color, title, user) {
    const e = E().setColor(color).setTitle(cut(title, 256));
    if (user) e.setAuthor({ name: cut(tag(user), 100), iconURL: av(user) });
    return e;
}
const selfDeleted = new Set();

async function onMessageDelete(m) {
    if (!inGuild(m.guild)) return;
    if (selfDeleted.delete(m.id)) return;
    if (m.author && m.author.bot && O().logs.ignoreBots) return;
    const ex = m.author ? await who(m.guild, AL.MessageDelete, m.author.id, 6000) : null;
    const e = logBase(RED, '🗑️ تم حذف رسالة', m.author)
        .setDescription(m.content ? cut(m.content, 1500) : '*لا يوجد نص (ملف/إمبد) أو الرسالة قديمة وغير مخزّنة*')
        .addFields(
            { name: '👤 الكاتب', value: uLine(m.author), inline: true },
            { name: '📍 الروم', value: '<#' + m.channelId + '>', inline: true },
            { name: '🗑️ حذفها', value: ex && ex.user ? uLine(ex.user) : '`الكاتب نفسه / غير معروف`', inline: true });
    const files = m.attachments && m.attachments.size ? [...m.attachments.values()].map(a => '`' + cut(a.name || 'ملف', 40) + '`').join(' ') : '';
    if (files) e.addFields({ name: '📎 المرفقات', value: cut(files, 1000), inline: false });
    e.setFooter({ text: 'ID الرسالة: ' + m.id + (m.author ? ' • ID العضو: ' + m.author.id : '') });
    await sendLog(m.guild, 'messages', e);
}
async function onMessageUpdate(a, b) {
    if (!inGuild(b.guild)) return;
    if (b.author && b.author.bot) return;
    try { if (b.partial) b = await b.fetch(); } catch {}
    if (a.content != null && a.content === b.content) return;
    if (O().logs.cats.messages.on) {
        const e = logBase(ORANGE, '✏️ تم تعديل رسالة', b.author)
            .setDescription('[الانتقال للرسالة](' + (b.url || ('https://discord.com/channels/' + b.guild.id + '/' + b.channelId + '/' + b.id)) + ')')
            .addFields(
                { name: '📄 قبل', value: a.content ? cut(a.content, 1000) : '`غير متاح`', inline: false },
                { name: '📝 بعد', value: b.content ? cut(b.content, 1000) : '`فاضي`', inline: false },
                { name: '👤 الكاتب', value: uLine(b.author), inline: true }, { name: '📍 الروم', value: '<#' + b.channelId + '>', inline: true })
            .setFooter({ text: 'ID الرسالة: ' + b.id });
        await sendLog(b.guild, 'messages', e);
    }
    try { await moderate(b, true); } catch (err) { console.error('[organizer:edit]', err.message); }
}
async function onBulkDelete(msgs, channel) {
    const g = channel && channel.guild; if (!inGuild(g)) return;
    const ex = await who(g, AL.MessageBulkDelete, channel.id, 8000);
    const e = logBase(RED, '🧹 حذف جماعي للرسائل')
        .setDescription('تم حذف **' + msgs.size + '** رسالة من <#' + channel.id + '>')
        .addFields({ name: '👮 بواسطة', value: ex && ex.user ? uLine(ex.user) : '`غير معروف`', inline: true });
    await sendLog(g, 'messages', e);
}
async function onMemberAdd(member) {
    if (!inGuild(member.guild)) return;
    const o = O(); const created = member.user.createdTimestamp || 0;
    const ageDays = created ? (Date.now() - created) / 86400000 : 999;
    const e = logBase(GREEN, '📥 انضم عضو جديد', member.user)
        .setDescription('<@' + member.id + '> انضم للسيرفر')
        .addFields(
            { name: '📅 عمر الحساب', value: created ? ts(created) : '`—`', inline: true },
            { name: '🔢 رقم العضو', value: String(member.guild.memberCount || '—'), inline: true },
            { name: '🤖 بوت؟', value: member.user.bot ? 'نعم' : 'لا', inline: true })
        .setThumbnail(av(member.user, 128) || null)
        .setFooter({ text: 'ID: ' + member.id });
    if (ageDays < 7) e.addFields({ name: '⚠️ تنبيه', value: 'الحساب جديد (أقل من 7 أيام)', inline: false });
    await sendLog(member.guild, 'members', e);
    if (member.user.bot) return;
    // رتبة تلقائية
    if (o.join.role) { try { await member.roles.add(o.join.role, 'رتبة تلقائية عند الانضمام'); } catch (err) { console.error('[organizer:autorole]', err.message); } }
    // حد أدنى لعمر الحساب
    if (o.join.minDays > 0 && ageDays < o.join.minDays) {
        const ev = logBase(RED, '🚫 طرد حساب جديد')
            .setDescription('<@' + member.id + '> حسابه أصغر من الحد المسموح (**' + o.join.minDays + '** يوم).')
            .addFields({ name: '📅 عمر الحساب', value: ts(created), inline: true });
        try {
            try { await member.send({ embeds: [E().setColor(RED).setTitle('🚫 تعذّر دخولك').setDescription('سيرفر **' + member.guild.name + '** يشترط أن يكون عمر حسابك **' + o.join.minDays + '** يوم على الأقل.\nتقدر تنضم بعد ما يكبر حسابك.')] }); } catch {}
            await member.kick('حساب أصغر من ' + o.join.minDays + ' يوم');
            await sendLog(member.guild, 'moderation', ev);
        } catch (err) { ev.addFields({ name: '⚠️', value: 'تعذّر الطرد: ' + cut(err.message, 100), inline: false }); await sendLog(member.guild, 'moderation', ev); }
        return;
    }
    // تنبيه الغارة
    const R = o.join.raid;
    if (R.count > 0) {
        const now = Date.now(); raidJoins.push(now);
        while (raidJoins.length && now - raidJoins[0] > R.sec * 1000) raidJoins.shift();
        if (raidJoins.length >= R.count && now - lastRaidAlert > 5 * 60 * 1000) {
            lastRaidAlert = now;
            await sendLog(member.guild, 'members', logBase(RED, '🚨 تنبيه غارة محتملة')
                .setDescription('انضم **' + raidJoins.length + '** عضو خلال **' + R.sec + '** ثانية!\nراجع الأعضاء الجدد، ولو تبغى استخدم `/lockdown` لقفل السيرفر.'));
        }
    }
}
let raidJoins = []; let lastRaidAlert = 0;
async function onMemberRemove(member) {
    if (!inGuild(member.guild)) return;
    const kicked = await who(member.guild, AL.MemberKick, member.id, 8000);
    const roles = member.roles && member.roles.cache ? [...member.roles.cache.values()].filter(r => r.id !== member.guild.id).map(r => '<@&' + r.id + '>') : [];
    const e = logBase(kicked ? ORANGE : GREY, kicked ? '👢 تم طرد عضو' : '📤 غادر عضو', member.user)
        .setDescription('<@' + member.id + '> ' + (kicked ? 'تم طرده من السيرفر' : 'غادر السيرفر'))
        .addFields(
            { name: '⏱️ مدة البقاء', value: member.joinedTimestamp ? ts(member.joinedTimestamp) : '`—`', inline: true },
            { name: '🏅 الرتب', value: cut(list(roles, 10), 1000), inline: false });
    if (kicked) e.addFields({ name: '👮 بواسطة', value: kicked.user ? uLine(kicked.user) : '`—`', inline: true }, { name: '📝 السبب', value: kicked.reason || '`بدون`', inline: true });
    e.setFooter({ text: 'ID: ' + member.id });
    await sendLog(member.guild, kicked ? 'moderation' : 'members', e);
}
async function onMemberUpdate(a, b) {
    if (!inGuild(b.guild)) return;
    if (b.user && b.user.bot && O().logs.ignoreBots) return;
    const e0 = { user: b.user };
    if (a.nickname !== b.nickname) {
        await sendLog(b.guild, 'members', logBase(BLURPLE, '🏷️ تغيير اللقب', b.user)
            .addFields({ name: '👤 العضو', value: uLine(b.user), inline: true }, { name: 'قبل', value: a.nickname ? cut(a.nickname, 100) : '`بدون`', inline: true }, { name: 'بعد', value: b.nickname ? cut(b.nickname, 100) : '`بدون`', inline: true }));
    }
    if (a.roles && b.roles && a.roles.cache && b.roles.cache) {
        const added = [...b.roles.cache.keys()].filter(id => !a.roles.cache.has(id));
        const removed = [...a.roles.cache.keys()].filter(id => !b.roles.cache.has(id));
        if (added.length || removed.length) {
            const ex = await who(b.guild, AL.MemberRoleUpdate, b.id, 8000);
            const e = logBase(added.length && !removed.length ? GREEN : (removed.length && !added.length ? RED : ORANGE), '🏅 تغيير رتب عضو', b.user)
                .addFields({ name: '👤 العضو', value: uLine(b.user), inline: true }, { name: '👮 بواسطة', value: ex && ex.user ? uLine(ex.user) : '`غير معروف`', inline: true });
            if (added.length) e.addFields({ name: '➕ أُضيفت', value: added.map(i => '<@&' + i + '>').join(' '), inline: false });
            if (removed.length) e.addFields({ name: '➖ أُزيلت', value: removed.map(i => '<@&' + i + '>').join(' '), inline: false });
            await sendLog(b.guild, 'members', e);
        }
    }
    const ta = a.communicationDisabledUntilTimestamp || 0, tb = b.communicationDisabledUntilTimestamp || 0;
    if (ta !== tb && (tb > Date.now() || ta > Date.now())) {
        const ex = await who(b.guild, AL.MemberUpdate, b.id, 8000);
        const on = tb > Date.now();
        const e = logBase(on ? ORANGE : GREEN, on ? '🔇 تايم أوت لعضو' : '🔊 فك التايم أوت', b.user)
            .addFields({ name: '👤 العضو', value: uLine(b.user), inline: true }, { name: '👮 بواسطة', value: ex && ex.user ? uLine(ex.user) : '`غير معروف`', inline: true });
        if (on) e.addFields({ name: '⏱️ ينتهي', value: ts(tb), inline: true });
        if (ex && ex.reason) e.addFields({ name: '📝 السبب', value: cut(ex.reason, 500), inline: false });
        await sendLog(b.guild, 'moderation', e);
    }
    void e0;
}
async function onBan(ban, add) {
    if (!inGuild(ban.guild)) return;
    const ex = await who(ban.guild, add ? AL.MemberBanAdd : AL.MemberBanRemove, ban.user.id, 8000);
    const e = logBase(add ? RED : GREEN, add ? '🔨 تم حظر عضو' : '🔓 تم فك الحظر', ban.user)
        .addFields({ name: '👤 العضو', value: uLine(ban.user), inline: true }, { name: '👮 بواسطة', value: ex && ex.user ? uLine(ex.user) : '`غير معروف`', inline: true });
    const reason = ban.reason || (ex && ex.reason);
    if (reason) e.addFields({ name: '📝 السبب', value: cut(reason, 500), inline: false });
    e.setFooter({ text: 'ID: ' + ban.user.id });
    await sendLog(ban.guild, 'moderation', e);
}
const chType = (c) => ({ 0: 'نصي', 2: 'صوتي', 4: 'تصنيف', 5: 'إعلانات', 13: 'ستيج', 15: 'منتدى' }[c.type] || 'روم');
async function onChannelCreate(c) {
    if (!inGuild(c.guild)) return;
    const ex = await who(c.guild, AL.ChannelCreate, c.id);
    await sendLog(c.guild, 'server', logBase(GREEN, '➕ إنشاء روم').setDescription('<#' + c.id + '> (`' + cut(c.name, 60) + '`)')
        .addFields({ name: 'النوع', value: chType(c), inline: true }, { name: '👮 بواسطة', value: ex && ex.user ? uLine(ex.user) : '`غير معروف`', inline: true }).setFooter({ text: 'ID: ' + c.id }));
}
async function onChannelDelete(c) {
    if (!inGuild(c.guild)) return;
    const ex = await who(c.guild, AL.ChannelDelete, c.id);
    await sendLog(c.guild, 'server', logBase(RED, '🗑️ حذف روم').setDescription('`#' + cut(c.name, 60) + '`')
        .addFields({ name: 'النوع', value: chType(c), inline: true }, { name: '👮 بواسطة', value: ex && ex.user ? uLine(ex.user) : '`غير معروف`', inline: true }).setFooter({ text: 'ID: ' + c.id }));
}
async function onChannelUpdate(a, b) {
    if (!inGuild(b.guild)) return;
    const d = [];
    if (a.name !== b.name) d.push({ name: '📛 الاسم', value: '`' + cut(a.name, 60) + '` ⟵ `' + cut(b.name, 60) + '`', inline: false });
    if ((a.topic || '') !== (b.topic || '')) d.push({ name: '📝 الوصف', value: cut((a.topic || 'بدون') + ' ⟵ ' + (b.topic || 'بدون'), 900), inline: false });
    if ((a.rateLimitPerUser || 0) !== (b.rateLimitPerUser || 0)) d.push({ name: '🐢 السلومود', value: (a.rateLimitPerUser || 0) + 'ث ⟵ ' + (b.rateLimitPerUser || 0) + 'ث', inline: true });
    if (a.nsfw !== b.nsfw) d.push({ name: '🔞 NSFW', value: (a.nsfw ? 'نعم' : 'لا') + ' ⟵ ' + (b.nsfw ? 'نعم' : 'لا'), inline: true });
    if (a.parentId !== b.parentId) d.push({ name: '📂 التصنيف', value: (a.parentId ? '<#' + a.parentId + '>' : 'بدون') + ' ⟵ ' + (b.parentId ? '<#' + b.parentId + '>' : 'بدون'), inline: false });
    try {
        const sig = (c) => JSON.stringify([...(c.permissionOverwrites && c.permissionOverwrites.cache ? c.permissionOverwrites.cache.values() : [])].map(p => [p.id, String(p.allow && p.allow.bitfield), String(p.deny && p.deny.bitfield)]).sort());
        if (sig(a) !== sig(b)) d.push({ name: '🔐 الصلاحيات', value: 'تم تعديل صلاحيات الروم', inline: false });
    } catch {}
    if (!d.length) return;
    await sendLog(b.guild, 'server', logBase(ORANGE, '🛠️ تعديل روم').setDescription('<#' + b.id + '>').addFields(...d).setFooter({ text: 'ID: ' + b.id }));
}
async function onRoleCreate(r) {
    if (!inGuild(r.guild)) return;
    const ex = await who(r.guild, AL.RoleCreate, r.id);
    await sendLog(r.guild, 'server', logBase(GREEN, '➕ إنشاء رتبة').setDescription('<@&' + r.id + '> (`' + cut(r.name, 60) + '`)')
        .addFields({ name: '👮 بواسطة', value: ex && ex.user ? uLine(ex.user) : '`غير معروف`', inline: true }).setFooter({ text: 'ID: ' + r.id }));
}
async function onRoleDelete(r) {
    if (!inGuild(r.guild)) return;
    const ex = await who(r.guild, AL.RoleDelete, r.id);
    await sendLog(r.guild, 'server', logBase(RED, '🗑️ حذف رتبة').setDescription('`' + cut(r.name, 60) + '`')
        .addFields({ name: '👮 بواسطة', value: ex && ex.user ? uLine(ex.user) : '`غير معروف`', inline: true }).setFooter({ text: 'ID: ' + r.id }));
}
async function onRoleUpdate(a, b) {
    if (!inGuild(b.guild)) return;
    const d = [];
    if (a.name !== b.name) d.push({ name: '📛 الاسم', value: '`' + cut(a.name, 60) + '` ⟵ `' + cut(b.name, 60) + '`', inline: false });
    if (a.color !== b.color) d.push({ name: '🎨 اللون', value: '#' + (a.color || 0).toString(16).padStart(6, '0') + ' ⟵ #' + (b.color || 0).toString(16).padStart(6, '0'), inline: true });
    if (a.hoist !== b.hoist) d.push({ name: '📌 عرض منفصل', value: (a.hoist ? 'نعم' : 'لا') + ' ⟵ ' + (b.hoist ? 'نعم' : 'لا'), inline: true });
    if (a.mentionable !== b.mentionable) d.push({ name: '📣 قابلة للمنشن', value: (a.mentionable ? 'نعم' : 'لا') + ' ⟵ ' + (b.mentionable ? 'نعم' : 'لا'), inline: true });
    try { if (String(a.permissions && a.permissions.bitfield) !== String(b.permissions && b.permissions.bitfield)) d.push({ name: '🔐 الصلاحيات', value: 'تم تعديل صلاحيات الرتبة', inline: false }); } catch {}
    if (!d.length) return;
    await sendLog(b.guild, 'server', logBase(ORANGE, '🛠️ تعديل رتبة').setDescription('<@&' + b.id + '>').addFields(...d).setFooter({ text: 'ID: ' + b.id }));
}
async function onVoiceState(a, b) {
    const g = (b && b.guild) || (a && a.guild); if (!inGuild(g)) return;
    const m = (b && b.member) || (a && a.member); if (!m || (m.user && m.user.bot && O().logs.ignoreBots)) return;
    const u = m.user;
    const aid = a && a.channelId, bid = b && b.channelId;
    let e = null;
    if (!aid && bid) e = logBase(GREEN, '🔊 دخول روم صوتي', u).setDescription('<@' + m.id + '> دخل <#' + bid + '>');
    else if (aid && !bid) e = logBase(GREY, '🔇 خروج من روم صوتي', u).setDescription('<@' + m.id + '> خرج من <#' + aid + '>');
    else if (aid && bid && aid !== bid) e = logBase(BLURPLE, '🔀 نقل بين الرومات', u).setDescription('<@' + m.id + '>: <#' + aid + '> ⟵ <#' + bid + '>');
    else if (aid && bid) {
        const ch = [];
        if (a.serverMute !== b.serverMute) ch.push(b.serverMute ? '🔇 كتمه السيرفر' : '🔊 فك كتم السيرفر');
        if (a.serverDeaf !== b.serverDeaf) ch.push(b.serverDeaf ? '🙉 صمّه السيرفر' : '👂 فك صمم السيرفر');
        if (a.streaming !== b.streaming) ch.push(b.streaming ? '🎥 بدأ بث' : '⏹️ أوقف البث');
        if (ch.length) e = logBase(ORANGE, '🎙️ تغيير حالة صوتية', u).setDescription('<@' + m.id + '> في <#' + bid + '>\n' + ch.join('\n'));
    }
    if (e) { e.setFooter({ text: 'ID: ' + m.id }); await sendLog(g, 'voice', e); }
}

// ───── تنظيم الشات ─────
const URL_RE = /(?:https?:\/\/|www\.)[^\s<>]+/gi;
const INVITE_RE = /(?:discord(?:app)?\.com\/invite|discord\.gg|discord\.me|dsc\.gg)\/([\w-]+)/i;
const EMOJI_RE = /<a?:\w{2,32}:\d{15,25}>|\p{Extended_Pictographic}/gu;
const hostOf = (u) => { try { return new URL(/^https?:\/\//i.test(u) ? u : 'http://' + u).hostname.replace(/^www\./, '').toLowerCase(); } catch { return ''; } };
function norm(s) {
    return String(s || '').toLowerCase()
        .replace(/[\u064B-\u065F\u0670\u0640\u200B-\u200F\u202A-\u202E\u2066-\u2069]/g, '')
        .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
        .replace(/(.)\1+/g, '$1');
}
const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function matchWords(text, words) {
    const t = norm(text);
    for (const raw of words) {
        const sub = /^\*.*\*$/.test(raw);
        const w = norm(raw.replace(/\*/g, '').trim());
        if (w.length < 2) continue;
        const re = sub ? new RegExp(escRe(w), 'u') : new RegExp('(^|[^\\p{L}\\p{N}])' + escRe(w) + '($|[^\\p{L}\\p{N}])', 'u');
        if (re.test(t)) return raw.replace(/\*/g, '');
    }
    return '';
}
const hist = new Map();     // userId -> [{t, id, ch, c}]
const strikes = new Map();  // userId -> [t]
function exempt(member, channelId) {
    const o = O();
    if (o.exemptChannels.includes(channelId)) return true;
    try {
        if (isAdmin(member)) return true;
        if (PF.Administrator && member.permissions && member.permissions.has(PF.Administrator)) return true;
        if (PF.ManageMessages && member.permissions && member.permissions.has(PF.ManageMessages)) return true;
        if (o.exemptRoles.some(r => member.roles.cache.has(r))) return true;
    } catch {}
    return false;
}
const hasMedia = (msg) => {
    if (msg.attachments && msg.attachments.size) return true;
    if (msg.stickers && msg.stickers.size) return true;
    if ((msg.embeds || []).some(e => e && (e.image || e.video || e.thumbnail))) return true;
    return /https?:\/\/\S+\.(png|jpe?g|gif|webp|mp4|mov|webm)(\?\S*)?/i.test(msg.content || '') || /https?:\/\/(?:media\.)?(tenor|giphy|imgur)\.\S+/i.test(msg.content || '');
};
function detect(msg, edited) {
    const o = O(); const R = o.chat.rules; const c = msg.content || '';
    const links = c.match(URL_RE) || [];
    if (R.invite.on) { const m = INVITE_RE.exec(c); if (m && !R.invite.allow.map(x => x.toLowerCase()).includes(m[1].toLowerCase())) return { rule: 'invite', why: 'ممنوع نشر روابط دعوات السيرفرات' }; }
    if (R.links.on && links.length) {
        const allow = R.links.allow.map(x => x.toLowerCase().replace(/^www\./, ''));
        const bad = links.find(l => { const h = hostOf(l); return h && !allow.some(a => h === a || h.endsWith('.' + a)); });
        if (bad) return { rule: 'links', why: 'ممنوع نشر الروابط هنا' };
    }
    if (R.words.on && R.words.list.length) { const w = matchWords(c, R.words.list); if (w) return { rule: 'words', why: 'رسالتك تحتوي على كلمة ممنوعة' }; }
    if (R.mention.on) { const n = (msg.mentions && msg.mentions.users ? msg.mentions.users.size : 0) + (msg.mentions && msg.mentions.roles ? msg.mentions.roles.size : 0); if (n > R.mention.max) return { rule: 'mention', why: 'منشن كثير بالرسالة' }; }
    if (R.emoji.on) { const n = (c.match(EMOJI_RE) || []).length; if (n > R.emoji.max) return { rule: 'emoji', why: 'إيموجي كثير بالرسالة' }; }
    if (R.caps.on) { const L = (c.match(/[A-Za-z]/g) || []).length; if (L >= R.caps.min) { const U = (c.match(/[A-Z]/g) || []).length; if (U / L * 100 >= R.caps.pct) return { rule: 'caps', why: 'لا تكتب بالحروف الكبيرة' }; } }
    if (!edited && (R.spam.on || R.dup.on)) {
        const now = Date.now(); const arr = hist.get(msg.author.id) || [];
        const keepFor = Math.max(R.spam.sec, R.dup.sec) * 1000;
        while (arr.length && now - arr[0].t > keepFor) arr.shift();
        arr.push({ t: now, id: msg.id, ch: msg.channelId, c: norm(c) });
        hist.set(msg.author.id, arr);
        if (R.spam.on && arr.filter(x => now - x.t <= R.spam.sec * 1000).length >= R.spam.count) return { rule: 'spam', why: 'تكتب بسرعة كبيرة (سبام)' };
        if (R.dup.on && c.trim() && arr.filter(x => x.c === norm(c) && now - x.t <= R.dup.sec * 1000).length >= R.dup.count) return { rule: 'dup', why: 'لا تكرر نفس الرسالة' };
    }
    return null;
}
function detectChannel(msg) {
    const mode = O().chanRules[msg.channelId]; if (!mode) return null;
    const c = msg.content || '';
    const hasLink = (c.match(URL_RE) || []).length > 0;
    if (mode === 'media' && !hasMedia(msg)) return { rule: 'chan', why: 'هذا الروم للصور والميديا فقط' };
    if (mode === 'text' && (hasLink || (msg.attachments && msg.attachments.size))) return { rule: 'chan', why: 'هذا الروم للنص فقط (بدون ملفات أو روابط)' };
    if (mode === 'links' && !hasLink) return { rule: 'chan', why: 'هذا الروم للروابط فقط' };
    return null;
}
async function punish(msg, v) {
    const o = O(); const C = o.chat; const uid = msg.author.id;
    const acts = [];
    // حذف (ومعه رسائل السبام الأخيرة)
    let ids = [msg.id];
    if (v.rule === 'spam' || v.rule === 'dup') {
        const arr = hist.get(uid) || [];
        ids = [...new Set([...arr.filter(x => x.ch === msg.channelId).map(x => x.id), msg.id])];
        hist.set(uid, []);
    }
    ids.forEach(i => selfDeleted.add(i));
    try {
        if (ids.length > 1 && msg.channel.bulkDelete) await msg.channel.bulkDelete(ids, true);
        else await msg.delete();
        acts.push('🗑️ حذف ' + (ids.length > 1 ? ids.length + ' رسائل' : 'الرسالة'));
    } catch (e) { acts.push('⚠️ تعذّر الحذف (' + cut(e.message, 60) + ')'); }
    // تنبيه مؤقت
    if (C.notice) {
        try {
            const n = await msg.channel.send({ content: '⚠️ <@' + uid + '> ' + v.why + '.', allowedMentions: { users: [uid] } });
            setTimeout(() => { try { n.delete().catch(() => {}); } catch {} }, clamp(C.noticeSec, 2, 30) * 1000).unref?.();
        } catch {}
    }
    // عقوبة تصاعدية
    const now = Date.now(); const arr = (strikes.get(uid) || []).filter(t => now - t < C.strikeWindow * 60000); arr.push(now);
    strikes.set(uid, arr);
    let timedOut = false;
    if (C.strikeLimit > 0 && arr.length >= C.strikeLimit && C.timeoutMin > 0) {
        try { if (msg.member.moderatable === false) throw new Error('رتبة العضو أعلى من البوت'); await msg.member.timeout(C.timeoutMin * 60000, 'تنظيم الشات: ' + C.strikeLimit + ' مخالفات'); timedOut = true; strikes.set(uid, []); acts.push('🔇 تايم أوت ' + C.timeoutMin + ' دقيقة'); }
        catch (e) { acts.push('⚠️ تعذّر التايم أوت (' + cut(e.message, 60) + ')'); }
    }
    const name = v.rule === 'chan' ? '📌 قاعدة الروم' : (RULES[v.rule].emoji + ' ' + RULES[v.rule].name);
    const e = logBase(timedOut ? RED : ORANGE, '🛡️ تنظيم الشات — ' + name, msg.author)
        .addFields(
            { name: '👤 العضو', value: uLine(msg.author), inline: true }, { name: '📍 الروم', value: '<#' + msg.channelId + '>', inline: true },
            { name: '⚖️ المخالفات', value: arr.length + '/' + (C.strikeLimit || '∞') + ' خلال ' + C.strikeWindow + ' دقيقة', inline: true },
            { name: '📝 السبب', value: cut(v.why, 200), inline: false },
            { name: '🛠️ الإجراء', value: cut(acts.join('\n'), 500), inline: false });
    if (msg.content) e.addFields({ name: '💬 الرسالة', value: cut(msg.content, 700), inline: false });
    await sendLog(msg.guild, 'moderation', e);
}
async function moderate(msg, edited) {
    if (!inGuild(msg.guild) || !msg.author || msg.author.bot || !msg.member) return false;
    if (exempt(msg.member, msg.channelId)) return false;
    const v = detectChannel(msg) || detect(msg, edited);
    if (!v) return false;
    await punish(msg, v);
    return true;
}
async function onMessage(msg) {
    try { return await moderate(msg, false); } catch (e) { console.error('[organizer]', e.message); return false; }
}

// ───── ربط الأحداث ─────
const wrap = (fn) => async (...a) => { try { await fn(...a); } catch (e) { console.error('[organizer]', e && e.message); } };
try {
    client.on('messageDelete', wrap(onMessageDelete));
    client.on('messageUpdate', wrap(onMessageUpdate));
    client.on('messageDeleteBulk', wrap(onBulkDelete));
    client.on('guildMemberUpdate', wrap(onMemberUpdate));
    client.on('guildBanAdd', wrap((b) => onBan(b, true)));
    client.on('guildBanRemove', wrap((b) => onBan(b, false)));
    client.on('channelCreate', wrap(onChannelCreate));
    client.on('channelDelete', wrap(onChannelDelete));
    client.on('channelUpdate', wrap(onChannelUpdate));
    client.on('roleCreate', wrap(onRoleCreate));
    client.on('roleDelete', wrap(onRoleDelete));
    client.on('roleUpdate', wrap(onRoleUpdate));
} catch (e) { console.error('[organizer] events:', e.message); }

// ───── لوحة الإدارة ─────
const sess = (i) => session(i, 'og', () => ({ page: 'logs', cat: 'messages', rule: 'spam', rch: '' }));
const onTxt = (b) => b ? '🟢' : '⚫';
function ruleSummary(k) {
    const r = O().chat.rules[k];
    if (k === 'spam') return r.count + ' رسائل خلال ' + r.sec + 'ث';
    if (k === 'dup') return 'تكرار ' + r.count + ' مرات خلال ' + r.sec + 'ث';
    if (k === 'caps') return r.pct + '% (من ' + r.min + ' حرف)';
    if (k === 'mention') return 'أكثر من ' + r.max;
    if (k === 'emoji') return 'أكثر من ' + r.max;
    if (k === 'words') return r.list.length + ' كلمة';
    if (k === 'links' || k === 'invite') return r.allow.length ? 'مسموح: ' + r.allow.length : 'ممنوع الكل';
    return '';
}
function buildPanel(i) {
    const o = O(); const s = sess(i);
    const nav = row(
        btn('og:nav:logs', 'السجلات', '📜', s.page === 'logs' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        btn('og:nav:chat', 'تنظيم الشات', '🛡️', s.page === 'chat' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        btn('og:nav:rules', 'قواعد الرومات', '📌', s.page === 'rules' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        btn('og:nav:join', 'الانضمام', '🚪', s.page === 'join' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        btn('og:nav:exempt', 'الإعفاءات', '🔕', s.page === 'exempt' ? ButtonStyle.Primary : ButtonStyle.Secondary));

    if (s.page === 'chat') {
        const rs = RULES[s.rule]; const r = o.chat.rules[s.rule];
        const e = embed().setTitle('🛡️ تنظيم الشات')
            .setDescription('قواعد تحذف المخالفات وتنبّه العضو، ولو تكررت المخالفات يطبّق البوت تايم أوت تلقائي. المسؤولين وأصحاب صلاحية إدارة الرسائل معفيين دائماً.')
            .addFields(
                { name: 'القواعد', value: Object.entries(RULES).map(([k, v]) => onTxt(o.chat.rules[k].on) + ' ' + v.emoji + ' **' + v.name + '** — ' + (o.chat.rules[k].on ? ruleSummary(k) : 'متوقفة')).join('\n') },
                { name: '⚖️ العقوبة التصاعدية', value: o.chat.strikeLimit > 0 ? '**' + o.chat.strikeLimit + '** مخالفات خلال **' + o.chat.strikeWindow + '** دقيقة ⟵ تايم أوت **' + o.chat.timeoutMin + '** دقيقة' : 'معطّلة', inline: false },
                { name: '📍 المحددة الحين', value: rs.emoji + ' **' + rs.name + '** — ' + rs.desc + '\nالحالة: ' + (r.on ? '🟢 مفعّلة' : '⚫ متوقفة'), inline: false });
        return { embeds: [e], components: [nav,
            row(strSel('og:rsel', 'اختر قاعدة لتعديلها…', Object.entries(RULES).map(([k, v]) => ({ label: v.name, value: k, description: cut(v.desc + ' • ' + (o.chat.rules[k].on ? 'مفعّلة' : 'متوقفة'), 100), emoji: { name: v.emoji }, default: k === s.rule })))),
            row(btn('og:rtog', r.on ? 'إيقاف القاعدة' : 'تفعيل القاعدة', r.on ? '⏸️' : '▶️', r.on ? ButtonStyle.Danger : ButtonStyle.Success),
                btn('og:rset', 'قيم القاعدة', '⚙️', ButtonStyle.Primary), btn('og:cset', 'العقوبات والتنبيه', '⚖️', ButtonStyle.Primary), btn('og:rrec', 'تفعيل الموصى به', '⚡', ButtonStyle.Secondary))] };
    }
    if (s.page === 'rules') {
        const entries = Object.entries(o.chanRules);
        const e = embed().setTitle('📌 قواعد الرومات')
            .setDescription('خلّ روم معين لنوع واحد فقط من الرسائل، وأي رسالة تخالف تنحذف تلقائياً مع تنبيه للعضو.\nاختر الروم أولاً ثم اختر القاعدة (أو «إزالة القاعدة»).')
            .addFields(
                { name: 'القواعد الحالية (' + entries.length + ')', value: entries.length ? cut(entries.map(([c, m]) => '<#' + c + '> ⟵ ' + (MODES[m] || m)).join('\n'), 1000) : '`لا توجد قواعد`' },
                { name: '📍 الروم المحدد', value: s.rch ? '<#' + s.rch + '>' + (o.chanRules[s.rch] ? ' — ' + MODES[o.chanRules[s.rch]] : '') : '`اختر روماً من القائمة`' });
        return { embeds: [e], components: [nav,
            row(chSel('og:cch', 'اختر الروم', { min: 1, max: 1, selected: s.rch ? [s.rch] : [] })),
            row(strSel('og:cmode', s.rch ? 'اختر القاعدة لهذا الروم…' : 'اختر الروم أولاً', [...Object.entries(MODES).map(([k, v]) => ({ label: v.replace(/^\S+\s/, ''), value: k, emoji: { name: v.split(' ')[0] } })), { label: 'إزالة القاعدة', value: 'none', emoji: { name: '🗑️' } }], { disabled: !s.rch }))] };
    }
    if (s.page === 'join') {
        const R = o.join.raid;
        const e = embed().setTitle('🚪 حماية الانضمام')
            .addFields(
                { name: '🏅 رتبة تلقائية', value: o.join.role ? '<@&' + o.join.role + '>' : '`بدون`', inline: true },
                { name: '📅 أقل عمر للحساب', value: o.join.minDays > 0 ? '**' + o.join.minDays + '** يوم (يُطرد الأصغر)' : '`بدون`', inline: true },
                { name: '🚨 تنبيه الغارة', value: R.count > 0 ? '**' + R.count + '** عضو خلال **' + R.sec + '** ثانية' : '`متوقف`', inline: true })
            .setDescription('تنطبق على الأعضاء الجدد فقط. تنبيه الغارة والطرد يُرسلان لسجل «الأعضاء» و«الإشراف».');
        return { embeds: [e], components: [nav,
            row(roleSel('og:jrole', 'الرتبة التلقائية عند الانضمام (اختياري)', { min: 0, max: 1, selected: o.join.role ? [o.join.role] : [] })),
            row(btn('og:jage', 'عمر الحساب', '📅', ButtonStyle.Primary), btn('og:jraid', 'تنبيه الغارة', '🚨', ButtonStyle.Primary))] };
    }
    if (s.page === 'exempt') {
        const e = embed().setTitle('🔕 الإعفاءات')
            .setDescription('القواعد (تنظيم الشات وقواعد الرومات) ما تنطبق على:\n• المسؤولين وأصحاب صلاحية Administrator أو إدارة الرسائل\n• الرتب والرومات اللي تحددها هنا')
            .addFields({ name: '🏅 رتب معفاة', value: list(o.exemptRoles.map(r => '<@&' + r + '>')), inline: false }, { name: '📍 رومات معفاة', value: list(o.exemptChannels.map(c => '<#' + c + '>')), inline: false });
        return { embeds: [e], components: [nav,
            row(roleSel('og:xrole', 'رتب معفاة (حتى 10)', { min: 0, max: 10, selected: o.exemptRoles })),
            row(chSel('og:xch', 'رومات معفاة (حتى 10)', { min: 0, max: 10, selected: o.exemptChannels }))] };
    }
    // logs
    const c = LOGCATS[s.cat]; const cc = o.logs.cats[s.cat];
    const e = embed().setTitle('📜 سجلات السيرفر')
        .setDescription('كل نوع حدث يروح لروم، أو كلها لروم افتراضي واحد. السجلات تعرض مين سوّى الإجراء (من سجل التدقيق) إذا أعطيت البوت صلاحية **View Audit Log**.')
        .addFields(
            { name: '📍 الروم الافتراضي', value: chTxt(o.logs.default), inline: true },
            { name: '🤖 سجلات البوتات', value: o.logs.ignoreBots ? '⚫ مخفية' : '🟢 تظهر', inline: true },
            { name: 'الأنواع', value: Object.entries(LOGCATS).map(([k, v]) => onTxt(o.logs.cats[k].on) + ' ' + v.emoji + ' **' + v.name + '** ⟵ ' + (o.logs.cats[k].ch ? '<#' + o.logs.cats[k].ch + '>' : (o.logs.default ? '<#' + o.logs.default + '> *(افتراضي)*' : '`بدون روم`'))).join('\n') },
            { name: '📍 المحدد الحين', value: c.emoji + ' **' + c.name + '** — ' + c.desc, inline: false });
    return { embeds: [e], components: [nav,
        row(chSel('og:ldef', 'الروم الافتراضي لكل السجلات', { min: 0, max: 1, selected: o.logs.default ? [o.logs.default] : [] })),
        row(strSel('og:lcat', 'اختر نوع السجل لتخصيصه…', Object.entries(LOGCATS).map(([k, v]) => ({ label: v.name, value: k, description: v.desc, emoji: { name: v.emoji }, default: k === s.cat })))),
        row(chSel('og:lch', 'روم سجل «' + c.name + '» (فاضي = الافتراضي)', { min: 0, max: 1, selected: cc.ch ? [cc.ch] : [] })),
        row(btn('og:ltog', cc.on ? 'إيقاف ' + c.name : 'تفعيل ' + c.name, cc.on ? '⏸️' : '▶️', cc.on ? ButtonStyle.Danger : ButtonStyle.Success),
            btn('og:ltest', 'سجل تجريبي', '🧪', ButtonStyle.Secondary), btn('og:lbots', o.logs.ignoreBots ? 'إظهار سجلات البوتات' : 'إخفاء سجلات البوتات', '🤖', ButtonStyle.Secondary))] };
}
const refresh = (i) => update(i, buildPanel(i));

async function slash(i) {
    if (!(await adminOnly(i))) return;
    const s = sess(i); s.page = 'logs';
    return i.reply({ ...buildPanel(i), flags: EPH });
}
async function component(i) {
    if (!(await adminOnly(i))) return;
    const o = O(); const s = sess(i); const act = i.customId.split(':')[1];
    const R = o.chat.rules[s.rule];
    if (i.isButton()) {
        if (act === 'rset') {
            if (s.rule === 'spam') return i.showModal(modal('ogm:rset', 'قيم: ' + RULES.spam.name, input('a', 'عدد الرسائل', { required: true, max: 2, value: R.count }), input('b', 'خلال كم ثانية', { required: true, max: 3, value: R.sec })));
            if (s.rule === 'dup') return i.showModal(modal('ogm:rset', 'قيم: ' + RULES.dup.name, input('a', 'عدد مرات التكرار', { required: true, max: 2, value: R.count }), input('b', 'خلال كم ثانية', { required: true, max: 3, value: R.sec })));
            if (s.rule === 'caps') return i.showModal(modal('ogm:rset', 'قيم: ' + RULES.caps.name, input('a', 'نسبة الكابس %', { required: true, max: 3, value: R.pct }), input('b', 'أقل عدد حروف', { required: true, max: 3, value: R.min })));
            if (s.rule === 'mention') return i.showModal(modal('ogm:rset', 'قيم: ' + RULES.mention.name, input('a', 'أقصى عدد منشن بالرسالة', { required: true, max: 3, value: R.max })));
            if (s.rule === 'emoji') return i.showModal(modal('ogm:rset', 'قيم: ' + RULES.emoji.name, input('a', 'أقصى عدد إيموجي بالرسالة', { required: true, max: 3, value: R.max })));
            if (s.rule === 'words') return i.showModal(modal('ogm:rset', 'الكلمات الممنوعة', input('a', 'كلمة بكل سطر (*كلمة* = حتى داخل كلمة)', { required: false, paragraph: true, max: 4000, value: R.list.join('\n'), placeholder: 'كلمة1\nكلمة2\n*جزء_من_كلمة*' })));
            return i.showModal(modal('ogm:rset', s.rule === 'invite' ? 'دعوات مسموحة' : 'مواقع مسموحة',
                input('a', s.rule === 'invite' ? 'أكواد دعوات مسموحة (كود بكل سطر)' : 'دومينات مسموحة (دومين بكل سطر)', { required: false, paragraph: true, max: 2000, value: R.allow.join('\n'), placeholder: s.rule === 'invite' ? 'abc123' : 'youtube.com\ntwitch.tv' })));
        }
        if (act === 'cset') return i.showModal(modal('ogm:cset', 'العقوبات والتنبيه',
            input('lim', 'عدد المخالفات قبل التايم أوت (0 = بدون)', { required: true, max: 2, value: o.chat.strikeLimit }),
            input('win', 'خلال كم دقيقة', { required: true, max: 3, value: o.chat.strikeWindow }),
            input('tmo', 'مدة التايم أوت بالدقائق', { required: true, max: 5, value: o.chat.timeoutMin }),
            input('nt', 'تنبيه العضو بالروم؟ (نعم/لا)', { required: true, max: 3, value: o.chat.notice ? 'نعم' : 'لا' }),
            input('ns', 'يختفي التنبيه بعد كم ثانية', { required: true, max: 2, value: o.chat.noticeSec })));
        if (act === 'jage') return i.showModal(modal('ogm:jage', 'أقل عمر للحساب', input('d', 'عدد الأيام (0 = بدون)', { required: true, max: 3, value: o.join.minDays })));
        if (act === 'jraid') return i.showModal(modal('ogm:jraid', 'تنبيه الغارة',
            input('n', 'عدد الأعضاء (0 = متوقف)', { required: true, max: 3, value: o.join.raid.count }), input('t', 'خلال كم ثانية', { required: true, max: 3, value: o.join.raid.sec })));
        if (act === 'ltest') {
            await i.deferReply({ flags: EPH });
            const ch = await logChannel(i.guild, s.cat);
            if (!ch) return i.editReply({ content: '❌ هذا النوع بدون روم أو متوقف. حدد روماً (أو الروم الافتراضي) وفعّل النوع.' });
            try { await ch.send({ embeds: [logBase(BLURPLE, '🧪 سجل تجريبي — ' + LOGCATS[s.cat].name, i.user).setDescription('هكذا تظهر سجلات **' + LOGCATS[s.cat].name + '** هنا.').setFooter({ text: 'اختبار من ' + tag(i.user) })] }); return i.editReply({ content: '✅ أُرسل سجل تجريبي في <#' + ch.id + '>' }); }
            catch (e) { return i.editReply({ content: '❌ تعذّر الإرسال: ' + cut(e.message, 150) + ' (تأكد من صلاحيات البوت في الروم)' }); }
        }
        await i.deferUpdate();
        if (act === 'nav') s.page = ['logs', 'chat', 'rules', 'join', 'exempt'].includes(i.customId.split(':')[2]) ? i.customId.split(':')[2] : 'logs';
        else if (act === 'rtog') R.on = !R.on;
        else if (act === 'rrec') for (const k of ['spam', 'dup', 'invite', 'mention', 'emoji']) o.chat.rules[k].on = true;
        else if (act === 'ltog') o.logs.cats[s.cat].on = !o.logs.cats[s.cat].on;
        else if (act === 'lbots') o.logs.ignoreBots = !o.logs.ignoreBots;
        H.save();
        return i.editReply(buildPanel(i));
    }
    await i.deferUpdate();
    if (i.isStringSelectMenu()) {
        const v = i.values[0];
        if (act === 'lcat' && LOGCATS[v]) s.cat = v;
        else if (act === 'rsel' && RULES[v]) s.rule = v;
        else if (act === 'cmode' && s.rch) { if (v === 'none') delete o.chanRules[s.rch]; else if (MODES[v]) o.chanRules[s.rch] = v; }
    } else if (i.isChannelSelectMenu()) {
        if (act === 'ldef') o.logs.default = i.values[0] || '';
        else if (act === 'lch') o.logs.cats[s.cat].ch = i.values[0] || '';
        else if (act === 'cch') s.rch = i.values[0] || '';
        else if (act === 'xch') o.exemptChannels = i.values.slice(0, 10);
    } else if (i.isRoleSelectMenu()) {
        if (act === 'jrole') o.join.role = i.values[0] || '';
        else if (act === 'xrole') o.exemptRoles = i.values.slice(0, 10);
    }
    H.save();
    return i.editReply(buildPanel(i));
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const o = O(); const s = sess(i); const act = i.customId.split(':')[1];
    const val = (n) => { try { return i.fields.getTextInputValue(n).trim(); } catch { return ''; } };
    const num = (n) => parseInt(val(n).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)), 10);
    const bad = (m) => i.reply({ content: '❌ ' + m, flags: EPH });
    const R = o.chat.rules[s.rule];
    if (act === 'rset') {
        if (s.rule === 'spam' || s.rule === 'dup') { const a = num('a'), b = num('b'); if (!(a >= 2 && a <= 50) || !(b >= 1 && b <= 300)) return bad('العدد من 2 إلى 50 والثواني من 1 إلى 300.'); R.count = a; R.sec = b; }
        else if (s.rule === 'caps') { const a = num('a'), b = num('b'); if (!(a >= 30 && a <= 100) || !(b >= 5 && b <= 500)) return bad('النسبة من 30 إلى 100 والحروف من 5 إلى 500.'); R.pct = a; R.min = b; }
        else if (s.rule === 'mention' || s.rule === 'emoji') { const a = num('a'); if (!(a >= 1 && a <= 200)) return bad('الرقم من 1 إلى 200.'); R.max = a; }
        else if (s.rule === 'words') R.list = parseList(val('a')).slice(0, 300);
        else R.allow = parseList(val('a')).map(x => s.rule === 'links' ? x.replace(/^https?:\/\//i, '').replace(/\/.*$/, '') : x.replace(/^.*\//, '')).slice(0, 100);
    } else if (act === 'cset') {
        const lim = num('lim'), win = num('win'), tmo = num('tmo'), ns = num('ns');
        if (![lim, win, tmo, ns].every(Number.isFinite) || lim < 0 || lim > 20 || win < 1 || win > 1440 || tmo < 0 || tmo > 40320 || ns < 2 || ns > 30) return bad('تأكد من الأرقام (المخالفات 0–20، الدقائق 1–1440، التايم أوت حتى 40320 دقيقة، التنبيه 2–30 ثانية).');
        o.chat.strikeLimit = lim; o.chat.strikeWindow = win; o.chat.timeoutMin = tmo; o.chat.noticeSec = ns; o.chat.notice = !/^(لا|no|n)$/i.test(val('nt'));
    } else if (act === 'jage') { const d = num('d'); if (!(d >= 0 && d <= 365)) return bad('الأيام من 0 إلى 365.'); o.join.minDays = d; }
    else if (act === 'jraid') { const n = num('n'), t = num('t'); if (!(n >= 0 && n <= 100) || !(t >= 3 && t <= 600)) return bad('العدد من 0 إلى 100 والثواني من 3 إلى 600.'); o.join.raid = { count: n, sec: t }; }
    else return;
    H.save();
    return refresh(i);
}

const commands = [{ name: 'organize', description: 'تنظيم السيرفر: السجلات، تنظيم الشات، قواعد الرومات، حماية الانضمام (إدارة)' }];
return { prefix: 'og', commands, ephemeral: ['organize'], slash: { organize: slash }, component, modal: modalSubmit,
    onMessage, onMemberAdd, onMemberRemove, onVoiceState,
    _t: { norm, matchWords, detect, detectChannel, moderate, hist, strikes, onMessageDelete, onMessageUpdate, onBulkDelete, onMemberAdd, onMemberRemove, onMemberUpdate, onBan, onChannelCreate, onChannelDelete, onChannelUpdate, onRoleCreate, onRoleDelete, onRoleUpdate, onVoiceState, buildPanel, O } };
};
