'use strict';
/**
 * نظام الألوان /colors — رتب ألوان جاهزة للأعضاء
 *  • مجموعات ألوان منتقاة (تُنشئ الرتب تلقائياً) • عنوان القائمة • شكل الألوان (مربعة/دائرية) • خلفية الصورة (شفافة/داكنة)
 *  • الأعضاء: `colors!` تعرض القائمة بصورة + قائمة اختيار، و`color! رقم` أو `color! #hex` أو `color! 0` للإزالة
 */
module.exports = (H) => {
const { D, client, SERVER_ID, EPH, row, btn, strSel, input, modal, embed, cut, adminOnly, update, onOff, save, session } = H;
const { ButtonStyle, AttachmentBuilder, PermissionFlagsBits: P } = D;
const db = H.db;

// ───── المجموعات ─────
const hex2 = h => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const toHex = a => '#' + a.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('').toUpperCase();
function ramp(from, to, n) {
    const a = hex2(from), b = hex2(to);
    return Array.from({ length: n }, (_, i) => toHex(a.map((v, k) => v + (b[k] - v) * (n === 1 ? 0 : i / (n - 1)))));
}
const GROUPS = [
    { id: 'mono', name: 'أحادي اللون', emoji: '⚪', colors: ramp('#F2F2F2', '#2B2B2B', 11) },
    { id: 'sun', name: 'شمس متوهجة', emoji: '🌅', colors: ramp('#FFB000', '#FF3B00', 20) },
    { id: 'tea', name: 'شجرة الشاي', emoji: '🍃', colors: ramp('#6FAE92', '#2C4F41', 10) },
    { id: 'lake', name: 'بحيرة طبيعية', emoji: '🏞️', colors: ramp('#26A69A', '#00483C', 10) },
    { id: 'ocean', name: 'المحيط الأطلسي', emoji: '🌊', colors: ramp('#2196F3', '#0D47A1', 10) },
    { id: 'blood', name: 'الدم الأحمر', emoji: '🩸', colors: ramp('#C00000', '#4A0000', 10) },
    { id: 'purple', name: 'موضوع بنفسجي', emoji: '🔮', colors: ramp('#AB2DBF', '#3F1788', 10) },
    { id: 'forest', name: 'موضوع الغابة', emoji: '🌲', colors: ramp('#4CAF50', '#1B5E20', 17) },
    { id: 'rose', name: 'وردي ناعم', emoji: '🌸', colors: ramp('#FFB3CF', '#C2185B', 10) },
    { id: 'gold', name: 'ذهبي فاخر', emoji: '🥇', colors: ramp('#FFE082', '#8D6E00', 10) },
    { id: 'sky', name: 'سماء زرقاء', emoji: '☁️', colors: ramp('#B3E5FC', '#0277BD', 12) }
];

const cfg = () => {
    const c = (db.colors = db.colors || {});
    c.enabled = c.enabled !== false;
    c.title = c.title || 'قائمة الألوان';
    c.shape = c.shape === 'circle' ? 'circle' : 'square';
    c.bg = c.bg === 'dark' ? 'dark' : 'transparent';
    c.group = c.group || '';
    c.roles = Array.isArray(c.roles) ? c.roles : []; // [{ id, hex, n }]
    return c;
};

// ───── الصورة ─────
let Canvas = null;
try { Canvas = require('@napi-rs/canvas'); } catch {}
function textColorFor(hex) { const [r, g, b] = hex2(hex); return (r * 299 + g * 587 + b * 114) / 1000 > 150 ? '#111111' : '#FFFFFF'; }
async function renderPalette(list, c) {
    if (!Canvas || !list.length) return null;
    const cols = list.length <= 12 ? 4 : 5; const cell = 120, gap = 18, pad = 36, titleH = 110;
    const rows = Math.ceil(list.length / cols);
    const W = pad * 2 + cols * cell + (cols - 1) * gap, Hh = titleH + pad + rows * cell + (rows - 1) * gap;
    const cv = Canvas.createCanvas(W, Hh); const g = cv.getContext('2d');
    if (c.bg === 'dark') {
        const bg = g.createLinearGradient(0, 0, W, Hh); bg.addColorStop(0, '#0C1A3D'); bg.addColorStop(1, '#040A1A');
        g.fillStyle = bg; g.beginPath(); if (g.roundRect) g.roundRect(0, 0, W, Hh, 28); else g.rect(0, 0, W, Hh); g.fill();
    }
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillStyle = c.bg === 'dark' ? '#FFFFFF' : '#FFFFFF'; g.shadowColor = 'rgba(0,0,0,0.6)'; g.shadowBlur = 8;
    g.font = '800 54px ARKFont, "Noto Sans Arabic", Arial, sans-serif';
    g.fillText(c.title, W / 2, titleH / 2 + 8, W - 60);
    g.shadowBlur = 0;
    list.forEach((it, i) => {
        const x = pad + (i % cols) * (cell + gap), y = titleH + Math.floor(i / cols) * (cell + gap);
        g.fillStyle = it.hex;
        g.beginPath();
        if (c.shape === 'circle') g.arc(x + cell / 2, y + cell / 2, cell / 2, 0, Math.PI * 2);
        else if (g.roundRect) g.roundRect(x, y, cell, cell, 22); else g.rect(x, y, cell, cell);
        g.fill();
        g.lineWidth = 3; g.strokeStyle = 'rgba(255,255,255,0.35)'; g.stroke();
        g.fillStyle = textColorFor(it.hex); g.font = '800 44px ARKFont, Arial, sans-serif';
        g.fillText(String(it.n), x + cell / 2, y + cell / 2 - 8);
        g.font = '600 18px Arial, sans-serif'; g.globalAlpha = 0.85; g.fillText(it.hex, x + cell / 2, y + cell / 2 + 30); g.globalAlpha = 1;
    });
    return cv.toBuffer('image/png');
}

// ───── الرتب ─────
const colorRoleIds = () => new Set(cfg().roles.map(r => r.id));
async function applyGroup(guild, groupId) {
    const c = cfg(); const grp = GROUPS.find(x => x.id === groupId);
    if (!grp) throw new Error('مجموعة غير معروفة.');
    const me = guild.members.me;
    if (!me || !me.permissions.has(P.ManageRoles)) throw new Error('البوت يحتاج صلاحية Manage Roles.');
    for (const r of c.roles) { const role = guild.roles.cache.get(r.id) || await guild.roles.fetch(r.id).catch(() => null); if (role) await role.delete('تغيير مجموعة الألوان').catch(() => {}); }
    c.roles = [];
    const top = me.roles.highest ? me.roles.highest.position : 1;
    let n = 0;
    for (const hex of grp.colors) {
        n++;
        const role = await guild.roles.create({ name: 'color ' + n, color: parseInt(hex.slice(1), 16), permissions: [], mentionable: false, hoist: false, reason: 'نظام الألوان: ' + grp.name });
        try { await role.setPosition(Math.max(1, top - 1)); } catch {}
        c.roles.push({ id: role.id, hex, n });
    }
    c.group = grp.id; save();
    return grp;
}
async function setMemberColor(member, entry) {
    const ids = [...colorRoleIds()];
    const have = member.roles.cache.filter(r => ids.includes(r.id));
    if (have.size) await member.roles.remove([...have.keys()], 'تغيير اللون').catch(() => {});
    if (entry) await member.roles.add(entry.id, 'اختيار لون');
}
function findEntry(q) {
    const c = cfg(); const t = String(q || '').trim();
    if (/^\d{1,2}$/.test(t)) return c.roles.find(r => r.n === parseInt(t, 10)) || null;
    if (/^#?[0-9a-f]{6}$/i.test(t)) {
        const h = (t.startsWith('#') ? t : '#' + t).toUpperCase();
        const [r, g, b] = hex2(h);
        let best = null, bd = Infinity;
        for (const e of c.roles) { const [r2, g2, b2] = hex2(e.hex); const d = (r - r2) ** 2 + (g - g2) ** 2 + (b - b2) ** 2; if (d < bd) { bd = d; best = e; } }
        return best;
    }
    return null;
}

// ───── للأعضاء ─────
async function paletteMessage() {
    const c = cfg();
    const e = embed().setTitle('🎨 ' + c.title).setDescription('اختر لونك من القائمة بالأسفل، أو اكتب `color! رقم` (مثال: `color! 3`)، و`color! 0` لإزالة لونك.');
    const rows = [];
    for (let k = 0; k < c.roles.length && rows.length < 4; k += 25) {
        const chunk = c.roles.slice(k, k + 25);
        rows.push(row(strSel('co:pick' + (k ? k : ''), 'اختر لونك' + (c.roles.length > 25 ? ' (' + (k + 1) + '-' + (k + chunk.length) + ')' : '') + '...', chunk.map(r => ({ label: 'لون ' + r.n, value: r.id, description: r.hex, emoji: undefined })))));
    }
    rows.push(row(btn('co:none', 'إزالة لوني', '🧹')));
    const files = []; const buf = await renderPalette(c.roles, c).catch(e2 => { console.warn('[colors] image:', e2.message); return null; });
    if (buf) { files.push(new AttachmentBuilder(buf, { name: 'colors.png' })); e.setImage('attachment://colors.png'); }
    else e.addFields({ name: 'الألوان', value: cut(c.roles.map(r => '`' + r.n + '` ' + r.hex).join(' • '), 1000) || '—' });
    return { embeds: [e], components: rows, files };
}
async function cmdColors(msg) {
    const c = cfg();
    if (!c.enabled) return msg.reply({ content: '⛔ نظام الألوان متوقف.' });
    if (!c.roles.length) return msg.reply({ content: 'ℹ️ لم تُجهّز الألوان بعد. الإدارة تستخدم `/colors`.' });
    return msg.channel.send({ ...(await paletteMessage()), allowedMentions: { parse: [] } });
}
async function cmdColor(msg, args) {
    const c = cfg();
    if (!c.enabled) return msg.reply({ content: '⛔ نظام الألوان متوقف.' });
    if (!c.roles.length) return msg.reply({ content: 'ℹ️ لم تُجهّز الألوان بعد.' });
    const t = String(args || '').trim();
    if (!t) return msg.reply({ content: 'ℹ️ اكتب `color! رقم` (مثال `color! 3`) أو `color! #FF0000` أو `colors!` لعرض القائمة، و`color! 0` للإزالة.' });
    try {
        if (t === '0' || /^(remove|إزالة|ازالة)$/i.test(t)) { await setMemberColor(msg.member, null); return msg.reply({ content: '✅ تمت إزالة لونك.' }); }
        const en = findEntry(t);
        if (!en) return msg.reply({ content: '❌ ما لقيت هذا اللون. اكتب `colors!` لعرض القائمة.' });
        await setMemberColor(msg.member, en);
        return msg.reply({ content: '✅ تم تغيير لونك إلى **' + en.n + '** (`' + en.hex + '`).' });
    } catch (e) { return msg.reply({ content: '❌ ما قدرت أغيّر لونك: ' + cut(e.message, 120) + '\nتأكد أن رتبة البوت أعلى من رتب الألوان.' }); }
}

// ───── القائمة /colors ─────
const st = i => session(i, 'co', () => ({}));
function view() {
    const c = cfg();
    const grp = GROUPS.find(x => x.id === c.group);
    const e = embed().setTitle('🎨 نظام الألوان')
        .setDescription('إدارة رتب الألوان في السيرفر وتطبيق المجموعات الاحترافية.')
        .addFields(
            { name: 'الحالة', value: onOff(c.enabled), inline: true },
            { name: 'المجموعة الحالية', value: grp ? grp.emoji + ' ' + grp.name + ' (' + c.roles.length + ' لون)' : '`لم تُطبَّق`', inline: true },
            { name: 'العنوان', value: '`' + c.title + '`', inline: true },
            { name: 'الشكل', value: c.shape === 'circle' ? '⚪ دائرية' : '⬜ مربعة', inline: true },
            { name: 'الخلفية', value: c.bg === 'dark' ? '🌑 داكنة' : '🔲 شفافة', inline: true },
            { name: 'الأوامر', value: '`colors!` عرض القائمة • `color! رقم` تغيير اللون', inline: false }
        );
    return { embeds: [e], components: [
        row(strSel('co:group', 'اختر مجموعة ألوان لتطبيقها (تنشئ الرتب تلقائياً)...', GROUPS.map(g => ({ label: g.name, value: g.id, emoji: g.emoji, description: g.colors.length + ' ألوان', default: g.id === c.group })))),
        row(strSel('co:shape', 'شكل الألوان', [{ label: 'مربعة', value: 'square', emoji: '⬜', default: c.shape === 'square' }, { label: 'دائرية', value: 'circle', emoji: '⚪', default: c.shape === 'circle' }])),
        row(strSel('co:bg', 'خلفية صورة القائمة', [{ label: 'شفافة', value: 'transparent', emoji: '🔲', default: c.bg === 'transparent' }, { label: 'داكنة', value: 'dark', emoji: '🌑', default: c.bg === 'dark' }])),
        row(btn('co:toggle', c.enabled ? 'إيقاف النظام' : 'تشغيل النظام', c.enabled ? '⛔' : '✅', c.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
            btn('co:title', 'عنوان القائمة', '✏️', ButtonStyle.Primary),
            btn('co:send', 'إرسال القائمة هنا', '📤', ButtonStyle.Primary, !c.roles.length),
            btn('co:clear', 'حذف رتب الألوان', '🗑️', ButtonStyle.Danger, !c.roles.length))
    ] };
}
async function slash(i) { if (!(await adminOnly(i))) return; return i.reply({ ...view(), flags: EPH }); }
async function component(i) {
    const a = i.customId.split(':')[1];
    const c = cfg();
    // الأعضاء
    if (a.startsWith('pick') || a === 'none') {
        if (!c.enabled) return i.reply({ content: '⛔ نظام الألوان متوقف.', flags: EPH });
        await i.deferReply({ flags: EPH });
        try {
            if (a === 'none') { await setMemberColor(i.member, null); return i.editReply({ content: '✅ تمت إزالة لونك.' }); }
            const en = c.roles.find(r => r.id === i.values[0]); if (!en) return i.editReply({ content: '❌ هذا اللون لم يعد متاحاً.' });
            await setMemberColor(i.member, en);
            return i.editReply({ content: '✅ تم تغيير لونك إلى **' + en.n + '** (`' + en.hex + '`).' });
        } catch (e) { return i.editReply({ content: '❌ ما قدرت أغيّر لونك: ' + cut(e.message, 120) + '\nتأكد أن رتبة البوت أعلى من رتب الألوان.' }); }
    }
    // الإدارة
    if (!(await adminOnly(i))) return;
    if (a === 'title') return i.showModal(modal('com:title', 'عنوان قائمة الألوان', input('title', 'العنوان الرئيسي في الصورة', { max: 40, value: c.title, required: true })));
    if (a === 'group') {
        await i.deferUpdate();
        try { await applyGroup(i.guild, i.values[0]); await i.editReply(view()); return i.followUp({ content: '✅ تم إنشاء رتب المجموعة. تأكد أن رتبة البوت أعلى منها، وارفع رتب الألوان فوق الرتب الملوّنة الأخرى لتظهر ألوانها.', flags: EPH }); }
        catch (e) { await i.editReply(view()); return i.followUp({ content: '❌ ' + e.message, flags: EPH }); }
    }
    if (a === 'send') { await i.deferUpdate(); await i.channel.send({ ...(await paletteMessage()), allowedMentions: { parse: [] } }).catch(e => i.followUp({ content: '❌ ' + e.message, flags: EPH })); return i.editReply(view()); }
    if (a === 'clear') {
        await i.deferUpdate();
        for (const r of c.roles) { const role = i.guild.roles.cache.get(r.id); if (role) await role.delete('حذف رتب الألوان').catch(() => {}); }
        c.roles = []; c.group = ''; save(); return i.editReply(view());
    }
    if (a === 'toggle') c.enabled = !c.enabled;
    else if (a === 'shape') c.shape = i.values[0] === 'circle' ? 'circle' : 'square';
    else if (a === 'bg') c.bg = i.values[0] === 'dark' ? 'dark' : 'transparent';
    save();
    return update(i, view());
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    cfg().title = i.fields.getTextInputValue('title').trim() || 'قائمة الألوان'; save();
    return i.isFromMessage && i.isFromMessage() ? update(i, view()) : i.reply({ content: '✅ تم الحفظ.', flags: EPH });
}
const commands = [{ name: 'colors', description: 'نظام الألوان: مجموعات رتب ملوّنة وقائمة اختيار للأعضاء (إدارة)' }];
H.colors = { cmdColor, cmdColors };
return { prefix: 'co', commands, ephemeral: ['colors'], slash: { colors: slash }, component, modal: modalSubmit };
};
