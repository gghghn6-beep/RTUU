'use strict';
/**
 * أوامر مساعدة: قفل/فتح، مسح، سلومود، معلومات سيرفر/عضو، أفاتار، رتبة تلقائية
 */
module.exports = (H) => {
const { D, client, BLUE, isAdmin, SERVER_ID, save, EPH, row, btn, roleSel, embed, cut, adminOnly, update, onOff, roleTxt, chTxt } = H;
const db = H.db;
const { ButtonStyle, PermissionFlagsBits, ChannelType } = D;

const cfg = () => {
    const u = (db.utils = db.utils || {});
    u.autorole = u.autorole || { enabled: false, roleId: '' };
    return u;
};

// ───── Lock / Unlock ─────
async function lockChannel(channel, locked) {
    const everyone = channel.guild.roles.everyone;
    const perms = {
        SendMessages: locked ? false : null,
        AddReactions: locked ? false : null,
        CreatePublicThreads: locked ? false : null,
        CreatePrivateThreads: locked ? false : null,
        SendMessagesInThreads: locked ? false : null,
        AttachFiles: locked ? false : null
    };
    await channel.permissionOverwrites.edit(everyone, perms);
}

async function cmdLock(i, lockAll = false) {
    if (!(await adminOnly(i))) return;
    const chOpt = i.options?.getChannel?.('channel');
    const target = chOpt || i.channel;
    if (!target || !target.isTextBased?.()) {
        return i.reply({ content: '❌ لازم قناة نصية.', flags: EPH });
    }
    try {
        if (lockAll) {
            let n = 0;
            for (const ch of i.guild.channels.cache.values()) {
                if (ch.isTextBased?.() && ch.permissionOverwrites) {
                    try { await lockChannel(ch, true); n++; } catch {}
                }
            }
            return i.reply({ content: `🔒 تم قفل **${n}** قناة (طوارئ).`, flags: EPH });
        }
        await lockChannel(target, true);
        return i.reply({ content: `🔒 تم قفل ${target}.`, flags: EPH });
    } catch (e) {
        return i.reply({ content: '❌ ' + cut(e.message, 150), flags: EPH });
    }
}

async function cmdUnlock(i, unlockAll = false) {
    if (!(await adminOnly(i))) return;
    const chOpt = i.options?.getChannel?.('channel');
    const target = chOpt || i.channel;
    try {
        if (unlockAll) {
            let n = 0;
            for (const ch of i.guild.channels.cache.values()) {
                if (ch.isTextBased?.() && ch.permissionOverwrites) {
                    try { await lockChannel(ch, false); n++; } catch {}
                }
            }
            return i.reply({ content: `🔓 تم فتح **${n}** قناة.`, flags: EPH });
        }
        await lockChannel(target, false);
        return i.reply({ content: `🔓 تم فتح ${target}.`, flags: EPH });
    } catch (e) {
        return i.reply({ content: '❌ ' + cut(e.message, 150), flags: EPH });
    }
}

// ───── Clear ─────
async function cmdClear(i) {
    if (!(await adminOnly(i))) return;
    const amount = i.options.getInteger('amount') || 10;
    if (amount < 1 || amount > 100) return i.reply({ content: '❌ بين 1 و 100.', flags: EPH });
    try {
        const deleted = await i.channel.bulkDelete(amount, true);
        return i.reply({ content: `🗑️ تم حذف **${deleted.size}** رسالة.`, flags: EPH });
    } catch (e) {
        return i.reply({ content: '❌ ' + cut(e.message, 150), flags: EPH });
    }
}

// ───── Slowmode ─────
async function cmdSlowmode(i) {
    if (!(await adminOnly(i))) return;
    const seconds = i.options.getInteger('seconds') ?? 0;
    if (seconds < 0 || seconds > 21600) return i.reply({ content: '❌ بين 0 و 21600.', flags: EPH });
    try {
        await i.channel.setRateLimitPerUser(seconds);
        return i.reply({ content: seconds === 0 ? '✅ تم إلغاء السلومود.' : `🐌 السلومود: **${seconds}** ثانية.`, flags: EPH });
    } catch (e) {
        return i.reply({ content: '❌ ' + cut(e.message, 150), flags: EPH });
    }
}

// ───── Server / User info / Avatar ─────
async function cmdServerInfo(i) {
    const g = i.guild;
    if (!g) return i.reply({ content: '❌ في سيرفر فقط.', flags: EPH });
    const owner = await g.fetchOwner().catch(() => null);
    const e = embed()
        .setTitle(g.name)
        .setThumbnail(g.iconURL({ size: 256 }))
        .addFields(
            { name: 'المالك', value: owner ? `${owner.user.tag}` : '—', inline: true },
            { name: 'الأعضاء', value: String(g.memberCount), inline: true },
            { name: 'القنوات', value: String(g.channels.cache.size), inline: true },
            { name: 'الرتب', value: String(g.roles.cache.size), inline: true },
            { name: 'تاريخ الإنشاء', value: `<t:${Math.floor(g.createdTimestamp / 1000)}:R>`, inline: true },
            { name: 'المستوى', value: `Boost ${g.premiumTier} (${g.premiumSubscriptionCount || 0})`, inline: true },
            { name: 'الآيدي', value: `\`${g.id}\``, inline: false }
        )
        .setColor(BLUE);
    if (g.bannerURL()) e.setImage(g.bannerURL({ size: 512 }));
    return i.reply({ embeds: [e] });
}

async function cmdUserInfo(i) {
    const user = i.options.getUser('user') || i.user;
    const member = await i.guild.members.fetch(user.id).catch(() => null);
    const e = embed()
        .setTitle(user.tag)
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .addFields(
            { name: 'الآيدي', value: `\`${user.id}\``, inline: true },
            { name: 'بوت؟', value: user.bot ? 'نعم' : 'لا', inline: true },
            { name: 'إنشاء الحساب', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true }
        )
        .setColor(BLUE);
    if (member) {
        e.addFields(
            { name: 'الانضمام', value: member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : '—', inline: true },
            { name: 'الرتب', value: member.roles.cache.filter(r => r.id !== i.guild.id).map(r => r.toString()).slice(0, 15).join(' ') || 'لا يوجد', inline: false },
            { name: 'أعلى رتبة', value: member.roles.highest?.toString() || '—', inline: true }
        );
        if (member.premiumSince) e.addFields({ name: 'بوست منذ', value: `<t:${Math.floor(member.premiumSinceTimestamp / 1000)}:R>`, inline: true });
    }
    return i.reply({ embeds: [e] });
}

async function cmdAvatar(i) {
    const user = i.options.getUser('user') || i.user;
    const url = user.displayAvatarURL({ size: 4096, extension: 'png' });
    const e = embed().setTitle(`أفاتار — ${user.tag}`).setImage(url).setColor(BLUE);
    return i.reply({ embeds: [e] });
}

// ───── Autorole ─────
async function onMemberAdd(member) {
    const u = cfg();
    if (!u.autorole?.enabled || !u.autorole.roleId) return;
    try {
        await member.roles.add(u.autorole.roleId, 'رتبة تلقائية');
    } catch (e) {
        console.error('[autorole]', e.message);
    }
}

function buildAutorolePanel() {
    const u = cfg();
    const e = embed()
        .setTitle('🎭 رتبة تلقائية (Autorole)')
        .setDescription('تُعطى تلقائياً لكل عضو جديد.')
        .addFields(
            { name: 'الحالة', value: onOff(u.autorole.enabled), inline: true },
            { name: 'الرتبة', value: roleTxt(u.autorole.roleId), inline: true }
        );
    return {
        embeds: [e],
        components: [
            row(
                btn('util:ar:toggle', u.autorole.enabled ? 'إيقاف' : 'تشغيل', u.autorole.enabled ? '⛔' : '✅', u.autorole.enabled ? ButtonStyle.Danger : ButtonStyle.Success)
            ),
            row(roleSel('util:ar:set', 'اختر الرتبة التلقائية'))
        ]
    };
}

async function slashAutorole(i) {
    if (!(await adminOnly(i))) return;
    return i.reply({ ...buildAutorolePanel(), flags: EPH });
}

async function component(i) {
    if (!(await adminOnly(i))) return;
    const parts = i.customId.split(':');
    if (parts[0] !== 'util') return;
    const u = cfg();
    if (parts[1] === 'ar') {
        if (parts[2] === 'toggle') {
            u.autorole.enabled = !u.autorole.enabled; H.save();
            return update(i, buildAutorolePanel());
        }
        if (parts[2] === 'set') {
            u.autorole.roleId = i.values[0]; H.save();
            return update(i, buildAutorolePanel());
        }
    }
}

// Prefix handlers for Arabic
async function onMessage(msg) {
    if (!msg.guild || msg.author.bot) return false;
    const content = (msg.content || '').trim();
    if (!content.startsWith('-')) return false;
    const parts = content.slice(1).split(/\s+/);
    const cmd = (parts[0] || '').toLowerCase();
    const arg = parts[1];

    // only admins for mod commands
    const needAdmin = ['قفل', 'فتح', 'قفل_الكل', 'مسح', 'سلومود'].includes(cmd);
    if (needAdmin && !isAdmin(msg.member)) return false;

    if (cmd === 'قفل') {
        try {
            const ch = arg ? msg.guild.channels.cache.get(arg.replace(/[<#>]/g, '')) : msg.channel;
            await lockChannel(ch || msg.channel, true);
            await msg.reply(`🔒 تم قفل ${ch || msg.channel}`);
        } catch (e) { await msg.reply('❌ ' + cut(e.message, 100)); }
        return true;
    }
    if (cmd === 'فتح') {
        try {
            const ch = arg ? msg.guild.channels.cache.get(arg.replace(/[<#>]/g, '')) : msg.channel;
            await lockChannel(ch || msg.channel, false);
            await msg.reply(`🔓 تم فتح ${ch || msg.channel}`);
        } catch (e) { await msg.reply('❌ ' + cut(e.message, 100)); }
        return true;
    }
    if (cmd === 'قفل_الكل') {
        let n = 0;
        for (const ch of msg.guild.channels.cache.values()) {
            if (ch.isTextBased?.()) { try { await lockChannel(ch, true); n++; } catch {} }
        }
        await msg.reply(`🔒 تم قفل ${n} قناة`);
        return true;
    }
    if (cmd === 'مسح') {
        const n = Math.min(100, Math.max(1, parseInt(arg, 10) || 10));
        try {
            const del = await msg.channel.bulkDelete(n + 1, true); // +1 for the command
            const m = await msg.channel.send(`🗑️ تم حذف ${del.size - 1} رسالة`);
            setTimeout(() => m.delete().catch(() => {}), 4000);
        } catch (e) { await msg.reply('❌ ' + cut(e.message, 100)); }
        return true;
    }
    return false;
}

const commands = [
    { name: 'lock', description: 'قفل قناة (منع الكتابة)', options: [{ name: 'channel', description: 'القناة (اختياري)', type: 7, required: false, channel_types: [0, 5] }] },
    { name: 'unlock', description: 'فتح قناة', options: [{ name: 'channel', description: 'القناة (اختياري)', type: 7, required: false, channel_types: [0, 5] }] },
    { name: 'lockdown', description: 'قفل كل القنوات النصية (طوارئ)' },
    { name: 'unlockall', description: 'فتح كل القنوات' },
    { name: 'clear', description: 'مسح رسائل', options: [{ name: 'amount', description: 'العدد (1-100)', type: 4, required: false, min_value: 1, max_value: 100 }] },
    { name: 'slowmode', description: 'تعيين السلومود', options: [{ name: 'seconds', description: 'الثواني (0 لإلغاء)', type: 4, required: true, min_value: 0, max_value: 21600 }] },
    { name: 'serverinfo', description: 'معلومات السيرفر' },
    { name: 'userinfo', description: 'معلومات عضو', options: [{ name: 'user', description: 'العضو', type: 6, required: false }] },
    { name: 'avatar', description: 'عرض الأفاتار', options: [{ name: 'user', description: 'العضو', type: 6, required: false }] },
    { name: 'autorole', description: 'إعداد الرتبة التلقائية للأعضاء الجدد' }
];

const slash = {
    lock: (i) => cmdLock(i, false),
    unlock: (i) => cmdUnlock(i, false),
    lockdown: (i) => cmdLock(i, true),
    unlockall: (i) => cmdUnlock(i, true),
    clear: cmdClear,
    slowmode: cmdSlowmode,
    serverinfo: cmdServerInfo,
    userinfo: cmdUserInfo,
    avatar: cmdAvatar,
    autorole: slashAutorole
};

return {
    prefix: 'util',
    commands,
    ephemeral: ['lock', 'unlock', 'lockdown', 'unlockall', 'clear', 'slowmode', 'autorole'],
    slash,
    component,
    onMessage,
    onMemberAdd
};
};
