'use strict';
/**
 * مساعد الذكاء الاصطناعي /ai — يتكلم مع الأعضاء في الرومات المحددة أو عند منشنه،
 * وينفّذ أوامر صوتية: يدخل/يطلع من الروم، يشغّل يوتيوب أو القرآن، يوقف/يتخطى/يغيّر الصوت.
 *
 * المفتاح يُوضع في متغير البيئة ANTHROPIC_API_KEY (لا يُحفظ في أي ملف).
 * النموذج: AI_MODEL (افتراضي claude-haiku-5-5 — الأسرع).
 */
module.exports = (H) => {
const { D, client, SERVER_ID, EPH, row, btn, chSel, roleSel, input, modal, embed, cut, adminOnly, update, chTxt, onOff, save, session } = H;
const { ButtonStyle, ChannelType } = D;
const db = H.db;

const cfg = () => {
    const a = (db.ai = db.ai || {});
    a.enabled = !!a.enabled;
    a.channels = Array.isArray(a.channels) ? a.channels : [];
    a.mention = a.mention !== false;            // الرد عند المنشن في أي روم
    a.voiceControl = a.voiceControl !== false;  // السماح بالأوامر الصوتية
    a.controlRoles = Array.isArray(a.controlRoles) ? a.controlRoles : []; // فاضي = الكل
    a.persona = a.persona || '';
    a.name = a.name || '';
    return a;
};
const MODEL = () => process.env.AI_MODEL || 'claude-haiku-5-5';
const hasKey = () => !!process.env.ANTHROPIC_API_KEY;

// ───── الذاكرة والحدود ─────
const memory = new Map();   // channelId -> { at, msgs: [{role, content}] }
const lastAt = new Map();   // userId -> ts
const perMin = new Map();   // userId -> [ts]
const MEM_TTL = 30 * 60 * 1000, MEM_MAX = 14;
function allow(uid) {
    const now = Date.now();
    if (now - (lastAt.get(uid) || 0) < 1500) return false;
    const arr = (perMin.get(uid) || []).filter(t => now - t < 60000);
    if (arr.length >= 15) return false;
    arr.push(now); perMin.set(uid, arr); lastAt.set(uid, now); return true;
}
function getMem(chId) {
    const m = memory.get(chId);
    if (!m || Date.now() - m.at > MEM_TTL) { const n = { at: Date.now(), msgs: [] }; memory.set(chId, n); return n; }
    m.at = Date.now(); return m;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of memory) if (now - v.at > MEM_TTL) memory.delete(k); }, 10 * 60 * 1000).unref();

// ───── الأدوات ─────
const TOOLS = [
    { name: 'voice_join', description: 'ادخل الروم الصوتي الذي فيه المستخدم الآن.', input_schema: { type: 'object', properties: {} } },
    { name: 'voice_leave', description: 'اطلع من الروم الصوتي وأوقف أي تشغيل.', input_schema: { type: 'object', properties: {} } },
    { name: 'play_youtube', description: 'شغّل مقطعاً من يوتيوب (بحث بالاسم أو رابط) في روم المستخدم الصوتي.', input_schema: { type: 'object', properties: { query: { type: 'string', description: 'اسم المقطع/الأغنية أو رابط يوتيوب' }, queue: { type: 'boolean', description: 'true لإضافته للانتظار بدل استبدال الحالي' } }, required: ['query'] } },
    { name: 'play_quran', description: 'شغّل سورة من القرآن الكريم في روم المستخدم الصوتي.', input_schema: { type: 'object', properties: { surah: { type: 'string', description: 'اسم السورة أو رقمها' }, reciter: { type: 'string', description: 'اسم القارئ (اختياري)' } }, required: ['surah'] } },
    { name: 'music_control', description: 'تحكم بالتشغيل الحالي.', input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['pause', 'resume', 'stop', 'skip'] } }, required: ['action'] } },
    { name: 'set_volume', description: 'غيّر مستوى الصوت من 0 إلى 150.', input_schema: { type: 'object', properties: { volume: { type: 'number' } }, required: ['volume'] } },
    { name: 'now_playing', description: 'اعرف ما الذي يعمل الآن.', input_schema: { type: 'object', properties: {} } }
];

function canControl(member) {
    const c = cfg();
    if (!c.voiceControl) return 'الأوامر الصوتية موقوفة من الإدارة.';
    if (!H.music) return 'المشغّل الصوتي غير متاح.';
    if (c.controlRoles.length && !H.isAdmin(member) && !member.roles.cache.some(r => c.controlRoles.includes(r.id))) return 'ما عندك صلاحية التحكم الصوتي.';
    return null;
}
async function runTool(name, args, ctx) {
    const M = H.music; const { member, guild } = ctx;
    const denied = canControl(member); if (denied) return { ok: false, error: denied };
    try {
        if (name === 'voice_join') {
            const st0 = await M.join(member);
            const ch = guild.channels.cache.get(st0.channelId);
            return { ok: true, message: 'دخلت ' + (ch ? ch.name : 'الروم') };
        }
        if (name === 'voice_leave') {
            const had = !!M.state(guild.id);
            M.leave(guild.id);
            try { const v = require('@discordjs/voice'); const c = v.getVoiceConnection(guild.id); if (c) { c.destroy(); return { ok: true, message: 'طلعت من الروم.' }; } } catch {}
            return had ? { ok: true, message: 'طلعت من الروم.' } : { ok: false, error: 'أنا مو في روم صوتي.' };
        }
        if (name === 'play_youtube') {
            const t = await M.youtubeTrack(args.query);
            const r = await M.play(member, t, args.queue ? 'queue' : 'now', ctx.channel.id);
            return { ok: true, message: (r.queued ? 'أضفته للانتظار: ' : 'يشتغل الآن: ') + t.title };
        }
        if (name === 'play_quran') {
            const t = await M.quranTrack(args.surah, args.reciter);
            await M.play(member, t, 'now', ctx.channel.id);
            return { ok: true, message: 'يشتغل الآن: ' + t.title + ' — ' + (t.sub || '') };
        }
        if (name === 'music_control') {
            const f = { pause: M.pause, resume: M.resume, stop: M.stop, skip: M.skip }[args.action];
            return f && f(guild.id) ? { ok: true, message: 'تم: ' + args.action } : { ok: false, error: 'ما في شيء يشتغل.' };
        }
        if (name === 'set_volume') { const n = M.setVolume(guild.id, args.volume); return n === false ? { ok: false, error: 'قيمة غير صالحة.' } : { ok: true, message: 'الصوت الآن ' + n + '%' }; }
        if (name === 'now_playing') { const n = M.nowPlaying(guild.id); return n ? { ok: true, message: 'يشتغل: ' + n.track.title + (n.paused ? ' (متوقف مؤقتاً)' : '') + ' — في الانتظار: ' + n.queue } : { ok: true, message: 'ما في شيء يشتغل الآن.' }; }
        return { ok: false, error: 'أداة غير معروفة.' };
    } catch (e) { return { ok: false, error: e.message }; }
}

// ───── الاتصال بالنموذج ─────
function systemPrompt(msg) {
    const c = cfg();
    const g = msg.guild; const name = c.name || (client.user && client.user.username) || 'المساعد';
    const inVoice = msg.member && msg.member.voice && msg.member.voice.channel ? msg.member.voice.channel.name : null;
    return [
        'أنت «' + name + '»، مساعد ذكي داخل سيرفر ديسكورد اسمه «' + (g ? g.name : '') + '». تتكلم بالعربية بلهجة ودودة ومهذبة وبسيطة (لهجة خليجية خفيفة)، وترد على لغة المستخدم لو كلمك بلغة ثانية.',
        'ردودك قصيرة ومباشرة (جملة إلى ثلاث جمل غالباً) إلا إذا طلب شرحاً. لا تكرر السؤال ولا تعتذر بلا داعي. لا تستخدم منشن @everyone أو @here أبداً.',
        'لديك أدوات تتحكم بالصوت: الدخول والخروج من الروم الصوتي، تشغيل يوتيوب، تشغيل القرآن، إيقاف/تخطي/صوت. استخدم الأداة المناسبة فور طلب المستخدم ثم أكّد له بجملة قصيرة. عبارات مثل «اطلع برا الروم» تعني voice_leave، و«ادخل» تعني voice_join، و«شغّل قرآن/سورة كذا» تعني play_quran، و«شغّل مقطع/أغنية» تعني play_youtube.',
        'لا تدّعِ أنك نفذت شيئاً إلا إذا نجحت الأداة. لو فشلت الأداة اشرح السبب للمستخدم ببساطة.',
        'المستخدم: ' + (msg.member ? msg.member.displayName : msg.author.username) + '. ' + (inVoice ? 'هو الآن في الروم الصوتي «' + inVoice + '».' : 'هو ليس في روم صوتي حالياً.'),
        c.persona ? 'تعليمات إضافية من الإدارة: ' + c.persona : ''
    ].filter(Boolean).join('\n');
}
async function callModel(system, messages, useTools) {
    const body = { model: MODEL(), max_tokens: 500, system, messages };
    if (useTools) body.tools = TOOLS;
    const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify(body), signal: AbortSignal.timeout(45000)
    });
    if (!res.ok) { const t = await res.text().catch(() => ''); throw new Error('API ' + res.status + ': ' + cut(t, 200)); }
    return res.json();
}
async function converse(msg, userText) {
    const mem = getMem(msg.channelId);
    mem.msgs.push({ role: 'user', content: (msg.member ? msg.member.displayName : msg.author.username) + ': ' + userText });
    if (mem.msgs.length > MEM_MAX) mem.msgs.splice(0, mem.msgs.length - MEM_MAX);
    // يجب أن تبدأ المحادثة برسالة user
    while (mem.msgs.length && mem.msgs[0].role !== 'user') mem.msgs.shift();
    const system = systemPrompt(msg);
    const useTools = cfg().voiceControl && !!H.music;
    const work = mem.msgs.slice();
    const ctx = { member: msg.member, guild: msg.guild, channel: msg.channel };
    let finalText = '';
    for (let step = 0; step < 4; step++) {
        const r = await callModel(system, work, useTools);
        const content = Array.isArray(r.content) ? r.content : [];
        const texts = content.filter(b => b.type === 'text').map(b => b.text).join('\n').trim();
        const uses = content.filter(b => b.type === 'tool_use');
        if (r.stop_reason !== 'tool_use' || !uses.length) { finalText = texts; break; }
        work.push({ role: 'assistant', content });
        const results = [];
        for (const u of uses) {
            const out = await runTool(u.name, u.input || {}, ctx);
            results.push({ type: 'tool_result', tool_use_id: u.id, content: JSON.stringify(out) });
        }
        work.push({ role: 'user', content: results });
        finalText = texts;
    }
    finalText = (finalText || 'تمّ ✅').slice(0, 1900);
    mem.msgs.push({ role: 'assistant', content: finalText });
    return finalText;
}

// ───── استقبال الرسائل ─────
function shouldHandle(msg) {
    const c = cfg();
    if (!c.enabled || !hasKey()) return false;
    if (!msg.guild || msg.guild.id !== SERVER_ID || msg.author.bot) return false;
    const text = (msg.content || '').trim();
    if (!text) return false;
    if (/^[-\/]/.test(text)) return false; // أوامر البوت
    const inChannel = c.channels.includes(msg.channelId);
    const mentioned = client.user && msg.mentions.users.has(client.user.id) && !msg.mentions.everyone;
    let isReply = false;
    if (msg.reference && msg.mentions.repliedUser && client.user && msg.mentions.repliedUser.id === client.user.id) isReply = true;
    return inChannel || (c.mention && (mentioned || isReply));
}
async function onMessage(msg) {
    if (!shouldHandle(msg)) return false;
    if (!allow(msg.author.id)) return true;
    let text = msg.content.replace(new RegExp('<@!?' + client.user.id + '>', 'g'), '').trim();
    if (!text) text = 'السلام عليكم';
    try { await msg.channel.sendTyping(); } catch {}
    try {
        const reply = await converse(msg, text);
        await msg.reply({ content: reply, allowedMentions: { parse: [], repliedUser: false } });
    } catch (e) {
        console.error('[ai]', e.message);
        await msg.reply({ content: '⚠️ ما قدرت أرد الحين، جرّب بعد لحظات.', allowedMentions: { parse: [], repliedUser: false } }).catch(() => {});
    }
    return true;
}

// ───── القائمة /ai ─────
const st = i => session(i, 'ai', () => ({}));
function view() {
    const c = cfg();
    const e = embed().setTitle('🤖 الذكاء الاصطناعي')
        .setDescription('مساعد يتكلم مع الأعضاء بالروم، وينفّذ أوامر صوتية: دخول/خروج، يوتيوب، قرآن.')
        .addFields(
            { name: 'الحالة', value: onOff(c.enabled), inline: true },
            { name: 'مفتاح API', value: hasKey() ? '✅ موجود' : '❌ ضع `ANTHROPIC_API_KEY` في الاستضافة', inline: true },
            { name: 'النموذج', value: '`' + MODEL() + '`', inline: true },
            { name: '💬 رومات المحادثة (يرد على كل رسالة)', value: c.channels.length ? c.channels.map(x => '<#' + x + '>').join(' ') : '`لا يوجد — يرد بالمنشن فقط`' },
            { name: 'الرد عند المنشن/الرد على رسالته', value: onOff(c.mention), inline: true },
            { name: 'الأوامر الصوتية', value: onOff(c.voiceControl), inline: true },
            { name: 'رتب التحكم الصوتي', value: c.controlRoles.length ? c.controlRoles.map(x => '<@&' + x + '>').join(' ') : '`الكل`', inline: true }
        )
        .setFooter({ text: 'أمثلة: «السلام عليكم» • «شغّل سورة الكهف» • «شغّل فيروز» • «اطلع برا الروم»' });
    return {
        embeds: [e],
        components: [
            row(btn('ai:toggle', c.enabled ? 'إيقاف' : 'تشغيل', c.enabled ? '⛔' : '✅', c.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
                btn('ai:mention', 'الرد بالمنشن', c.mention ? '✅' : '⛔'),
                btn('ai:voice', 'الأوامر الصوتية', c.voiceControl ? '✅' : '⛔'),
                btn('ai:persona', 'شخصية البوت', '🎭', ButtonStyle.Primary)),
            row(chSel('ai:chs', 'اختر رومات المحادثة (حتى 5)', { max: 5, min: 0, selected: c.channels })),
            row(roleSel('ai:roles', 'رتب التحكم الصوتي (فاضي = الكل)', { max: 10, min: 0, selected: c.controlRoles })),
            row(btn('ai:clear', 'مسح الرومات', '🧹'), btn('ai:forget', 'مسح الذاكرة', '🧠'))
        ]
    };
}
async function slash(i) { if (!(await adminOnly(i))) return; return i.reply({ ...view(), flags: EPH }); }
async function component(i) {
    if (!(await adminOnly(i))) return;
    const a = i.customId.split(':')[1]; const c = cfg();
    if (a === 'persona') return i.showModal(modal('aim:persona', 'شخصية الذكاء الاصطناعي', input('name', 'اسم المساعد (اختياري)', { max: 40, value: c.name }), input('persona', 'تعليمات إضافية', { paragraph: true, max: 800, value: c.persona, placeholder: 'مثال: كن مرحاً ولا تتكلم في السياسة' })));
    if (a === 'toggle') c.enabled = !c.enabled;
    else if (a === 'mention') c.mention = !c.mention;
    else if (a === 'voice') c.voiceControl = !c.voiceControl;
    else if (a === 'chs') c.channels = [...i.values];
    else if (a === 'roles') c.controlRoles = [...i.values];
    else if (a === 'clear') c.channels = [];
    else if (a === 'forget') memory.clear();
    save();
    return update(i, view());
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const c = cfg();
    c.name = i.fields.getTextInputValue('name').trim();
    c.persona = i.fields.getTextInputValue('persona').trim();
    save();
    return i.isFromMessage && i.isFromMessage() ? update(i, view()) : i.reply({ content: '✅ تم الحفظ.', flags: EPH });
}
const commands = [{ name: 'ai', description: 'إعداد الذكاء الاصطناعي: الرومات والأوامر الصوتية والشخصية (إدارة)' }];
return { prefix: 'ai', commands, ephemeral: ['ai'], slash: { ai: slash }, component, modal: modalSubmit, onMessage };
};
