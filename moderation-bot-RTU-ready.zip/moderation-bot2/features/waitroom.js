'use strict';
/**
 * روم الانتظار /waitroom
 * عضو يدخل روم الانتظار ← البوت يرسل طلب في روم الطلبات ← الدعم يضغط قبول فيسحبه
 */
module.exports = (H) => {
const { D, client, BLUE, isAdmin, SERVER_ID, save, EPH, row, btn, chSel, roleSel, embed, cut, adminOnly, update, onOff, chTxt, roleTxt } = H;
const db = H.db;
const { ButtonStyle, ChannelType, PermissionFlagsBits, VoiceChannel } = D;
const voiceQueues = new Map();
const voiceConnections = new Map();
const voicePlayers = new Map();

const cfg = () => {
    const w = (db.waitroom = db.waitroom || {});
    w.enabled = !!w.enabled;
    w.waitChannelId = w.waitChannelId || '';
    w.requestChannelId = w.requestChannelId || '';
    w.supportRoles = Array.isArray(w.supportRoles) ? w.supportRoles : [];
    w.welcomeMsg = w.welcomeMsg || 'السلام عليكم {user}، تم إرسال طلبك للدعم. انتظر قليلاً...';
    w.announceChannelId = w.announceChannelId || '';
    w.announceText = w.announceText || 'تم إرسال طلب إلى {label}';
    w.announceLabel = w.announceLabel || 'الدعم الفني';
    w.pending = w.pending || {}; // userId -> { requestMsgId, channelId, at }
    return w;
};

function isSupport(member) {
    if (!member) return false;
    if (isAdmin(member)) return true;
    const w = cfg();
    return w.supportRoles.some(rid => member.roles.cache.has(rid));
}

async function speakAnnouncement(guild, channelId, text) {
    if (!channelId || !text) return;
    const prior = voiceQueues.get(guild.id) || Promise.resolve();
    const next = prior.catch(() => {}).then(async () => {
        let voice, ffmpegPath, spawn, Readable;
        try {
            voice = require('@discordjs/voice');
            try { ffmpegPath = require('ffmpeg-static'); } catch { ffmpegPath = null; }
            if (!ffmpegPath || !require('fs').existsSync(ffmpegPath)) ffmpegPath = 'ffmpeg'; // بديل: ffmpeg المثبت على الاستضافة
            ({ spawn } = require('child_process'));
            ({ Readable } = require('stream'));
        } catch (e) { console.warn('[waitroom:voice] مكتبات الصوت غير متوفرة:', e.message); return; }
        try {
            const channel = guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null);
            if (!channel || !channel.isVoiceBased?.() || channel.type !== ChannelType.GuildVoice) return;
            const tts = require('google-tts-api');
            const audioUrl = tts.getAudioUrl(String(text).slice(0, 180), { lang: 'ar', slow: false, host: 'https://translate.google.com' });
            const response = await fetch(audioUrl);
            if (!response.ok) throw new Error('تعذر جلب الصوت: HTTP ' + response.status);
            const audio = Buffer.from(await response.arrayBuffer());
            const old = voiceConnections.get(guild.id);
            if (old) { try { old.destroy(); } catch {} }
            const connection = voice.joinVoiceChannel({ channelId: channel.id, guildId: guild.id, adapterCreator: guild.voiceAdapterCreator, selfDeaf: true, selfMute: false });
            voiceConnections.set(guild.id, connection);
            await voice.entersState(connection, voice.VoiceConnectionStatus.Ready, 15000);
            const player = voice.createAudioPlayer();
            voicePlayers.set(guild.id, player);
            connection.subscribe(player);
            const ff = spawn(ffmpegPath, ['-hide_banner', '-loglevel', 'error', '-i', 'pipe:0', '-f', 's16le', '-ar', '48000', '-ac', '2', 'pipe:1'], { stdio: ['pipe', 'pipe', 'ignore'] });
            ff.stdin.end(audio);
            const resource = voice.createAudioResource(ff.stdout, { inputType: voice.StreamType.Raw });
            player.play(resource);
            await voice.entersState(player, voice.AudioPlayerStatus.Idle, 30000).catch(e => { try { player.stop(true); } catch {} throw e; });
            await new Promise(resolve => setTimeout(resolve, 1200));
            if (voiceConnections.get(guild.id) === connection) { connection.destroy(); voiceConnections.delete(guild.id); voicePlayers.delete(guild.id); }
        } catch (e) { console.warn('[waitroom:voice] فشل الإعلان الصوتي:', e.message); const c = voiceConnections.get(guild.id); if (c) { try { c.destroy(); } catch {} voiceConnections.delete(guild.id); } }
    });
    voiceQueues.set(guild.id, next);
    return next;
}

async function onVoiceState(oldState, newState) {
    const w = cfg();
    if (!w.enabled || !w.waitChannelId) return;
    const joined = !oldState.channelId && newState.channelId;
    const movedIn = oldState.channelId !== newState.channelId && newState.channelId === w.waitChannelId;
    if (!(joined || movedIn) || newState.channelId !== w.waitChannelId) return;
    if (newState.member?.user?.bot) return;

    const member = newState.member;
    const guild = newState.guild;
    if (!member || !guild) return;

    // already pending?
    if (w.pending[member.id] && Date.now() - (w.pending[member.id].at || 0) < 120000) return;

    // welcome in wait channel (text message if possible - wait channel is voice, so DM or request channel note)
    try {
        const text = String(w.welcomeMsg).replace(/\{user\}/gi, `<@${member.id}>`).replace(/\{username\}/gi, member.user.username);
        // send ephemeral-like via request channel or try system
        if (w.requestChannelId) {
            const reqCh = guild.channels.cache.get(w.requestChannelId) || await guild.channels.fetch(w.requestChannelId).catch(() => null);
            if (reqCh && reqCh.isTextBased()) {
                const e = embed()
                    .setTitle('🔔 طلب دعم فني جديد')
                    .setDescription('وصل طلب انضمام جديد من روم الانتظار. اختر **قبول** لسحب العضو إلى رومك الصوتي، أو **رفض** لإنهاء الطلب.')
                    .addFields(
                        { name: '👤 العضو', value: `${member} • ${member.user.tag}`, inline: true },
                        { name: '🔊 روم الانتظار', value: `<#${w.waitChannelId}>`, inline: true },
                        { name: '⏱️ وقت الطلب', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true }
                    )
                    .setColor(BLUE)
                    .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
                    .setFooter({ text: `${guild.name} • نظام الدعم الصوتي` })
                    .setTimestamp();
                const msg = await reqCh.send({
                    content: w.supportRoles.length ? w.supportRoles.map(r => `<@&${r}>`).join(' ') : null,
                    embeds: [e],
                    components: [row(
                        btn(`wr:accept:${member.id}`, 'قبول', '✅', ButtonStyle.Success),
                        btn(`wr:deny:${member.id}`, 'رفض', '❌', ButtonStyle.Danger)
                    )],
                    allowedMentions: { roles: w.supportRoles }
                });
                w.pending[member.id] = { requestMsgId: msg.id, channelId: reqCh.id, at: Date.now() };
                H.save();
            }
        }
        // also try notify the user
        try {
            await member.send({ embeds: [embed().setTitle('تم إرسال طلبك').setDescription(text.replace(/<@\d+>/g, 'أنت')).setColor(BLUE)] }).catch(() => {});
        } catch {}
        if (w.announceChannelId) {
            const spoken = String(w.announceText).replace(/\{label\}/gi, w.announceLabel).replace(/\{user\}/gi, member.user.username).slice(0, 180);
            // لا نؤخر إنشاء طلب الانتظار بسبب خدمة الصوت؛ الإعلان محاولة مستقلة.
            speakAnnouncement(guild, w.announceChannelId, spoken).catch(e => console.warn('[waitroom:voice]', e.message));
        }
    } catch (e) {
        console.error('[waitroom]', e.message);
    }
}

async function component(i) {
    const parts = i.customId.split(':');
    const action = parts[1];
    const targetId = parts[2];
    const w = cfg();

    if (action === 'accept' || action === 'deny') {
        if (!isSupport(i.member)) {
            return i.reply({ content: '❌ للدعم فقط.', flags: EPH });
        }
        const target = await i.guild.members.fetch(targetId).catch(() => null);
        const pend = w.pending[targetId];

        if (action === 'deny') {
            if (pend) {
                delete w.pending[targetId];
                H.save();
            }
            try { await i.message.edit({ components: [] }); } catch {}
            return i.reply({ content: `تم رفض طلب <@${targetId}>.`, flags: EPH });
        }

        // accept: move to supporter's current voice
        if (!i.member.voice?.channelId) {
            return i.reply({ content: '❌ لازم تكون في روم صوتي عشان أسحبه لك.', flags: EPH });
        }
        if (!target || !target.voice?.channelId) {
            if (pend) { delete w.pending[targetId]; H.save(); }
            try { await i.message.edit({ components: [] }); } catch {}
            return i.reply({ content: '❌ العضو مو موجود في روم الانتظار حالياً.', flags: EPH });
        }
        try {
            await target.voice.setChannel(i.member.voice.channelId, 'قبول من روم الانتظار');
            if (pend) { delete w.pending[targetId]; H.save(); }
            try { await i.message.edit({ embeds: [embed().setTitle('✅ تم القبول').setDescription(`${target} نُقل إلى ${i.member.voice.channel}`).setColor('#57F287')], components: [] }); } catch {}
            return i.reply({ content: `✅ تم سحب ${target} إلى رومك.`, flags: EPH });
        } catch (e) {
            return i.reply({ content: '❌ فشل السحب. تأكد أن البوت عنده صلاحية **Move Members**. ' + cut(e.message, 80), flags: EPH });
        }
    }

    }

function buildPanel() {
    const w = cfg();
    const e = embed()
        .setTitle('📞 روم الانتظار')
        .setDescription('العضو يدخل روم الانتظار ← يُرسل طلب في روم الطلبات. يمكن للبوت الانضمام لروم صوتي محدد ونطق العبارة عند كل طلب.\nيلزم صلاحية **Move Members** للسحب و**Connect + Speak** للإعلان الصوتي.')
        .addFields(
            { name: 'الحالة', value: onOff(w.enabled), inline: true },
            { name: 'روم الانتظار', value: w.waitChannelId ? `<#${w.waitChannelId}>` : '`غير محدد`', inline: true },
            { name: 'روم الطلبات', value: chTxt(w.requestChannelId), inline: true },
            { name: 'رتب الدعم', value: w.supportRoles.length ? w.supportRoles.map(r => `<@&${r}>`).join(' ') : '`غير محدد`', inline: false },
            { name: 'رسالة الترحيب', value: cut(w.welcomeMsg, 200), inline: false },
            { name: 'روم الإعلان الصوتي', value: w.announceChannelId ? `<#${w.announceChannelId}>` : '`متوقف`', inline: true },
            { name: 'العبارة المنطوقة', value: cut(w.announceText.replace(/\{label\}/gi, w.announceLabel), 180), inline: false },
            { name: 'التسمية', value: cut(w.announceLabel, 60), inline: true }
        );
    return {
        embeds: [e],
        components: [
            row(
                btn('wr:toggle', w.enabled ? 'إيقاف' : 'تشغيل', w.enabled ? '⛔' : '✅', w.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
                btn('wr:cfgmsg', 'تعديل الرسالة', '✏️', ButtonStyle.Secondary),
                btn('wr:cfgvoice', 'العبارة الصوتية', '🔊', ButtonStyle.Secondary),
                btn('wr:togglevoice', w.announceChannelId ? 'إيقاف الصوت' : 'الصوت متوقف', '🔈', w.announceChannelId ? ButtonStyle.Danger : ButtonStyle.Secondary)
            ),
            row(chSel('wr:setwait', 'اختر روم الانتظار (صوتي)', { types: [ChannelType.GuildVoice, ChannelType.GuildStageVoice] })),
            row(chSel('wr:setreq', 'اختر روم الطلبات (نصي)')),
            row(chSel('wr:setannounce', 'اختر روم نطق الطلب (اختياري)', { types: [ChannelType.GuildVoice] })),
            row(roleSel('wr:setroles', 'رتب الدعم', { max: 10, min: 0 }))
        ]
    };
}

async function slash(i) {
    if (!(await adminOnly(i))) return;
    return i.reply({ ...buildPanel(), flags: EPH });
}

async function componentFull(i) {
    const id = i.customId;
    if (id.startsWith('wr:accept:') || id.startsWith('wr:deny:')) return component(i);
    if (!(await adminOnly(i))) return;
    const parts = id.split(':');
    const a = parts[1];
    const w = cfg();
    if (a === 'toggle') {
        w.enabled = !w.enabled; H.save();
        return update(i, buildPanel());
    }
    if (a === 'togglevoice') {
        w.announceChannelId = ''; H.save();
        return update(i, buildPanel());
    }
    if (a === 'setwait') {
        w.waitChannelId = i.values[0]; H.save();
        return update(i, buildPanel());
    }
    if (a === 'setreq') {
        w.requestChannelId = i.values[0]; H.save();
        return update(i, buildPanel());
    }
    if (a === 'setannounce') {
        w.announceChannelId = i.values[0]; H.save();
        return update(i, buildPanel());
    }
    if (a === 'setroles') {
        w.supportRoles = i.values || []; H.save();
        return update(i, buildPanel());
    }
    if (a === 'cfgvoice') {
        const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = D;
        const m = new ModalBuilder().setCustomId('wr:m:voice').setTitle('إعداد العبارة الصوتية');
        m.addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('text').setLabel('النص؛ استخدم {label} للتسمية').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(180).setValue(cut(w.announceText, 180))),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('label').setLabel('التسمية مثل الدعم الفني أو الرقابة').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(60).setValue(cut(w.announceLabel, 60)))
        );
        return i.showModal(m);
    }
    if (a === 'cfgmsg') {
        const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = D;
        const m = new ModalBuilder().setCustomId('wr:m:msg').setTitle('رسالة الترحيب');
        const t = new TextInputBuilder().setCustomId('msg').setLabel('الرسالة ({user} للمنشن)').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(500).setValue(cut(w.welcomeMsg, 500));
        m.addComponents(new ActionRowBuilder().addComponents(t));
        return i.showModal(m);
    }
}

async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    if (i.customId === 'wr:m:voice') {
        const w = cfg();
        w.announceText = i.fields.getTextInputValue('text').trim() || w.announceText;
        w.announceLabel = i.fields.getTextInputValue('label').trim() || w.announceLabel;
        H.save();
        return i.reply({ content: '✅ تم حفظ نص الإعلان الصوتي والتسمية.', flags: EPH });
    }
    if (i.customId === 'wr:m:msg') {
        const w = cfg();
        w.welcomeMsg = i.fields.getTextInputValue('msg').trim() || w.welcomeMsg;
        H.save();
        return i.reply({ content: '✅ تم حفظ الرسالة.', flags: EPH });
    }
}

const commands = [{ name: 'waitroom', description: 'إعداد روم الانتظار وطلبات الدعم الصوتي' }];
return {
    prefix: 'wr',
    commands,
    ephemeral: ['waitroom'],
    slash: { waitroom: slash },
    component: componentFull,
    modal: modalSubmit,
    onVoiceState
};
};
