'use strict';
// ═══ streams.js — إشعارات البثوث والمقاطع (يوتيوب • تيك توك • كيك) ═══
// /streams → لوحة الإدارة: تضيف حسابات، تحدد روم الإرسال والمنشن والرسالة والصورة، وتجرب الإرسال والفحص
// البوت يفحص كل دقيقة أو دقيقتين، وأول ما يبدأ بث أو ينزل مقطع جديد يرسل الإشعار بالروم.
module.exports = (H) => {
const { D, EPH, BLUE, row, btn, strSel, chSel, roleSel, input, modal, embed, cut, rid, isUrl, session, adminOnly, update, chTxt, roleTxt, getTextChannel, client, SERVER_ID } = H;
const db = H.db;
const { ButtonStyle, EmbedBuilder } = D;

const MAX_ITEMS = 25;
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const PLAT = {
    youtube: { name: 'يوتيوب', emoji: '▶️', color: 0xFF0000, live: true, video: true },
    tiktok: { name: 'تيك توك', emoji: '🎵', color: 0x25F4EE, live: true, video: true },
    kick: { name: 'كيك', emoji: '🟢', color: 0x53FC18, live: true, video: false }
};
const DEF_TEXT = {
    live: '🔴 **[name]** بدأ بث مباشر الآن على [platform]! تعال شاركه 🎥',
    video: '🎬 **[name]** نزّل مقطع جديد على [platform]! 🔥'
};

// ───── التخزين ─────
function S() {
    const s = (db.streams = db.streams || {});
    s.items = Array.isArray(s.items) ? s.items : [];
    s.intervalSec = Number.isFinite(s.intervalSec) ? s.intervalSec : 60;
    s.rsshub = s.rsshub || 'https://rsshub.app';
    return s;
}

// إمبد يحتفظ بلونه (يتجاوز تغيير اللون والتذييل والوقت التلقائي في index.js)
const E = () => { const e = new EmbedBuilder(); e.toJSON = function () { return { ...this.data }; }; return e; };
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const normColor = (c) => { const m = /^#?([0-9a-f]{6})$/i.exec(String(c || '').trim()); return m ? '#' + m[1].toLowerCase() : null; };
const fill = (t, v) => String(t).replace(/[\{\[]\s*(name|title|url|platform|game|viewers)\s*[\}\]]/gi, (m, k) => (v[k.toLowerCase()] != null ? v[k.toLowerCase()] : m));
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const decodeXml = (t) => String(t || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").trim();

// ───── الشبكة ─────
async function http(url, { headers = {}, timeout = 15000, method = 'GET' } = {}) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeout);
    try {
        const r = await fetch(url, { method, headers: { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9', ...headers }, signal: ctl.signal, redirect: 'follow' });
        const text = method === 'HEAD' ? '' : await r.text();
        return { status: r.status, ok: r.ok, text };
    } catch (e) {
        const code = (e && e.cause && (e.cause.code || e.cause.message)) || e.message;
        throw new Error('تعذّر الاتصال: ' + cut(String(code), 120));
    } finally { clearTimeout(t); }
}
const YT_HEADERS = { Cookie: 'CONSENT=YES+1; SOCS=CAI' };

// ───── يوتيوب ─────
function ytInput(raw) {
    raw = String(raw || '').trim();
    const id = /UC[\w-]{22}/.exec(raw);
    if (id) return { id: id[0] };
    const h = /@([\w.\-]+)/.exec(raw) || /^([\w.\-]{3,})$/.exec(raw);
    return h ? { handle: h[1] } : null;
}
function parseChannelHtml(html) {
    const id = /"(?:channelId|externalId)":"(UC[\w-]{22})"/.exec(html) || /channel\/(UC[\w-]{22})/.exec(html);
    const name = /<meta property="og:title" content="([^"]+)"/.exec(html);
    const img = /<meta property="og:image" content="([^"]+)"/.exec(html);
    return { id: id ? id[1] : '', name: name ? decodeXml(name[1]) : '', avatar: img ? img[1] : '' };
}
async function ytResolve(raw) {
    const p = ytInput(raw);
    if (!p) throw new Error('اكتب رابط القناة أو @اسم القناة');
    const url = p.id ? 'https://www.youtube.com/channel/' + p.id : 'https://www.youtube.com/@' + p.handle;
    const r = await http(url, { headers: YT_HEADERS });
    if (r.status === 404) throw new Error('ما لقيت هذي القناة على يوتيوب');
    if (!r.ok) throw new Error('يوتيوب رد بـ HTTP ' + r.status);
    const c = parseChannelHtml(r.text);
    const id = p.id || c.id;
    if (!id) throw new Error('ما قدرت أستخرج رقم القناة، جرّب تحط رابط القناة اللي فيه /channel/UC…');
    return { id, name: c.name, avatar: c.avatar };
}
function parseRss(xml) {
    const out = [];
    for (const m of String(xml).matchAll(/<entry>([\s\S]*?)<\/entry>/g)) {
        const b = m[1];
        const id = /<yt:videoId>([^<]+)<\/yt:videoId>/.exec(b);
        if (!id) continue;
        const title = /<title>([\s\S]*?)<\/title>/.exec(b);
        const pub = /<published>([^<]+)<\/published>/.exec(b);
        const au = /<author>[\s\S]*?<name>([\s\S]*?)<\/name>/.exec(b);
        out.push({ id: id[1], title: title ? decodeXml(title[1]) : '', published: pub ? Date.parse(pub[1]) || 0 : 0, author: au ? decodeXml(au[1]) : '' });
    }
    return out;
}
function classifyWatch(html) {
    if (/"isLiveNow"\s*:\s*true/.test(html)) return 'live';
    if (/"isUpcoming"\s*:\s*true/.test(html)) return 'upcoming';
    if (/"isLiveContent"\s*:\s*true/.test(html)) return 'ended';
    if (/"videoId"\s*:\s*"/.test(html) || /ytInitialPlayerResponse/.test(html)) return 'video';
    return 'unknown';
}
async function ytClassify(id) {
    try {
        const r = await http('https://www.youtube.com/watch?v=' + id, { headers: YT_HEADERS });
        return r.ok ? classifyWatch(r.text) : 'unknown';
    } catch { return 'unknown'; }
}
// صفحة /live للقناة: لو القناة بث الحين تتحول لصفحة البث (أسرع من RSS اللي يتأخر أحياناً)
async function ytLiveProbe(ytId) {
    try {
        const r = await http('https://www.youtube.com/channel/' + ytId + '/live', { headers: YT_HEADERS });
        if (!r.ok || !/"isLiveNow"\s*:\s*true/.test(r.text)) return null;
        const c = /<link rel="canonical" href="https:\/\/www\.youtube\.com\/watch\?v=([\w-]{11})"/.exec(r.text);
        if (!c) return null;
        const t = /<meta property="og:title" content="([^"]+)"/.exec(r.text);
        return { id: c[1], title: t ? decodeXml(t[1]) : '' };
    } catch { return null; }
}
async function ytThumb(id) {
    const max = 'https://i.ytimg.com/vi/' + id + '/maxresdefault.jpg';
    try { const r = await http(max, { method: 'HEAD', timeout: 6000 }); if (r.ok) return max; } catch {}
    return 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg';
}
async function checkYouTube(it) {
    const st = it.state; const events = []; const info = []; const errors = [];
    const r = await http('https://www.youtube.com/feeds/videos.xml?channel_id=' + it.ytId, { headers: YT_HEADERS });
    if (r.status === 404) throw new Error('القناة غير موجودة (تأكد من الرابط)');
    if (!r.ok) throw new Error('يوتيوب رد بـ HTTP ' + r.status);
    const entries = parseRss(r.text);
    if (!entries.length && !/<feed/.test(r.text)) throw new Error('رد غير متوقع من يوتيوب');
    st.seen = Array.isArray(st.seen) ? st.seen : []; st.upcoming = st.upcoming || {};
    const seen = new Set(st.seen);
    const baseline = !st.init;
    const mk = async (e) => ({ title: e.title, url: 'https://www.youtube.com/watch?v=' + e.id, thumb: await ytThumb(e.id), startedAt: Date.now() });
    // 1) بث جاري: نتأكد إنه للحين شغال
    if (st.liveId) {
        const c = await ytClassify(st.liveId);
        if (c === 'live') st.off = 0; else { st.off = (st.off || 0) + 1; if (st.off >= 2) { st.liveId = ''; st.off = 0; } }
    }
    // 1.5) فحص مباشر: هل القناة بث الحين؟ (يلتقط البث حتى لو RSS متأخر)
    if (it.kinds.live && !st.liveId) {
        const L = await ytLiveProbe(it.ytId);
        if (L && st.liveId !== L.id) {
            seen.add(L.id); delete st.upcoming[L.id]; st.liveId = L.id; st.off = 0;
            events.push({ kind: 'live', data: await mk({ id: L.id, title: L.title || it.name }), undo: () => { st.liveId = ''; seen.delete(L.id); st.seen = [...seen]; } });
        }
    }
    // 2) بثوث مجدولة: لما تبدأ نرسل
    for (const [id, t] of Object.entries(st.upcoming)) {
        const c = await ytClassify(id);
        if (c === 'live') {
            delete st.upcoming[id];
            const e = entries.find(x => x.id === id) || { id, title: it.name };
            if (it.kinds.live && st.liveId !== id) { const prev = st.liveId; st.liveId = id; st.off = 0; events.push({ kind: 'live', data: await mk(e), undo: () => { st.liveId = prev || ''; st.upcoming[id] = t; } }); }
        } else if (c !== 'upcoming' || Date.now() - t > 72 * 3600 * 1000) delete st.upcoming[id];
    }
    // 3) فيديوهات/بثوث جديدة
    let checked = 0;
    for (const e of entries) {
        if (seen.has(e.id)) continue;
        if (baseline && checked >= 5) { seen.add(e.id); continue; }
        checked++;
        const c = await ytClassify(e.id);
        seen.add(e.id);
        if (c === 'live') {
            if (it.kinds.live && st.liveId !== e.id) { const prev = st.liveId; st.liveId = e.id; st.off = 0; events.push({ kind: 'live', data: await mk(e), undo: () => { st.liveId = prev || ''; seen.delete(e.id); st.seen = [...seen]; } }); }
        } else if (c === 'upcoming') st.upcoming[e.id] = Date.now();
        else if ((c === 'video' || c === 'unknown') && !baseline && it.kinds.video && (!e.published || Date.now() - e.published < 48 * 3600 * 1000)) {
            events.push({ kind: 'video', data: await mk(e), undo: () => { seen.delete(e.id); st.seen = [...seen]; } });
        }
    }
    st.seen = [...seen].slice(-100); st.init = true;
    info.push('📺 آخر فيديو: ' + (entries[0] ? cut(entries[0].title, 80) : '—'));
    info.push('🔴 حالة البث: ' + (st.liveId ? 'مباشر الآن' : 'غير مباشر'));
    return { events, info, errors, ok: 1 };
}

// ───── كيك ─────
const kickSlug = (raw) => { const m = /(?:kick\.com\/)?@?([\w\-]{2,40})\/?$/i.exec(String(raw || '').trim().replace(/\?.*$/, '')); return m ? m[1].toLowerCase() : ''; };
function parseKick(j) {
    const ls = j && j.livestream;
    const live = !!(ls && ls.is_live !== false);
    const cat = live && Array.isArray(ls.categories) && ls.categories[0] ? ls.categories[0].name : '';
    const th = live && ls.thumbnail ? (ls.thumbnail.url || ls.thumbnail.src || '') : '';
    return {
        name: (j && j.user && j.user.username) || (j && j.slug) || '', avatar: (j && j.user && j.user.profile_pic) || '',
        live, id: live ? String(ls.id || ls.created_at || ls.start_time || 'live') : '', title: live ? (ls.session_title || '') : '',
        viewers: live ? (ls.viewer_count || 0) : 0, game: cat, thumb: th
    };
}
async function kickInfo(slug) {
    let last;
    for (const u of ['https://kick.com/api/v2/channels/' + slug, 'https://kick.com/api/v1/channels/' + slug]) {
        try {
            const r = await http(u, { headers: { Accept: 'application/json', Referer: 'https://kick.com/' } });
            if (r.status === 404) throw Object.assign(new Error('القناة غير موجودة على كيك (تأكد من الاسم)'), { fatal: true });
            if (r.status === 403 || r.status === 429) { last = new Error('كيك رفض الطلب (HTTP ' + r.status + ') — غالباً حماية Cloudflare تحجب عنوان الاستضافة'); continue; }
            if (!r.ok) { last = new Error('كيك رد بـ HTTP ' + r.status); continue; }
            return parseKick(JSON.parse(r.text));
        } catch (e) { if (e.fatal) throw e; last = e; }
    }
    throw last || new Error('تعذّر الاتصال بكيك');
}
async function checkKick(it) {
    const st = it.state; const events = []; const info = [];
    const k = await kickInfo(it.handle);
    if (k.live) {
        st.off = 0;
        if (st.liveId !== k.id && it.kinds.live) {
            const prev = st.liveId; st.liveId = k.id;
            events.push({ kind: 'live', data: { title: k.title || it.name, url: 'https://kick.com/' + it.handle, thumb: k.thumb, game: k.game, viewers: k.viewers, startedAt: Date.now() }, undo: () => { st.liveId = prev || ''; } });
        }
    } else if (st.liveId) { st.off = (st.off || 0) + 1; if (st.off >= 2) { st.liveId = ''; st.off = 0; } }
    if (k.avatar && !it.avatar) it.avatar = k.avatar;
    st.init = true;
    info.push('🔴 حالة البث: ' + (k.live ? 'مباشر الآن — ' + cut(k.title, 60) : 'غير مباشر'));
    if (k.live) info.push('🎮 ' + (k.game || '—') + ' • 👥 ' + k.viewers);
    return { events, info, errors: [], ok: 1 };
}

// ───── تيك توك ─────
const ttUser = (raw) => { const m = /@?([\w.]{2,30})\/?$/.exec(String(raw || '').trim().replace(/\?.*$/, '').replace(/\/(live|video\/\d+)\/?$/i, '')); return m ? m[1] : ''; };
function parseTikTokLive(j) {
    const d = (j && j.data) || {}; const u = d.user || {}; const room = d.liveRoom || {};
    const live = u.status === 2 || room.status === 2;
    return {
        live, id: String(u.roomId || room.roomId || (live ? 'live' : '')), title: room.title || '', viewers: (room.liveRoomStats && room.liveRoomStats.userCount) || 0,
        thumb: room.coverUrl || '', name: u.nickname || '', avatar: u.avatarLarger || u.avatarThumb || '', notFound: !!(j && j.statusCode && !j.data)
    };
}
async function tiktokLive(user) {
    const r = await http('https://www.tiktok.com/api-live/user/room/?aid=1988&sourceType=54&uniqueId=' + encodeURIComponent(user), { headers: { Accept: 'application/json', Referer: 'https://www.tiktok.com/@' + user + '/live' } });
    if (r.status === 403 || r.status === 429) throw new Error('تيك توك رفض الطلب (HTTP ' + r.status + ') — يحجب عناوين الاستضافة أحياناً');
    if (!r.ok) throw new Error('تيك توك رد بـ HTTP ' + r.status);
    let j; try { j = JSON.parse(r.text); } catch { throw new Error('رد غير متوقع من تيك توك'); }
    const p = parseTikTokLive(j);
    if (p.notFound) throw new Error('الحساب غير موجود أو محجوب على تيك توك');
    return p;
}
function parseRssHub(xml) {
    const out = [];
    for (const m of String(xml).matchAll(/<item>([\s\S]*?)<\/item>/g)) {
        const b = m[1];
        const link = /<link>([\s\S]*?)<\/link>/.exec(b);
        const id = link ? /video\/(\d{8,25})/.exec(decodeXml(link[1])) : null;
        if (!id) continue;
        const title = /<title>([\s\S]*?)<\/title>/.exec(b);
        const pub = /<pubDate>([\s\S]*?)<\/pubDate>/.exec(b);
        const img = /<img[^>]+src=["']([^"']+)["']/.exec(decodeXml((/<description>([\s\S]*?)<\/description>/.exec(b) || [])[1] || ''));
        out.push({ id: id[1], url: decodeXml(link[1]), title: title ? decodeXml(title[1]) : '', published: pub ? Date.parse(decodeXml(pub[1])) || 0 : 0, thumb: img ? img[1] : '' });
    }
    return out;
}
async function tiktokVideos(user) {
    const base = S().rsshub.replace(/\/+$/, '');
    const r = await http(base + '/tiktok/user/@' + encodeURIComponent(user), { timeout: 20000 });
    if (!r.ok) throw new Error('RSSHub رد بـ HTTP ' + r.status + ' — غيّر رابط RSSHub من الإعدادات (يفضّل تستخدم واحد خاص فيك)');
    const items = parseRssHub(r.text);
    if (!items.length && !/<rss|<feed/.test(r.text)) throw new Error('رد غير متوقع من RSSHub');
    return items;
}
async function checkTikTok(it) {
    const st = it.state; const events = []; const info = []; const errors = []; let ok = 0;
    if (it.kinds.live) {
        try {
            const L = await tiktokLive(it.handle); ok++;
            if (L.live) {
                st.off = 0;
                if (st.liveId !== L.id) {
                    const prev = st.liveId; st.liveId = L.id;
                    events.push({ kind: 'live', data: { title: L.title || it.name, url: 'https://www.tiktok.com/@' + it.handle + '/live', thumb: L.thumb, viewers: L.viewers, startedAt: Date.now() }, undo: () => { st.liveId = prev || ''; } });
                }
            } else if (st.liveId) { st.off = (st.off || 0) + 1; if (st.off >= 2) { st.liveId = ''; st.off = 0; } }
            if (L.avatar && !it.avatar) it.avatar = L.avatar;
            info.push('🔴 حالة البث: ' + (L.live ? 'مباشر الآن — ' + cut(L.title, 60) : 'غير مباشر'));
        } catch (e) { errors.push('البث: ' + e.message); }
    }
    if (it.kinds.video) {
        try {
            const vids = await tiktokVideos(it.handle); ok++;
            st.seen = Array.isArray(st.seen) ? st.seen : [];
            const seen = new Set(st.seen); const baseline = !st.init;
            for (const v of vids) {
                if (seen.has(v.id)) continue;
                seen.add(v.id);
                if (!baseline && (!v.published || Date.now() - v.published < 48 * 3600 * 1000)) {
                    events.push({ kind: 'video', data: { title: v.title || it.name, url: v.url, thumb: v.thumb, startedAt: Date.now() }, undo: () => { seen.delete(v.id); st.seen = [...seen]; } });
                }
            }
            st.seen = [...seen].slice(-100);
            info.push('🎞️ آخر مقطع: ' + (vids[0] ? cut(vids[0].title || vids[0].url, 70) : '—'));
        } catch (e) { errors.push('المقاطع: ' + e.message); }
    }
    if (ok) st.init = true;
    return { events, info, errors, ok };
}

// ───── الإرسال ─────
function buildPayload(item, ev, test) {
    const P = PLAT[item.platform]; const d = ev.data; const live = ev.kind === 'live';
    const text = fill(live ? (item.liveText || DEF_TEXT.live) : (item.videoText || DEF_TEXT.video), { name: item.name, title: d.title || '', url: d.url || '', platform: P.name, game: d.game || '', viewers: d.viewers != null ? d.viewers : '' });
    const mention = item.roleId ? '<@&' + item.roleId + '>' : (item.everyone ? '@everyone' : '');
    const content = cut((test ? '🧪 **رسالة تجريبية — هكذا يظهر الإشعار**\n' : '') + (mention ? mention + '\n' : '') + text, 2000);
    const color = normColor(item.color) ? parseInt(normColor(item.color).slice(1), 16) : P.color;
    const e = E().setColor(color).setAuthor({ name: cut(item.name, 256), iconURL: item.avatar && isUrl(item.avatar) ? item.avatar : undefined })
        .setTitle(cut(d.title || item.name, 256))
        .setDescription(P.emoji + ' **' + P.name + '**  •  ' + (live ? '🔴 بث مباشر الآن' : '🎬 مقطع جديد'));
    if (isUrl(d.url)) e.setURL(d.url);
    if (live && (d.game || d.viewers)) {
        const f = [];
        if (d.game) f.push({ name: '🎮 التصنيف', value: cut(String(d.game), 200), inline: true });
        if (d.viewers) f.push({ name: '👥 المشاهدين', value: String(d.viewers), inline: true });
        if (f.length) e.addFields(...f);
    }
    const img = isUrl(item.image) ? item.image : (isUrl(d.thumb) ? d.thumb : '');
    if (img) e.setImage(img.trim());
    e.setFooter({ text: cut(item.footer || (P.name + (live ? ' • بث مباشر' : ' • مقطع جديد')), 200) });
    const comps = [];
    if (isUrl(d.url)) comps.push(new D.ActionRowBuilder().addComponents(new D.ButtonBuilder().setStyle(ButtonStyle.Link).setLabel(live ? 'شاهد البث' : 'شاهد المقطع').setEmoji(live ? '🔴' : '▶️').setURL(d.url)));
    const allowed = item.roleId ? { roles: [item.roleId] } : (item.everyone ? { parse: ['everyone'] } : { parse: [] });
    return { content, embeds: [e], components: comps, allowedMentions: allowed };
}
async function notify(item, ev, test) {
    const guild = client.guilds && client.guilds.cache && client.guilds.cache.get(SERVER_ID);
    if (!guild) throw new Error('السيرفر غير متاح للبوت');
    const ch = item.channelId ? await getTextChannel(guild, item.channelId) : null;
    if (!ch) throw new Error('روم الإرسال غير محدد أو البوت ما يشوفه');
    try { await ch.send(buildPayload(item, ev, test)); }
    catch (e) { throw new Error('تعذّر الإرسال للروم: ' + cut(e.message, 150) + ' (تأكد من صلاحيات البوت)'); }
}

// ───── الفحص ─────
const CHECKERS = { youtube: checkYouTube, kick: checkKick, tiktok: checkTikTok };
async function runCheck(item, { dry = false } = {}) {
    const it = dry ? { ...item, kinds: { ...item.kinds }, state: JSON.parse(JSON.stringify(item.state || {})) } : item;
    it.state = it.state || {};
    const res = { events: [], info: [], errors: [], sent: 0 };
    try {
        const r = await CHECKERS[it.platform](it);
        res.events = r.events; res.info = r.info; res.errors = r.errors || []; res.ok = r.ok;
    } catch (e) { res.errors = [e.message]; res.ok = 0; }
    if (!dry) {
        it.state.lastCheck = Date.now();
        for (const ev of res.events) {
            try { await notify(it, ev, false); res.sent++; }
            catch (e) { res.errors.push(e.message); if (ev.undo) ev.undo(); }
        }
        if (res.ok) it.state.lastOk = Date.now();
        it.state.lastError = res.errors.length ? cut(res.errors.join(' | '), 400) : '';
        H.save();
    }
    return res;
}
let running = false;
async function tick() {
    if (running) return; running = true;
    try {
        if (!client.isReady || !client.isReady()) return;
        for (const it of S().items) {
            if (!it.enabled || !it.channelId) continue;
            try { await runCheck(it); } catch (e) { console.error('[streams]', it.name, e.message); }
            await sleep(400);
        }
    } finally { running = false; }
}
let timer = null;
function schedule(first) {
    if (timer) clearTimeout(timer);
    timer = setTimeout(async () => { try { await tick(); } catch (e) { console.error('[streams] tick:', e.message); } schedule(); }, first || clamp(S().intervalSec, 60, 900) * 1000);
    if (timer.unref) timer.unref();
}
schedule(30000);

// ───── لوحة الإدارة ─────
const sess = (i) => session(i, 'st', () => ({ sel: '', confirm: false }));
const kindsTxt = (it) => [it.kinds.video && PLAT[it.platform].video ? '🎬' : '', it.kinds.live ? '🔴' : ''].filter(Boolean).join('');
const statusIcon = (it) => it.state && it.state.lastError ? '🔴' : (it.state && it.state.lastOk ? '🟢' : '⚪');
const line = (it) => PLAT[it.platform].emoji + ' **' + cut(it.name, 30) + '** ' + kindsTxt(it) + ' → ' + (it.channelId ? '<#' + it.channelId + '>' : '`بدون روم`') + ' ' + statusIcon(it) + (it.enabled ? '' : ' ⏸️');
const ago = (t) => t ? '<t:' + Math.floor(t / 1000) + ':R>' : '`—`';

function buildPanel(i) {
    const s = S(); const ss = sess(i);
    const it = s.items.find(x => x.id === ss.sel);
    if (!it) {
        ss.sel = '';
        const e = embed().setTitle('📡 إشعارات البثوث والمقاطع')
            .setDescription('أضف حسابات يوتيوب وتيك توك وكيك، وحدد لكل واحد روم الإرسال والمنشن والرسالة والصورة. أول ما يبدأ بث أو ينزل مقطع جديد يرسل البوت إشعار فوراً.\n\n🟢 يعمل • 🔴 فيه خطأ • ⚪ ما انفحص بعد • ⏸️ متوقف')
            .addFields(
                { name: 'الحسابات (' + s.items.length + '/' + MAX_ITEMS + ')', value: s.items.length ? cut(s.items.map(line).join('\n'), 1000) : '`لا توجد حسابات — اضغط أحد أزرار الإضافة`' },
                { name: '⚙️ الفحص', value: 'كل **' + clamp(s.intervalSec, 60, 900) + '** ثانية', inline: true },
                { name: '🎵 RSSHub لمقاطع تيك توك', value: '`' + cut(s.rsshub, 60) + '`', inline: true });
        const comps = [row(
            btn('st:add:youtube', 'يوتيوب', '▶️', ButtonStyle.Danger, s.items.length >= MAX_ITEMS), btn('st:add:tiktok', 'تيك توك', '🎵', ButtonStyle.Secondary, s.items.length >= MAX_ITEMS),
            btn('st:add:kick', 'كيك', '🟢', ButtonStyle.Success, s.items.length >= MAX_ITEMS), btn('st:scan', 'فحص الكل', '🔍', ButtonStyle.Primary, !s.items.length), btn('st:set', 'الإعدادات', '⚙️', ButtonStyle.Secondary))];
        if (s.items.length) comps.push(row(strSel('st:sel', 'اختر حساباً لتعديله…', s.items.map(x => ({ label: cut(x.name, 90), value: x.id, description: cut(PLAT[x.platform].name + ' • ' + (x.enabled ? 'يعمل' : 'متوقف') + (x.state && x.state.lastError ? ' • فيه خطأ' : ''), 100), emoji: { name: PLAT[x.platform].emoji } })))));
        return { embeds: [e], components: comps };
    }
    const P = PLAT[it.platform];
    const e = embed().setTitle(P.emoji + ' ' + cut(it.name, 100)).setColor(P.color)
        .setDescription('**' + P.name + '** • `' + cut(it.handle, 60) + '`')
        .addFields(
            { name: '📍 روم الإرسال', value: chTxt(it.channelId), inline: true },
            { name: '🔔 المنشن', value: it.roleId ? roleTxt(it.roleId) : (it.everyone ? '@everyone' : '`بدون`'), inline: true },
            { name: '🔌 الحالة', value: it.enabled ? '✅ يعمل' : '⏸️ متوقف', inline: true },
            { name: '🎛️ ينبّه على', value: [it.kinds.video && P.video ? '🎬 مقاطع' : '', it.kinds.live ? '🔴 بثوث' : ''].filter(Boolean).join(' • ') || '`لا شيء`', inline: true },
            { name: '🖼️ صورة مخصصة', value: it.image ? '✅ موجودة' : '`صورة البث/المقطع نفسه`', inline: true },
            { name: '🩺 آخر فحص', value: ago(it.state && it.state.lastCheck) + (it.state && it.state.lastError ? '\n🔴 ' + cut(it.state.lastError, 300) : (it.state && it.state.lastOk ? '\n🟢 سليم' : '')), inline: false });
    return { embeds: [e], components: [
        row(btn('st:back', 'رجوع', '⬅️', ButtonStyle.Secondary), btn('st:msg', 'الرسالة', '✏️', ButtonStyle.Primary), btn('st:look', 'الصورة واللون', '🖼️', ButtonStyle.Primary), btn('st:test', 'إرسال تجريبي', '📨', ButtonStyle.Success), btn('st:chk', 'فحص الآن', '🔍', ButtonStyle.Secondary)),
        row(chSel('st:ch', 'روم إرسال الإشعارات', { min: 0, max: 1, selected: it.channelId ? [it.channelId] : [] })),
        row(roleSel('st:role', 'رتبة المنشن (اختياري)', { min: 0, max: 1, selected: it.roleId ? [it.roleId] : [] })),
        row(btn('st:kv', 'مقاطع', '🎬', it.kinds.video && P.video ? ButtonStyle.Success : ButtonStyle.Secondary, !P.video), btn('st:kl', 'بثوث', '🔴', it.kinds.live ? ButtonStyle.Success : ButtonStyle.Secondary),
            btn('st:ev', '@everyone', '📣', it.everyone ? ButtonStyle.Success : ButtonStyle.Secondary), btn('st:en', it.enabled ? 'إيقاف' : 'تشغيل', it.enabled ? '⏸️' : '▶️', ButtonStyle.Secondary),
            btn('st:del', ss.confirm ? 'تأكيد الحذف ⚠️' : 'حذف', '🗑️', ButtonStyle.Danger))] };
}
const refresh = (i) => update(i, buildPanel(i));

async function slash(i) {
    if (!(await adminOnly(i))) return;
    const ss = sess(i); ss.sel = ''; ss.confirm = false;
    return i.reply({ ...buildPanel(i), flags: EPH });
}

function resultEmbed(it, r, title) {
    const e = E().setColor(r.errors.length && !r.ok ? 0xED4245 : (r.errors.length ? 0xFEE75C : 0x57F287)).setTitle(title)
        .setDescription((r.info.length ? r.info.join('\n') : '') + (r.errors.length ? '\n\n' + r.errors.map(x => '🔴 ' + x).join('\n') : (r.ok ? '\n\n🟢 الاتصال سليم' : '')));
    if (r.events && r.events.length) e.addFields({ name: '📣 كان راح يرسل الحين', value: r.events.map(x => (x.kind === 'live' ? '🔴 بث: ' : '🎬 مقطع: ') + cut(x.data.title, 80)).join('\n').slice(0, 1000) });
    return e;
}

async function component(i) {
    if (!(await adminOnly(i))) return;
    const s = S(); const ss = sess(i); const act = i.customId.split(':')[1];
    const it = s.items.find(x => x.id === ss.sel);
    if (act !== 'del') ss.confirm = false;

    if (i.isButton()) {
        if (act === 'add') {
            const pl = i.customId.split(':')[2];
            if (!PLAT[pl]) return;
            const hint = pl === 'youtube' ? 'رابط القناة أو @اسمها' : pl === 'kick' ? 'اسم القناة أو رابطها' : '@اسم الحساب أو رابطه';
            return i.showModal(modal('stm:add:' + pl, 'إضافة ' + PLAT[pl].name,
                input('handle', hint, { required: true, max: 120 }),
                input('name', 'الاسم الظاهر في الإشعار (اختياري)', { required: false, max: 60 })));
        }
        if (act === 'set') return i.showModal(modal('stm:set', 'إعدادات الفحص',
            input('sec', 'كل كم ثانية يفحص (60 – 900)', { required: true, max: 3, value: clamp(s.intervalSec, 60, 900) }),
            input('rss', 'رابط RSSHub لمقاطع تيك توك', { required: true, max: 200, value: s.rsshub })));
        if (act === 'msg' && it) return i.showModal(modal('stm:msg', 'نص الإشعار',
            input('live', 'نص البث [name] [title] [platform] [game]', { required: false, paragraph: true, max: 500, value: it.liveText, placeholder: DEF_TEXT.live }),
            input('video', 'نص المقطع [name] [title] [platform]', { required: false, paragraph: true, max: 500, value: it.videoText, placeholder: DEF_TEXT.video })));
        if (act === 'look' && it) return i.showModal(modal('stm:look', 'الصورة واللون',
            input('image', 'رابط صورة مخصصة (فاضي = صورة البث نفسه)', { required: false, max: 300, value: it.image }),
            input('color', 'لون الإشعار (مثال: #ff0000)', { required: false, max: 7, value: it.color }),
            input('footer', 'نص التذييل (اختياري)', { required: false, max: 100, value: it.footer })));
        if (act === 'test' && it) {
            await i.deferReply({ flags: EPH });
            const ev = it.kinds.live || !PLAT[it.platform].video
                ? { kind: 'live', data: { title: 'عنوان البث التجريبي', url: it.platform === 'kick' ? 'https://kick.com/' + it.handle : (it.platform === 'tiktok' ? 'https://www.tiktok.com/@' + it.handle + '/live' : 'https://www.youtube.com/@' + it.handle), thumb: '', game: 'Just Chatting', viewers: 123 } }
                : { kind: 'video', data: { title: 'عنوان المقطع التجريبي', url: 'https://www.youtube.com/', thumb: '' } };
            try { await notify(it, ev, true); return i.editReply({ content: '✅ أُرسلت رسالة تجريبية في <#' + it.channelId + '>' }); }
            catch (e) { return i.editReply({ content: '❌ ' + e.message }); }
        }
        if (act === 'chk' && it) {
            await i.deferReply({ flags: EPH });
            const r = await runCheck(it, { dry: true });
            return i.editReply({ embeds: [resultEmbed(it, r, '🔍 فحص ' + cut(it.name, 80))] });
        }
        if (act === 'scan') {
            await i.deferReply({ flags: EPH });
            const lines = []; let sent = 0;
            for (const x of s.items) {
                if (!x.channelId) { lines.push('⚪ ' + x.name + ' — بدون روم إرسال'); continue; }
                const r = await runCheck(x); sent += r.sent;
                lines.push((r.errors.length && !r.ok ? '🔴 ' : r.errors.length ? '🟠 ' : '🟢 ') + '**' + cut(x.name, 30) + '** — ' + (r.errors.length ? cut(r.errors[0], 140) : (r.sent ? 'أُرسل ' + r.sent + ' إشعار' : 'لا جديد')));
                await sleep(300);
            }
            return i.editReply({ embeds: [E().setColor(BLUE).setTitle('🔍 نتيجة فحص الكل').setDescription(cut(lines.join('\n') || 'لا توجد حسابات', 4000)).setFooter({ text: 'أُرسل ' + sent + ' إشعار' })] });
        }
        await i.deferUpdate();
        if (act === 'back') ss.sel = '';
        else if (it && act === 'kv') { if (PLAT[it.platform].video) it.kinds.video = !it.kinds.video; }
        else if (it && act === 'kl') it.kinds.live = !it.kinds.live;
        else if (it && act === 'ev') { it.everyone = !it.everyone; if (it.everyone) it.roleId = ''; }
        else if (it && act === 'en') it.enabled = !it.enabled;
        else if (it && act === 'del') {
            if (!ss.confirm) ss.confirm = true;
            else { s.items = s.items.filter(x => x.id !== it.id); ss.sel = ''; ss.confirm = false; }
        }
        H.save();
        return i.editReply(buildPanel(i));
    }

    await i.deferUpdate();
    if (i.isStringSelectMenu() && act === 'sel') ss.sel = i.values[0];
    else if (i.isChannelSelectMenu() && act === 'ch' && it) it.channelId = i.values[0] || '';
    else if (i.isRoleSelectMenu() && act === 'role' && it) { it.roleId = i.values[0] || ''; if (it.roleId) it.everyone = false; }
    H.save();
    return i.editReply(buildPanel(i));
}

async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const s = S(); const ss = sess(i); const parts = i.customId.split(':'); const act = parts[1];
    const it = s.items.find(x => x.id === ss.sel);
    const val = (n) => { try { return i.fields.getTextInputValue(n).trim(); } catch { return ''; } };
    const bad = (m) => i.reply({ content: '❌ ' + m, flags: EPH });

    if (act === 'add') {
        const pl = parts[2]; if (!PLAT[pl]) return;
        if (s.items.length >= MAX_ITEMS) return bad('وصلت الحد الأقصى (' + MAX_ITEMS + ').');
        await i.deferUpdate();
        const raw = val('handle'); const custom = val('name');
        let item = { id: rid(), platform: pl, handle: '', ytId: '', name: custom, avatar: '', channelId: '', roleId: '', everyone: false, kinds: { video: !!PLAT[pl].video, live: true }, liveText: '', videoText: '', image: '', color: '', footer: '', enabled: true, state: {} };
        try {
            if (pl === 'youtube') { const r = await ytResolve(raw); item.ytId = r.id; item.handle = (ytInput(raw) && ytInput(raw).handle) || r.id; item.name = custom || r.name || item.handle; item.avatar = r.avatar; }
            else if (pl === 'kick') { const slug = kickSlug(raw); if (!slug) throw new Error('اكتب اسم قناة كيك أو رابطها'); item.handle = slug; item.name = custom || slug; try { const k = await kickInfo(slug); item.name = custom || k.name || slug; item.avatar = k.avatar; } catch (e) { if (/غير موجودة/.test(e.message)) throw e; } }
            else { const u = ttUser(raw); if (!u) throw new Error('اكتب @اسم الحساب أو رابطه'); item.handle = u; item.name = custom || '@' + u; }
        } catch (e) { await i.editReply(buildPanel(i)); return i.followUp({ content: '❌ ' + e.message, flags: EPH }); }
        s.items.push(item); ss.sel = item.id; H.save();
        await i.editReply(buildPanel(i));
        return i.followUp({ content: '✅ تمت إضافة **' + item.name + '**. الحين اختر **روم الإرسال** (ورتبة المنشن لو تبغى)، وبعدها جرّب **إرسال تجريبي**.', flags: EPH });
    }
    if (act === 'set') {
        const sec = parseInt(val('sec'), 10); const rss = val('rss');
        if (!Number.isFinite(sec) || sec < 60 || sec > 900) return bad('الفحص من 60 إلى 900 ثانية.');
        if (!isUrl(rss)) return bad('رابط RSSHub غير صحيح.');
        s.intervalSec = sec; s.rsshub = rss.replace(/\/+$/, ''); schedule();
    } else if (act === 'msg' && it) { it.liveText = val('live'); it.videoText = val('video'); }
    else if (act === 'look' && it) {
        const img = val('image'), col = val('color');
        if (img && !isUrl(img)) return bad('رابط الصورة غير صحيح.');
        if (col && !normColor(col)) return bad('اللون لازم يكون بصيغة #ff0000');
        it.image = img; it.color = normColor(col) || ''; it.footer = val('footer');
    } else return;
    H.save();
    return refresh(i);
}

const commands = [{ name: 'streams', description: 'إشعارات البثوث والمقاطع: يوتيوب • تيك توك • كيك (إدارة)' }];
return { prefix: 'st', commands, ephemeral: ['streams'], slash: { streams: slash }, component, modal: modalSubmit,
    _t: { parseRss, classifyWatch, parseChannelHtml, ytInput, parseKick, kickSlug, parseTikTokLive, parseRssHub, ttUser, buildPayload, runCheck, tick, buildPanel } };
};
