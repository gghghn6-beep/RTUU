'use strict';
// ═══ إدارة الأوامر: /cmdmanager — تفعيل وإيقاف أوامر الشات (-أمر) بقائمة ═══
module.exports = (H) => {
const { D, EPH, row, btn, strSel, embed, cut, session, adminOnly, update } = H;
const db = H.db;
const { ButtonStyle } = D;
const PAGE = 20;
const disabled = () => ((db.cmds = db.cmds || {}).disabled = (db.cmds.disabled || []));
function groups() {
    const CMDS = H.getCMDS() || {}; const map = new Map();
    for (const [name, fn] of Object.entries(CMDS)) { if (!map.has(fn)) map.set(fn, []); map.get(fn).push(name); }
    return [...map.values()].map(a => ({ id: a[0], aliases: a }));
}
const sess = (i) => session(i, 'cm', () => ({ page: 0 }));
function buildPanel(i) {
    const g = groups(); const s = sess(i); const dis = new Set(disabled());
    const pages = Math.max(1, Math.ceil(g.length / PAGE)); s.page = Math.min(s.page, pages - 1);
    const slice = g.slice(s.page * PAGE, s.page * PAGE + PAGE);
    const e = embed().setTitle('🧰 إدارة الأوامر')
        .setDescription('أوامر الشات التي تبدأ بـ `-`. **المحدد في القائمة = مفعّل**، وإلغاء التحديد يوقف الأمر.')
        .addFields({ name: '📊 الحالة', value: 'مفعّل: **' + g.filter(x => !dis.has(x.id)).length + '** • متوقف: **' + g.filter(x => dis.has(x.id)).length + '**', inline: true }, { name: '📄 الصفحة', value: (s.page + 1) + ' / ' + pages, inline: true },
            { name: '🗂️ أوامر هذه الصفحة', value: slice.map(x => (dis.has(x.id) ? '⛔' : '✅') + ' `' + x.aliases.join(' / ') + '`').join('\n') || '—' });
    const rows = [];
    if (slice.length) rows.push(row(strSel('cm:sel', 'الأوامر المفعّلة في هذه الصفحة', slice.map(x => ({ label: cut(x.aliases.join(' / '), 100), value: x.id, default: !dis.has(x.id) })), { min: 0, max: slice.length })));
    rows.push(row(btn('cm:prev', 'السابق', '◀️', ButtonStyle.Secondary, s.page <= 0), btn('cm:next', 'التالي', '▶️', ButtonStyle.Secondary, s.page >= pages - 1), btn('cm:all', 'تفعيل الكل', '✅', ButtonStyle.Success), btn('cm:none', 'إيقاف الكل', '⛔', ButtonStyle.Danger)));
    return { embeds: [e], components: rows };
}
async function slash(i) { if (!(await adminOnly(i))) return; return i.reply({ ...buildPanel(i), flags: EPH }); }
async function component(i) {
    if (!(await adminOnly(i))) return;
    const s = sess(i); const a = i.customId.split(':')[1]; const g = groups();
    await i.deferUpdate();
    if (a === 'prev') s.page = Math.max(0, s.page - 1);
    else if (a === 'next') s.page++;
    else if (a === 'all') db.cmds.disabled = [];
    else if (a === 'none') db.cmds.disabled = g.map(x => x.id);
    else if (a === 'sel') {
        const slice = g.slice(s.page * PAGE, s.page * PAGE + PAGE); const keep = new Set(i.values);
        const dis = new Set(disabled());
        for (const x of slice) { if (keep.has(x.id)) dis.delete(x.id); else dis.add(x.id); }
        db.cmds.disabled = [...dis];
    }
    H.save();
    return i.editReply(buildPanel(i));
}
function isCommandDisabled(name) {
    const d = (db.cmds && db.cmds.disabled) || []; if (!d.length) return false;
    const g = groups().find(x => x.aliases.includes(name));
    return !!g && d.includes(g.id);
}
const commands = [{ name: 'cmdmanager', description: 'قائمة إدارة أوامر الشات (تفعيل / إيقاف كل أمر)' }];
return { prefix: 'cm', commands, ephemeral: ['cmdmanager'], slash: { cmdmanager: slash }, component, isCommandDisabled, _buildPanel: buildPanel };
};
