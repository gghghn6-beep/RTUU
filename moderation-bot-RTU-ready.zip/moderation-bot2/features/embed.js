'use strict';
// ═══ صانع الإيمبد: /embed — قائمة تصميم + معاينة حية + إرسال + حفظ وتحميل قوالب ═══
module.exports = (H) => {
const { D, path, fs, DATA_DIR, BLUE, EPH, row, btn, strSel, chSel, input, modal, embed, cut, isUrl, rid, session, adminOnly, update, fetchBuffer, onOff, chTxt, getTextChannel } = H;
const db = H.db;
const { ButtonBuilder, ButtonStyle, AttachmentBuilder } = D;
const ASSETS = path.join(DATA_DIR, 'embed-assets');
const COLORS = [
    { label: 'أزرق (الافتراضي)', value: '#0A3A8C', emoji: '🔵' }, { label: 'أزرق غامق', value: '#0A3A8C', emoji: '🔵' },
    { label: 'أحمر', value: '#ED4245', emoji: '🔴' }, { label: 'أخضر', value: '#57F287', emoji: '🟢' },
    { label: 'أصفر', value: '#FEE75C', emoji: '🟡' }, { label: 'وردي', value: '#EB459E', emoji: '🌸' },
    { label: 'برتقالي', value: '#E67E22', emoji: '🟠' }, { label: 'أبيض', value: '#FFFFFF', emoji: '⚪' },
    { label: 'داكن', value: '#2B2D31', emoji: '⚫' }, { label: 'لون مخصص (HEX)', value: 'custom', emoji: '🎨' }
];
const blank = () => ({ actionType: 'buttons', actionPh: '', actions: [], channelId: '', content: '', color: '#0A3A8C', author: { name: '', url: '', icon: '' }, title: '', url: '', description: '', thumbnail: '', image: '', fields: [], footer: { text: '', icon: '' }, timestamp: false, buttons: [] });
const draftOf = (i) => session(i, 'em', blank);
const saved = () => (db.embeds = db.embeds || {});

function parseEmoji(e) {
    e = String(e || '').trim(); if (!e) return undefined;
    const m = e.match(/^<(a?):(\w+):(\d+)>$/); if (m) return { id: m[3], name: m[2], animated: !!m[1] };
    const u = e.match(/\p{Extended_Pictographic}\uFE0F?(\u200D\p{Extended_Pictographic}\uFE0F?)*/u);
    return u ? u[0] : undefined;
}
function actionRows(d, sid) {
    const acts = d.actions.slice(0, 10); if (!acts.length) return [];
    if (d.actionType === 'menu') return [row(strSel('ea:' + sid + ':m', cut(d.actionPh || 'اختر من القائمة...', 150), acts.map(a => ({ label: a.label, value: a.id, emoji: parseEmoji(a.emoji) })), { min: 1, max: 1 }))];
    const out = []; for (let k = 0; k < acts.length; k += 5) out.push(row(...acts.slice(k, k + 5).map(a => btn('ea:' + sid + ':' + a.id, a.label, parseEmoji(a.emoji), ButtonStyle.Secondary)))); return out;
}
function toApi(d, sid) {
    const files = []; const seen = new Set();
    const att = (v) => {
        if (!v) return undefined;
        if (v.startsWith('file:')) {
            const n = v.slice(5); const p = path.join(ASSETS, n);
            if (!fs.existsSync(p)) return undefined;
            if (!seen.has(n)) { seen.add(n); files.push(new AttachmentBuilder(p, { name: n })); }
            return 'attachment://' + n;
        }
        return isUrl(v) ? v.trim() : undefined;
    };
    const e = { color: parseInt(String(d.color || '#0A3A8C').replace('#', ''), 16) || 0x0A3A8C };
    if (d.title) { e.title = cut(d.title, 256); if (isUrl(d.url)) e.url = d.url.trim(); }
    if (d.description) e.description = cut(d.description, 4000);
    if (d.author.name) { e.author = { name: cut(d.author.name, 256) }; if (isUrl(d.author.url)) e.author.url = d.author.url.trim(); const ic = att(d.author.icon); if (ic) e.author.icon_url = ic; }
    const th = att(d.thumbnail); if (th) e.thumbnail = { url: th };
    const im = att(d.image); if (im) e.image = { url: im };
    if (d.fields.length) e.fields = d.fields.slice(0, 10).map(f => ({ name: cut(f.name, 256), value: cut(f.value, 1024), inline: !!f.inline }));
    if (d.footer.text) { e.footer = { text: cut(d.footer.text, 2048) }; const ic = att(d.footer.icon); if (ic) e.footer.icon_url = ic; }
    if (d.timestamp) e.timestamp = new Date().toISOString();
    const valid = !!(e.title || e.description || e.fields || e.image || e.thumbnail || e.author || e.footer);
    const components = sid ? actionRows(d, sid) : [];
    if (d.buttons.length) components.push(row(...d.buttons.slice(0, 5).map(b => new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel(cut(b.label, 80)).setURL(b.url))));
    return { embed: e, files, components, valid };
}

const pageOf = (i) => session(i, 'emp', () => ({ page: 'main', sel: null }));
function buildPanel(i) { return pageOf(i).page === 'actions' ? buildActionsPanel(i) : buildMainPanel(i); }
function buildMainPanel(i) {
    const d = draftOf(i);
    const api = toApi(d);
    const names = Object.keys(saved());
    const info = embed().setTitle('🧩 صانع الإيمبد')
        .setDescription('صمّم رسالتك خطوة خطوة، المعاينة تظهر تحت مباشرة، وبعدها اختر الروم واضغط **إرسال**.')
        .addFields(
            { name: '📍 الروم', value: chTxt(d.channelId), inline: true },
            { name: '🎨 اللون', value: '`' + d.color + '`', inline: true },
            { name: '🕒 التوقيت', value: d.timestamp ? 'ظاهر' : 'مخفي', inline: true },
            { name: '🧱 المحتوى', value: 'حقول: **' + d.fields.length + '/10** • أزرار روابط: **' + d.buttons.length + '/5**' + (d.content ? ' • نص فوق الإيمبد ✅' : '') + ' • إجراءات تفاعلية: **' + d.actions.length + '/10**', inline: false },
            { name: '💾 القوالب المحفوظة', value: names.length ? names.slice(0, 15).map(n => '`' + n + '`').join(' • ') : 'لا يوجد' }
        ).setFooter({ text: 'معاينة حية • كل شيء بالألوان الزرقاء 💙' });
    const preview = api.valid ? api.embed : { color: 0x0A3A8C, description: '*المعاينة فارغة — ابدأ بـ **الأساسيات** لإضافة عنوان ووصف.*' };
    const rows = [
        row(btn('em:main', 'الأساسيات', '✏️', ButtonStyle.Primary), btn('em:author', 'الكاتب', '👤'), btn('em:media', 'الصور', '🖼️'), btn('em:footer', 'الفوتر', '🔻'), btn('em:ts', d.timestamp ? 'إخفاء الوقت' : 'إظهار الوقت', '🕒')),
        row(btn('em:addf', 'حقل', '➕'), btn('em:delf', 'حذف حقل', '➖', ButtonStyle.Secondary, !d.fields.length), btn('em:btns', 'أزرار', '🔘'), btn('em:save', 'حفظ', '💾'), btn('em:load', 'تحميل', '📂')),
        row(strSel('em:color', 'لون الشريط الجانبي', COLORS.map(c => ({ ...c, default: c.value.toLowerCase() === d.color.toLowerCase() })))),
        row(chSel('em:ch', 'اختر الروم اللي يرسل فيه الإيمبد', { selected: d.channelId ? [d.channelId] : [] })),
        row(btn('em:send', 'إرسال', '📤', ButtonStyle.Success), btn('em:content', 'نص فوق الإيمبد', '📝'), btn('em:acts', 'إجراءات', '🎛️', ButtonStyle.Primary), btn('em:clear', 'تفريغ', '🧹', ButtonStyle.Danger))
    ];
    const out = { embeds: [info, preview], components: rows, attachments: [] };
    if (api.files.length) out.files = api.files;
    return out;
}
function buildActionsPanel(i) {
    const d = draftOf(i); const s = pageOf(i); const api = toApi(d);
    if (!d.actions.find(a => a.id === s.sel)) s.sel = d.actions[0] ? d.actions[0].id : null;
    const cur = d.actions.find(a => a.id === s.sel);
    const info = embed().setTitle('🎛️ الإجراءات التفاعلية')
        .setDescription('كل إجراء = **زر** (أو خيار في **قائمة**) يرد على الضاغط برسالة **مخفية** تظهر له وحده — مثل: قوانين العدل، قوانين الصحة، قوانين الشات...\nاتركها فاضية وتصير الرسالة عادية بدون أزرار.')
        .addFields(
            { name: '🔘 النوع', value: d.actionType === 'menu' ? 'قائمة منسدلة' : 'أزرار', inline: true }, { name: '📊 العدد', value: d.actions.length + '/10', inline: true },
            { name: '🗂️ الإجراءات', value: d.actions.length ? d.actions.map(a => (a.id === s.sel ? '▶️ ' : '▫️ ') + (a.emoji ? a.emoji + ' ' : '') + '**' + cut(a.label, 40) + '**').join('\n') : '`لا توجد إجراءات — اضغط ➕ إضافة`' });
    if (cur) info.addFields({ name: '💬 الرد المخفي (' + cut(cur.label, 30) + ')', value: cut(cur.reply, 900) });
    info.setFooter({ text: 'معاينة حية • كل شيء بالألوان الزرقاء 💙' });
    const preview = api.valid ? api.embed : { color: 0x0A3A8C, description: '*المعاينة فارغة — ارجع وابدأ بـ **الأساسيات**.*' };
    const rows = [row(btn('em:actback', 'رجوع', '⬅️', ButtonStyle.Primary), btn('em:actnew', 'إضافة', '➕', ButtonStyle.Success, d.actions.length >= 10), btn('em:actedit', 'تعديل', '✏️', ButtonStyle.Secondary, !cur),
        btn('em:actdel', 'حذف', '🗑️', ButtonStyle.Danger, !cur), btn('em:acttype', d.actionType === 'menu' ? 'النوع: قائمة' : 'النوع: أزرار', '🔁'))];
    if (d.actions.length) rows.push(row(strSel('em:actpick', 'اختر إجراء لتعديله', d.actions.map(a => ({ label: a.label, value: a.id, emoji: parseEmoji(a.emoji), description: cut(a.reply, 90), default: a.id === s.sel })))));
    const out = { embeds: [info, preview], components: rows, attachments: [] };
    if (api.files.length) out.files = api.files;
    return out;
}
const refresh = (i) => update(i, buildPanel(i));

async function saveAsset(att) {
    if (!String(att.contentType || '').startsWith('image/')) throw new Error('لازم تكون صورة');
    const { buf } = await fetchBuffer(att.url, 8 * 1048576);
    fs.mkdirSync(ASSETS, { recursive: true });
    const ext = ((att.name || '').split('.').pop() || 'png').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 5) || 'png';
    const name = rid() + rid() + '.' + ext;
    fs.writeFileSync(path.join(ASSETS, name), buf);
    return 'file:' + name;
}

async function slashEmbed(i) {
    if (!(await adminOnly(i))) return;
    const d = draftOf(i);
    if (i.options.getBoolean('reset')) { const n = blank(); for (const k of Object.keys(d)) delete d[k]; Object.assign(d, n); }
    const th = i.options.getAttachment('thumbnail'), im = i.options.getAttachment('image');
    try { if (th) d.thumbnail = await saveAsset(th); if (im) d.image = await saveAsset(im); }
    catch (e) { return i.reply({ content: '❌ تعذّر تحميل الصورة: ' + e.message, flags: EPH }); }
    return i.reply({ ...buildPanel(i), flags: EPH });
}

async function component(i) {
    if (!(await adminOnly(i))) return;
    const d = draftOf(i); const id = i.customId; const a = id.split(':')[1];
    if (i.isButton()) {
        if (a === 'main') return i.showModal(modal('emm:main', 'الأساسيات',
            input('title', 'العنوان', { value: d.title, max: 256 }), input('url', 'رابط العنوان (اختياري)', { value: d.url, max: 300 }),
            input('description', 'وصف الإيمبد', { value: d.description, paragraph: true, max: 4000 })));
        if (a === 'author') return i.showModal(modal('emm:author', 'الكاتب',
            input('name', 'اسم الكاتب', { value: d.author.name, max: 256 }), input('url', 'رابط الكاتب (اختياري)', { value: d.author.url, max: 300 }),
            input('icon', 'رابط صورة الكاتب (اختياري)', { value: d.author.icon.startsWith('file:') ? '' : d.author.icon, max: 300 })));
        if (a === 'media') return i.showModal(modal('emm:media', 'الصور',
            input('thumbnail', 'رابط الصورة المصغرة (يمين)', { value: d.thumbnail.startsWith('file:') ? '' : d.thumbnail, max: 400, placeholder: 'أو ارفعها بـ /embed thumbnail:' }),
            input('image', 'رابط الصورة الكبيرة', { value: d.image.startsWith('file:') ? '' : d.image, max: 400, placeholder: 'أو ارفعها بـ /embed image:' })));
        if (a === 'footer') return i.showModal(modal('emm:footer', 'الفوتر',
            input('text', 'نص الذيل', { value: d.footer.text, max: 2048 }), input('icon', 'رابط صورة الذيل (اختياري)', { value: d.footer.icon.startsWith('file:') ? '' : d.footer.icon, max: 300 })));
        if (a === 'addf') {
            if (d.fields.length >= 10) return i.reply({ content: '❌ الحد الأقصى 10 حقول.', flags: EPH });
            return i.showModal(modal('emm:addf', 'حقل جديد',
                input('name', 'اسم الحقل', { required: true, max: 256 }), input('value', 'قيمة الحقل', { required: true, paragraph: true, max: 1024 }),
                input('inline', 'بجانب غيره؟ (نعم / لا)', { value: 'لا', max: 3 })));
        }
        if (a === 'delf') return i.showModal(modal('emm:delf', 'حذف حقل', input('n', 'رقم الحقل (1 - ' + d.fields.length + ')', { required: true, max: 2 })));
        if (a === 'btns') return i.showModal(modal('emm:btns', 'أزرار الروابط (حد أقصى 5)',
            input('lines', 'كل سطر: نص الزر | الرابط', { paragraph: true, max: 1000, placeholder: 'يوتيوب | https://youtube.com/...', value: d.buttons.map(b => b.label + ' | ' + b.url).join('\n') })));
        if (a === 'content') return i.showModal(modal('emm:content', 'نص الرسالة', input('text', 'نص فوق الإيمبد (اختياري)', { value: d.content, paragraph: true, max: 2000 }), input('ph', 'عنوان القائمة المنسدلة (اختياري)', { value: d.actionPh, max: 100, placeholder: 'اختر القسم...' })));
        if (a === 'actnew') {
            if (d.actions.length >= 10) return i.reply({ content: '❌ الحد الأقصى 10 إجراءات.', flags: EPH });
            return i.showModal(modal('emm:act', 'إجراء جديد', input('label', 'اسم الزر / الخيار', { required: true, max: 80, placeholder: 'قوانين العدل' }), input('emoji', 'إيموجي (اختياري)', { max: 60, placeholder: '⚖️' }), input('reply', 'الرد المخفي عند الضغط', { required: true, paragraph: true, max: 3500, placeholder: 'اكتب القوانين هنا...' })));
        }
        if (a === 'actedit') { const c = d.actions.find(x => x.id === pageOf(i).sel); if (c) return i.showModal(modal('emm:actedit', 'تعديل الإجراء', input('label', 'اسم الزر / الخيار', { required: true, max: 80, value: c.label }), input('emoji', 'إيموجي (اختياري)', { max: 60, value: c.emoji }), input('reply', 'الرد المخفي عند الضغط', { required: true, paragraph: true, max: 3500, value: c.reply }))); }
        if (a === 'save') return i.showModal(modal('emm:save', 'حفظ القالب', input('name', 'اسم القالب', { required: true, max: 40 })));
        if (a === 'load') return i.showModal(modal('emm:load', 'تحميل قالب', input('name', 'اسم القالب', { required: true, max: 40, placeholder: Object.keys(saved()).slice(0, 5).join(' / ') })));
        await i.deferUpdate();
        const ps = pageOf(i);
        if (a === 'acts') ps.page = 'actions';
        else if (a === 'actback') ps.page = 'main';
        else if (a === 'acttype') d.actionType = d.actionType === 'menu' ? 'buttons' : 'menu';
        else if (a === 'actdel') { d.actions = d.actions.filter(x => x.id !== ps.sel); ps.sel = null; }
        else if (a === 'ts') d.timestamp = !d.timestamp;
        else if (a === 'clear') { const n = blank(); n.channelId = d.channelId; for (const k of Object.keys(d)) delete d[k]; Object.assign(d, n); }
        else if (a === 'send') {
            const sid = rid(); const api = toApi(d, sid);
            if (!api.valid) return i.followUp({ content: '❌ الإيمبد فاضي — أضف عنوان أو وصف أولاً.', flags: EPH });
            const ch = await getTextChannel(i.guild, d.channelId);
            if (!ch) return i.followUp({ content: '❌ اختر الروم أولاً من القائمة.', flags: EPH });
            try {
                if (d.actions.length) {
                    const store = (db.embedMsgs = db.embedMsgs || {});
                    store[sid] = { type: d.actionType, color: d.color, actions: d.actions.map(x => ({ id: x.id, label: x.label, emoji: x.emoji, reply: x.reply })) };
                    const keys = Object.keys(store); for (const k of keys.slice(0, Math.max(0, keys.length - 300))) delete store[k];
                    H.save();
                }
                const sent = await ch.send({ content: d.content || undefined, embeds: [api.embed], files: api.files, components: api.components });
                await i.followUp({ content: '✅ تم الإرسال إلى <#' + ch.id + '>\n' + sent.url, flags: EPH });
            } catch (e) { await i.followUp({ content: '❌ فشل الإرسال: ' + e.message + '\nتأكد من صلاحيات البوت في الروم.', flags: EPH }); }
        }
        return i.editReply(buildPanel(i));
    }
    if (i.isStringSelectMenu() && a === 'actpick') { pageOf(i).sel = i.values[0]; return refresh(i); }
    if (i.isStringSelectMenu() && a === 'color') {
        const v = i.values[0];
        if (v === 'custom') return i.showModal(modal('emm:color', 'لون مخصص', input('hex', 'كود اللون HEX (مثل #0A3A8C)', { required: true, max: 7, value: d.color })));
        d.color = v; return refresh(i);
    }
    if (i.isChannelSelectMenu() && a === 'ch') { d.channelId = i.values[0]; return refresh(i); }
}

async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const d = draftOf(i); const a = i.customId.split(':')[1];
    const f = (n) => { try { return i.fields.getTextInputValue(n).trim(); } catch { return ''; } };
    const bad = (m) => i.reply({ content: '❌ ' + m, flags: EPH });
    if (a === 'main') { d.title = f('title'); d.url = f('url'); d.description = i.fields.getTextInputValue('description'); if (d.url && !isUrl(d.url)) { d.url = ''; } }
    else if (a === 'author') { d.author = { name: f('name'), url: isUrl(f('url')) ? f('url') : '', icon: isUrl(f('icon')) ? f('icon') : (d.author.icon.startsWith('file:') ? d.author.icon : '') }; }
    else if (a === 'media') {
        const t = f('thumbnail'), im = f('image');
        if ((t && !isUrl(t)) || (im && !isUrl(im))) return bad('الرابط لازم يبدأ بـ https://');
        if (t) d.thumbnail = t; else if (!d.thumbnail.startsWith('file:')) d.thumbnail = '';
        if (im) d.image = im; else if (!d.image.startsWith('file:')) d.image = '';
    }
    else if (a === 'footer') { d.footer = { text: f('text'), icon: isUrl(f('icon')) ? f('icon') : (d.footer.icon.startsWith('file:') ? d.footer.icon : '') }; }
    else if (a === 'addf') { if (d.fields.length >= 10) return bad('الحد الأقصى 10 حقول.'); d.fields.push({ name: f('name'), value: i.fields.getTextInputValue('value').trim(), inline: /^(نعم|yes|y|true|1)$/i.test(f('inline')) }); }
    else if (a === 'delf') { const n = parseInt(f('n'), 10); if (!(n >= 1 && n <= d.fields.length)) return bad('رقم الحقل غير صحيح.'); d.fields.splice(n - 1, 1); }
    else if (a === 'btns') {
        const out = [];
        for (const line of f('lines').split('\n').map(s => s.trim()).filter(Boolean)) {
            const [label, ...rest] = line.split('|'); const url = rest.join('|').trim();
            if (!label.trim() || !isUrl(url)) return bad('السطر غير صحيح: `' + cut(line, 60) + '` — الصيغة: نص | https://...');
            out.push({ label: cut(label.trim(), 80), url });
        }
        if (out.length > 5) return bad('الحد الأقصى 5 أزرار.');
        d.buttons = out;
    }
    else if (a === 'content') { d.content = i.fields.getTextInputValue('text').trim(); d.actionPh = f('ph'); }
    else if (a === 'act' || a === 'actedit') {
        const label = f('label'), reply = i.fields.getTextInputValue('reply').trim();
        if (!label || !reply) return bad('الاسم والرد مطلوبين.');
        const emoji = f('emoji');
        if (a === 'act') { if (d.actions.length >= 10) return bad('الحد الأقصى 10 إجراءات.'); const x = { id: rid(), label, emoji, reply }; d.actions.push(x); pageOf(i).sel = x.id; }
        else { const c = d.actions.find(x => x.id === pageOf(i).sel); if (c) { c.label = label; c.emoji = emoji; c.reply = reply; } }
        pageOf(i).page = 'actions';
    }
    else if (a === 'color') { const h = f('hex'); if (!/^#?[0-9a-f]{6}$/i.test(h)) return bad('اللون لازم يكون مثل #0A3A8C'); d.color = h.startsWith('#') ? h : '#' + h; }
    else if (a === 'save') {
        const n = f('name'); const s = saved();
        if (!s[n] && Object.keys(s).length >= 25) return bad('وصلت الحد الأقصى للقوالب (25).');
        s[n] = JSON.parse(JSON.stringify({ ...d, channelId: '' })); H.save();
    }
    else if (a === 'load') {
        const s = saved(); const n = f('name');
        if (!s[n]) return bad('ما لقيت قالب بهذا الاسم.');
        const ch = d.channelId; for (const k of Object.keys(d)) delete d[k]; Object.assign(d, blank(), JSON.parse(JSON.stringify(s[n])), { channelId: ch });
    }
    return refresh(i);
}

async function publicAction(i) {
    const [, sid, what] = i.customId.split(':');
    const rec = (db.embedMsgs || {})[sid];
    const id = i.isStringSelectMenu && i.isStringSelectMenu() ? i.values[0] : what;
    const a = rec && rec.actions.find(x => x.id === id);
    if (!a) return i.reply({ content: '❌ هذا الإجراء لم يعد متاحاً.', flags: EPH });
    const color = parseInt(String(rec.color || '#0A3A8C').replace('#', ''), 16) || 0x0A3A8C;
    return i.reply({ embeds: [{ color, title: cut((a.emoji ? a.emoji + ' ' : '') + a.label, 256), description: cut(a.reply, 4000) }], flags: EPH });
}
const commands = [
    { name: 'embed', description: 'صانع الإيمبد: قائمة تصميم + معاينة حية + إرسال وحفظ قوالب', options: [
        { name: 'image', description: 'ارفع الصورة الكبيرة للإيمبد', type: 11, required: false },
        { name: 'thumbnail', description: 'ارفع الصورة المصغرة للإيمبد', type: 11, required: false },
        { name: 'reset', description: 'ابدأ إيمبد جديد من الصفر', type: 5, required: false }
    ]}
];
return { prefix: 'em', commands, ephemeral: ['embed'], slash: { embed: slashEmbed }, component, modal: modalSubmit, extra: { ea: publicAction }, _buildPanel: buildPanel };
};
