'use strict';
/**
 * حدود الصلاحيات /limits — حماية من التخريب (Anti-Nuke):
 *  • حد أعلى لعمليات الباند • الطرد • الرومات (إنشاء/حذف) • الرتب (إنشاء/حذف) • إدارة رتب الأعضاء (إعطاء/سحب)
 *  • إجراء عند التجاوز: سحب الرتب الإدارية (ينصح به) / طرد / حظر
 *  • قائمة بيضاء (لا تُراقَب) + روم سجل التجاوزات
 * وأمر الشات automod! لقاعدة Discord AutoMod الخاصة بمنع منشن السبام.
 */
module.exports = (H) => {
const { D, client, SERVER_ID, isAdmin, save, row, btn, strSel, chSel, input, modal, embed, cut, adminOnly, update, onOff, chTxt, clamp } = H;
const db = H.db;
const { ButtonStyle, AuditLogEvent: AL, PermissionFlagsBits: P } = D;

const KEYS = {
    ban: ['🔨', 'الحد الأعلى للباند'], kick: ['👢', 'الحد الأعلى للطرد'], channels: ['💬', 'الحد الأعلى للرومات (إنشاء / حذف)'],
    roles: ['🏷️', 'الحد الأعلى للرتب (إنشاء / حذف)'], rolemgmt: ['👤', 'إدارة رتب الأعضاء (إعطاء / سحب)']
};
const ACTIONS = { strip: ['🧹', 'سحب الرتب الإدارية من العضو (ينصح به)'], kick: ['👢', 'طرد العضو'], ban: ['🔨', 'حظر العضو'] };
const WINDOWS = [1, 5, 10, 30, 60];
const DANGER = [P.Administrator, P.ManageGuild, P.ManageRoles, P.ManageChannels, P.BanMembers, P.KickMembers, P.ManageWebhooks].filter(Boolean);

function cfg() {
    const c = (db.limits = db.limits || {});
    c.enabled = !!c.enabled;
    c.action = ACTIONS[c.action] ? c.action : 'strip';
    c.window = WINDOWS.includes(c.window) ? c.window : 10;
    c.limits = c.limits || {};
    for (const k of Object.keys(KEYS)) c.limits[k] = Number.isFinite(c.limits[k]) ? c.limits[k] : 3;
    c.whitelist = Array.isArray(c.whitelist) ? c.whitelist : [];
    c.logChannelId = c.logChannelId || '';
    c.recent = Array.isArray(c.recent) ? c.recent : [];
    return c;
}

// ───── الرصد ─────
const hits = new Map();
async function executor(guild, type, targetId) {
    await new Promise(r => setTimeout(r, 900));
    try {
        const logs = await guild.fetchAuditLogs({ type, limit: 6 }); const now = Date.now();
        const e = logs.entries.find(x => (!targetId || (x.target && x.target.id === targetId)) && now - x.createdTimestamp < 20000);
        return e && e.executor ? e.executor.id : null;
    } catch { return null; }
}
async function track(guild, key, uid, what) {
    const c = cfg();
    if (!c.enabled || !uid || uid === client.user.id || uid === guild.ownerId || c.whitelist.includes(uid)) return;
    const k = uid + ':' + key; const now = Date.now();
    const arr = (hits.get(k) || []).filter(t => now - t < c.window * 60000); arr.push(now); hits.set(k, arr);
    if (arr.length <= c.limits[key]) return;
    hits.delete(k);
    await punish(guild, uid, key, arr.length, what);
}
async function punish(guild, uid, key, n, what) {
    const c = cfg(); const m = await guild.members.fetch(uid).catch(() => null); const reason = 'تجاوز حدود الصلاحيات: ' + KEYS[key][1];
    let res;
    try {
        if (c.action === 'ban') { await guild.members.ban(uid, { reason }); res = 'تم حظره'; }
        else if (!m) res = 'العضو غير موجود في السيرفر';
        else if (c.action === 'kick') { await m.kick(reason); res = 'تم طرده'; }
        else {
            const bad = m.roles.cache.filter(r => r.id !== guild.id && !r.managed && DANGER.some(f => r.permissions.has(f)));
            if (bad.size) await m.roles.remove([...bad.keys()], reason);
            res = 'سُحبت رتبه الإدارية (' + bad.size + ')';
        }
    } catch (e) { res = 'فشل التنفيذ: ' + cut(e.message, 80); }
    c.recent.unshift({ uid, key, n, at: Date.now(), res }); c.recent = c.recent.slice(0, 8); save();
    const e = embed().setTitle('🚨 تجاوز حدود الصلاحيات').setTimestamp()
        .addFields({ name: 'المنفّذ', value: '<@' + uid + '>', inline: true }, { name: 'العملية', value: KEYS[key][0] + ' ' + KEYS[key][1], inline: true }, { name: 'العدد', value: n + ' خلال ' + c.window + ' دقيقة', inline: true },
            { name: 'آخر عملية', value: cut(what || '—', 200) }, { name: 'الإجراء', value: ACTIONS[c.action][0] + ' ' + res });
    try { const ch = c.logChannelId && guild.channels.cache.get(c.logChannelId); if (ch && ch.isTextBased()) await ch.send({ embeds: [e] }); } catch {}
}
let hooked = false;
function hook() {
    if (hooked) return; hooked = true;
    const g = (x) => x && x.guild && x.guild.id === SERVER_ID ? x.guild : null;
    const safe = (fn) => async (...a) => { try { await fn(...a); } catch (e) { console.error('[limits]', e.message); } };
    client.on('guildBanAdd', safe(async (ban) => { const gu = g(ban); if (!gu || !cfg().enabled) return; track(gu, 'ban', await executor(gu, AL.MemberBanAdd, ban.user.id), 'باند ' + ban.user.tag); }));
    client.on('guildMemberRemove', safe(async (m) => { const gu = g(m); if (!gu || !cfg().enabled) return; const u = await executor(gu, AL.MemberKick, m.id); if (u) track(gu, 'kick', u, 'طرد ' + (m.user ? m.user.tag : m.id)); }));
    client.on('channelCreate', safe(async (ch) => { const gu = g(ch); if (!gu || !cfg().enabled) return; track(gu, 'channels', await executor(gu, AL.ChannelCreate, ch.id), 'إنشاء روم ' + ch.name); }));
    client.on('channelDelete', safe(async (ch) => { const gu = g(ch); if (!gu || !cfg().enabled) return; track(gu, 'channels', await executor(gu, AL.ChannelDelete, ch.id), 'حذف روم ' + ch.name); }));
    client.on('roleCreate', safe(async (r) => { const gu = g(r); if (!gu || !cfg().enabled) return; track(gu, 'roles', await executor(gu, AL.RoleCreate, r.id), 'إنشاء رتبة ' + r.name); }));
    client.on('roleDelete', safe(async (r) => { const gu = g(r); if (!gu || !cfg().enabled) return; track(gu, 'roles', await executor(gu, AL.RoleDelete, r.id), 'حذف رتبة ' + r.name); }));
    client.on('guildMemberUpdate', safe(async (o, n) => {
        const gu = g(n); if (!gu || !cfg().enabled || !o.roles || o.roles.cache.size === n.roles.cache.size) return;
        const u = await executor(gu, AL.MemberRoleUpdate, n.id); if (u && u !== n.id) track(gu, 'rolemgmt', u, 'تعديل رتب ' + n.user.tag);
    }));
}

// ───── لوحة التحكم ─────
function build() {
    const c = cfg();
    const e = embed().setTitle('🔐 حدود الصلاحيات').setDescription('يراقب العمليات الخطرة لكل عضو، وإذا تجاوز الحد خلال المدة المحددة ينفَّذ عليه الإجراء تلقائياً.')
        .addFields({ name: 'الحالة', value: onOff(c.enabled), inline: true }, { name: 'الإجراء', value: ACTIONS[c.action][0] + ' ' + ACTIONS[c.action][1], inline: true }, { name: 'المدة', value: c.window + ' دقيقة', inline: true },
            { name: 'الحدود', value: Object.entries(KEYS).map(([k, v]) => v[0] + ' ' + v[1] + ': **' + c.limits[k] + '**').join('\n') },
            { name: '✅ القائمة البيضاء', value: c.whitelist.length ? c.whitelist.map(x => '<@' + x + '>').join(' ') : 'فارغة' }, { name: '📜 روم السجل', value: chTxt(c.logChannelId) });
    if (c.recent.length) e.addFields({ name: '🕘 آخر التجاوزات', value: c.recent.slice(0, 5).map(r => '<@' + r.uid + '> • ' + KEYS[r.key][0] + ' ×' + r.n + ' • <t:' + Math.floor(r.at / 1000) + ':R>').join('\n') });
    const wl = new D.UserSelectMenuBuilder().setCustomId('lm:wl').setPlaceholder('القائمة البيضاء (أعضاء لا تُراقَب)...').setMinValues(0).setMaxValues(25);
    if (c.whitelist.length) { try { wl.setDefaultUsers(c.whitelist.slice(0, 25)); } catch {} }
    return {
        embeds: [e], components: [
            row(strSel('lm:act', 'الإجراء المتخذ عند التجاوز', Object.entries(ACTIONS).map(([k, v]) => ({ label: v[1], value: k, emoji: v[0], default: c.action === k })))),
            row(chSel('lm:log', 'روم سجل التجاوزات', { selected: c.logChannelId ? [c.logChannelId] : [], min: 0 })),
            row(wl),
            row(strSel('lm:win', 'مدة العدّ', WINDOWS.map(w => ({ label: w + ' دقيقة', value: String(w), default: c.window === w })))),
            row(btn('lm:toggle', c.enabled ? 'إيقاف الحماية' : 'تفعيل الحماية', c.enabled ? '⛔' : '✅', c.enabled ? ButtonStyle.Danger : ButtonStyle.Success), btn('lm:edit', 'تعديل الحدود', '⚙️', ButtonStyle.Primary))
        ]
    };
}
async function slash(i) { if (!(await adminOnly(i))) return; return i.reply({ ...build(), flags: H.EPH }); }
async function component(i) {
    if (!(await adminOnly(i))) return;
    const c = cfg(); const a = i.customId.split(':')[1];
    if (a === 'edit') {
        return i.showModal(modal('lmm:edit', 'تعديل حدود الصلاحيات', ...Object.entries(KEYS).map(([k, v]) => input(k, v[1].replace('الحد الأعلى ', ''), { value: c.limits[k], required: true, max: 3 }))));
    }
    if (a === 'toggle') c.enabled = !c.enabled;
    else if (a === 'act' && ACTIONS[i.values[0]]) c.action = i.values[0];
    else if (a === 'win' && WINDOWS.includes(+i.values[0])) c.window = +i.values[0];
    else if (a === 'log') c.logChannelId = i.values[0] || '';
    else if (a === 'wl') c.whitelist = [...i.values];
    save();
    return update(i, build());
}
async function modalSubmit(i) {
    if (!(await adminOnly(i))) return;
    const c = cfg();
    for (const k of Object.keys(KEYS)) { const n = parseInt(i.fields.getTextInputValue(k), 10); if (Number.isFinite(n)) c.limits[k] = clamp(n, 1, 50); }
    save();
    return update(i, build());
}

// ───── automod! — قاعدة منع منشن السبام في AutoMod الخاص بديسكورد ─────
async function automod(msg, args) {
    if (!msg.guild || msg.guild.id !== SERVER_ID) return;
    const say = (t, icon = '✅') => msg.reply({ embeds: [embed().setDescription(icon + '  ' + t)], allowedMentions: { repliedUser: false } });
    if (!isAdmin(msg.member)) return say('هذا الأمر للإدارة فقط.', '❌');
    try {
        const g = msg.guild; const rules = await g.autoModerationRules.fetch(); const ex = rules.find(r => r.name === 'Block Mention Spam');
        const a = String(args || '').trim();
        if (/^(off|ايقاف|إيقاف|حذف)$/i.test(a)) { if (!ex) return say('القاعدة غير موجودة أصلاً.', 'ℹ️'); await ex.delete('automod! off'); return say('تم حذف قاعدة **Block Mention Spam**.'); }
        const limit = clamp(parseInt(a, 10) || 5, 2, 50);
        const data = {
            name: 'Block Mention Spam', eventType: D.AutoModerationRuleEventType.MessageSend, triggerType: D.AutoModerationRuleTriggerType.MentionSpam,
            triggerMetadata: { mentionTotalLimit: limit }, enabled: true, reason: 'automod! بواسطة ' + msg.author.tag,
            actions: [{ type: D.AutoModerationActionType.BlockMessage }, { type: D.AutoModerationActionType.Timeout, metadata: { durationSeconds: 600 } }]
        };
        if (ex) await ex.edit(data); else await g.autoModerationRules.create(data);
        return say('قاعدة **Block Mention Spam** تعمل الآن: أكثر من **' + limit + '** منشن = حذف الرسالة + تايم أوت 10 دقائق.\nللإيقاف: `automod! off`');
    } catch (e) { return say('تعذّر التنفيذ: ' + cut(e.message, 150) + '\n(يحتاج البوت صلاحية Manage Server)', '❌'); }
}
function onReady() {
    hook();
    try { const CMDS = H.getCMDS(); if (!CMDS['automod!']) CMDS['automod!'] = automod; } catch (e) { console.error('[limits]', e.message); }
}
const commands = [{ name: 'limits', description: 'حدود الصلاحيات: حماية من التخريب (باند / طرد / رومات / رتب) + قائمة بيضاء (إدارة)' }];
return { prefix: 'lm', commands, ephemeral: ['limits'], slash: { limits: slash }, component, modal: modalSubmit, onReady, _build: build };
};
