'use strict';
/**
 * أوامر الشات بنمط «اسم!» — الإدارة والعقوبات والمعلومات والرتب والإيموجي (كلها تظهر في /cmdmanager):
 *  معلومات : help! avatar! banner! profile! level! server! user! ping! semoji! statistics! messages! point! bots! botstatus! advice! pslist!
 *  عقوبات  : warn! warnings! dinfractions! timeout! untimeout! mute! mymute! unmute! prison! myprison! unprison! stats!
 *  صوت     : vmute! unvmute! vkick! move! moveme! moveto! moveall!
 *  رتب     : role! rblock! removeblock! roleblocks!
 *  صور     : blockpic! blocked! removeblockpic!
 *  إيموجي  : aemoji! stickers!
 * كل الردود إيمبد بالأزرق الغامق، والتخزين في data/features.json تحت modcmds.
 */
module.exports = (H) => {
const { D, client, isAdmin, SERVER_ID, save, cut, embed, fmtVoice } = H;
const { PermissionFlagsBits: P, ChannelType: CT } = D;
const db = H.db;
const EXP = P.ManageGuildExpressions || P.ManageEmojisAndStickers;

// ───── أدوات عامة ─────
class Soft extends Error {}
const NOPING = { allowedMentions: { repliedUser: false, parse: [] } };
const send = (msg, e, extra = {}) => msg.reply({ embeds: [e], ...NOPING, ...extra });
const say = (msg, text, icon = '✅') => send(msg, embed().setDescription(icon + '  ' + text));
const S = () => {
    const m = (db.modcmds = db.modcmds || {});
    for (const k of ['infr', 'mutes', 'prison', 'blockpic', 'roleblocks', 'points', 'modstats', 'roleIds']) m[k] = m[k] || {};
    return m;
};
const T = (ms, f = 'R') => '<t:' + Math.floor(ms / 1000) + ':' + f + '>';
const can = (member, flag) => !!member && (isAdmin(member) || member.permissions.has(flag));
const UNITS = { s: 1e3, 'ث': 1e3, m: 6e4, 'د': 6e4, h: 36e5, 'س': 36e5, d: 864e5, 'ي': 864e5, w: 6048e5, 'أ': 6048e5 };
function parseDur(tok) {
    const m = String(tok || '').match(/^(\d+)\s*([smhdwثدسيأ])?$/i);
    if (!m) return null;
    const n = parseInt(m[1], 10); const u = (m[2] || 'm').toLowerCase();
    return n > 0 ? n * (UNITS[u] || 6e4) : null;
}
function takeDur(rest) {
    const toks = String(rest || '').trim().split(/\s+/).filter(Boolean);
    const ms = toks.length ? parseDur(toks[0]) : null;
    return { ms, reason: (ms ? toks.slice(1) : toks).join(' ') };
}
function fmtDur(ms) {
    const s = Math.max(1, Math.round(ms / 1000));
    if (s < 60) return s + ' ثانية';
    const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); const p = [];
    if (d) p.push(d + ' يوم'); if (h) p.push(h + ' ساعة'); if (m) p.push(m + ' دقيقة');
    return p.join(' و ');
}
const bar = (a, b, n = 16) => { const f = b > 0 ? Math.max(0, Math.min(n, Math.round(a / b * n))) : 0; return '▰'.repeat(f) + '▱'.repeat(n - f); };

/** تغليف الأمر: فحص السيرفر والصلاحية ومعالجة الأخطاء بشكل موحّد */
const wrap = (flag, fn) => async (msg, args) => {
    if (!msg.guild || msg.guild.id !== SERVER_ID || !msg.member) return;
    try {
        if (flag === 'admin' ? !isAdmin(msg.member) : (flag && !can(msg.member, flag))) throw new Soft('ما عندك صلاحية لاستخدام هذا الأمر.');
        await fn(msg, String(args || '').trim());
    } catch (e) {
        let text = e instanceof Soft ? e.message : (e && e.code === 50013 ? 'البوت ما عنده صلاحية كافية أو رتبته أقل من المطلوب.' : cut(e && e.message ? e.message : e, 200));
        if (!(e instanceof Soft)) console.error('[modcmds]', e && e.stack ? e.stack : e);
        try { await say(msg, text, '❌'); } catch {}
    }
};
const pub = (fn) => wrap(null, fn);

/** تحديد العضو: منشن / آيدي / رد على رسالته */
async function target(msg, args) {
    const a = String(args || '').trim(); const tok = a.split(/\s+/)[0] || '';
    const m = tok.match(/^<@!?(\d{15,25})>$/) || tok.match(/^(\d{15,25})$/);
    let member = null, rest = a;
    if (m) { member = msg.guild.members.cache.get(m[1]) || await msg.guild.members.fetch(m[1]).catch(() => null); rest = a.slice(tok.length).trim(); }
    else if (msg.reference && msg.reference.messageId) {
        try { const r = await msg.channel.messages.fetch(msg.reference.messageId); member = r.member || await msg.guild.members.fetch(r.author.id).catch(() => null); } catch {}
    }
    return { member, id: m ? m[1] : null, rest };
}
const needMember = (t) => { if (!t.member) throw new Soft('حدّد العضو: منشن أو آيدي أو ردّ على رسالته.'); return t.member; };
function guard(msg, m, o = {}) {
    if (!m) throw new Soft('حدّد العضو: منشن أو آيدي أو ردّ على رسالته.');
    if (!o.self && m.id === msg.author.id) throw new Soft('ما تقدر تطبّق هذا على نفسك.');
    if (m.id === msg.guild.ownerId) throw new Soft('لا يمكن تطبيق هذا على مالك السيرفر.');
    if (m.id === client.user.id) throw new Soft('لا يمكن تطبيق هذا على البوت.');
    if (msg.author.id !== msg.guild.ownerId && m.id !== msg.author.id && msg.member.roles.highest.position <= m.roles.highest.position) throw new Soft('رتبة العضو أعلى من رتبتك أو تساويها.');
    if (msg.guild.members.me.roles.highest.position <= m.roles.highest.position) throw new Soft('رتبة البوت أقل من رتبة العضو، ارفع رتبة البوت أولاً.');
    return m;
}
async function dm(user, e) { try { await user.send({ embeds: [e] }); return true; } catch { return false; } }
async function logTo(guild, kind, e) {
    try {
        const c = H.getConfig() || {}; const lg = (c.moderation && c.moderation.logs) || {}; const id = lg[kind] || lg.general; if (!id) return;
        const ch = guild.channels.cache.get(id); if (ch && ch.isTextBased && ch.isTextBased()) await ch.send({ embeds: [e] });
    } catch {}
}

// ───── سجل العقوبات ─────
const TYPES = { warn: ['⚠️', 'تحذير'], mute: ['🔇', 'ميوت كتابي'], timeout: ['⏳', 'تايم أوت'], prison: ['⛓️', 'سجن'], vmute: ['🎙️', 'ميوت صوتي'], vkick: ['👢', 'طرد صوتي'], blockpic: ['🚫', 'بلوك صور'], rblock: ['🏷️', 'بلوك رتبة'] };
function addInf(uid, type, by, reason, extra = {}) {
    const s = S(); const a = (s.infr[uid] = s.infr[uid] || []);
    const rec = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 4), type, by, reason: cut(reason || 'بدون سبب', 300), at: Date.now(), ...extra };
    a.push(rec); if (a.length > 200) a.shift();
    const ms = (s.modstats[by] = s.modstats[by] || {}); ms[type] = (ms[type] || 0) + 1; ms.total = (ms.total || 0) + 1;
    save(); return rec;
}
const infLine = (r, i) => (i != null ? '`' + i + '.` ' : '') + (TYPES[r.type] ? TYPES[r.type][0] + ' **' + TYPES[r.type][1] + '**' : '**' + r.type + '**') + ' • ' + T(r.at) + ' • بواسطة <@' + r.by + '>\n└ ' + cut(r.reason, 120) + (r.ms ? ' (' + fmtDur(r.ms) + ')' : '');
function punishEmbed(icon, title, member, by, reason, ms) {
    const e = embed().setTitle(icon + ' ' + title).setThumbnail(member.user.displayAvatarURL({ size: 256 }))
        .addFields({ name: 'العضو', value: '<@' + member.id + '>', inline: true }, { name: 'بواسطة', value: '<@' + by + '>', inline: true });
    if (ms) e.addFields({ name: 'المدة', value: fmtDur(ms), inline: true });
    return e.addFields({ name: 'السبب', value: cut(reason || 'بدون سبب', 500) }).setTimestamp();
}

// ───── رتب الميوت والسجن (تُنشأ تلقائياً عند أول استخدام) ─────
const PERMS = {
    mute: { SendMessages: false, AddReactions: false, SendMessagesInThreads: false, CreatePublicThreads: false, CreatePrivateThreads: false, Speak: false },
    prison: { ViewChannel: false }
};
let creatingPrisonCh = false;
async function applyOverwrites(guild, role, key) {
    for (const ch of guild.channels.cache.values()) {
        if (!ch.permissionOverwrites || (ch.isThread && ch.isThread())) continue;
        if (key === 'prison' && ch.id === S().roleIds.prisonChannel) continue;
        try { await ch.permissionOverwrites.edit(role, PERMS[key], { reason: 'modcmds: ' + key }); } catch {}
    }
}
async function ensureRole(guild, key, name, color) {
    const s = S(); const cfg = H.getConfig() || {};
    const id = (key === 'mute' && cfg.roles && cfg.roles.mute) || s.roleIds[key];
    let role = id && (guild.roles.cache.get(id) || await guild.roles.fetch(id).catch(() => null));
    if (role) return role;
    role = await guild.roles.create({ name, color, permissions: [], reason: 'modcmds: ' + key });
    s.roleIds[key] = role.id; save();
    await applyOverwrites(guild, role, key);
    if (key === 'prison') {
        creatingPrisonCh = true;
        try {
            const ch = await guild.channels.create({ name: 'السجن', type: CT.GuildText, reason: 'modcmds: prison',
                permissionOverwrites: [{ id: guild.roles.everyone.id, deny: [P.ViewChannel] }, { id: role.id, allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory] }] });
            s.roleIds.prisonChannel = ch.id; save();
        } catch (e) { console.error('[modcmds] prison channel:', e.message); } finally { creatingPrisonCh = false; }
    }
    return role;
}

// ───── مؤقتات الميوت والسجن (تستمر بعد إعادة التشغيل) ─────
const timers = new Map();
function arm(kind, uid) {
    const k = kind + ':' + uid; clearTimeout(timers.get(k)); timers.delete(k);
    const rec = S()[kind][uid]; if (!rec || !rec.until) return;
    const left = rec.until - Date.now();
    if (left <= 0) return expire(kind, uid);
    timers.set(k, setTimeout(() => arm(kind, uid), Math.min(left, 2147000000)));
}
async function releasePrison(m, rec, reason) {
    const me = m.guild.members.me;
    const keep = new Set([...m.roles.cache.keys()].filter(id => id !== rec.roleId));
    for (const id of rec.roles || []) { const r = m.guild.roles.cache.get(id); if (r && !r.managed && r.position < me.roles.highest.position) keep.add(id); }
    keep.delete(m.guild.id);
    await m.roles.set([...keep], reason);
}
async function expire(kind, uid) {
    const s = S(); const rec = s[kind][uid]; if (!rec) return;
    const guild = client.guilds.cache.get(SERVER_ID);
    const m = guild && await guild.members.fetch(uid).catch(() => null);
    if (m) {
        try {
            if (kind === 'mutes') await m.roles.remove(rec.roleId, 'انتهت مدة الميوت');
            else await releasePrison(m, rec, 'انتهت مدة السجن');
        } catch (e) { console.error('[modcmds] expire:', e.message); }
    }
    delete s[kind][uid]; save();
}

// ═════════════════════ أوامر المعلومات ═════════════════════
const GROUPS = [
    ['📌 معلومات', 'avatar! banner! profile! level! user! server! ping! statistics! messages! point! bots! botstatus! pslist! advice! semoji!'],
    ['🛡️ عقوبات', 'warn! warnings! dinfractions! timeout! untimeout! mute! mymute! unmute! prison! myprison! unprison! stats!'],
    ['🔊 الصوت', 'vmute! unvmute! vkick! move! moveme! moveto! moveall!'],
    ['🏷️ الرتب', 'role! rblock! removeblock! roleblocks!'],
    ['🖼️ الصور', 'blockpic! blocked! removeblockpic!'],
    ['😀 الإيموجي', 'aemoji! stickers!'],
    ['⚙️ الإعدادات والشات', 'setlog! detlog! setvoice! hide! unhide! lock! unlock! slowmode! color! colors!']
];
const help = pub(async (msg) => {
    const e = embed().setTitle('📚 أوامر الشات').setDescription('تكتب الأمر مباشرة بدون أي بادئة، مثال: `warn! @عضو السبب`\nيمكنك إيقاف أي أمر من `/cmdmanager`.');
    for (const [n, v] of GROUPS) e.addFields({ name: n, value: v.split(' ').map(x => '`' + x + '`').join(' ') });
    await send(msg, e.setFooter({ text: 'للتفاصيل الكاملة اكتب /help' }));
});
const avatar = pub(async (msg, args) => {
    const t = await target(msg, args); const m = t.member || msg.member; const u = m.user;
    const e = embed().setTitle('🖼️ صورة ' + (m.displayName || u.username)).setImage(u.displayAvatarURL({ size: 1024 }));
    const g = m.avatar ? m.displayAvatarURL({ size: 1024 }) : null;
    e.setDescription('[تحميل الصورة](' + u.displayAvatarURL({ size: 4096 }) + ')' + (g ? '\n🔹 للسيرفر: [فتح](' + g + ')' : ''));
    await send(msg, e);
});
const banner = pub(async (msg, args) => {
    const t = await target(msg, args); const id = t.member ? t.member.id : (t.id || msg.author.id);
    const u = await client.users.fetch(id, { force: true });
    const url = u.bannerURL({ size: 1024 });
    if (!url) throw new Soft('هذا العضو ما عنده بانر.');
    await send(msg, embed().setTitle('🎞️ بانر ' + u.username).setImage(url).setDescription('[تحميل البانر](' + u.bannerURL({ size: 4096 }) + ')'));
});
const user = pub(async (msg, args) => {
    const t = await target(msg, args); const m = t.member || msg.member; const u = m.user;
    await send(msg, embed().setTitle('👤 ' + u.username).setThumbnail(u.displayAvatarURL({ size: 256 }))
        .addFields({ name: '🆔 الآيدي', value: '`' + u.id + '`', inline: true }, { name: '📅 إنشاء الحساب', value: T(u.createdTimestamp, 'F') + '\n' + T(u.createdTimestamp), inline: true },
            { name: '📥 الانضمام للسيرفر', value: m.joinedTimestamp ? T(m.joinedTimestamp, 'F') + '\n' + T(m.joinedTimestamp) : '—', inline: true }));
});
const profile = pub(async (msg, args) => {
    const t = await target(msg, args); const m = t.member || msg.member;
    const u = await client.users.fetch(m.id, { force: true }).catch(() => m.user);
    const st = H.getStats(m.id); const lp = H.levels && H.levels.getLevelProfile ? H.levels.getLevelProfile(m.id) : null;
    const roles = m.roles.cache.filter(r => r.id !== msg.guild.id).sort((a, b) => b.position - a.position).first(8).map(r => '<@&' + r.id + '>').join(' ') || '—';
    const warns = ((S().infr[m.id]) || []).filter(x => x.type === 'warn').length;
    const e = embed().setTitle('🪪 ملف ' + (m.displayName || u.username)).setThumbnail(m.displayAvatarURL({ size: 256 }))
        .addFields({ name: '🆔 الآيدي', value: '`' + m.id + '`', inline: true }, { name: '📅 الحساب', value: T(u.createdTimestamp), inline: true }, { name: '📥 الانضمام', value: m.joinedTimestamp ? T(m.joinedTimestamp) : '—', inline: true },
            { name: '💬 الرسائل', value: '**' + st.messages + '**' + (st.chatRank ? ' (#' + st.chatRank + ')' : ''), inline: true },
            { name: '🔊 الفويس', value: '**' + fmtVoice(st.voiceMs) + '**' + (st.voiceRank ? ' (#' + st.voiceRank + ')' : ''), inline: true },
            { name: '⚠️ التحذيرات', value: '**' + warns + '**', inline: true });
    if (lp) e.addFields({ name: '⭐ المستوى', value: 'LVL **' + lp.level + '** • ' + lp.xp + ' XP', inline: true });
    e.addFields({ name: '🏷️ الرتب', value: cut(roles, 1000) });
    const b = u.bannerURL && u.bannerURL({ size: 1024 }); if (b) e.setImage(b);
    await send(msg, e);
});
const level = pub(async (msg, args) => {
    const t = await target(msg, args); const m = t.member || msg.member; const st = H.getStats(m.id);
    const lp = H.levels && H.levels.getLevelProfile ? H.levels.getLevelProfile(m.id) : null;
    if (!lp) throw new Soft('نظام المستويات غير متاح حالياً.');
    await send(msg, embed().setTitle('⭐ مستوى ' + (m.displayName || m.user.username)).setThumbnail(m.displayAvatarURL({ size: 256 }))
        .setDescription('**LVL ' + lp.level + '**\n`' + bar(lp.currentXp, lp.nextLevelXp) + '` ' + lp.currentXp + ' / ' + lp.nextLevelXp + ' XP')
        .addFields({ name: '🏆 الترتيب', value: String(lp.rank || '—'), inline: true }, { name: '✨ إجمالي XP', value: String(lp.xp), inline: true },
            { name: '💬 الرسائل', value: String(st.messages), inline: true }, { name: '🔊 الفويس', value: fmtVoice(st.voiceMs), inline: true }));
});
const server = pub(async (msg) => {
    const g = msg.guild; await g.fetch().catch(() => {});
    const ch = g.channels.cache; const owner = await g.fetchOwner().catch(() => null);
    const e = embed().setTitle('🏰 ' + g.name).setThumbnail(g.iconURL({ size: 256 }))
        .addFields({ name: '👑 المالك', value: owner ? '<@' + owner.id + '>' : '—', inline: true }, { name: '📅 الإنشاء', value: T(g.createdTimestamp), inline: true }, { name: '🆔 الآيدي', value: '`' + g.id + '`', inline: true },
            { name: '👥 الأعضاء', value: '**' + g.memberCount + '**', inline: true },
            { name: '💬 الرومات', value: '#' + ch.filter(c => c.type === CT.GuildText || c.type === CT.GuildAnnouncement).size + ' • 🔊' + ch.filter(c => c.type === CT.GuildVoice || c.type === CT.GuildStageVoice).size + ' • 📁' + ch.filter(c => c.type === CT.GuildCategory).size, inline: true },
            { name: '🏷️ الرتب', value: '**' + g.roles.cache.size + '**', inline: true },
            { name: '😀 الإيموجي / الستيكرز', value: g.emojis.cache.size + ' / ' + g.stickers.cache.size, inline: true },
            { name: '🚀 البوست', value: 'مستوى **' + g.premiumTier + '** • ' + (g.premiumSubscriptionCount || 0) + ' بوست', inline: true });
    const b = g.bannerURL && g.bannerURL({ size: 1024 }); if (b) e.setImage(b);
    await send(msg, e);
});
const ping = pub(async (msg) => {
    const m = await send(msg, embed().setDescription('🏓  جاري القياس...'));
    const rtt = m.createdTimestamp - msg.createdTimestamp;
    await m.edit({ embeds: [embed().setTitle('🏓 سرعة اتصال البوت').addFields({ name: 'الرسائل', value: '`' + rtt + 'ms`', inline: true }, { name: 'الاتصال (WS)', value: '`' + Math.round(client.ws.ping) + 'ms`', inline: true })] });
});
const semoji = pub(async (msg, args) => {
    const m = args.match(/<(a?):(\w+):(\d+)>/);
    if (m) {
        const url = 'https://cdn.discordapp.com/emojis/' + m[3] + '.' + (m[1] ? 'gif' : 'png') + '?size=512';
        return send(msg, embed().setTitle(':' + m[2] + ':').setImage(url).setDescription('[تحميل الصورة](' + url + ')'));
    }
    const tok = args.split(/\s+/)[0] || '';
    if (!tok || !/\p{Extended_Pictographic}/u.test(tok)) throw new Soft('اكتب إيموجي، مثال: `semoji! 😀` أو إيموجي سيرفر.');
    const cp = [...tok].map(c => c.codePointAt(0).toString(16)).filter(x => x !== 'fe0f').join('-');
    await send(msg, embed().setTitle(tok).setImage('https://cdn.jsdelivr.net/gh/jdecked/twemoji@latest/assets/72x72/' + cp + '.png'));
});
const statistics = pub(async (msg) => {
    const g = msg.guild; await g.members.fetch().catch(() => {});
    const all = H.getAllStats(); const msgs = all.reduce((a, x) => a + x.messages, 0); const voice = all.reduce((a, x) => a + x.voiceMs, 0);
    const top = (k, f) => all.filter(x => x[k] > 0).sort((a, b) => b[k] - a[k]).slice(0, 5).map((x, i) => '`' + (i + 1) + '.` <@' + x.uid + '> — ' + f(x[k])).join('\n') || '—';
    await send(msg, embed().setTitle('📊 إحصائيات ' + g.name).setThumbnail(g.iconURL({ size: 256 }))
        .addFields({ name: '👥 الأعضاء', value: g.members.cache.filter(m => !m.user.bot).size + ' عضو • ' + g.members.cache.filter(m => m.user.bot).size + ' بوت', inline: true },
            { name: '🔊 داخل الفويس الآن', value: String(g.voiceStates.cache.filter(v => v.channelId).size), inline: true },
            { name: '💬 مجموع الرسائل', value: '**' + msgs + '**', inline: true }, { name: '🎙️ مجموع الفويس', value: '**' + fmtVoice(voice) + '**', inline: true },
            { name: '🏆 أعلى 5 في الشات', value: top('messages', n => n + ' رسالة') }, { name: '🏆 أعلى 5 في الفويس', value: top('voiceMs', fmtVoice) }));
});
const messages = pub(async (msg, args) => {
    let list = H.getAllStats(); const rm = msg.mentions.roles.first(); const t = await target(msg, args.replace(/<@&\d+>/g, ''));
    if (rm) { await msg.guild.members.fetch().catch(() => {}); const ids = new Set(rm.members.keys()); list = list.filter(x => ids.has(x.uid)); }
    list = list.filter(x => x.messages > 0).sort((a, b) => b.messages - a.messages);
    const label = rm ? ' — رتبة ' + rm.name : '';
    if (t.member) {
        const i = list.findIndex(x => x.uid === t.member.id);
        return send(msg, embed().setTitle('💬 رسائل ' + (t.member.displayName || t.member.user.username)).setThumbnail(t.member.displayAvatarURL({ size: 128 }))
            .addFields({ name: 'المجموع', value: '**' + (i >= 0 ? list[i].messages : 0) + '**', inline: true }, { name: 'الترتيب', value: i >= 0 ? '#' + (i + 1) + ' من ' + list.length : '—', inline: true }));
    }
    await send(msg, embed().setTitle('💬 ترتيب الرسائل' + label).setDescription(list.slice(0, 10).map((x, i) => '`' + (i + 1) + '.` <@' + x.uid + '> — **' + x.messages + '**').join('\n') || 'لا توجد بيانات.')
        .setFooter({ text: 'المجموع: ' + list.reduce((a, x) => a + x.messages, 0) + ' رسالة' }));
});
const point = pub(async (msg, args) => {
    const pts = S().points; const sub = (args.split(/\s+/)[0] || '').toLowerCase();
    const ops = { add: 1, '+': 1, 'اضافة': 1, 'إضافة': 1, remove: 1, '-': 1, 'خصم': 1, set: 1, 'تعيين': 1 };
    if (ops[sub]) {
        if (!can(msg.member, P.ManageGuild)) throw new Soft('إدارة النقاط للإدارة فقط.');
        const t = await target(msg, args.slice(sub.length)); const m = needMember(t); const n = parseInt(t.rest, 10);
        if (!Number.isFinite(n) || n < 0 || n > 1e6) throw new Soft('اكتب رقماً صحيحاً، مثال: `point! add @عضو 10`');
        const cur = pts[m.id] || 0; const add = ['add', '+', 'اضافة', 'إضافة'].includes(sub); const sett = ['set', 'تعيين'].includes(sub);
        pts[m.id] = Math.max(0, sett ? n : add ? cur + n : cur - n); save();
        return say(msg, 'نقاط <@' + m.id + '> الآن **' + pts[m.id] + '**.');
    }
    if (['top', 'توب', 'ترتيب'].includes(sub)) {
        const l = Object.entries(pts).filter(x => x[1] > 0).sort((a, b) => b[1] - a[1]).slice(0, 10);
        return send(msg, embed().setTitle('🏅 أعلى النقاط').setDescription(l.map((x, i) => '`' + (i + 1) + '.` <@' + x[0] + '> — **' + x[1] + '**').join('\n') || 'لا توجد نقاط بعد.'));
    }
    const t = await target(msg, args); const m = t.member || msg.member;
    await send(msg, embed().setTitle('🏅 نقاط ' + (m.displayName || m.user.username)).setDescription('**' + (pts[m.id] || 0) + '** نقطة').setFooter({ text: 'point! top • point! add @عضو 10 (للإدارة)' }));
});
const bots = pub(async (msg) => {
    await msg.guild.members.fetch().catch(() => {});
    const l = msg.guild.members.cache.filter(m => m.user.bot).sort((a, b) => a.joinedTimestamp - b.joinedTimestamp);
    await send(msg, embed().setTitle('🤖 البوتات في السيرفر (' + l.size + ')').setDescription(l.map(m => '▸ <@' + m.id + '> — ' + (m.joinedTimestamp ? T(m.joinedTimestamp) : '')).join('\n').slice(0, 4000) || 'لا توجد بوتات.'));
});
const botstatus = pub(async (msg) => {
    await msg.guild.members.fetch().catch(() => {});
    const l = msg.guild.members.cache.filter(m => m.user.bot);
    const lines = l.map(m => '▸ <@' + m.id + '> ' + (m.voice && m.voice.channel ? '🔊 ' + m.voice.channel.name : '') + (m.permissions.has(P.Administrator) ? ' 👑 أدمن' : '')).join('\n');
    const up = process.uptime(); const mem = Math.round(process.memoryUsage().rss / 1048576);
    await send(msg, embed().setTitle('🤖 حالة البوتات في السيرفر').setDescription(cut(lines || 'لا توجد بوتات.', 3000))
        .addFields({ name: '⚙️ هذا البوت', value: 'تشغيل: **' + fmtDur(up * 1000) + '**\nالاتصال: **' + Math.round(client.ws.ping) + 'ms**\nالذاكرة: **' + mem + 'MB**' }));
});
const TIPS = [
    'فعّل التحقق بخطوتين لكل حسابات الإدارة.', 'لا تعطي رتبة فيها صلاحية «Administrator» إلا لمن تثق به تماماً.', 'اجعل رتبة البوت أعلى من رتب الأعضاء ليعمل الميوت والسجن.',
    'فعّل سجلات السيرفر بأمر `setlog!` لمراجعة أي حدث مشبوه.', 'امنع روابط الدعوات من الرتب العادية عبر `/organize` أو قواعد AutoMod.', 'راجع قائمة البوتات بأمر `bots!` واحذف أي بوت ما تحتاجه.',
    'استخدم القائمة البيضاء للأشخاص الموثوقين فقط ولا تكثر منها.', 'فعّل `/antispam` وراجع قناة الفخ (الفحص) بشكل دوري.', 'لا تشارك توكن البوت مع أحد، ولو تسرّب أعد توليده فوراً.', 'اضبط الوضع البطيء `slowmode!` عند الزحمة لمنع الفوضى.'
];
const advice = pub(async (msg) => { await send(msg, embed().setTitle('💡 نصيحة').setDescription(TIPS[Math.floor(Math.random() * TIPS.length)])); });
const RULE_NAMES = { messages: '💬 سبام الرسائل', bots: '🤖 سبام البوتات', emoji: '😀 سبام الإيموجي', images: '🖼️ سبام الصور', attachments: '📎 سبام المرفقات', webhook: '🪝 سبام الويب هوك' };
const pslist = pub(async (msg) => {
    const a = db.antispam || {}; const rules = a.rules || {};
    const on = (k) => a.enabled && (rules[k] ? rules[k].on !== false : true);
    const s = S(); const e = embed().setTitle('🛡️ قائمة الحماية')
        .setDescription('**منع السبام:** ' + (a.enabled ? '✅ مفعّل' : '⛔ متوقف') + '\n' + Object.entries(RULE_NAMES).map(([k, n]) => (on(k) ? '✅ ' : '⛔ ') + n).join('\n'));
    try {
        const r = await msg.guild.autoModerationRules.fetch();
        e.addFields({ name: '🧱 AutoMod الخاص بديسكورد', value: r.size ? r.map(x => (x.enabled ? '✅ ' : '⛔ ') + cut(x.name, 40)).join('\n') : 'لا توجد قواعد.' });
    } catch {}
    e.addFields({ name: '🔒 أنظمة العقوبات', value: '🔇 ميوت نشط: **' + Object.keys(s.mutes).length + '**\n⛓️ مسجونون: **' + Object.keys(s.prison).length + '**\n🚫 بلوك صور: **' + Object.keys(s.blockpic).length + '**\n🏷️ بلوك رتب: **' + Object.keys(s.roleblocks).length + '**' });
    await send(msg, e);
});

// ═════════════════════ التحذيرات والعقوبات ═════════════════════
const warn = wrap(P.ModerateMembers, async (msg, args) => {
    const t = await target(msg, args); const m = guard(msg, needMember(t)); const reason = t.rest || 'بدون سبب';
    addInf(m.id, 'warn', msg.author.id, reason);
    const count = S().infr[m.id].filter(x => x.type === 'warn').length;
    const e = punishEmbed('⚠️', 'تحذير', m, msg.author.id, reason).addFields({ name: 'عدد التحذيرات', value: '**' + count + '**', inline: true });
    const sent = await dm(m.user, embed().setTitle('⚠️ تحذير في ' + msg.guild.name).setDescription('السبب: ' + cut(reason, 500)).setTimestamp());
    await send(msg, e.setFooter({ text: sent ? 'تم إرسال تنبيه خاص للعضو' : 'تعذّر إرسال خاص للعضو' }));
    logTo(msg.guild, 'warn', e);
});
const warnings = pub(async (msg, args) => {
    const t = await target(msg, args); const m = t.member || msg.member;
    if (m.id !== msg.author.id && !can(msg.member, P.ModerateMembers)) throw new Soft('تقدر تشوف تحذيراتك فقط.');
    const l = (S().infr[m.id] || []).filter(x => x.type === 'warn').reverse();
    await send(msg, embed().setTitle('⚠️ تحذيرات ' + (m.displayName || m.user.username)).setThumbnail(m.displayAvatarURL({ size: 128 }))
        .setDescription(l.slice(0, 10).map((r, i) => infLine(r, i + 1)).join('\n\n') || 'لا توجد تحذيرات 👌').setFooter({ text: 'المجموع: ' + l.length }));
});
const dinfractions = pub(async (msg, args) => {
    const t = await target(msg, args); const m = t.member || msg.member;
    if (m.id !== msg.author.id && !can(msg.member, P.ModerateMembers)) throw new Soft('تقدر تشوف سجلك فقط.');
    const s = S(); const toks = t.rest.split(/\s+/).filter(Boolean); const sub = (toks[0] || '').toLowerCase();
    if (['clear', 'مسح', 'all'].includes(sub)) {
        if (!isAdmin(msg.member)) throw new Soft('مسح السجل للإدارة العليا فقط.');
        const n = (s.infr[m.id] || []).length; delete s.infr[m.id]; save();
        return say(msg, 'تم مسح **' + n + '** من سجل عقوبات <@' + m.id + '>.');
    }
    if (['del', 'حذف'].includes(sub)) {
        if (!isAdmin(msg.member)) throw new Soft('حذف عقوبة للإدارة العليا فقط.');
        const arr = (s.infr[m.id] || []).slice().reverse(); const i = parseInt(toks[1], 10) - 1;
        if (!arr[i]) throw new Soft('رقم غير صحيح، شوف الأرقام من `dinfractions! @عضو`.');
        s.infr[m.id] = s.infr[m.id].filter(x => x.id !== arr[i].id); save();
        return say(msg, 'تم حذف العقوبة رقم **' + (i + 1) + '**.');
    }
    const l = (s.infr[m.id] || []).slice().reverse();
    await send(msg, embed().setTitle('📋 سجل عقوبات ' + (m.displayName || m.user.username)).setThumbnail(m.displayAvatarURL({ size: 128 }))
        .setDescription(l.slice(0, 10).map((r, i) => infLine(r, i + 1)).join('\n\n') || 'السجل نظيف ✨')
        .setFooter({ text: 'المجموع: ' + l.length + ' • للإدارة: dinfractions! @عضو clear | del 2' }));
});
const timeout = wrap(P.ModerateMembers, async (msg, args) => {
    const t = await target(msg, args); const m = guard(msg, needMember(t));
    const cfg = H.getConfig() || {}; const def = ((cfg.moderation && cfg.moderation.defaultMuteMinutes) || 60) * 60000;
    const d = takeDur(t.rest); const ms = Math.min(d.ms || def, 28 * 864e5);
    await m.timeout(ms, 'timeout! بواسطة ' + msg.author.tag + ' — ' + (d.reason || ''));
    addInf(m.id, 'timeout', msg.author.id, d.reason, { ms });
    const e = punishEmbed('⏳', 'تايم أوت', m, msg.author.id, d.reason, ms);
    await send(msg, e); logTo(msg.guild, 'mute', e);
});
const untimeout = wrap(P.ModerateMembers, async (msg, args) => {
    const t = await target(msg, args); const m = guard(msg, needMember(t), { self: true });
    if (!m.communicationDisabledUntilTimestamp || m.communicationDisabledUntilTimestamp < Date.now()) throw new Soft('العضو ليس عليه تايم أوت.');
    await m.timeout(null, 'untimeout! بواسطة ' + msg.author.tag);
    await say(msg, 'تم فك التايم أوت عن <@' + m.id + '>.'); logTo(msg.guild, 'unmute', embed().setDescription('⏳ فك تايم أوت عن <@' + m.id + '> بواسطة <@' + msg.author.id + '>'));
});
const mute = wrap(P.ModerateMembers, async (msg, args) => {
    const t = await target(msg, args); const m = guard(msg, needMember(t)); const s = S();
    if (s.mutes[m.id]) throw new Soft('العضو مكتوم أصلاً.');
    const d = takeDur(t.rest);
    const role = await ensureRole(msg.guild, 'mute', 'Muted 🔇', 0x1F2A44);
    await m.roles.add(role, 'mute! بواسطة ' + msg.author.tag);
    s.mutes[m.id] = { by: msg.author.id, reason: d.reason || 'بدون سبب', at: Date.now(), until: d.ms ? Date.now() + d.ms : 0, roleId: role.id }; save(); arm('mutes', m.id);
    addInf(m.id, 'mute', msg.author.id, d.reason, d.ms ? { ms: d.ms } : {});
    const e = punishEmbed('🔇', 'ميوت كتابي', m, msg.author.id, d.reason, d.ms);
    await send(msg, e); logTo(msg.guild, 'mute', e);
});
const unmute = wrap(P.ModerateMembers, async (msg, args) => {
    const t = await target(msg, args); const m = needMember(t); const s = S(); const rec = s.mutes[m.id];
    if (!rec) throw new Soft('العضو ليس عليه ميوت كتابي.');
    await m.roles.remove(rec.roleId, 'unmute! بواسطة ' + msg.author.tag).catch(() => {});
    delete s.mutes[m.id]; arm('mutes', m.id); save();
    await say(msg, 'تم فك الميوت الكتابي عن <@' + m.id + '>.'); logTo(msg.guild, 'unmute', embed().setDescription('🔊 فك ميوت عن <@' + m.id + '> بواسطة <@' + msg.author.id + '>'));
});
const mymute = pub(async (msg) => {
    const rec = S().mutes[msg.author.id]; const to = msg.member.communicationDisabledUntilTimestamp;
    if (!rec && !(to && to > Date.now())) return say(msg, 'ما عليك أي ميوت حالياً 👌', 'ℹ️');
    const e = embed().setTitle('🔇 معلومات ميوتك');
    if (rec) e.addFields({ name: 'ميوت كتابي', value: 'بواسطة <@' + rec.by + '>\nالسبب: ' + cut(rec.reason, 200) + '\nينتهي: ' + (rec.until ? T(rec.until) : 'دائم حتى فكّه') });
    if (to && to > Date.now()) e.addFields({ name: 'تايم أوت', value: 'ينتهي ' + T(to) });
    await send(msg, e);
});
const prison = wrap(P.ModerateMembers, async (msg, args) => {
    const t = await target(msg, args); const m = guard(msg, needMember(t)); const s = S();
    if (s.prison[m.id]) throw new Soft('العضو مسجون أصلاً.');
    const d = takeDur(t.rest); const me = msg.guild.members.me;
    const role = await ensureRole(msg.guild, 'prison', 'Prison ⛓️', 0x0B1A33);
    const saved = m.roles.cache.filter(r => r.id !== msg.guild.id && !r.managed && r.position < me.roles.highest.position).map(r => r.id);
    const fixed = m.roles.cache.filter(r => r.id !== msg.guild.id && (r.managed || r.position >= me.roles.highest.position)).map(r => r.id);
    await m.roles.set([...fixed, role.id], 'prison! بواسطة ' + msg.author.tag);
    s.prison[m.id] = { by: msg.author.id, reason: d.reason || 'بدون سبب', at: Date.now(), until: d.ms ? Date.now() + d.ms : 0, roles: saved, roleId: role.id }; save(); arm('prison', m.id);
    if (m.voice && m.voice.channel) m.voice.disconnect('prison!').catch(() => {});
    addInf(m.id, 'prison', msg.author.id, d.reason, d.ms ? { ms: d.ms } : {});
    const e = punishEmbed('⛓️', 'سجن', m, msg.author.id, d.reason, d.ms);
    await send(msg, e); logTo(msg.guild, 'mute', e);
});
const unprison = wrap(P.ModerateMembers, async (msg, args) => {
    const t = await target(msg, args); const m = needMember(t); const s = S(); const rec = s.prison[m.id];
    if (!rec) throw new Soft('العضو مو مسجون.');
    await releasePrison(m, rec, 'unprison! بواسطة ' + msg.author.tag);
    delete s.prison[m.id]; arm('prison', m.id); save();
    await say(msg, 'تم إخراج <@' + m.id + '> من السجن وإرجاع رتبه.'); logTo(msg.guild, 'unmute', embed().setDescription('🔓 إخراج <@' + m.id + '> من السجن بواسطة <@' + msg.author.id + '>'));
});
const myprison = pub(async (msg) => {
    const rec = S().prison[msg.author.id];
    if (!rec) return say(msg, 'أنت مو مسجون 👌', 'ℹ️');
    await send(msg, embed().setTitle('⛓️ معلومات سجنك').addFields({ name: 'بواسطة', value: '<@' + rec.by + '>', inline: true }, { name: 'ينتهي', value: rec.until ? T(rec.until) : 'حتى يُفكّ يدوياً', inline: true }, { name: 'السبب', value: cut(rec.reason, 300) }));
});
const stats = pub(async (msg, args) => {
    const t = await target(msg, args); const m = t.member || msg.member;
    if (m.id !== msg.author.id && !can(msg.member, P.ModerateMembers)) throw new Soft('تقدر تشوف إحصائياتك فقط.');
    const ms = S().modstats[m.id] || {};
    const lines = Object.entries(TYPES).map(([k, v]) => v[0] + ' ' + v[1] + ': **' + (ms[k] || 0) + '**').join('\n');
    await send(msg, embed().setTitle('📈 إحصائيات الإداري ' + (m.displayName || m.user.username)).setThumbnail(m.displayAvatarURL({ size: 128 }))
        .setDescription(lines).addFields({ name: 'إجمالي الإجراءات', value: '**' + (ms.total || 0) + '**', inline: true }, { name: 'انضم', value: m.joinedTimestamp ? T(m.joinedTimestamp) : '—', inline: true }));
});

// ═════════════════════ أوامر الصوت ═════════════════════
function resolveVoice(g, tok) {
    if (!tok) return null; const id = (tok.match(/^<#(\d+)>$/) || tok.match(/^(\d{15,25})$/) || [])[1];
    const isV = c => c && (c.type === CT.GuildVoice || c.type === CT.GuildStageVoice);
    if (id) { const c = g.channels.cache.get(id); return isV(c) ? c : null; }
    return g.channels.cache.find(c => isV(c) && c.name.toLowerCase().includes(tok.toLowerCase())) || null;
}
const inVoice = (m) => { if (!m.voice || !m.voice.channel) throw new Soft('العضو مو في روم صوتي.'); return m; };
const vmute = wrap(P.MuteMembers, async (msg, args) => {
    const t = await target(msg, args); const m = inVoice(guard(msg, needMember(t)));
    await m.voice.setMute(true, 'vmute! بواسطة ' + msg.author.tag); addInf(m.id, 'vmute', msg.author.id, t.rest);
    await say(msg, 'تم كتم <@' + m.id + '> صوتياً 🎙️');
});
const unvmute = wrap(P.MuteMembers, async (msg, args) => {
    const t = await target(msg, args); const m = inVoice(needMember(t));
    await m.voice.setMute(false, 'unvmute! بواسطة ' + msg.author.tag);
    await say(msg, 'تم فك الميوت الصوتي عن <@' + m.id + '>.');
});
const vkick = wrap(P.MoveMembers, async (msg, args) => {
    const t = await target(msg, args); const m = inVoice(guard(msg, needMember(t)));
    const name = m.voice.channel.name; await m.voice.disconnect('vkick! بواسطة ' + msg.author.tag); addInf(m.id, 'vkick', msg.author.id, t.rest || name);
    await say(msg, 'تم طرد <@' + m.id + '> من **' + name + '** 👢');
});
const move = wrap(P.MoveMembers, async (msg, args) => {
    const my = msg.member.voice.channel; if (!my) throw new Soft('ادخل روم صوتي أولاً ثم اكتب الأمر.');
    const t = await target(msg, args); const m = inVoice(guard(msg, needMember(t)));
    await m.voice.setChannel(my, 'move! بواسطة ' + msg.author.tag); await say(msg, 'تم سحب <@' + m.id + '> إلى **' + my.name + '**.');
});
const moveme = wrap(P.MoveMembers, async (msg, args) => {
    if (!msg.member.voice.channel) throw new Soft('لازم تكون في روم صوتي عشان أنقلك.');
    const t = await target(msg, args); const m = inVoice(needMember(t));
    await msg.member.voice.setChannel(m.voice.channel, 'moveme!'); await say(msg, 'تم نقلك إلى **' + m.voice.channel.name + '**.');
});
const moveto = wrap(P.MoveMembers, async (msg, args) => {
    const t = await target(msg, args); const who = t.member || msg.member; const ch = resolveVoice(msg.guild, (t.member ? t.rest : args).split(/\s+/)[0]);
    if (!ch) throw new Soft('حدّد الروم الصوتي: `moveto! #الروم` أو `moveto! @عضو #الروم`');
    inVoice(who); if (who.id !== msg.author.id) guard(msg, who);
    await who.voice.setChannel(ch, 'moveto!'); await say(msg, 'تم نقل <@' + who.id + '> إلى **' + ch.name + '**.');
});
const moveall = wrap(P.MoveMembers, async (msg, args) => {
    const toks = args.split(/\s+/).filter(Boolean); let from, to;
    if (toks.length >= 2) { from = resolveVoice(msg.guild, toks[0]); to = resolveVoice(msg.guild, toks[1]); }
    else if (toks.length === 1) { from = msg.member.voice.channel; to = resolveVoice(msg.guild, toks[0]); }
    if (!from || !to) throw new Soft('الاستخدام: `moveall! #من #إلى` أو `moveall! #إلى` (يسحب من رومك الحالي).');
    if (from.id === to.id) throw new Soft('الروم المصدر والهدف نفس الروم.');
    const list = [...from.members.values()]; if (!list.length) throw new Soft('الروم فاضي.');
    let n = 0; for (const m of list) { try { await m.voice.setChannel(to, 'moveall! بواسطة ' + msg.author.tag); n++; } catch {} }
    await say(msg, 'تم سحب **' + n + '** عضو من **' + from.name + '** إلى **' + to.name + '**.');
});

// ═════════════════════ الرتب ═════════════════════
function findRole(msg, text) {
    const g = msg.guild; const t = String(text || '').trim(); if (!t) return null;
    const id = (t.match(/<@&(\d+)>/) || t.match(/^(\d{15,25})$/) || [])[1];
    if (id) return g.roles.cache.get(id) || null;
    const q = t.toLowerCase();
    return g.roles.cache.find(r => r.name.toLowerCase() === q) || g.roles.cache.find(r => r.name.toLowerCase().includes(q)) || null;
}
function checkRole(msg, r) {
    if (!r) throw new Soft('حدّد الرتبة: منشن أو آيدي أو اسمها.');
    if (r.id === msg.guild.id || r.managed) throw new Soft('هذي الرتبة ما تنعطى يدوياً.');
    const owner = msg.author.id === msg.guild.ownerId;
    if (!owner && r.position >= msg.member.roles.highest.position) throw new Soft('هذي الرتبة أعلى من رتبتك أو تساويها.');
    if (!owner && r.permissions.has(P.Administrator) && !msg.member.permissions.has(P.Administrator)) throw new Soft('ما تقدر تتعامل مع رتبة فيها صلاحية Administrator.');
    if (r.position >= msg.guild.members.me.roles.highest.position) throw new Soft('رتبة البوت أقل من هذه الرتبة، ارفع رتبة البوت.');
    return r;
}
const role = wrap(P.ManageRoles, async (msg, args) => {
    const t = await target(msg, args); const m = guard(msg, needMember(t), { self: true }); const r = checkRole(msg, findRole(msg, t.rest));
    if (m.roles.cache.has(r.id)) { await m.roles.remove(r, 'role! بواسطة ' + msg.author.tag); return say(msg, 'تم سحب <@&' + r.id + '> من <@' + m.id + '>.'); }
    if ((S().roleblocks[m.id] || []).includes(r.id)) throw new Soft('العضو عليه بلوك من هذي الرتبة، فكّه بـ `removeblock!`.');
    await m.roles.add(r, 'role! بواسطة ' + msg.author.tag); await say(msg, 'تم إعطاء <@&' + r.id + '> لـ <@' + m.id + '>.');
});
const rblock = wrap(P.ManageRoles, async (msg, args) => {
    const t = await target(msg, args); const m = guard(msg, needMember(t)); const r = checkRole(msg, findRole(msg, t.rest)); const s = S();
    const a = (s.roleblocks[m.id] = s.roleblocks[m.id] || []); if (a.includes(r.id)) throw new Soft('العضو عليه بلوك من هذي الرتبة أصلاً.');
    a.push(r.id); save(); if (m.roles.cache.has(r.id)) await m.roles.remove(r, 'rblock!').catch(() => {});
    addInf(m.id, 'rblock', msg.author.id, 'رتبة ' + r.name);
    await say(msg, 'تم منع <@' + m.id + '> من الحصول على <@&' + r.id + '>.');
});
const removeblock = wrap(P.ManageRoles, async (msg, args) => {
    const t = await target(msg, args); const m = needMember(t); const s = S(); const a = s.roleblocks[m.id] || [];
    if (!a.length) throw new Soft('العضو ما عليه أي بلوك رتب.');
    if (!t.rest) { delete s.roleblocks[m.id]; save(); return say(msg, 'تم فك كل بلوكات الرتب عن <@' + m.id + '>.'); }
    const r = findRole(msg, t.rest); if (!r || !a.includes(r.id)) throw new Soft('هذي الرتبة مو ضمن بلوكات العضو.');
    s.roleblocks[m.id] = a.filter(x => x !== r.id); if (!s.roleblocks[m.id].length) delete s.roleblocks[m.id]; save();
    await say(msg, 'تم فك بلوك <@&' + r.id + '> عن <@' + m.id + '>.');
});
const roleblocks = pub(async (msg, args) => {
    const t = await target(msg, args); const s = S();
    if (t.member) {
        const a = (s.roleblocks[t.member.id] || []).filter(id => msg.guild.roles.cache.has(id));
        return send(msg, embed().setTitle('🏷️ بلوكات رتب ' + (t.member.displayName || t.member.user.username)).setDescription(a.map(id => '▸ <@&' + id + '>').join('\n') || 'لا توجد بلوكات رتب.'));
    }
    const l = Object.entries(s.roleblocks).filter(x => x[1].length);
    await send(msg, embed().setTitle('🏷️ الأعضاء المحظورون من الرتب (' + l.length + ')').setDescription(l.slice(0, 15).map(([id, a]) => '▸ <@' + id + '> — ' + a.map(r => '<@&' + r + '>').join(' ')).join('\n') || 'لا يوجد أحد.'));
});

// ═════════════════════ بلوك الصور ═════════════════════
const hasPicture = (msg) => msg.attachments.some(a => (a.contentType || '').startsWith('image/') || /\.(png|jpe?g|gif|webp|bmp|avif)(\?|$)/i.test(a.name || a.url || ''))
    || msg.embeds.some(e => e.image || e.type === 'image' || e.type === 'gifv') || msg.stickers.size > 0
    || /https?:\/\/\S+\.(png|jpe?g|gif|webp)(\?\S*)?/i.test(msg.content || '') || /(tenor\.com|giphy\.com)/i.test(msg.content || '');
const blockpic = wrap(P.ManageMessages, async (msg, args) => {
    const t = await target(msg, args); const m = guard(msg, needMember(t)); const s = S();
    if (s.blockpic[m.id]) throw new Soft('العضو عليه بلوك صور أصلاً.');
    s.blockpic[m.id] = { by: msg.author.id, at: Date.now(), reason: t.rest || 'بدون سبب' }; save(); addInf(m.id, 'blockpic', msg.author.id, t.rest);
    await say(msg, 'تم منع <@' + m.id + '> من إرسال الصور 🚫');
});
const blocked = pub(async (msg) => {
    const l = Object.entries(S().blockpic);
    await send(msg, embed().setTitle('🚫 الأعضاء المحظورون من الصور (' + l.length + ')').setDescription(l.slice(0, 20).map(([id, r]) => '▸ <@' + id + '> — ' + T(r.at) + ' • <@' + r.by + '>').join('\n') || 'لا يوجد أحد.'));
});
const removeblockpic = wrap(P.ManageMessages, async (msg, args) => {
    const t = await target(msg, args); const m = needMember(t); const s = S();
    if (!s.blockpic[m.id]) throw new Soft('العضو ما عليه بلوك صور.');
    delete s.blockpic[m.id]; save(); await say(msg, 'تم فك بلوك الصور عن <@' + m.id + '>.');
});
async function onMessage(msg) {
    if (!msg.guild || msg.guild.id !== SERVER_ID || !msg.author || msg.author.bot || !S().blockpic[msg.author.id] || !hasPicture(msg)) return false;
    await msg.delete().catch(() => {});
    const n = await msg.channel.send({ content: '<@' + msg.author.id + '>', embeds: [embed().setDescription('🚫  ممنوع إرسال الصور — عليك بلوك صور.')], allowedMentions: { users: [msg.author.id] } }).catch(() => null);
    if (n) setTimeout(() => n.delete().catch(() => {}), 5000);
    return true;
}

// ═════════════════════ الإيموجي والستيكرز ═════════════════════
const cleanName = (s, min = 2) => { let n = String(s || '').replace(/[^\w]/g, '_').slice(0, 32); while (n.length < min) n += '_'; return n; };
const IMG_RE = /^image\/|\.(png|jpe?g|gif|webp)(\?|$)/i;
async function refMsg(msg) { if (!msg.reference || !msg.reference.messageId) return null; return msg.channel.messages.fetch(msg.reference.messageId).catch(() => null); }
const aemoji = wrap(EXP, async (msg, args) => {
    const items = []; const ref = await refMsg(msg); const texts = [args, ref ? ref.content : ''].join(' ');
    for (const m of texts.matchAll(/<(a?):(\w+):(\d+)>/g)) items.push({ name: cleanName(m[2]), url: 'https://cdn.discordapp.com/emojis/' + m[3] + '.' + (m[1] ? 'gif' : 'png') + '?size=128' });
    const nameArg = args.replace(/<a?:\w+:\d+>/g, '').replace(/https?:\/\/\S+/g, '').trim().split(/\s+/)[0];
    const files = [...msg.attachments.values(), ...(ref ? [...ref.attachments.values()] : [])].filter(a => IMG_RE.test(a.contentType || a.name || ''));
    files.forEach((a, i) => items.push({ name: cleanName(files.length === 1 && nameArg ? nameArg : (a.name || 'emoji').replace(/\.\w+$/, '')), url: a.url }));
    const u = args.match(/https?:\/\/\S+\.(?:png|jpe?g|gif|webp)\S*/i); if (u) items.push({ name: cleanName(nameArg && !/^https?:/i.test(nameArg) ? nameArg : 'emoji'), url: u[0] });
    if (!items.length) throw new Soft('الاستخدام: `aemoji! <إيموجي سيرفر>` أو أرفق صورة مع `aemoji! الاسم` أو ردّ على رسالة فيها صورة.');
    const added = [], failed = [];
    for (const it of items.slice(0, 10)) {
        try { const e = await msg.guild.emojis.create({ attachment: it.url, name: it.name, reason: 'aemoji! بواسطة ' + msg.author.tag }); added.push(e.toString()); }
        catch (e) { failed.push('`' + it.name + '` — ' + cut(e.message, 60)); }
    }
    const e = embed().setTitle('😀 إضافة إيموجي');
    if (added.length) e.addFields({ name: '✅ تمت الإضافة (' + added.length + ')', value: added.join(' ') });
    if (failed.length) e.addFields({ name: '❌ فشلت (' + failed.length + ')', value: failed.join('\n') });
    await send(msg, e);
});
const stickers = wrap(EXP, async (msg, args) => {
    const ref = await refMsg(msg); let url = null, base = '';
    const st = msg.stickers.first() || (ref && ref.stickers.first());
    const a = [...msg.attachments.values(), ...(ref ? [...ref.attachments.values()] : [])].find(x => IMG_RE.test(x.contentType || x.name || ''));
    if (a) { url = a.url; base = (a.name || '').replace(/\.\w+$/, ''); } else if (st) { url = st.url; base = st.name; }
    else { const u = args.match(/https?:\/\/\S+/); if (u) url = u[0]; }
    if (!url) throw new Soft('الاستخدام: أرفق صورة PNG مع `stickers! الاسم` أو ردّ على رسالة فيها صورة/ستيكر.');
    const name = cut(args.replace(/https?:\/\/\S+/g, '').trim().split(/\s+/)[0] || base || 'sticker', 30).padEnd(2, '_');
    try {
        const s = await msg.guild.stickers.create({ file: url, name, tags: cut(name, 200), reason: 'stickers! بواسطة ' + msg.author.tag });
        await send(msg, embed().setTitle('🏷️ تمت إضافة الستيكر').setDescription('الاسم: **' + s.name + '**').setThumbnail(s.url));
    } catch (e) { throw new Soft('تعذّرت الإضافة: ' + cut(e.message, 120) + '\nالمطلوب: PNG/APNG/GIF بحجم أقل من 512KB وأبعاد 320×320.'); }
});

// ═════════════════════ التسجيل والأحداث ═════════════════════
const TABLE = {
    'help!': help, 'avatar!': avatar, 'banner!': banner, 'profile!': profile, 'level!': level, 'server!': server, 'user!': user, 'ping!': ping,
    'semoji!': semoji, 'statistics!': statistics, 'messages!': messages, 'point!': point, 'bots!': bots, 'botstatus!': botstatus, 'advice!': advice, 'pslist!': pslist,
    'warn!': warn, 'warnings!': warnings, 'dinfractions!': dinfractions, 'timeout!': timeout, 'untimeout!': untimeout,
    'mute!': mute, 'mymute!': mymute, 'unmute!': unmute, 'prison!': prison, 'myprison!': myprison, 'unprison!': unprison, 'stats!': stats,
    'vmute!': vmute, 'unvmute!': unvmute, 'vkick!': vkick, 'move!': move, 'moveme!': moveme, 'moveto!': moveto, 'moveall!': moveall,
    'role!': role, 'rblock!': rblock, 'removeblock!': removeblock, 'roleblocks!': roleblocks,
    'blockpic!': blockpic, 'blocked!': blocked, 'removeblockpic!': removeblockpic, 'aemoji!': aemoji, 'stickers!': stickers
};
let hooked = false;
function onReady() {
    try {
        const CMDS = H.getCMDS();
        for (const [k, fn] of Object.entries(TABLE)) if (!CMDS[k]) CMDS[k] = fn;
        console.log('[modcmds] ✅ ' + Object.keys(TABLE).length + ' أمر شات جاهز');
        const s = S(); for (const uid of Object.keys(s.mutes)) arm('mutes', uid); for (const uid of Object.keys(s.prison)) arm('prison', uid);
        if (hooked) return; hooked = true;
        client.on('guildMemberUpdate', async (_old, nw) => {
            try {
                if (!nw.guild || nw.guild.id !== SERVER_ID) return;
                const bl = S().roleblocks[nw.id]; if (!bl || !bl.length) return;
                const bad = nw.roles.cache.filter(r => bl.includes(r.id)); if (bad.size) await nw.roles.remove([...bad.keys()], 'rblock!');
            } catch {}
        });
        client.on('channelCreate', async (ch) => {
            try {
                if (!ch.guild || ch.guild.id !== SERVER_ID || !ch.permissionOverwrites) return; const ids = S().roleIds;
                if (ids.mute) { const r = ch.guild.roles.cache.get(ids.mute); if (r) await ch.permissionOverwrites.edit(r, PERMS.mute); }
                if (ids.prison && !creatingPrisonCh && ch.id !== ids.prisonChannel) { const r = ch.guild.roles.cache.get(ids.prison); if (r) await ch.permissionOverwrites.edit(r, PERMS.prison); }
            } catch {}
        });
    } catch (e) { console.error('[modcmds]', e.message); }
}
/** إذا خرج عضو عليه ميوت/سجن ثم رجع، تُعاد العقوبة عليه */
async function onMemberAdd(member) {
    try {
        if (!member.guild || member.guild.id !== SERVER_ID) return; const s = S();
        const mu = s.mutes[member.id]; if (mu && (!mu.until || mu.until > Date.now())) await member.roles.add(mu.roleId, 'إعادة الميوت بعد الرجوع').catch(() => {});
        const pr = s.prison[member.id]; if (pr && (!pr.until || pr.until > Date.now())) await member.roles.add(pr.roleId, 'إعادة السجن بعد الرجوع').catch(() => {});
    } catch {}
}
return { onReady, onMessage, onMemberAdd, _table: TABLE };
};
