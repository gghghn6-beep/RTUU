'use strict';
/**
 * المشغّل الصوتي /music — يوتيوب + القرآن الكريم (mp3quran.net) + أزرار تحكم
 * يستخدمه أيضاً نظام الذكاء الاصطناعي (ai.js) عبر H.music
 *
 * المتطلبات: @discordjs/voice + ffmpeg (موجودان أصلاً)، ولليوتيوب: youtube-sr و @distube/ytdl-core
 * (تُحمَّل عند الحاجة فقط، لو غير مثبتة يرد البوت برسالة واضحة ولا يتعطل).
 */
module.exports = (H) => {
const { D, client, EPH, row, btn, embed, cut, adminOnly } = H;
const { ButtonStyle, PermissionFlagsBits: P } = D;
const { spawn } = require('child_process');

let voice = null;
try { voice = require('@discordjs/voice'); } catch {}
let ffmpegPath = null;
function getFfmpeg() {
    if (ffmpegPath) return ffmpegPath;
    try { const p = require('ffmpeg-static'); if (p && require('fs').existsSync(p)) return (ffmpegPath = p); } catch {}
    return (ffmpegPath = 'ffmpeg');
}

const states = new Map(); // guildId -> state
const IDLE_LEAVE_MS = 5 * 60 * 1000;

// ───── إعدادات ─────
const cfg = () => {
    const m = (H.db.music = H.db.music || {});
    m.volume = Number.isFinite(m.volume) ? m.volume : 80;
    m.reciter = m.reciter || 'مشاري العفاسي';
    m.maxQueue = Number.isFinite(m.maxQueue) ? m.maxQueue : 25;
    return m;
};

// ───── القرآن ─────
const SURAHS = ['الفاتحة','البقرة','آل عمران','النساء','المائدة','الأنعام','الأعراف','الأنفال','التوبة','يونس','هود','يوسف','الرعد','إبراهيم','الحجر','النحل','الإسراء','الكهف','مريم','طه','الأنبياء','الحج','المؤمنون','النور','الفرقان','الشعراء','النمل','القصص','العنكبوت','الروم','لقمان','السجدة','الأحزاب','سبأ','فاطر','يس','الصافات','ص','الزمر','غافر','فصلت','الشورى','الزخرف','الدخان','الجاثية','الأحقاف','محمد','الفتح','الحجرات','ق','الذاريات','الطور','النجم','القمر','الرحمن','الواقعة','الحديد','المجادلة','الحشر','الممتحنة','الصف','الجمعة','المنافقون','التغابن','الطلاق','التحريم','الملك','القلم','الحاقة','المعارج','نوح','الجن','المزمل','المدثر','القيامة','الإنسان','المرسلات','النبأ','النازعات','عبس','التكوير','الانفطار','المطففين','الانشقاق','البروج','الطارق','الأعلى','الغاشية','الفجر','البلد','الشمس','الليل','الضحى','الشرح','التين','العلق','القدر','البينة','الزلزلة','العاديات','القارعة','التكاثر','العصر','الهمزة','الفيل','قريش','الماعون','الكوثر','الكافرون','النصر','المسد','الإخلاص','الفلق','الناس'];
const normAr = s => String(s || '').toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .replace(/^(سوره|سورة)\s*/, '').replace(/^ال/, '').replace(/\s+/g, ' ').trim();
function findSurah(q) {
    const t = String(q || '').trim();
    if (/^\d{1,3}$/.test(t)) { const n = parseInt(t, 10); return n >= 1 && n <= 114 ? n : 0; }
    const nq = normAr(t.replace(/^(سورة|سوره)\s*/, ''));
    if (!nq) return 0;
    let idx = SURAHS.findIndex(s => normAr(s) === nq);
    if (idx < 0) idx = SURAHS.findIndex(s => normAr(s).startsWith(nq) || nq.startsWith(normAr(s)));
    return idx >= 0 ? idx + 1 : 0;
}
let reciterCache = { at: 0, list: [] };
async function getReciters() {
    if (Date.now() - reciterCache.at < 12 * 3600 * 1000 && reciterCache.list.length) return reciterCache.list;
    try {
        const res = await fetch('https://www.mp3quran.net/api/v3/reciters?language=ar', { signal: AbortSignal.timeout(10000) });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const j = await res.json();
        const list = Array.isArray(j.reciters) ? j.reciters : [];
        if (list.length) reciterCache = { at: Date.now(), list };
        return list;
    } catch (e) { console.warn('[music] reciters:', e.message); return reciterCache.list; }
}
async function quranTrack(surahQ, reciterQ) {
    const n = findSurah(surahQ);
    if (!n) throw new Error('ما عرفت السورة «' + surahQ + '». اكتب اسم السورة أو رقمها (1-114).');
    const pad = String(n).padStart(3, '0');
    const list = await getReciters();
    const wanted = normAr(reciterQ || cfg().reciter);
    let rec = list.find(r => normAr(r.name).includes(wanted)) || list.find(r => normAr(r.name).includes(normAr(cfg().reciter)));
    let url = '', rname = '';
    if (rec) {
        const mo = (rec.moshaf || []).find(m => String(m.surah_list || '').split(',').includes(String(n))) || null;
        if (mo && mo.server) { url = String(mo.server).replace(/\/?$/, '/') + pad + '.mp3'; rname = rec.name; }
    }
    if (!url) { url = 'https://server8.mp3quran.net/afs/' + pad + '.mp3'; rname = 'مشاري العفاسي'; } // احتياطي
    return { kind: 'url', url, title: 'سورة ' + SURAHS[n - 1], sub: rname, icon: '📖' };
}

// ───── يوتيوب ─────
function ytLibs() {
    let sr, ytdl;
    try { sr = require('youtube-sr'); sr = sr.default || sr.YouTube || sr; } catch {}
    try { ytdl = require('@distube/ytdl-core'); } catch {}
    return { sr, ytdl };
}
async function youtubeTrack(query) {
    const { sr, ytdl } = ytLibs();
    if (!sr || !ytdl) throw new Error('مكتبات اليوتيوب غير مثبتة. نفّذ: npm install youtube-sr @distube/ytdl-core');
    const q = String(query || '').trim();
    if (!q) throw new Error('اكتب اسم المقطع أو رابطه.');
    let url = q, title = q, dur = '', thumb = '';
    if (/^https?:\/\//i.test(q)) {
        if (!ytdl.validateURL(q)) throw new Error('الرابط ليس رابط يوتيوب صالح.');
    } else {
        const v = await sr.searchOne(q, 'video', false);
        if (!v || !v.url) throw new Error('ما لقيت نتيجة لـ «' + cut(q, 60) + '».');
        url = v.url; title = v.title || q; dur = v.durationFormatted || ''; thumb = (v.thumbnail && v.thumbnail.url) || '';
    }
    return { kind: 'yt', url, title, sub: dur, thumb, icon: '▶️' };
}

// ───── الصوت ─────
function needVoice() { return voice ? null : 'مكتبة الصوت @discordjs/voice غير مثبتة على الاستضافة.'; }
function stateOf(gid) { return states.get(gid) || null; }
function killProc(st) { try { if (st && st.proc) { st.proc.stdin && st.proc.stdin.destroy(); st.proc.kill('SIGKILL'); } } catch {} if (st) st.proc = null; try { if (st && st.src && st.src.destroy) st.src.destroy(); } catch {} if (st) st.src = null; }
function armIdle(st) {
    clearTimeout(st.idleTimer);
    st.idleTimer = setTimeout(() => { if (!st.current && stayChannelId() !== st.channelId) leave(st.guildId); }, IDLE_LEAVE_MS);
}

async function joinChannel(ch) {
    const err = needVoice(); if (err) throw new Error(err);
    if (!ch) throw new Error('ادخل روم صوتي أول، وبعدها اطلب مني.');
    const me = ch.guild.members.me;
    const perms = me && ch.permissionsFor(me);
    if (!perms || !perms.has(P.Connect) || !perms.has(P.Speak) || !perms.has(P.ViewChannel)) throw new Error('البوت يحتاج صلاحيات Connect و Speak في ' + ch.name + '.');
    let st = stateOf(ch.guild.id);
    if (st && st.channelId === ch.id && st.connection && st.connection.state.status !== voice.VoiceConnectionStatus.Destroyed) return st;
    if (st) leave(ch.guild.id);
    const connection = voice.joinVoiceChannel({ channelId: ch.id, guildId: ch.guild.id, adapterCreator: ch.guild.voiceAdapterCreator, selfDeaf: true, selfMute: false });
    try { await voice.entersState(connection, voice.VoiceConnectionStatus.Ready, 15000); }
    catch { try { connection.destroy(); } catch {} throw new Error('تعذّر الاتصال بالروم الصوتي.'); }
    const player = voice.createAudioPlayer({ behaviors: { noSubscriber: voice.NoSubscriberBehavior.Pause } });
    connection.subscribe(player);
    st = { guildId: ch.guild.id, channelId: ch.id, connection, player, queue: [], current: null, resource: null, proc: null, src: null, idleTimer: null, textChannelId: null, paused: false };
    states.set(ch.guild.id, st);
    player.on(voice.AudioPlayerStatus.Idle, () => { killProc(st); st.current = null; next(st.guildId).catch(() => {}); });
    player.on('error', e => { console.error('[music] player:', e.message); killProc(st); st.current = null; next(st.guildId).catch(() => {}); });
    connection.on(voice.VoiceConnectionStatus.Disconnected, async () => {
        try {
            await Promise.race([voice.entersState(connection, voice.VoiceConnectionStatus.Signalling, 5000), voice.entersState(connection, voice.VoiceConnectionStatus.Connecting, 5000)]);
        } catch { const stay = stayChannelId(); leave(st.guildId); if (stay === ch.id) setTimeout(() => stayJoin().catch(() => {}), 5000); }
    });
    armIdle(st);
    return st;
}
async function ensureConnection(member) {
    const ch = member && member.voice && member.voice.channel;
    if (!ch) throw new Error('ادخل روم صوتي أول، وبعدها اطلب مني.');
    return joinChannel(ch);
}
/** الروم الذي يبقى فيه البوت دائماً (setvoice!) */
const stayChannelId = () => (H.db.stay && H.db.stay.channelId) || '';
async function stayJoin() {
    const id = stayChannelId(); if (!id) return false;
    const ch = client.channels.cache.get(id) || await client.channels.fetch(id).catch(() => null);
    if (!ch || !ch.isVoiceBased || !ch.isVoiceBased()) return false;
    await joinChannel(ch); return true;
}
function setStay(channelId) { H.db.stay = channelId ? { channelId } : {}; H.save(); }

function makeResource(st, track) {
    const ff = getFfmpeg();
    const base = ['-hide_banner', '-loglevel', 'error', '-vn', '-f', 's16le', '-ar', '48000', '-ac', '2', 'pipe:1'];
    let proc;
    if (track.kind === 'yt') {
        const { ytdl } = ytLibs();
        const src = ytdl(track.url, { filter: 'audioonly', quality: 'highestaudio', highWaterMark: 1 << 25 });
        proc = spawn(ff, ['-i', 'pipe:0', ...base], { stdio: ['pipe', 'pipe', 'ignore'] });
        src.on('error', e => { console.error('[music] ytdl:', e.message); try { proc.kill('SIGKILL'); } catch {} });
        proc.stdin.on('error', () => {});
        src.pipe(proc.stdin);
        st.src = src;
    } else {
        proc = spawn(ff, ['-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_delay_max', '5', '-i', track.url, ...base], { stdio: ['ignore', 'pipe', 'ignore'] });
    }
    proc.on('error', e => console.error('[music] ffmpeg:', e.message));
    st.proc = proc;
    const res = voice.createAudioResource(proc.stdout, { inputType: voice.StreamType.Raw, inlineVolume: true });
    if (res.volume) res.volume.setVolume(Math.max(0, Math.min(1.5, (st.volume != null ? st.volume : cfg().volume) / 100)));
    return res;
}

async function startTrack(st, track) {
    killProc(st);
    st.current = track; st.paused = false;
    st.resource = makeResource(st, track);
    st.player.play(st.resource);
    clearTimeout(st.idleTimer);
    await postPanel(st).catch(() => {});
}
async function next(gid) {
    const st = stateOf(gid); if (!st) return;
    if (st.current) return;
    const t = st.queue.shift();
    if (!t) { await postPanel(st, true).catch(() => {}); armIdle(st); return; }
    try { await startTrack(st, t); } catch (e) { console.error('[music] start:', e.message); st.current = null; return next(gid); }
}

/** تشغيل: mode = 'now' (يستبدل الحالي) أو 'queue' */
async function play(member, track, mode = 'now', textChannelId) {
    const st = await ensureConnection(member);
    if (textChannelId) st.textChannelId = textChannelId;
    track.by = member.id;
    if (mode === 'queue' && st.current) {
        if (st.queue.length >= cfg().maxQueue) throw new Error('قائمة الانتظار ممتلئة.');
        st.queue.push(track); await postPanel(st).catch(() => {});
        return { queued: true, position: st.queue.length, track };
    }
    await startTrack(st, track);
    return { queued: false, track };
}
function pause(gid) { const st = stateOf(gid); if (!st || !st.current) return false; st.player.pause(true); st.paused = true; return true; }
function resume(gid) { const st = stateOf(gid); if (!st || !st.current) return false; st.player.unpause(); st.paused = false; return true; }
function skip(gid) { const st = stateOf(gid); if (!st || !st.current) return false; st.player.stop(true); return true; }
function stop(gid) { const st = stateOf(gid); if (!st) return false; st.queue = []; st.current = null; try { st.player.stop(true); } catch {} killProc(st); armIdle(st); return true; }
function leave(gid) {
    const st = stateOf(gid); if (!st) return false;
    clearTimeout(st.idleTimer); st.queue = []; st.current = null;
    try { st.player.stop(true); } catch {} killProc(st);
    try { st.connection.destroy(); } catch {}
    states.delete(gid); return true;
}
function setVolume(gid, v) {
    const st = stateOf(gid); const n = Math.max(0, Math.min(150, Math.round(Number(v))));
    if (!Number.isFinite(n)) return false;
    cfg().volume = n; H.save();
    if (st) { st.volume = n; if (st.resource && st.resource.volume) st.resource.volume.setVolume(n / 100); }
    return n;
}
function nowPlaying(gid) { const st = stateOf(gid); return st && st.current ? { track: st.current, queue: st.queue.length, paused: st.paused } : null; }

// ───── اللوحة ─────
function panel(st, ended) {
    const t = st && st.current;
    const e = embed().setTitle(t ? (st.paused ? '⏸️ متوقف مؤقتاً' : '🎵 يُشغَّل الآن') : '🎵 المشغّل الصوتي');
    if (t) {
        e.setDescription('**' + cut(t.title, 200) + '**' + (t.sub ? '\n' + cut(t.sub, 100) : '') + '\n[' + (t.kind === 'yt' ? 'يوتيوب' : 'مصدر الصوت') + '](' + t.url + ')');
        if (t.thumb) e.setThumbnail(t.thumb);
        e.addFields({ name: '🔊 الصوت', value: '**' + (st.volume != null ? st.volume : cfg().volume) + '%**', inline: true }, { name: '📜 في الانتظار', value: '**' + st.queue.length + '**', inline: true }, { name: '👤 بطلب', value: t.by ? '<@' + t.by + '>' : '—', inline: true });
    } else e.setDescription(ended ? 'انتهى التشغيل. اطلب مقطعاً جديداً أو أخرجني من الروم.' : 'لا يوجد شيء يعمل حالياً.');
    const on = !!t;
    return {
        embeds: [e],
        components: [row(
            btn('mu:pause', st && st.paused ? 'استكمال' : 'إيقاف مؤقت', st && st.paused ? '▶️' : '⏸️', ButtonStyle.Primary, !on),
            btn('mu:skip', 'تخطي', '⏭️', ButtonStyle.Secondary, !on),
            btn('mu:stop', 'إيقاف', '⏹️', ButtonStyle.Secondary, !on),
            btn('mu:vdn', '', '🔉', ButtonStyle.Secondary),
            btn('mu:vup', '', '🔊', ButtonStyle.Secondary)
        ), row(btn('mu:leave', 'إخراج البوت من الروم', '🚪', ButtonStyle.Danger))]
    };
}
async function postPanel(st, ended) {
    if (!st.textChannelId) return;
    const ch = client.channels.cache.get(st.textChannelId) || await client.channels.fetch(st.textChannelId).catch(() => null);
    if (!ch || !ch.send) return;
    const p = panel(st, ended);
    if (st.panelMsg) { try { await st.panelMsg.edit(p); return; } catch { st.panelMsg = null; } }
    st.panelMsg = await ch.send({ ...p, allowedMentions: { parse: [] } }).catch(() => null);
}

// ───── الأوامر ─────
const sameRoom = (i, st) => i.member && i.member.voice && i.member.voice.channelId === st.channelId;

async function slash(i) {
    const type = i.options.getString('type') || 'youtube';
    const q = i.options.getString('query');
    if (!q) {
        const st = stateOf(i.guildId);
        return i.reply({ ...panel(st || {}), flags: EPH });
    }
    await i.deferReply({ flags: EPH });
    try {
        const track = type === 'quran' ? await quranTrack(q, i.options.getString('reciter')) : await youtubeTrack(q);
        const r = await play(i.member, track, i.options.getString('mode') || 'now', i.channelId);
        return i.editReply({ content: r.queued ? '➕ أُضيف إلى الانتظار (#' + r.position + '): **' + cut(track.title, 100) + '**' : '✅ جاري التشغيل: **' + cut(track.title, 100) + '**' });
    } catch (e) { return i.editReply({ content: '❌ ' + e.message }); }
}

async function component(i) {
    const a = i.customId.split(':')[1];
    const st = stateOf(i.guildId);
    if (!st) return i.reply({ content: '❌ البوت ليس في روم صوتي.', flags: EPH });
    if (!sameRoom(i, st) && !H.isAdmin(i.member)) return i.reply({ content: '❌ لازم تكون في نفس الروم الصوتي مع البوت.', flags: EPH });
    if (a === 'pause') { st.paused ? resume(i.guildId) : pause(i.guildId); }
    else if (a === 'skip') skip(i.guildId);
    else if (a === 'stop') stop(i.guildId);
    else if (a === 'vup') setVolume(i.guildId, (st.volume != null ? st.volume : cfg().volume) + 10);
    else if (a === 'vdn') setVolume(i.guildId, (st.volume != null ? st.volume : cfg().volume) - 10);
    else if (a === 'leave') { leave(i.guildId); return i.update({ embeds: [embed().setTitle('🚪 تم الخروج').setDescription('خرج البوت من الروم الصوتي.')], components: [] }); }
    return i.update(panel(st));
}

const commands = [{
    name: 'music', description: 'المشغّل الصوتي: يوتيوب والقرآن الكريم مع أزرار تحكم',
    options: [
        { name: 'query', description: 'اسم المقطع أو رابطه / اسم السورة أو رقمها', type: 3, required: false },
        { name: 'type', description: 'المصدر', type: 3, required: false, choices: [{ name: 'يوتيوب', value: 'youtube' }, { name: 'القرآن الكريم', value: 'quran' }] },
        { name: 'reciter', description: 'القارئ (للقرآن فقط) مثل: العفاسي', type: 3, required: false },
        { name: 'mode', description: 'تشغيل الآن أو إضافة للانتظار', type: 3, required: false, choices: [{ name: 'الآن', value: 'now' }, { name: 'إضافة للانتظار', value: 'queue' }] }
    ]
}];

H.music = { join: ensureConnection, joinChannel, stayJoin, setStay, stayChannelId, play, pause, resume, skip, stop, leave, setVolume, nowPlaying, youtubeTrack, quranTrack, findSurah, SURAHS, hasVoice: () => !!voice, state: stateOf };
function onReady() { setTimeout(() => { stayJoin().catch(e => console.warn('[music] stay:', e.message)); }, 4000); }
return { prefix: 'mu', commands, ephemeral: ['music'], slash: { music: slash }, component, onReady };
};
