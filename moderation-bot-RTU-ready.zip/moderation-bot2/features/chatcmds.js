'use strict';
/**
 * أوامر الشات بنمط «اسم!» — تظهر في /cmdmanager ويمكن تفعيلها وإيقافها:
 *   hide! / unhide!   إخفاء/إظهار الروم عن الجميع
 *   lock! / unlock!   قفل/فتح الكتابة في الروم
 *   slowmode! 5       الوضع البطيء بالثواني (0 للإلغاء)
 *   setlog! / detlog! إنشاء/حذف رومات السجلات
 *   setvoice!         تثبيت البوت في روم صوتي (يبقى 24 ساعة)، و setvoice! off للإلغاء
 *   color! / colors!  تغيير لونك / عرض قائمة الألوان (للجميع)
 */
module.exports = (H) => {
const { D, SERVER_ID, isAdmin, cut } = H;
const { PermissionFlagsBits: P } = D;

const deny = (msg) => msg.reply({ content: '❌ هذا الأمر للإدارة فقط.', allowedMentions: { repliedUser: false } });
const ok = (msg, t) => msg.reply({ content: '✅ ' + t, allowedMentions: { repliedUser: false } });
const fail = (msg, e) => msg.reply({ content: '❌ ' + cut(e && e.message ? e.message : e, 200), allowedMentions: { repliedUser: false } });
const admin = (fn) => async (msg, args) => {
    if (!msg.guild || msg.guild.id !== SERVER_ID) return;
    if (!isAdmin(msg.member)) return deny(msg);
    try { await fn(msg, args); } catch (e) { await fail(msg, e); }
};
const setEveryone = (msg, perms, reason) => msg.channel.permissionOverwrites.edit(msg.guild.roles.everyone, perms, { reason });

const hide = admin(async (msg) => { await setEveryone(msg, { ViewChannel: false }, 'hide! بواسطة ' + msg.author.tag); await ok(msg, 'تم إخفاء الروم عن الجميع.').catch(() => {}); });
const unhide = admin(async (msg) => { await setEveryone(msg, { ViewChannel: null }, 'unhide!'); await ok(msg, 'تم إظهار الروم.'); });
const lock = admin(async (msg) => { await setEveryone(msg, { SendMessages: false }, 'lock!'); await ok(msg, 'تم قفل الروم 🔒'); });
const unlock = admin(async (msg) => { await setEveryone(msg, { SendMessages: null }, 'unlock!'); await ok(msg, 'تم فتح الروم 🔓'); });
const slowmode = admin(async (msg, args) => {
    const n = parseInt(String(args || '').trim(), 10);
    if (!Number.isFinite(n) || n < 0 || n > 21600) throw new Error('اكتب عدد الثواني من 0 إلى 21600، مثال: `slowmode! 5`');
    await msg.channel.setRateLimitPerUser(n, 'slowmode!');
    await ok(msg, n ? 'الوضع البطيء الآن **' + n + '** ثانية.' : 'تم إلغاء الوضع البطيء.');
});
const setlog = admin(async (msg) => { const n = await H.logs.autoCreate(msg.guild); await ok(msg, 'تم إنشاء **' + n + '** رومات سجلات وربطها. اضبط التفاصيل من `/logs`.'); });
const detlog = admin(async (msg) => { const n = await H.logs.autoDelete(msg.guild); await ok(msg, 'تم حذف **' + n + '** من رومات السجلات.'); });
const setvoice = admin(async (msg, args) => {
    if (!H.music) throw new Error('المشغّل الصوتي غير متاح.');
    if (/^(off|إلغاء|الغاء|ايقاف|إيقاف)$/i.test(String(args || '').trim())) { H.music.setStay(''); H.music.leave(msg.guild.id); return ok(msg, 'تم إلغاء التثبيت، وخرج البوت من الروم الصوتي.'); }
    const ch = msg.member.voice && msg.member.voice.channel;
    if (!ch) throw new Error('ادخل روم صوتي أول ثم اكتب `setvoice!` (أو `setvoice! off` للإلغاء).');
    await H.music.joinChannel(ch); H.music.setStay(ch.id);
    await ok(msg, 'تم تثبيت البوت في **' + ch.name + '** 🎙️');
});
const color = (msg, args) => H.colors.cmdColor(msg, args);
const colors = (msg) => H.colors.cmdColors(msg);

const TABLE = {
    'hide!': hide, 'unhide!': unhide, 'lock!': lock, 'unlock!': unlock, 'slowmode!': slowmode,
    'setlog!': setlog, 'detlog!': detlog, 'setvoice!': setvoice, 'color!': color, 'colors!': colors
};
/** يُسجَّل في جدول الأوامر الرئيسي بعد جاهزية البوت */
function onReady() {
    try {
        const CMDS = H.getCMDS();
        for (const [k, fn] of Object.entries(TABLE)) if (!CMDS[k]) CMDS[k] = fn;
        console.log('[chatcmds] ✅ أوامر الشات: ' + Object.keys(TABLE).join(' '));
    } catch (e) { console.error('[chatcmds]', e.message); }
}
return { onReady, _table: TABLE };
};
