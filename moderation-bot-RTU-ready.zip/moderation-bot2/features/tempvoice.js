'use strict';
// ═══ الرومات الصوتية المؤقتة: /tempvoice ═══
// عضو يدخل قناة «انضم للإنشاء» ← ينشأ له روم خاص ← يتحكم فيه من لوحة التحكم (تُرسل بزر 📤 إلى قناة التحكم)
module.exports = (H) => {
const { D, SERVER_ID, EPH, row, btn, chSel, strSel, userSel, input, modal, embed, cut, clamp, session, adminOnly, update, onOff, chTxt, isAdmin, getTextChannel } = H;
const db = H.db;
const { ButtonStyle, ChannelType, PermissionFlagsBits } = D;
const cfgRaw = () => { const t = (db.tempvoice = db.tempvoice || {}); t.rooms = t.rooms || {}; return t; };
const val = (t) => ({
    enabled: !!t.enabled, creatorId: t.creatorId || '', categoryId: t.categoryId || '', controlId: t.controlId || '',
    name: t.name || '{user} 🎙️', limit: Number.isFinite(t.limit) ? t.limit : 0, bitrate: Number.isFinite(t.bitrate) ? t.bitrate : 64,
    autoDelete: t.autoDelete !== false, title: t.title || '🎛️ لوحة التحكم بالغرفة', desc: t.desc || 'استخدم الأزرار أدناه للتحكم في غرفتك الصوتية الخاصة.\nلازم تكون صاحب غرفة مؤقتة (ادخل قناة الإنشاء أولاً).',
    disabled: Array.isArray(t.disabled) ? t.disabled : []
});
// key, label(زر), وصف (قائمة الصلاحيات), emoji
const ABILITIES = [
    { key: 'rename', btn: 'الاسم', label: 'تغيير اسم الغرفة', emoji: '✏️' }, { key: 'limit', btn: 'الحد', label: 'تغيير حد الأعضاء', emoji: '👥' },
    { key: 'bitrate', btn: 'البت ريت', label: 'تغيير البت ريت', emoji: '🎚️' }, { key: 'region', btn: 'المنطقة', label: 'تغيير المنطقة / السيرفر', emoji: '🌐' },
    { key: 'lock', btn: 'القفل', label: 'خصوصية القناة (قفل / فتح)', emoji: '🔒' }, { key: 'hide', btn: 'الإخفاء', label: 'إخفاء / إظهار الغرفة', emoji: '👁️' },
    { key: 'kick', btn: 'طرد', label: 'طرد عضو', emoji: '🚪' }, { key: 'ban', btn: 'حظر', label: 'حظر عضو', emoji: '⛔' },
    { key: 'unban', btn: 'رفع الحظر', label: 'رفع الحظر', emoji: '✅' }, { key: 'invite', btn: 'دعوة', label: 'دعوة عضو (حتى لو مقفلة)', emoji: '📨' },
    { key: 'trust', btn: 'ثقة', label: 'إعطاء ثقة', emoji: '🛡️' }, { key: 'untrust', btn: 'إلغاء الثقة', label: 'إلغاء الثقة', emoji: '🚫' },
    { key: 'claim', btn: 'استلام', label: 'المطالبة Claim (استلام غرفة خالية من المالك)', emoji: '🎙️' }, { key: 'transfer', btn: 'نقل الملكية', label: 'نقل الملكية', emoji: '👑' },
    { key: 'delete', btn: 'حذف', label: 'إلغاء الغرفة (حذف فوري)', emoji: '🗑️' }
];
const KEYS = new Set(ABILITIES.map(a => a.key));
const USER_ACTS = new Set(['kick', 'ban', 'unban', 'invite', 'trust', 'untrust', 'transfer']);
const REGIONS = [['auto', 'تلقائي'], ['us-east', 'أمريكا الشرقية'], ['us-west', 'أمريكا الغربية'], ['us-central', 'أمريكا الوسطى'], ['us-south', 'أمريكا الجنوبية'], ['europe', 'أوروبا'], ['rotterdam', 'روتردام'], ['russia', 'روسيا'], ['india', 'الهند'], ['japan', 'اليابان'], ['hongkong', 'هونغ كونغ'], ['singapore', 'سنغافورة'], ['sydney', 'سيدني'], ['southafrica', 'جنوب أفريقيا'], ['brazil', 'البرازيل']];
const roomName = (tpl, m) => cut(String(tpl).replace(/\{user\}/gi, m.displayName || m.user.username).replace(/\{username\}/gi, m.user.username).replace(/\{server\}/gi, m.guild.name).replace(/\{userid\}/gi, m.id), 100) || m.user.username;
const sess = (i) => session(i, 'tv', () => ({ page: 'main' }));

// ───── لوحة التحكم (الرسالة) ─────
function controlRows(c, chId) {
    const on = ABILITIES.filter(a => !c.disabled.includes(a.key));
    const rows = [];
    for (let k = 0; k < on.length; k += 5) rows.push(row(...on.slice(k, k + 5).map(a => btn('tv:' + a.key + (chId ? ':' + chId : ''), a.btn, a.emoji, a.key === 'delete' ? ButtonStyle.Danger : a.key === 'claim' ? ButtonStyle.Primary : ButtonStyle.Secondary))));
    return rows;
}
function controlMessage(chId) {
    const c = val(cfgRaw());
    const e = embed().setTitle(cut(c.title, 256)).setDescription(cut(c.desc, 3000));
    const lines = ABILITIES.filter(a => !c.disabled.includes(a.key)).map(a => a.emoji + ' ' + a.label);
    if (lines.length) e.addFields({ name: 'المتاح لصاحب الغرفة', value: cut(lines.join('\n'), 1000) });
    return { embeds: [e], components: controlRows(c, chId) };
}
async function sendControlPanel(guild) {
    const t = cfgRaw(); const c = val(t);
    if (!c.controlId) return { ok: false, why: 'حدّد قناة التحكم النصية أولاً.' };
    const ch = await getTextChannel(guild, c.controlId);
    if (!ch) return { ok: false, why: 'قناة التحكم غير موجودة أو ما أقدر أوصلها.' };
    const msg = controlMessage('');
    if (!msg.components.length) return { ok: false, why: 'كل الصلاحيات معطّلة — فعّل صلاحية واحدة على الأقل.' };
    try {
        const ref = t.panelRef;
        if (ref && ref.channelId === ch.id && ch.messages && ch.messages.fetch) {
            const old = await ch.messages.fetch(ref.messageId).catch(() => null);
            if (old) { await old.edit(msg); return { ok: true, url: old.url, updated: true }; }
        }
        const sent = await ch.send(msg); t.panelRef = { channelId: ch.id, messageId: sent.id }; H.save();
        return { ok: true, url: sent.url };
    } catch (e) { return { ok: false, why: 'فشل الإرسال: ' + cut(e.message, 150) + ' — تأكد من صلاحيات البوت في القناة.' }; }
}

// ───── قائمة الإعدادات ─────
function buildPanel(i) {
    const t = cfgRaw(); const c = val(t); const s = sess(i);
    const rows = [];
    let e;
    if (s.page === 'perms') {
        e = embed().setTitle('🔐 ما يستطيع صاحب الغرفة فعله')
            .setDescription('حدد الأزرار المتاحة في لوحة التحكم. **المحدد في القائمة = مفعّل**.\nبعد التعديل اضغط **📤 إرسال اللوحة** لتحديث الرسالة في قناة التحكم.')
            .addFields({ name: 'الصلاحيات', value: ABILITIES.map(a => (c.disabled.includes(a.key) ? '⛔' : '✅') + ' ' + a.emoji + ' ' + a.label).join('\n') });
        rows.push(row(btn('tv:back', 'رجوع', '⬅️', ButtonStyle.Primary), btn('tv:allon', 'تفعيل الكل', '✅', ButtonStyle.Success), btn('tv:alloff', 'إيقاف الكل', '⛔', ButtonStyle.Danger), btn('tv:send', 'إرسال اللوحة', '📤', ButtonStyle.Success)));
        rows.push(row(strSel('tv:abil', 'الصلاحيات المفعّلة', ABILITIES.map(a => ({ label: a.label, value: a.key, emoji: a.emoji, default: !c.disabled.includes(a.key) })), { min: 0, max: ABILITIES.length })));
        e.setFooter({ text: 'كل شيء بالألوان الزرقاء 💙' });
        return { embeds: [e], components: rows };
    }
    e = embed().setTitle('🔊 الرومات المؤقتة')
        .setDescription('عضو يدخل قناة **انضم للإنشاء** فينشأ له روم خاص ويُنقل إليه، ويتحكم فيه من **لوحة التحكم** اللي ترسلها لقناة التحكم بزر **📤 إرسال اللوحة**. يُحذف الروم عند خلوه.')
        .addFields(
            { name: '🔌 النظام', value: onOff(c.enabled), inline: true }, { name: '🗑️ حذف عند الخلو', value: c.autoDelete ? 'نعم' : 'لا', inline: true },
            { name: '🎤 قناة الإنشاء', value: chTxt(c.creatorId), inline: true }, { name: '🎛️ قناة التحكم', value: c.controlId ? chTxt(c.controlId) : '`غير محددة` (اللوحة تُرسل داخل كل روم)', inline: true }, { name: '📁 الفئة', value: c.categoryId ? '<#' + c.categoryId + '>' : 'نفس فئة قناة الإنشاء', inline: true },
            { name: '📤 اللوحة', value: t.panelRef ? 'مرسلة ✅ <#' + t.panelRef.channelId + '>' : 'لم تُرسل بعد', inline: true },
            { name: '🏷️ قالب الاسم', value: '`' + c.name + '`\nالمتغيرات: `{user}` `{username}` `{server}` `{userid}`', inline: false },
            { name: '👥 الحد الأقصى', value: c.limit ? String(c.limit) : 'بلا حد', inline: true }, { name: '🎚️ البت ريت', value: c.bitrate + ' kbps', inline: true },
            { name: '🔥 غرف نشطة', value: String(Object.keys(t.rooms).length), inline: true })
        .setFooter({ text: 'كل شيء بالألوان الزرقاء 💙' });
    rows.push(row(chSel('tv:creator', 'قناة "انضم للإنشاء" (صوتية)', { types: [ChannelType.GuildVoice], selected: c.creatorId ? [c.creatorId] : [] })));
    rows.push(row(chSel('tv:control', 'قناة التحكم النصية (اختياري)', { min: 0, selected: c.controlId ? [c.controlId] : [] })));
    rows.push(row(chSel('tv:cat', 'الفئة / Category (اختياري)', { types: [ChannelType.GuildCategory], min: 0, selected: c.categoryId ? [c.categoryId] : [] })));
    rows.push(row(btn('tv:tog', c.enabled ? 'إيقاف النظام' : 'تفعيل النظام', '🔌', c.enabled ? ButtonStyle.Danger : ButtonStyle.Success), btn('tv:room', 'إعدادات الغرفة', '⚙️', ButtonStyle.Primary), btn('tv:msg', 'رسالة اللوحة', '📝'), btn('tv:auto', c.autoDelete ? 'الحذف: يعمل' : 'الحذف: متوقف', '🗑️'), btn('tv:send', 'إرسال اللوحة', '📤', ButtonStyle.Success)));
    rows.push(row(btn('tv:perms', 'صلاحيات صاحب الغرفة', '🔐', ButtonStyle.Secondary)));
    return { embeds: [e], components: rows };
}
const refresh = (i) => update(i, buildPanel(i));
async function slash(i) { if (!(await adminOnly(i))) return; sess(i).page = 'main'; return i.reply({ ...buildPanel(i), flags: EPH }); }

// ───── إنشاء وحذف الغرف ─────
async function cleanup(guild, chId, deleteChannel) {
    const t = cfgRaw(); const r = t.rooms[chId];
    if (r && r.messageId) { const pc = await getTextChannel(guild, r.panelChannelId); if (pc) { const m = await pc.messages.fetch(r.messageId).catch(() => null); if (m) await m.delete().catch(() => {}); } }
    if (deleteChannel) { const ch = guild.channels.cache.get(chId); if (ch) await ch.delete('غرفة مؤقتة فارغة').catch(() => {}); }
    delete t.rooms[chId]; H.save();
}
async function createRoom(member) {
    const t = cfgRaw(); const c = val(t); const guild = member.guild;
    const creator = guild.channels.cache.get(c.creatorId);
    const parent = c.categoryId || (creator && creator.parentId) || undefined;
    const maxBr = guild.maximumBitrate || 96000;
    const ch = await guild.channels.create({
        name: roomName(c.name, member), type: ChannelType.GuildVoice, parent, userLimit: clamp(c.limit, 0, 99), bitrate: clamp(c.bitrate * 1000, 8000, maxBr),
        permissionOverwrites: [{ id: member.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak, PermissionFlagsBits.Stream] }],
        reason: 'روم مؤقت لـ ' + member.user.username
    });
    try { await member.voice.setChannel(ch); } catch { await ch.delete().catch(() => {}); return; }
    const room = { ownerId: member.id, panelChannelId: '', messageId: '', trusted: [], createdAt: Date.now() };
    t.rooms[ch.id] = room;
    // إن كانت قناة التحكم محددة فاللوحة الثابتة هناك تكفي، وإلا نرسل لوحة داخل شات الروم نفسه
    if (!c.controlId) {
        try { const m = await ch.send(controlMessage(ch.id)); room.panelChannelId = ch.id; room.messageId = m.id; } catch (e) { console.warn('[tempvoice] panel:', e.message); }
    }
    H.save();
}
async function onVoiceState(oldS, newS) {
    const t = cfgRaw(); const c = val(t);
    if (!c.enabled || !newS.guild || newS.guild.id !== SERVER_ID) return;
    if (newS.channelId && newS.channelId === c.creatorId && oldS.channelId !== newS.channelId && newS.member && !newS.member.user.bot) await createRoom(newS.member);
    if (oldS.channelId && oldS.channelId !== newS.channelId && t.rooms[oldS.channelId] && c.autoDelete) {
        const ch = oldS.guild.channels.cache.get(oldS.channelId);
        if (!ch || ch.members.size === 0) await cleanup(oldS.guild, oldS.channelId, true);
    }
}
async function onReady() {
    const t = cfgRaw(); const guild = H.client.guilds && H.client.guilds.cache.get(SERVER_ID); if (!guild) return;
    for (const id of Object.keys(t.rooms)) {
        const ch = guild.channels.cache.get(id);
        if (!ch) await cleanup(guild, id, false);
        else if (val(t).autoDelete && ch.members.size === 0) await cleanup(guild, id, true);
    }
}

// ───── أزرار صاحب الغرفة ─────
function resolveRoom(i, hint, key) {
    const t = cfgRaw();
    if (hint && t.rooms[hint]) return hint;
    const cur = i.member.voice && i.member.voice.channelId;
    if (key === 'claim') return cur && t.rooms[cur] ? cur : null;
    if (cur && t.rooms[cur] && (t.rooms[cur].ownerId === i.user.id || isAdmin(i.member))) return cur;
    const own = Object.entries(t.rooms).find(([, r]) => r.ownerId === i.user.id);
    return own ? own[0] : null;
}
async function roomAction(i, key, hint) {
    const t = cfgRaw(); const c = val(t);
    const say = (m) => (i.deferred || i.replied ? i.editReply({ content: m, components: [] }) : i.reply({ content: m, flags: EPH }));
    if (c.disabled.includes(key)) return say('⛔ هذه الميزة معطّلة من الإدارة.');
    const chId = resolveRoom(i, hint, key);
    if (!chId) return say(key === 'claim' ? '❌ لازم تكون داخل روم مؤقت.' : '❌ ما عندك روم مؤقت — ادخل قناة الإنشاء أولاً وبيتسوى لك روم.');
    const room = t.rooms[chId]; const ch = i.guild.channels.cache.get(chId);
    if (!ch) { await cleanup(i.guild, chId, false); return say('❌ هذه الغرفة لم تعد موجودة.'); }
    const m = i.member; const owner = room.ownerId === m.id; const admin = isAdmin(m);
    if (key === 'claim') {
        if (!ch.members.has(m.id)) return say('❌ لازم تكون داخل الروم.');
        if (ch.members.has(room.ownerId) && room.ownerId !== m.id) return say('❌ صاحب الروم موجود داخله.');
        room.ownerId = m.id; H.save();
        await ch.permissionOverwrites.edit(m.id, { ViewChannel: true, Connect: true, Speak: true }).catch(() => {});
        return say('👑 صرت صاحب الغرفة.');
    }
    if (!owner && !admin) return say('❌ هذا الزر لصاحب الغرفة فقط.');
    if (key === 'rename') return i.showModal(modal('tvm:rename:' + chId, 'تغيير اسم الغرفة', input('name', 'الاسم الجديد', { required: true, max: 100, value: ch.name })));
    if (key === 'limit') return i.showModal(modal('tvm:limit:' + chId, 'حد الأعضاء', input('n', 'العدد (0 = بلا حد)', { required: true, max: 2, value: ch.userLimit })));
    if (key === 'bitrate') return i.showModal(modal('tvm:bitrate:' + chId, 'البت ريت', input('n', 'kbps (8 - ' + Math.floor((i.guild.maximumBitrate || 96000) / 1000) + ')', { required: true, max: 3, value: Math.round((ch.bitrate || 64000) / 1000) })));
    if (USER_ACTS.has(key)) {
        const lab = ABILITIES.find(a => a.key === key).label;
        return i.reply({ content: '**' + lab + '** — اختر العضو:', components: [row(userSel('tv:do:' + key + ':' + chId, 'اختر العضو'))], flags: EPH });
    }
    if (key === 'region') return i.reply({ content: '🌐 اختر منطقة الخادم الصوتي:', components: [row(strSel('tv:reg:' + chId, 'المنطقة', REGIONS.map(([v, l]) => ({ label: l, value: v }))))], flags: EPH });
    await i.deferReply({ flags: EPH });
    try {
        if (key === 'lock') {
            const ow = ch.permissionOverwrites.cache && ch.permissionOverwrites.cache.get(i.guild.id);
            const locked = !!(ow && ow.deny && ow.deny.has && ow.deny.has(PermissionFlagsBits.Connect));
            await ch.permissionOverwrites.edit(i.guild.id, { Connect: locked ? null : false });
            return say(locked ? '🔓 تم فتح الغرفة.' : '🔒 تم قفل الغرفة.');
        }
        if (key === 'hide') {
            const ow = ch.permissionOverwrites.cache && ch.permissionOverwrites.cache.get(i.guild.id);
            const hidden = !!(ow && ow.deny && ow.deny.has && ow.deny.has(PermissionFlagsBits.ViewChannel));
            await ch.permissionOverwrites.edit(i.guild.id, { ViewChannel: hidden ? null : false });
            return say(hidden ? '👁️ تم إظهار الغرفة.' : '🙈 تم إخفاء الغرفة.');
        }
        if (key === 'delete') { await cleanup(i.guild, chId, true); return say('🗑️ تم حذف الغرفة.'); }
    } catch (e) { return say('❌ فشل التنفيذ: ' + cut(e.message, 150) + '\nتأكد من صلاحية Manage Channels للبوت.'); }
}
async function pickUser(i) { // tv:do:<key>:<chId>
    const [, , key, chId] = i.customId.split(':'); const t = cfgRaw(); const room = t.rooms[chId]; const ch = i.guild.channels.cache.get(chId);
    await i.deferUpdate();
    const say = (m) => i.editReply({ content: m, components: [] });
    if (!room || !ch) return say('❌ هذه الغرفة لم تعد موجودة.');
    if (room.ownerId !== i.user.id && !isAdmin(i.member)) return say('❌ لصاحب الغرفة فقط.');
    const uid = i.values[0];
    if (uid === room.ownerId && key !== 'transfer' && key !== 'invite' && key !== 'trust') return say('❌ ما تقدر تسوي هذا لصاحب الغرفة.');
    try {
        if (key === 'kick') { const tm = ch.members.get(uid); if (!tm) return say('❌ العضو مو داخل الغرفة.'); await tm.voice.disconnect('طرد من الغرفة المؤقتة'); return say('🚪 تم طرد <@' + uid + '>.'); }
        if (key === 'ban') { await ch.permissionOverwrites.edit(uid, { Connect: false }); const tm = ch.members.get(uid); if (tm) await tm.voice.disconnect('حظر من الغرفة المؤقتة'); return say('⛔ تم حظر <@' + uid + '> من الغرفة.'); }
        if (key === 'unban') { await ch.permissionOverwrites.edit(uid, { Connect: null }); return say('✅ تم رفع الحظر عن <@' + uid + '>.'); }
        if (key === 'invite') { await ch.permissionOverwrites.edit(uid, { ViewChannel: true, Connect: true }); return say('📨 تمت دعوة <@' + uid + '> — يقدر يدخل حتى لو الغرفة مقفلة.'); }
        if (key === 'trust') { room.trusted = [...new Set([...(room.trusted || []), uid])]; H.save(); await ch.permissionOverwrites.edit(uid, { ViewChannel: true, Connect: true }); return say('🛡️ تم إعطاء <@' + uid + '> ثقة في غرفتك.'); }
        if (key === 'untrust') { room.trusted = (room.trusted || []).filter(x => x !== uid); H.save(); await ch.permissionOverwrites.edit(uid, { ViewChannel: null, Connect: null }); return say('🚫 تم إلغاء ثقة <@' + uid + '>.'); }
        if (key === 'transfer') {
            const tm = ch.members.get(uid); if (!tm || tm.user.bot) return say('❌ العضو لازم يكون داخل الغرفة.');
            room.ownerId = uid; H.save(); await ch.permissionOverwrites.edit(uid, { ViewChannel: true, Connect: true, Speak: true }).catch(() => {});
            return say('👑 تم نقل الملكية إلى <@' + uid + '>.');
        }
    } catch (e) { return say('❌ فشل التنفيذ: ' + cut(e.message, 150)); }
}
async function pickRegion(i) { // tv:reg:<chId>
    const chId = i.customId.split(':')[2]; const t = cfgRaw(); const room = t.rooms[chId]; const ch = i.guild.channels.cache.get(chId);
    await i.deferUpdate();
    if (!room || !ch) return i.editReply({ content: '❌ هذه الغرفة لم تعد موجودة.', components: [] });
    if (room.ownerId !== i.user.id && !isAdmin(i.member)) return i.editReply({ content: '❌ لصاحب الغرفة فقط.', components: [] });
    const v = i.values[0];
    try { await ch.setRTCRegion(v === 'auto' ? null : v); return i.editReply({ content: '🌐 تم تغيير المنطقة إلى **' + (REGIONS.find(r => r[0] === v) || [v, v])[1] + '**.', components: [] }); }
    catch (e) { return i.editReply({ content: '❌ ' + cut(e.message, 150), components: [] }); }
}

async function component(i) {
    const parts = i.customId.split(':'); const a = parts[1];
    if (a === 'do') return pickUser(i);
    if (a === 'reg') return pickRegion(i);
    if (KEYS.has(a)) return roomAction(i, a, parts[2]);
    if (!(await adminOnly(i))) return;
    const t = cfgRaw(); const c = val(t); const s = sess(i);
    if (i.isButton()) {
        if (a === 'room') return i.showModal(modal('tvm:room', 'إعدادات الغرفة الافتراضية',
            input('name', 'قالب الاسم  ({user} {username})', { required: true, max: 100, value: c.name }), input('limit', 'الحد الأقصى للأعضاء (0 = بلا حد)', { required: true, max: 2, value: c.limit }), input('bitrate', 'البت ريت kbps (8 - 384)', { required: true, max: 3, value: c.bitrate })));
        if (a === 'msg') return i.showModal(modal('tvm:msg', 'رسالة لوحة التحكم', input('title', 'العنوان', { required: true, max: 100, value: c.title }), input('desc', 'الوصف', { required: true, paragraph: true, max: 1000, value: c.desc })));
        await i.deferUpdate();
        if (a === 'tog') t.enabled = !c.enabled; else if (a === 'auto') t.autoDelete = !c.autoDelete;
        else if (a === 'perms') s.page = 'perms'; else if (a === 'back') s.page = 'main';
        else if (a === 'allon') t.disabled = []; else if (a === 'alloff') t.disabled = ABILITIES.map(x => x.key);
        else if (a === 'send') {
            const r = await sendControlPanel(i.guild);
            await i.followUp({ content: r.ok ? (r.updated ? '✅ تم تحديث لوحة التحكم.\n' : '✅ تم إرسال لوحة التحكم.\n') + r.url : '❌ ' + r.why, flags: EPH });
        }
        H.save(); return i.editReply(buildPanel(i));
    }
    await i.deferUpdate();
    if (a === 'creator') t.creatorId = i.values[0]; else if (a === 'control') t.controlId = i.values[0] || ''; else if (a === 'cat') t.categoryId = i.values[0] || '';
    else if (a === 'abil') { const on = new Set(i.values); t.disabled = ABILITIES.filter(x => !on.has(x.key)).map(x => x.key); }
    H.save(); return i.editReply(buildPanel(i));
}
async function modalSubmit(i) {
    const parts = i.customId.split(':'); const a = parts[1]; const t = cfgRaw();
    const f = (n) => i.fields.getTextInputValue(n).trim();
    if (a === 'rename' || a === 'limit' || a === 'bitrate') {
        const chId = parts[2]; const room = t.rooms[chId]; const ch = i.guild.channels.cache.get(chId);
        if (!room || !ch) return i.reply({ content: '❌ هذه الغرفة لم تعد موجودة.', flags: EPH });
        if (room.ownerId !== i.user.id && !isAdmin(i.member)) return i.reply({ content: '❌ لصاحب الغرفة فقط.', flags: EPH });
        try {
            if (a === 'rename') await ch.setName(cut(f('name'), 100));
            else if (a === 'limit') { const n = parseInt(f('n'), 10); if (!(n >= 0 && n <= 99)) return i.reply({ content: '❌ العدد بين 0 و 99.', flags: EPH }); await ch.setUserLimit(n); }
            else { const n = parseInt(f('n'), 10); const mx = Math.floor((i.guild.maximumBitrate || 96000) / 1000); if (!(n >= 8 && n <= mx)) return i.reply({ content: '❌ البت ريت بين 8 و ' + mx + ' kbps.', flags: EPH }); await ch.setBitrate(n * 1000); }
        } catch (e) { return i.reply({ content: '❌ ' + cut(e.message, 150), flags: EPH }); }
        return i.reply({ content: '✅ تم التحديث.', flags: EPH });
    }
    if (!(await adminOnly(i))) return;
    if (a === 'room') {
        const l = parseInt(f('limit'), 10), b = parseInt(f('bitrate'), 10);
        if (!(l >= 0 && l <= 99) || !(b >= 8 && b <= 384)) return i.reply({ content: '❌ تأكد من الأرقام (الحد 0-99 والبت ريت 8-384).', flags: EPH });
        t.name = f('name'); t.limit = l; t.bitrate = b;
    } else if (a === 'msg') { t.title = f('title'); t.desc = i.fields.getTextInputValue('desc').trim(); }
    H.save(); return refresh(i);
}

const commands = [{ name: 'tempvoice', description: 'قائمة إعدادات الرومات الصوتية المؤقتة وإرسال لوحة التحكم' }];
return { prefix: 'tv', commands, ephemeral: ['tempvoice'], slash: { tempvoice: slash }, component, modal: modalSubmit, onVoiceState, onReady, _buildPanel: buildPanel, _controlMessage: controlMessage, _sendControlPanel: sendControlPanel };
};
