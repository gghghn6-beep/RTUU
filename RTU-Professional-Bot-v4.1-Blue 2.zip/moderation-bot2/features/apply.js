'use strict';
// ═══ apply.js — نظام التقديمات الاحترافي ═══
// /apply  → لوحة الإدارة (تقديمات بأي اسم، أسئلة بالعشرات، أوراق، صور، رومات قبول/رفض/استقبال، رسائل خاص)
// الأعضاء: قائمة منسدلة في الروم → يختار التقديم → أسئلة داخل أوراق (نوافذ) → مراجعة → إرسال
module.exports = (H) => {
const { D, EPH, BLUE, row, btn, strSel, chSel, roleSel, input, modal, embed, cut, rid, isUrl, session, adminOnly, update, chTxt, getTextChannel, isAdmin } = H;
const db = H.db;
const { ButtonStyle, EmbedBuilder } = D;

const MAX_APPS = 25;            // حد القائمة المنسدلة
const MAX_Q = 100;              // أقصى عدد أسئلة للتقديم الواحد
const QLEN = 300;               // أقصى طول للسؤال
const SESSION_MS = 3 * 24 * 60 * 60 * 1000;   // مسودة التقديم محفوظة 3 أيام (تبقى حتى بعد إعادة تشغيل البوت)
const GREEN = 0x57F287, RED = 0xED4245, YELLOW = 0xFEE75C, BLURPLE = 0x0F2A66;

// ───── التخزين ─────
const PANEL_DEFAULTS = {
    title: 'تقديم إدارة', description: 'مرحباً بك في قسم الدعم الفني.\nإذا كنت ترغب في الانضمام إلى الإدارة، يرجى تأكيد طلبك من الأسفل.\nوإذا كنت ترغب في التقديم على الإدارة العليا، يمكنك الضغط على الزر المخصص أدناه.',
    color: '#0F2A66', image: '', banner: '', thumbnail: '', footer: '', footerIcon: '', authorName: '', authorIcon: '', content: '',
    placeholder: 'اختر نوع التقديم…', showList: 'yes', rulesChannelId: '', channelId: '', messageId: ''
};
function A() {
    const a = (db.apply = db.apply || {});
    if (!a.panel) a.panel = {};
    for (const [k, v] of Object.entries(PANEL_DEFAULTS)) if (a.panel[k] == null) a.panel[k] = v;
    a.apps = Array.isArray(a.apps) ? a.apps : [];
    a.subs = a.subs && typeof a.subs === 'object' ? a.subs : {};
    a.reviewerRoles = Array.isArray(a.reviewerRoles) ? a.reviewerRoles : [];
    a.logChannelId = a.logChannelId || '';
    a.acceptLogId = a.acceptLogId || '';
    a.rejectLogId = a.rejectLogId || '';
    return a;
}
const findApp = (id) => A().apps.find(x => x.id === id);

// إمبد خاص بهذا النظام: يحتفظ بلونه وتذييله ولا يأخذ التذييل/الوقت التلقائي حق index.js
const E = () => { const e = new EmbedBuilder(); e.toJSON = function () { return { ...this.data }; }; return e; };
E.from = (x) => { const e = EmbedBuilder.from(x); e.toJSON = function () { return { ...this.data }; }; return e; };

// ───── أدوات ─────
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const EMOJI_RE = /^(<a?:\w{2,32}:\d{15,25}>|[\p{Extended_Pictographic}\u{1F1E6}-\u{1F1FF}][\p{Extended_Pictographic}\uFE0F\u200D\u{1F3FB}-\u{1F3FF}\u{1F1E6}-\u{1F1FF}]*)$/u;
const okEmoji = (e) => { e = String(e || '').trim(); return e && EMOJI_RE.test(e) ? e : ''; };
const emojiObj = (e) => {
    const m = /^<(a?):(\w{2,32}):(\d{15,25})>$/.exec(e || '');
    if (m) return { id: m[3], name: m[2], animated: !!m[1] };
    return e ? { name: e } : undefined;
};
const normColor = (c) => { const m = /^#?([0-9a-f]{6})$/i.exec(String(c || '').trim()); return m ? '#' + m[1].toLowerCase() : null; };
const parseColor = (c, fb) => { const n = normColor(c); return n ? parseInt(n.slice(1), 16) : (fb != null ? fb : BLUE); };
const fill = (t, v) => String(t).replace(/[\{\[]\s*(user|app|server|reason|note|reviewer|role)\s*[\}\]]/gi, (m, k) => (v[k.toLowerCase()] != null ? v[k.toLowerCase()] : m));
const bar = (a, b, n = 12) => { const f = b ? clamp(Math.round(a / b * n), 0, n) : 0; return '▰'.repeat(f) + '▱'.repeat(n - f) + '  ' + (b ? Math.round(a / b * 100) : 0) + '%'; };
const guildIcon = (g) => { try { return (g && g.iconURL && g.iconURL({ size: 128 })) || undefined; } catch { return undefined; } };
const botUser = () => (H.client && H.client.user) || null;
const botIcon = () => { try { const u = botUser(); return u ? u.displayAvatarURL({ size: 128 }) : undefined; } catch { return undefined; } };

// الأسئلة: السطر اللي يبدأ بـ ~ يكون جوابه قصير (سطر واحد)
const isShort = (q) => /^~/.test(q);
const qText = (q) => String(q).replace(/^~\s*/, '');
const perPage = (app) => clamp(parseInt(app.perPage, 10) || 5, 1, 5);
const pagesOf = (app) => Math.max(1, Math.ceil(app.questions.length / perPage(app)));
const pageRange = (app, page) => { const s = page * perPage(app); return [s, Math.min(app.questions.length, s + perPage(app))]; };
const qLines = (app, from, to, len = 300) => app.questions.slice(from, to).map((q, k) => '**' + (from + k + 1) + '.** ' + cut(qText(q), len)).join('\n');
const canReview = (i) => { const a = A(); try { return isAdmin(i.member) || a.reviewerRoles.some(r => i.member.roles.cache.has(r)); } catch { return false; } };
const firstMissing = (app, p) => app.questions.findIndex((_, k) => !p.answers[k]);

// مسودات الإجابات: محفوظة في data/features.json فلا تضيع بإعادة التشغيل
const drafts = () => (A().drafts = A().drafts && typeof A().drafts === 'object' ? A().drafts : {});
const pending = {
    has: (k) => Object.prototype.hasOwnProperty.call(drafts(), k),
    get: (k) => drafts()[k],
    set: (k, v) => { drafts()[k] = v; H.save(); },
    delete: (k) => { if (k in drafts()) { delete drafts()[k]; H.save(); } },
    [Symbol.iterator]: function* () { yield* Object.entries(drafts()); }
};
function pend(uid, appId, create) {
    const now = Date.now();
    for (const [k, v] of pending) if (now - v.at > SESSION_MS) pending.delete(k);
    const key = uid + ':' + appId;
    if (!pending.has(key) && create) pending.set(key, { answers: {}, at: now });
    const p = pending.get(key); if (p) p.at = now;
    return p;
}
// نرد على نفس الرسالة المؤقتة لو التفاعل جاي منها، وإلا رسالة جديدة
const respond = (i, p) => {
    const fromMsg = typeof i.isFromMessage === 'function' ? i.isFromMessage() : !!(i.isButton && i.isButton());
    return fromMsg && typeof i.update === 'function' ? i.update(p) : i.reply({ ...p, flags: EPH });
};

// ───── لوحة الأعضاء (مؤلف + عنوان + وصف + تذييل + قائمة منسدلة) ─────
function panelPayload() {
    const a = A(); const p = a.panel;
    const color = parseColor(p.color);
    const SEP = '▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬';
    const rules = p.rulesChannelId ? '📜 **قوانين التقديم:** <#' + p.rulesChannelId + '>\n*اقرأها جيداً قبل ما تقدّم*\n\n' + SEP + '\n\n' : '';
    let desc = rules + cut(p.description || PANEL_DEFAULTS.description, 1400);
    if (p.showList !== 'no' && a.apps.length) {
        const lines = a.apps.slice(0, 12).map(x => (x.emoji || '🔹') + ' **' + cut(x.name, 40) + '**' + (x.open ? '' : '  🔴 *(مغلق)*') + (x.rulesChannelId ? '  ・  📜 <#' + x.rulesChannelId + '>' : '') + (x.description ? '\n> ' + cut(x.description, 100) : ''));
        desc += '\n\n' + SEP + '\n**🗂️ الأقسام المتاحة**\n\n' + lines.join('\n\n') + '\n' + SEP;
    }
    const bn = (botUser() && botUser().username) || '';
    const e = E().setColor(color)
        .setTitle(cut(p.title || PANEL_DEFAULTS.title, 256))
        .setDescription(cut(desc, 4000));
    const an = p.authorName || bn;
    if (an) e.setAuthor({ name: cut(an, 256), iconURL: isUrl(p.authorIcon) ? p.authorIcon.trim() : botIcon() });
    const img = isUrl(p.image) ? p.image : (isUrl(p.banner) ? p.banner : '');
    let autoFile = null;
    if (img) e.setImage(img.trim());
    else { const b = require('./banners').banner(cut(p.title || PANEL_DEFAULTS.title, 40), 'نظام التقديمات'); if (b) { autoFile = b; e.setImage('attachment://' + b.name); } }
    if (isUrl(p.thumbnail)) e.setThumbnail(p.thumbnail.trim());
    const ft = p.footer || (bn ? bn + ' • نظام التقديمات' : '');
    if (ft) e.setFooter({ text: cut(ft, 200), iconURL: isUrl(p.footerIcon) ? p.footerIcon.trim() : botIcon() });
    const open = a.apps.filter(x => x.open);
    const menu = open.length
        ? strSel('ap:pick', p.placeholder || PANEL_DEFAULTS.placeholder, open.map(x => ({ label: x.name, value: x.id, description: x.description || undefined, emoji: emojiObj(x.emoji) })))
        : strSel('ap:pick', 'لا توجد تقديمات متاحة حالياً', [{ label: 'مغلق', value: 'none' }], { disabled: true });
    const comps = [row(menu)];
    if (p.rulesChannelId && H.SERVER_ID) comps.push(new D.ActionRowBuilder().addComponents(
        new D.ButtonBuilder().setStyle(ButtonStyle.Link).setLabel('قوانين التقديم').setEmoji(H.E('ap.rules') || '📜').setURL('https://discord.com/channels/' + H.SERVER_ID + '/' + p.rulesChannelId)));
    const out = { content: p.content ? cut(p.content, 2000) : '', embeds: [e], components: comps };
    if (autoFile) out.files = [autoFile];
    return out;
}
async function publishPanel(guild) {
    const a = A(); const p = a.panel;
    const ch = await getTextChannel(guild, p.channelId);
    if (!ch) return { ok: false, msg: '❌ اختر روم النشر أولاً.' };
    if (!a.apps.some(x => x.open)) return { ok: false, msg: '❌ أضف تقديماً واحداً مفتوحاً على الأقل.' };
    const payload = panelPayload();
    try {
        if (p.messageId) {
            const old = await ch.messages.fetch(p.messageId).catch(() => null);
            if (old) { await old.edit({ ...payload, attachments: [] }); return { ok: true, msg: '✅ تم تحديث اللوحة المنشورة في ' + chTxt(ch.id) }; }
        }
        const m = await ch.send(payload);
        p.messageId = m.id; H.save();
        return { ok: true, msg: '✅ تم نشر اللوحة في ' + chTxt(ch.id) };
    } catch (e) { return { ok: false, msg: '❌ تعذّر النشر: ' + cut(e.message, 150) + '\nتأكد من صلاحيات البوت في الروم.' }; }
}
// تحديث اللوحة المنشورة تلقائياً بعد أي تعديل (بصمت)
async function refreshPanel(guild) {
    const p = A().panel;
    if (!guild || !p.channelId || !p.messageId) return;
    try {
        const ch = await getTextChannel(guild, p.channelId);
        const msg = ch && await ch.messages.fetch(p.messageId).catch(() => null);
        if (msg) await msg.edit({ ...panelPayload(), attachments: [] });
    } catch {}
}
const resetSelect = (i) => { try { i.message.edit(panelPayload()).catch(() => {}); } catch {} };

// ───── مسار العضو ─────
// إحصائيات وتقييمات (من سجل التقديمات المحفوظ)
function statsOf(subs) {
    const c = { total: subs.length, pending: 0, accepted: 0, rejected: 0 };
    let sum = 0, n = 0;
    for (const x of subs) { c[x.status] = (c[x.status] || 0) + 1; if (typeof x.score === 'number') { sum += x.score; n++; } }
    c.avg = n ? Math.round(sum / n * 10) / 10 : null;
    return c;
}
const appStats = (appId) => statsOf(Object.values(A().subs).filter(x => x.appId === appId));
const userStats = (uid) => statsOf(Object.values(A().subs).filter(x => x.userId === uid));
const scoreBar = (n) => '▰'.repeat(clamp(n, 0, 10)) + '▱'.repeat(10 - clamp(n, 0, 10)) + '  **' + n + '/10**';
const statsLine = (c) => '📥 **' + c.total + '** تقديم • ✅ قُبل **' + c.accepted + '** • ❌ رُفض **' + c.rejected + '** • ⏳ معلّق **' + c.pending + '**' + (c.avg != null ? '\n⭐ متوسط التقييم: **' + c.avg + '/10**' : '');

// يرجع null لو يقدر يقدّم، وإلا رسالة (التقديم يبقى ظاهر في القائمة لكنه يتوقف عنده)
function statusCard(color, title, desc, fields) {
    return { embeds: [E().setColor(color).setTitle(title).setDescription(desc).addFields(...fields)] };
}
function canApply(i, app) {
    const a = A();
    if (!app || !app.open) return { content: '⛔ هذا التقديم مغلق حالياً.' };
    if (!app.questions.length) return { content: '⚠️ لم يتم ضبط أسئلة هذا التقديم بعد.' };
    const m = i.member;
    try {
        if (app.reqRole && !m.roles.cache.has(app.reqRole)) return { content: '🔒 هذا التقديم يتطلب الرتبة <@&' + app.reqRole + '>.' };
        if (app.minDays > 0 && m.joinedTimestamp) {
            const days = (Date.now() - m.joinedTimestamp) / 86400000;
            if (days < app.minDays) return { content: '⏳ لازم تكون في السيرفر **' + app.minDays + '** يوم على الأقل (باقي ' + Math.ceil(app.minDays - days) + ' يوم).' };
        }
    } catch {}
    const mine = Object.values(a.subs).filter(x => x.userId === i.user.id && x.appId === app.id).sort((x, y) => y.at - x.at);
    const name = (app.emoji ? app.emoji + ' ' : '') + app.name;
    const pend = mine.find(x => x.status === 'pending');
    if (pend) return statusCard(YELLOW, '⏳ تقديمك قيد المراجعة',
        'تقدمت على **' + name + '** <t:' + Math.floor(pend.at / 1000) + ':R>.\nالتقديم متوقف عندك لين تصدر الإدارة قرارها، وتوصلك النتيجة على الخاص.',
        [{ name: '🧾 رقم الطلب', value: '`' + pend.id + '`', inline: true }, { name: '📌 الحالة', value: '⏳ بانتظار المراجعة', inline: true }]);
    const acc = mine.find(x => x.status === 'accepted');
    if (acc) return statusCard(GREEN, '✅ تم قبولك في هذا القسم',
        'تم قبول تقديمك على **' + name + '**، وما تقدر تقدّم عليه مرة ثانية.',
        [{ name: '🧾 رقم الطلب', value: '`' + acc.id + '`', inline: true }, { name: '📅 تاريخ القبول', value: '<t:' + Math.floor((acc.decidedAt || acc.at) / 1000) + ':D>', inline: true }]);
    const rej = mine.find(x => x.status === 'rejected');
    if (rej && app.cooldownH < 0) return statusCard(RED, '❌ لا يمكنك إعادة التقديم',
        'تم رفض تقديمك السابق على **' + name + '**، وهذا القسم لا يسمح بإعادة التقديم.',
        [{ name: '🧾 رقم الطلب', value: '`' + rej.id + '`', inline: true }, { name: '📅 تاريخ القرار', value: '<t:' + Math.floor((rej.decidedAt || rej.at) / 1000) + ':D>', inline: true }]);
    if (rej && app.cooldownH > 0 && Date.now() < (rej.decidedAt || 0) + app.cooldownH * 3600000) {
        const when = Math.floor(((rej.decidedAt || 0) + app.cooldownH * 3600000) / 1000);
        return statusCard(RED, '🕒 التقديم متوقف مؤقتاً',
            'تم رفض تقديمك السابق على **' + name + '**. تقدر تقدّم من جديد <t:' + when + ':R>.',
            [{ name: '🧾 رقم الطلب', value: '`' + rej.id + '`', inline: true }, { name: '🔁 إعادة التقديم', value: '<t:' + when + ':f>', inline: true }]);
    }
    try { if (app.acceptRole && m.roles.cache.has(app.acceptRole)) return { content: '✅ أنت حاصل على رتبة هذا القسم بالفعل.' }; } catch {}
    return null;
}
async function pick(i) {
    const app = findApp(i.values[0]);
    resetSelect(i);
    const err = canApply(i, app);
    if (err) return i.reply({ ...err, flags: EPH });
    const p = pend(i.user.id, app.id, true);
    const miss = firstMissing(app, p);
    // كمّل كل الأسئلة قبل وما أرسل → شاشة المراجعة، وإلا يفتح أول ورقة ناقصة مباشرة
    if (miss === -1) return i.reply({ ...progressPayload(app, p, pagesOf(app) - 1), flags: EPH });
    return showPage(i, app, Math.floor(miss / perPage(app)));
}
function showPage(i, app, page) {
    const [s, e] = pageRange(app, page);
    const title = cut(app.name, 30) + (pagesOf(app) > 1 ? ' (' + (page + 1) + '/' + pagesOf(app) + ')' : '');
    const saved = pend(i.user.id, app.id, false);
    const rows = [];
    for (let k = s; k < e; k++) {
        const q = app.questions[k]; const short = isShort(q); const t = qText(q);
        rows.push(input('q' + k, (k + 1) + '. ' + t, {
            required: true, paragraph: !short, max: short ? 300 : 1000,
            placeholder: t.length > 40 ? t : 'اكتب إجابتك هنا',
            value: saved && saved.answers[k] ? saved.answers[k] : undefined
        }));
    }
    return i.showModal(modal('apm:p:' + app.id + ':' + page, title, ...rows));
}
async function startApp(i, appId) {
    const app = findApp(appId);
    const err = canApply(i, app);
    if (err) return i.reply({ ...err, flags: EPH });
    pend(i.user.id, app.id, true);
    return showPage(i, app, 0);
}
async function contApp(i, appId, page) {
    const app = findApp(appId);
    if (!app || !app.open) return i.reply({ content: '⛔ هذا التقديم مغلق حالياً.', flags: EPH });
    if (!pend(i.user.id, app.id, false)) return i.reply({ content: '⌛ انتهت الجلسة، اختر التقديم من القائمة وابدأ من جديد.', flags: EPH });
    if (!(page >= 0 && page < pagesOf(app))) page = 0;
    return showPage(i, app, page);
}
async function editPage(i, appId) {
    const app = findApp(appId);
    if (!app || !app.open) return i.reply({ content: '⛔ هذا التقديم مغلق حالياً.', flags: EPH });
    if (!pend(i.user.id, app.id, false)) return i.reply({ content: '⌛ انتهت الجلسة، اختر التقديم من القائمة وابدأ من جديد.', flags: EPH });
    const page = clamp(parseInt(i.values[0], 10) || 0, 0, pagesOf(app) - 1);
    return showPage(i, app, page);
}
function progressPayload(app, p, savedPage) {
    const total = app.questions.length;
    const done = app.questions.filter((_, k) => p.answers[k]).length;
    const miss = firstMissing(app, p);
    if (miss !== -1) {
        const next = Math.floor(miss / perPage(app));
        const [s, e] = pageRange(app, next);
        const em = E().setColor(YELLOW)
            .setAuthor({ name: cut(app.name, 256) })
            .setTitle('✅ تم حفظ الورقة ' + (savedPage + 1) + ' من ' + pagesOf(app))
            .setDescription(bar(done, total) + '\n**' + done + '** من **' + total + '** سؤال\n\n**الورقة التالية (' + (next + 1) + '/' + pagesOf(app) + '):**\n' + qLines(app, s, e));
        return { embeds: [em], components: [row(btn('ap:cont:' + app.id + ':' + next, 'أكمل الأسئلة (' + (next + 1) + '/' + pagesOf(app) + ')', '📝', ButtonStyle.Primary), btn('ap:cancel:' + app.id, 'إلغاء', H.E('ap.cancel') || '✖️', ButtonStyle.Secondary))] };
    }
    const em = E().setColor(GREEN)
        .setAuthor({ name: cut(app.name, 256) })
        .setTitle('📋 راجع تقديمك قبل الإرسال')
        .setDescription(bar(total, total) + '\nأجبت على **' + total + '** سؤال في **' + pagesOf(app) + '** ' + (pagesOf(app) > 1 ? 'أوراق' : 'ورقة') + '.\n\nلو تبغى تعدّل أي ورقة اخترها من القائمة، وإذا جاهز اضغط **إرسال**.')
        .setFooter({ text: 'بعد الإرسال ما تقدر تعدّل إجاباتك' });
    const pagesOpts = Array.from({ length: pagesOf(app) }, (_, k) => { const [s, e] = pageRange(app, k); return { label: 'الورقة ' + (k + 1), value: String(k), description: 'الأسئلة ' + (s + 1) + ' – ' + e }; });
    return { embeds: [em], components: [
        row(btn('ap:send:' + app.id, 'إرسال التقديم', H.E('ap.send') || '✅', ButtonStyle.Success), btn('ap:cancel:' + app.id, 'إلغاء', '✖️', ButtonStyle.Danger)),
        row(strSel('ap:edpage:' + app.id, '✏️ تعديل إجابات ورقة…', pagesOpts.slice(0, 25)))] };
}
async function submitPage(i, appId, page) {
    const app = findApp(appId);
    if (!app || !app.open) return i.reply({ content: '⛔ هذا التقديم مغلق حالياً.', flags: EPH });
    const p = pend(i.user.id, app.id, false);
    if (!p) return i.reply({ content: '⌛ انتهت الجلسة، اختر التقديم من القائمة وابدأ من جديد.', flags: EPH });
    const [s, e] = pageRange(app, page);
    for (let k = s; k < e; k++) {
        try { p.answers[k] = i.fields.getTextInputValue('q' + k).trim(); } catch {}
    }
    H.save();
    return respond(i, progressPayload(app, p, page));
}
async function cancelApp(i, appId) {
    pending.delete(i.user.id + ':' + appId);
    return i.update({ content: '✖️ تم إلغاء التقديم.', embeds: [], components: [] });
}

function chunkAnswers(app, answers) {
    const blocks = app.questions.map((q, k) => '**' + (k + 1) + '. ' + cut(qText(q), 200) + '**\n' + cut(answers[k] || '—', 1000));
    const chunks = []; let cur = '';
    for (const b of blocks) {
        if (cur && (cur.length + b.length + 2) > 3600) { chunks.push(cur); cur = ''; }
        cur += (cur ? '\n\n' : '') + b;
    }
    if (cur) chunks.push(cur);
    return chunks;
}
async function sendApp(i, appId) {
    const a = A();
    const app = findApp(appId);
    const err = canApply(i, app);
    if (err) return i.reply({ ...err, flags: EPH });
    const p = pend(i.user.id, app.id, false);
    if (!p) return i.reply({ content: '⌛ انتهت الجلسة، اختر التقديم من القائمة وابدأ من جديد.', flags: EPH });
    const miss = firstMissing(app, p);
    if (miss !== -1) return respond(i, progressPayload(app, p, Math.max(0, Math.floor(miss / perPage(app)) - 1)));
    const ch = await getTextChannel(i.guild, app.channelId || a.logChannelId);
    if (!ch) return i.reply({ content: '❌ لم تُضبط قناة استقبال التقديمات بعد، تواصل مع الإدارة.', flags: EPH });

    const id = rid() + rid();
    const sub = { id, appId: app.id, appName: app.name, userId: i.user.id, at: Date.now(), status: 'pending', answers: app.questions.map((q, k) => ({ q, a: cut(p.answers[k], 1000) })) };
    const m = i.member;
    const info = [
        '👤 **المتقدم:** <@' + i.user.id + '>  (`' + i.user.id + '`)',
        '🗂️ **القسم:** ' + (app.emoji ? app.emoji + ' ' : '') + app.name,
        i.user.createdTimestamp ? '📅 **أنشأ حسابه:** <t:' + Math.floor(i.user.createdTimestamp / 1000) + ':R>' : '',
        m && m.joinedTimestamp ? '📥 **انضم للسيرفر:** <t:' + Math.floor(m.joinedTimestamp / 1000) + ':R>' : '',
        '🕒 **وقت التقديم:** <t:' + Math.floor(sub.at / 1000) + ':F>',
        '📊 **عدد الأسئلة:** ' + app.questions.length
    ].filter(Boolean).join('\n');
    const header = E().setColor(parseColor(app.color, BLURPLE))
        .setAuthor({ name: cut(i.user.username, 256), iconURL: i.user.displayAvatarURL({ size: 128 }) })
        .setTitle(cut('📥 تقديم جديد — ' + app.name, 256))
        .setDescription(info)
        .setThumbnail(i.user.displayAvatarURL({ size: 256 }))
        .addFields({ name: 'الحالة', value: '⏳ بانتظار المراجعة', inline: false })
        .setFooter({ text: 'رقم التقديم: ' + id });
    { const prev = userStats(i.user.id); if (prev.total) header.addFields({ name: '📂 سجل المتقدم السابق', value: cut(statsLine(prev), 1000), inline: false }); }
    const chunks = chunkAnswers(app, p.answers);
    const answerEmbed = (txt, n) => E().setColor(parseColor(app.color, BLURPLE)).setDescription(txt).setFooter({ text: 'الإجابات ' + n + '/' + chunks.length + ' • ' + id });
    const buttons = row(btn('ap:acc:' + id, 'قبول', H.E('ap.accept') || '✅', ButtonStyle.Success), btn('ap:rej:' + id, 'رفض', H.E('ap.reject') || '❌', ButtonStyle.Danger));
    try {
        const mention = app.mentionRole ? '<@&' + app.mentionRole + '>' : '';
        const first = await ch.send({ content: mention || undefined, embeds: [header, answerEmbed(chunks[0], 1)], components: [buttons], allowedMentions: { roles: app.mentionRole ? [app.mentionRole] : [] } });
        for (let k = 1; k < chunks.length; k++) await ch.send({ embeds: [answerEmbed(chunks[k], k + 1)] });
        sub.channelId = ch.id; sub.messageId = first.id;
    } catch (e) {
        return i.reply({ content: '❌ تعذّر إرسال تقديمك لقناة المراجعة (' + cut(e.message, 100) + '). أخبر الإدارة.', flags: EPH });
    }
    a.subs[id] = sub;
    // التقديمات المعلّقة لا تُحذف أبداً؛ نقصّ فقط الأقدم من المنتهية إذا زادت عن 3000
    const keys = Object.keys(a.subs).filter(k => a.subs[k].status !== 'pending');
    if (Object.keys(a.subs).length > 3000) keys.sort((x, y) => a.subs[x].at - a.subs[y].at).slice(0, Object.keys(a.subs).length - 3000).forEach(k => delete a.subs[k]);
    H.save();
    pending.delete(i.user.id + ':' + app.id);
    return i.update({ content: '', components: [], embeds: [E().setColor(GREEN)
        .setAuthor({ name: cut(i.guild ? i.guild.name : 'التقديمات', 256), iconURL: guildIcon(i.guild) })
        .setTitle('✅ تم استلام تقديمك')
        .setDescription('تقديمك على **' + app.name + '** وصل للإدارة وهو الحين قيد المراجعة.\nستصلك النتيجة على الخاص، تأكد أن خاصك مفتوح.')
        .addFields({ name: '🧾 رقم التقديم', value: '`' + id + '`', inline: true }, { name: '🕒 الوقت', value: '<t:' + Math.floor(sub.at / 1000) + ':R>', inline: true })] });
}

// ───── المراجعة (قبول / رفض) ─────
// ═════ قرار القبول / الرفض (رسالة الخاص + اللوق + تحديث رسالة المراجعة) ═════
const SEP = '▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬';
function fmtDur(ms) { const m = Math.max(1, Math.round(ms / 60000)); if (m < 60) return m + ' دقيقة'; const h = Math.round(m / 60); if (h < 48) return h + ' ساعة'; return Math.round(h / 24) + ' يوم'; }
const dmLinkRow = (guild) => (guild && guild.id)
    ? new D.ActionRowBuilder().addComponents(new D.ButtonBuilder().setStyle(ButtonStyle.Link).setLabel('العودة إلى ' + cut(guild.name || 'السيرفر', 40)).setEmoji('🔗').setURL('https://discord.com/channels/' + guild.id))
    : null;
async function dm(userId, embedObj, guild) {
    try {
        const u = await H.client.users.fetch(userId);
        const payload = { embeds: [embedObj] };
        const r = dmLinkRow(guild); if (r) payload.components = [r];
        await u.send(payload);
        return true;
    } catch { return false; }
}
function decisionText(app, sub, status, note, guild, byId, roleId) {
    const vars = { user: '<@' + sub.userId + '>', app: app.name, server: guild ? guild.name : '', reason: note || 'لم يُذكر سبب', note: note || '', reviewer: byId ? '<@' + byId + '>' : '', role: roleId ? '<@&' + roleId + '>' : '' };
    if (status === 'accepted') return fill(app.acceptMsg ||
        'السلام عليكم [user]،\n\nيسرّنا إبلاغك بأنه **تم قبول** طلبك للانضمام إلى **[app]** في **[server]** بعد مراجعة الإدارة لإجاباتك.\n\n**الخطوات القادمة**\n• اطّلع على قوانين القسم وتعليماته\n• تواصل مع الإدارة عند الحاجة\n\nنتشرف بانضمامك ونتمنى لك التوفيق. 🌟', vars);
    return fill(app.rejectMsg ||
        'السلام عليكم [user]،\n\nنشكرك على اهتمامك بـ **[app]** وعلى وقتك وجهدك في تعبئة الطلب.\nبعد المراجعة، نأسف لإبلاغك بأنه **لم يتم قبول** طلبك في الوقت الحالي.\n\nهذا القرار لا يقلل من قيمتك، ونرحّب بمحاولتك مجدداً مستقبلاً. 🤍', vars);
}
function decisionEmbed(app, sub, status, byId, note, guild, text, roleId) {
    const ok = status === 'accepted';
    const logo = ok ? app.logoAccept : app.logoReject;
    const submitted = sub.at || (Date.now() - 3 * 3600000);
    const e = E().setColor(ok ? GREEN : RED)
        .setAuthor({ name: cut((guild ? guild.name : 'التقديمات') + ' • نظام التقديمات', 256), iconURL: guildIcon(guild) })
        .setTitle(ok ? '🎉 تهانينا — تم قبول طلبك' : '📋 نتيجة طلب التقديم')
        .setDescription(cut(text + '\n\n' + SEP, 3500))
        .addFields(
            { name: '🗂️ القسم', value: cut((app.emoji ? app.emoji + ' ' : '') + app.name, 200), inline: true },
            { name: '📌 القرار', value: ok ? '✅ **مقبول**' : '❌ **مرفوض**', inline: true },
            { name: '🧾 رقم الطلب', value: '`' + sub.id + '`', inline: true },
            { name: '👮 المراجع', value: '<@' + byId + '>', inline: true },
            { name: '📅 تاريخ التقديم', value: '<t:' + Math.floor(submitted / 1000) + ':D>', inline: true },
            { name: '⏱️ مدة المراجعة', value: fmtDur(Date.now() - submitted), inline: true });
    if (ok && roleId) e.addFields({ name: '🏅 الرتبة الجديدة', value: '<@&' + roleId + '>', inline: false });
    if (!ok && app.cooldownH > 0) e.addFields({ name: '🔁 إعادة التقديم', value: 'تقدر تقدّم من جديد <t:' + Math.floor((Date.now() + app.cooldownH * 3600000) / 1000) + ':R>', inline: false });
    if (note) e.addFields({ name: ok ? '📝 ملاحظة المراجع' : '📝 سبب القرار', value: cut('> ' + note.replace(/\n/g, '\n> '), 1000), inline: false });
    const th = isUrl(logo) ? logo.trim() : guildIcon(guild);
    if (th) e.setThumbnail(th);
    if (isUrl(app.image)) e.setImage(app.image.trim());
    e.setFooter({ text: cut((guild ? guild.name : '') + ' • قرار رسمي من الإدارة', 200), iconURL: guildIcon(guild) });
    return e;
}
async function logDecision(i, app, sub, status, note, res) {
    const a = A(); const ok = status === 'accepted';
    const chId = ok ? (app.acceptLogId || a.acceptLogId) : (app.rejectLogId || a.rejectLogId);
    if (!chId) return null;
    const ch = await getTextChannel(i.guild, chId);
    if (!ch) return false;
    let u = null; try { u = await H.client.users.fetch(sub.userId); } catch {}
    const e = E().setColor(ok ? GREEN : RED)
        .setAuthor({ name: (ok ? 'سجل القبول' : 'سجل الرفض') + ' • ' + cut(i.guild ? i.guild.name : '', 100), iconURL: guildIcon(i.guild) })
        .setTitle((ok ? '✅ تم قبول التقديم — ' : '❌ تم رفض التقديم — ') + cut(app.name, 200))
        .setDescription('<@' + sub.userId + '>  ⟵  بواسطة  <@' + i.user.id + '>\n' + SEP)
        .addFields(
            { name: '👤 المتقدم', value: '<@' + sub.userId + '>\n`' + sub.userId + '`', inline: true },
            { name: '👮 المراجع', value: '<@' + i.user.id + '>\n`' + i.user.id + '`', inline: true },
            { name: '🗂️ القسم', value: cut((app.emoji ? app.emoji + ' ' : '') + app.name, 200), inline: true },
            { name: '📅 وقت التقديم', value: '<t:' + Math.floor(sub.at / 1000) + ':f>', inline: true },
            { name: '🕒 وقت القرار', value: '<t:' + Math.floor(Date.now() / 1000) + ':f>', inline: true },
            { name: '⏱️ مدة المراجعة', value: fmtDur(Date.now() - sub.at), inline: true });
    e.addFields({ name: '⭐ تقييم المراجع', value: typeof sub.score === 'number' ? scoreBar(sub.score) : '`لم يُقيَّم`', inline: false });
    if (note) e.addFields({ name: ok ? '📝 الملاحظة' : '📝 السبب', value: cut('> ' + note.replace(/\n/g, '\n> '), 1000), inline: false });
    e.addFields({ name: '📊 نتائج القسم', value: cut(statsLine(appStats(app.id || sub.appId)), 1000), inline: false });
    const checks = [];
    if (ok && app.acceptRole) checks.push('🏅 **الرتبة:** ' + (res && res.roleOk ? '✅ أُعطيت <@&' + app.acceptRole + '>' : '❌ تعذّر إعطاؤها'));
    checks.push('📬 **رسالة الخاص:** ' + (res && res.sent ? '✅ وصلت' : '❌ خاصه مقفل'));
    if (sub.channelId && sub.messageId && i.guild) checks.push('🔗 [عرض التقديم الأصلي](https://discord.com/channels/' + i.guild.id + '/' + sub.channelId + '/' + sub.messageId + ')');
    e.addFields({ name: '📋 حالة الإجراءات', value: cut(checks.join('\n'), 1000), inline: false });
    if (u) e.setThumbnail(u.displayAvatarURL({ size: 256 }));
    e.setFooter({ text: 'رقم الطلب: ' + sub.id, iconURL: u ? u.displayAvatarURL({ size: 64 }) : undefined });
    try { await ch.send({ embeds: [e], allowedMentions: { parse: [] } }); return true; } catch { return false; }
}
function decidedPayload(i, status, byId, note, score) {
    const ok = status === 'accepted';
    const embeds = ((i.message && i.message.embeds) || []).map(e => E.from(e));
    if (embeds[0]) {
        embeds[0].setColor(ok ? GREEN : RED);
        const fields = (embeds[0].data.fields || []).filter(f => f.name !== 'الحالة');
        fields.push({ name: 'الحالة', value: (ok ? '✅ **مقبول**' : '❌ **مرفوض**') + ' بواسطة <@' + byId + '> • <t:' + Math.floor(Date.now() / 1000) + ':R>' + (typeof score === 'number' ? '\n⭐ **التقييم:** ' + scoreBar(score) : '') + (note ? '\n> **' + (ok ? 'الملاحظة' : 'السبب') + ':** ' + cut(note, 500) : ''), inline: false });
        embeds[0].setFields(fields);
    }
    const done = row(btn('ap:done', ok ? 'تم القبول' : 'تم الرفض', ok ? '✅' : '❌', ok ? ButtonStyle.Success : ButtonStyle.Danger, true));
    return { content: '', embeds, components: [done] };
}
async function decide(i, sub, status, note) {
    const app = findApp(sub.appId) || { name: sub.appName, questions: [] };
    sub.status = status; sub.by = i.user.id; sub.reason = note || ''; sub.decidedAt = Date.now(); H.save();
    let roleOk = null;
    if (status === 'accepted' && app.acceptRole) {
        const m = await i.guild.members.fetch(sub.userId).catch(() => null);
        if (m) { try { await m.roles.add(app.acceptRole, 'قبول تقديم: ' + app.name); roleOk = true; } catch { roleOk = false; } } else roleOk = false;
    }
    const roleId = roleOk ? app.acceptRole : '';
    const sent = await dm(sub.userId, decisionEmbed(app, sub, status, i.user.id, note, i.guild, decisionText(app, sub, status, note, i.guild, i.user.id, roleId), roleId), i.guild);
    const logged = await logDecision(i, app, sub, status, note, { sent, roleOk });
    return { sent, roleOk, logged };
}
async function review(i, action, subId) {
    const a = A(); const sub = a.subs[subId];
    if (!canReview(i)) return i.reply({ content: '❌ ليس لديك صلاحية مراجعة التقديمات.', flags: EPH });
    if (!sub) return i.reply({ content: '❌ هذا التقديم غير موجود في السجل.', flags: EPH });
    if (sub.status !== 'pending') return i.reply({ content: 'ℹ️ تمت معالجة هذا التقديم مسبقاً.', flags: EPH });
    const score = input('score', 'تقييمك للتقديم من 10 (اختياري)', { required: false, max: 2, placeholder: '8' });
    if (action === 'rej') return i.showModal(modal('apm:rej:' + subId, 'رفض التقديم', input('reason', 'سبب الرفض (اختياري)', { paragraph: true, max: 500, placeholder: 'يصل للمتقدم على الخاص' }), score));
    return i.showModal(modal('apm:acc:' + subId, 'قبول التقديم', input('note', 'ملاحظة للمتقدم (اختياري)', { paragraph: true, max: 500, placeholder: 'تصله مع رسالة القبول' }), score));
}
async function decideSubmit(i, status, subId) {
    const a = A(); const sub = a.subs[subId];
    if (!canReview(i)) return i.reply({ content: '❌ ليس لديك صلاحية مراجعة التقديمات.', flags: EPH });
    if (!sub) return i.reply({ content: '❌ هذا التقديم غير موجود في السجل.', flags: EPH });
    if (sub.status !== 'pending') return i.reply({ content: 'ℹ️ تمت معالجة هذا التقديم مسبقاً.', flags: EPH });
    let note = ''; try { note = i.fields.getTextInputValue(status === 'accepted' ? 'note' : 'reason').trim(); } catch {}
    let rawScore = ''; try { rawScore = i.fields.getTextInputValue('score').trim(); } catch {}
    let score = null;
    if (rawScore) {
        const n = Number(rawScore.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
        if (!Number.isInteger(n) || n < 0 || n > 10) return i.reply({ content: '❌ التقييم لازم يكون رقم صحيح من 0 إلى 10.', flags: EPH });
        score = n;
    }
    sub.score = score;
    await i.deferUpdate();
    const r = await decide(i, sub, status, note);
    await i.editReply(decidedPayload(i, status, i.user.id, note, score));
    const notes = [];
    if (!r.sent) notes.push('⚠️ تعذّر إرسال رسالة للمتقدم على الخاص (خاصه مقفل).');
    if (r.roleOk === false) notes.push('⚠️ تعذّر إعطاء الرتبة (تأكد أن رتبة البوت أعلى منها وأن العضو داخل السيرفر).');
    if (r.logged === false) notes.push('⚠️ تعذّر الإرسال لروم السجل (تأكد من صلاحيات البوت).');
    if (notes.length) await i.followUp({ content: notes.join('\n'), flags: EPH }).catch(() => {});
}

// ───── لوحة الإدارة ─────
const sess = (i) => session(i, 'ap', () => ({ page: 'panel', sel: '', sub: 'q', confirm: false }));
const appLine = (x) => (x.emoji ? x.emoji + ' ' : '') + '**' + cut(x.name, 40) + '** — ' + x.questions.length + ' سؤال • ' + (x.open ? '🟢' : '🔴');
const chOrDefault = (own, def) => own ? chTxt(own) : (def ? chTxt(def) + ' *(افتراضي)*' : '`غير محدد`');

function buildPanel(i) {
    const a = A(); const p = a.panel; const s = sess(i);
    const nav = row(
        btn('ap:nav:panel', 'اللوحة', '🎨', s.page === 'panel' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        btn('ap:nav:apps', 'التقديمات', '🗂️', s.page === 'apps' ? ButtonStyle.Primary : ButtonStyle.Secondary),
        btn('ap:nav:route', 'الرومات والصلاحيات', '📡', s.page === 'route' ? ButtonStyle.Primary : ButtonStyle.Secondary));

    // ── صفحة التقديمات ──
    if (s.page === 'apps') {
        const app = a.apps.find(x => x.id === s.sel);
        if (!app) {
            s.sel = '';
            const e = embed().setTitle('🗂️ إدارة التقديمات')
                .setDescription('أضف أي عدد من التقديمات (إدارة، رقابة، …) وسمّها زي ما تبغى. لكل تقديم أسئلته (تقدر تضيف عشرات الأسئلة) وأوراقه ورومات القبول والرفض ورسائله.')
                .addFields({ name: 'التقديمات (' + a.apps.length + '/' + MAX_APPS + ')', value: a.apps.length ? cut(a.apps.map(appLine).join('\n'), 1000) : '`لا توجد تقديمات — اضغط «إضافة تقديم»`' });
            const comps = [nav];
            if (a.apps.length) comps.push(row(strSel('ap:app', 'اختر تقديماً لتعديله…', a.apps.map(x => ({ label: x.name, value: x.id, description: x.questions.length + ' سؤال • ' + (x.open ? 'مفتوح' : 'مغلق'), emoji: emojiObj(x.emoji) })))));
            comps.push(row(btn('ap:add', 'إضافة تقديم', '➕', ButtonStyle.Success, a.apps.length >= MAX_APPS)));
            return { embeds: [e], components: comps };
        }
        const sub = s.sub || 'q';
        const tabs = row(
            btn('ap:back', 'رجوع', '⬅️', ButtonStyle.Secondary),
            btn('ap:sub:q', 'الأسئلة', '❓', sub === 'q' ? ButtonStyle.Primary : ButtonStyle.Secondary),
            btn('ap:sub:ch', 'الرومات', '📡', sub === 'ch' ? ButtonStyle.Primary : ButtonStyle.Secondary),
            btn('ap:sub:roles', 'الرتب', '🏅', sub === 'roles' ? ButtonStyle.Primary : ButtonStyle.Secondary),
            btn('ap:sub:look', 'المظهر', '🎨', sub === 'look' ? ButtonStyle.Primary : ButtonStyle.Secondary));
        const e = embed().setTitle(cut((app.emoji ? app.emoji + ' ' : '') + app.name, 200))
            .setDescription(app.description ? cut(app.description, 300) : '`بدون وصف`');
        if (normColor(app.color)) e.setColor(parseColor(app.color));
        if (sub === 'q') {
            e.addFields(
                { name: '🔌 الحالة', value: app.open ? '🟢 مفتوح' : '🔴 مغلق', inline: true },
                { name: '📊 الأسئلة', value: app.questions.length + '/' + MAX_Q, inline: true },
                { name: '📄 الأوراق', value: pagesOf(app) + ' (كل ورقة ' + perPage(app) + ' أسئلة)', inline: true },
                { name: '⏱️ بعد الرفض', value: app.cooldownH < 0 ? '🚫 ممنوع إعادة التقديم' : (app.cooldownH ? 'انتظار ' + app.cooldownH + ' ساعة' : '`يقدر يعيد فوراً`'), inline: true },
                { name: '📅 أقل مدة بالسيرفر', value: app.minDays ? app.minDays + ' يوم' : '`بدون`', inline: true },
                { name: '📊 نتائج التقييم', value: cut(statsLine(appStats(app.id)), 1000), inline: false },
                { name: '👁️ أول الأسئلة', value: app.questions.length ? cut(qLines(app, 0, Math.min(app.questions.length, 6), 80), 1000) : '`لا توجد أسئلة — اضغط «إضافة أسئلة»`' });
            return { embeds: [e], components: [tabs,
                row(btn('ap:qadd', 'إضافة أسئلة', '➕', ButtonStyle.Success, app.questions.length >= MAX_Q), btn('ap:qdel', 'حذف', '➖', ButtonStyle.Danger, !app.questions.length),
                    btn('ap:qedit', 'تعديل/نقل', '✏️', ButtonStyle.Primary, !app.questions.length), btn('ap:qlist', 'عرض الكل', '📃', ButtonStyle.Secondary, !app.questions.length),
                    btn('ap:qset', 'الإعدادات', '⚙️', ButtonStyle.Secondary)),
                row(btn('ap:tog', app.open ? 'إغلاق التقديم' : 'فتح التقديم', app.open ? '🔒' : '🔓', ButtonStyle.Secondary),
                    btn('ap:del', s.confirm ? 'تأكيد الحذف ⚠️' : 'حذف التقديم', '🗑️', ButtonStyle.Danger))] };
        }
        if (sub === 'ch') {
            e.addFields(
                { name: '📥 روم استقبال التقديمات', value: chOrDefault(app.channelId, a.logChannelId), inline: false },
                { name: '✅ لوق القبول', value: chOrDefault(app.acceptLogId, a.acceptLogId), inline: true },
                { name: '❌ لوق الرفض', value: chOrDefault(app.rejectLogId, a.rejectLogId), inline: true },
                { name: '📜 روم قوانين هذا التقديم', value: app.rulesChannelId ? chTxt(app.rulesChannelId) : '`بدون (يستخدم قوانين اللوحة)`', inline: false });
            return { embeds: [e], components: [tabs,
                row(chSel('ap:ach', 'روم استقبال هذا التقديم (فاضي = الافتراضي)', { min: 0, max: 1, selected: app.channelId ? [app.channelId] : [] })),
                row(chSel('ap:aalog', 'لوق القبول (فاضي = الافتراضي)', { min: 0, max: 1, selected: app.acceptLogId ? [app.acceptLogId] : [] })),
                row(chSel('ap:arlog', 'لوق الرفض (فاضي = الافتراضي)', { min: 0, max: 1, selected: app.rejectLogId ? [app.rejectLogId] : [] })),
                row(chSel('ap:arul', '📜 روم قوانين هذا التقديم (اختياري)', { min: 0, max: 1, selected: app.rulesChannelId ? [app.rulesChannelId] : [] }))] };
        }
        if (sub === 'roles') {
            e.addFields(
                { name: '🏅 رتبة تُعطى عند القبول', value: app.acceptRole ? '<@&' + app.acceptRole + '>' : '`بدون`', inline: true },
                { name: '🔔 منشن عند وصول تقديم', value: app.mentionRole ? '<@&' + app.mentionRole + '>' : '`بدون`', inline: true },
                { name: '🔒 رتبة مطلوبة للتقديم', value: app.reqRole ? '<@&' + app.reqRole + '>' : '`الجميع`', inline: true });
            return { embeds: [e], components: [tabs,
                row(roleSel('ap:arole', 'رتبة تُعطى عند القبول (اختياري)', { min: 0, max: 1, selected: app.acceptRole ? [app.acceptRole] : [] })),
                row(roleSel('ap:mrole', 'رتبة تُمنشن عند وصول تقديم (اختياري)', { min: 0, max: 1, selected: app.mentionRole ? [app.mentionRole] : [] })),
                row(roleSel('ap:qrole', 'رتبة مطلوبة لتقدر تقدّم (اختياري)', { min: 0, max: 1, selected: app.reqRole ? [app.reqRole] : [] }))] };
        }
        // look
        e.addFields(
            { name: '🖼️ صورة التقديم', value: app.image ? '✅ موجودة' : '`بدون`', inline: true },
            { name: '🎨 اللون', value: '`' + (normColor(app.color) || 'مثل اللوحة') + '`', inline: true },
            { name: '✅ شعار القبول', value: app.logoAccept ? '✅ موجود' : '`شعار السيرفر`', inline: true },
            { name: '❌ شعار الرفض', value: app.logoReject ? '✅ موجود' : '`شعار السيرفر`', inline: true },
            { name: '💬 رسائل الخاص', value: (app.acceptMsg ? '✅ قبول مخصصة' : 'قبول افتراضية') + ' • ' + (app.rejectMsg ? '✅ رفض مخصصة' : 'رفض افتراضية'), inline: false });
        return { embeds: [e], components: [tabs,
            row(btn('ap:edit', 'الاسم والوصف', '✏️', ButtonStyle.Primary), btn('ap:img', 'صور وألوان وشعارات', '🖼️', ButtonStyle.Primary),
                btn('ap:msgs', 'رسائل القبول والرفض', '💬', ButtonStyle.Primary), btn('ap:prev', 'معاينة رسائل الخاص', '👁️', ButtonStyle.Secondary))] };
    }

    // ── صفحة الرومات والصلاحيات (افتراضية لكل التقديمات) ──
    if (s.page === 'route') {
        const e = embed().setTitle('📡 الرومات والصلاحيات')
            .setDescription('هذي الإعدادات الافتراضية لكل التقديمات. تقدر تخصص روم مختلف لتقديم معين من تبويب «الرومات» داخل التقديم نفسه.')
            .addFields(
                { name: '📥 استقبال التقديمات', value: chTxt(a.logChannelId), inline: true },
                { name: '✅ لوق القبول', value: chTxt(a.acceptLogId), inline: true },
                { name: '❌ لوق الرفض', value: chTxt(a.rejectLogId), inline: true },
                { name: '👮 رتب المراجعين', value: a.reviewerRoles.length ? a.reviewerRoles.map(r => '<@&' + r + '>').join(' ') : '`الإدارة فقط`' });
        return { embeds: [e], components: [nav,
            row(chSel('ap:rch', 'روم استقبال التقديمات (الافتراضي)', { min: 0, max: 1, selected: a.logChannelId ? [a.logChannelId] : [] })),
            row(chSel('ap:ralog', 'لوق القبول (الافتراضي)', { min: 0, max: 1, selected: a.acceptLogId ? [a.acceptLogId] : [] })),
            row(chSel('ap:rrlog', 'لوق الرفض (الافتراضي)', { min: 0, max: 1, selected: a.rejectLogId ? [a.rejectLogId] : [] })),
            row(roleSel('ap:rev', 'رتب تقدر تقبل/ترفض (الإدارة دايماً تقدر)', { min: 0, max: 10, selected: a.reviewerRoles }))] };
    }

    // ── صفحة اللوحة ──
    const e = embed().setTitle('🎨 لوحة التقديمات')
        .setDescription('الرسالة اللي ينشرها البوت للأعضاء: مؤلف + عنوان + وصف + تذييل وتحتها قائمة منسدلة بالتقديمات.')
        .addFields(
            { name: '🧾 العنوان', value: cut(p.title, 100), inline: true },
            { name: '🎨 اللون', value: '`' + (normColor(p.color) || '#0F2A66') + '`', inline: true },
            { name: '🖼️ الصور', value: [p.image ? '✅ صورة' : '— صورة', p.banner ? '✅ بانر' : '— بانر', p.thumbnail ? '✅ مصغرة' : '— مصغرة'].join(' • '), inline: true },
            { name: '👤 هوية اللوحة', value: (p.authorName || (botUser() && botUser().username) || '—') + ' • ' + (p.footer ? 'تذييل ✅' : 'بدون تذييل'), inline: true },
            { name: '📜 روم قوانين التقديم', value: p.rulesChannelId ? chTxt(p.rulesChannelId) : '`غير محدد`', inline: true },
            { name: '📍 روم النشر', value: chTxt(p.channelId), inline: true },
            { name: '📌 الحالة', value: p.messageId ? '✅ منشورة' : '`لم تُنشر بعد`', inline: true },
            { name: '🗂️ التقديمات (' + a.apps.length + ')', value: a.apps.length ? cut(a.apps.map(x => (x.emoji ? x.emoji + ' ' : '') + x.name + (x.open ? '' : ' 🔴')).join(' • '), 1000) : '`لا توجد — افتح تبويب التقديمات وأضف أول تقديم`' });
    return { embeds: [e], components: [nav,
        row(btn('ap:panel', 'نص اللوحة', '✏️', ButtonStyle.Primary), btn('ap:media', 'صور', '🖼️', ButtonStyle.Primary),
            btn('ap:ident', 'الهوية', '👤', ButtonStyle.Primary), btn('ap:preview', 'معاينة', '👁️', ButtonStyle.Secondary),
            btn('ap:publish', p.messageId ? 'تحديث' : 'نشر', '📤', ButtonStyle.Success, !p.channelId || !a.apps.some(x => x.open))),
        row(chSel('ap:prul', '📜 روم قوانين التقديم (يظهر بارز في اللوحة)', { min: 0, max: 1, selected: p.rulesChannelId ? [p.rulesChannelId] : [] })),
        row(chSel('ap:pch', 'روم نشر اللوحة', { min: 0, max: 1, selected: p.channelId ? [p.channelId] : [] }))] };
}
const refresh = (i) => update(i, buildPanel(i));

async function slash(i) {
    if (!(await adminOnly(i))) return;
    const s = sess(i); s.page = 'panel'; s.sel = ''; s.sub = 'q'; s.confirm = false;
    return i.reply({ ...buildPanel(i), flags: EPH });
}

async function component(i) {
    const parts = i.customId.split(':'); const act = parts[1];
    // مسار الأعضاء والمراجعين
    if (act === 'pick' && i.isStringSelectMenu()) return pick(i);
    if (act === 'start' && i.isButton()) return startApp(i, parts[2]);
    if (act === 'cont' && i.isButton()) return contApp(i, parts[2], parseInt(parts[3], 10) || 0);
    if (act === 'send' && i.isButton()) return sendApp(i, parts[2]);
    if (act === 'cancel' && i.isButton()) return cancelApp(i, parts[2]);
    if (act === 'edpage' && i.isStringSelectMenu()) return editPage(i, parts[2]);
    if ((act === 'acc' || act === 'rej') && i.isButton()) return review(i, act, parts[2]);

    // من هنا إدارة فقط
    if (!(await adminOnly(i))) return;
    const a = A(); const p = a.panel; const s = sess(i);
    const app = a.apps.find(x => x.id === s.sel);
    if (act !== 'del') s.confirm = false;

    if (i.isButton()) {
        if (act === 'panel') return i.showModal(modal('apm:panel', 'نص اللوحة',
            input('title', 'العنوان', { required: true, max: 100, value: p.title }),
            input('desc', 'الوصف (يظهر داخل اللوحة)', { required: true, paragraph: true, max: 1500, value: p.description }),
            input('color', 'اللون (مثال: #0F2A66)', { required: false, max: 7, value: p.color }),
            input('image', 'رابط الصورة الكبيرة (اختياري)', { required: false, max: 300, value: p.image }),
            input('content', 'نص خارج اللوحة فوقها (اختياري)', { required: false, paragraph: true, max: 1000, value: p.content })));
        if (act === 'media') return i.showModal(modal('apm:media', 'صور اللوحة',
            input('banner', 'رابط صورة كبيرة (تظهر داخل اللوحة)', { required: false, max: 300, value: p.banner }),
            input('thumb', 'رابط صورة مصغرة (يمين اللوحة)', { required: false, max: 300, value: p.thumbnail }),
            input('ph', 'نص القائمة المنسدلة', { required: false, max: 100, value: p.placeholder }),
            input('lst', 'عرض قائمة الأقسام داخل اللوحة؟ (نعم/لا)', { required: false, max: 3, value: p.showList === 'no' ? 'لا' : 'نعم' })));
        if (act === 'ident') return i.showModal(modal('apm:ident', 'هوية اللوحة',
            input('an', 'اسم المؤلف (فوق العنوان)', { required: false, max: 80, value: p.authorName, placeholder: 'فاضي = اسم البوت' }),
            input('ai', 'رابط أيقونة المؤلف', { required: false, max: 300, value: p.authorIcon, placeholder: 'فاضي = صورة البوت' }),
            input('ft', 'نص التذييل (أسفل اللوحة)', { required: false, max: 100, value: p.footer }),
            input('fi', 'رابط أيقونة التذييل', { required: false, max: 300, value: p.footerIcon })));
        if (act === 'add') return i.showModal(modal('apm:add', 'إضافة تقديم',
            input('name', 'اسم التقديم (مثال: تقديم إدارة)', { required: true, max: 40 }),
            input('emoji', 'إيموجي (اختياري)', { required: false, max: 40 }),
            input('desc', 'وصف قصير يظهر في القائمة (اختياري)', { required: false, max: 100 })));
        if (act === 'preview') { await i.reply({ ...panelPayload(), flags: EPH }); return; }
        if (act === 'qadd' && app) return i.showModal(modal('apm:qadd', 'إضافة أسئلة',
            input('qs', 'اكتب كل سؤال في سطر', { required: true, paragraph: true, max: 4000, placeholder: 'كم عمرك؟\n~ ما اسمك؟  (علامة ~ = جواب قصير)\nليش تبغى تتقدم؟' })));
        if (act === 'qdel' && app) return i.showModal(modal('apm:qdel', 'حذف أسئلة',
            input('nums', 'أرقام الأسئلة (1,3) أو (5-10) أو: الكل', { required: true, max: 100, placeholder: '2,4,7-9' })));
        if (act === 'qedit' && app) return i.showModal(modal('apm:qedit', 'تعديل أو نقل سؤال',
            input('num', 'رقم السؤال', { required: true, max: 3 }),
            input('text', 'النص الجديد (فاضي = بدون تغيير)', { required: false, max: QLEN }),
            input('pos', 'انقله لرقم (اختياري)', { required: false, max: 3 })));
        if (act === 'qset' && app) return i.showModal(modal('apm:qset', 'إعدادات التقديم',
            input('pp', 'أسئلة كل ورقة (1 – 5)', { required: true, max: 1, value: perPage(app) }),
            input('cd', 'انتظار بعد الرفض بالساعات (0=فوراً، -1=ممنوع)', { required: true, max: 4, value: app.cooldownH || 0 }),
            input('md', 'أقل مدة بالسيرفر بالأيام (0 = بدون)', { required: true, max: 4, value: app.minDays || 0 })));
        if (act === 'edit' && app) return i.showModal(modal('apm:edit', 'الاسم والوصف',
            input('name', 'اسم التقديم', { required: true, max: 40, value: app.name }),
            input('emoji', 'إيموجي (اختياري)', { required: false, max: 40, value: app.emoji }),
            input('desc', 'وصف قصير (اختياري)', { required: false, max: 100, value: app.description })));
        if (act === 'img' && app) return i.showModal(modal('apm:img', 'صور وألوان وشعارات',
            input('image', 'رابط صورة التقديم الكبيرة', { required: false, max: 300, value: app.image }),
            input('color', 'لون التقديم (مثال: #ff8800)', { required: false, max: 7, value: app.color }),
            input('la', 'رابط شعار القبول (يظهر بالخاص)', { required: false, max: 300, value: app.logoAccept }),
            input('lr', 'رابط شعار الرفض (يظهر بالخاص)', { required: false, max: 300, value: app.logoReject })));
        if (act === 'msgs' && app) return i.showModal(modal('apm:msgs', 'رسائل القبول والرفض',
            input('okmsg', 'رسالة القبول [user] [app] [server]', { required: false, paragraph: true, max: 1000, value: app.acceptMsg, placeholder: 'فاضي = الرسالة الافتراضية' }),
            input('nomsg', 'رسالة الرفض [reason] [app] [server]', { required: false, paragraph: true, max: 1000, value: app.rejectMsg, placeholder: 'فاضي = الرسالة الافتراضية' })));
        if (act === 'qlist' && app) {
            const lines = app.questions.map((q, k) => '**' + (k + 1) + '.** ' + (isShort(q) ? '`قصير` ' : '') + cut(qText(q), QLEN));
            const chunks = []; let cur = '';
            for (const l of lines) { if (cur && cur.length + l.length + 1 > 3800) { chunks.push(cur); cur = ''; } cur += (cur ? '\n' : '') + l; }
            if (cur) chunks.push(cur);
            const mk = (t, n) => E().setColor(BLUE).setTitle(n === 0 ? '📃 أسئلة ' + cut(app.name, 100) + ' (' + app.questions.length + ')' : 'تابع (' + (n + 1) + '/' + chunks.length + ')').setDescription(t);
            await i.reply({ embeds: [mk(chunks[0], 0)], flags: EPH });
            for (let k = 1; k < chunks.length; k++) await i.followUp({ embeds: [mk(chunks[k], k)], flags: EPH });
            return;
        }
        if (act === 'prev' && app) {
            const fake = { id: 'EXAMPLE1234', userId: i.user.id, at: Date.now() - 5 * 3600000 };
            const ok = decisionEmbed(app, fake, 'accepted', i.user.id, 'ملاحظة تجريبية من المراجع', i.guild, decisionText(app, fake, 'accepted', 'ملاحظة تجريبية من المراجع', i.guild, i.user.id, app.acceptRole), app.acceptRole);
            const no = decisionEmbed(app, fake, 'rejected', i.user.id, 'سبب تجريبي للرفض', i.guild, decisionText(app, fake, 'rejected', 'سبب تجريبي للرفض', i.guild, i.user.id, ''), '');
            const lr = dmLinkRow(i.guild);
            await i.reply({ content: '👁️ هذا شكل الرسالتين اللي توصل للمتقدم على الخاص:', embeds: [ok], components: lr ? [lr] : [], flags: EPH });
            await i.followUp({ embeds: [no], components: lr ? [dmLinkRow(i.guild)] : [], flags: EPH });
            return;
        }
        await i.deferUpdate();
        if (act === 'nav') { s.page = ['apps', 'route'].includes(parts[2]) ? parts[2] : 'panel'; if (s.page === 'apps') s.sel = ''; }
        else if (act === 'back') { s.sel = ''; s.page = 'apps'; }
        else if (act === 'sub') { s.sub = ['q', 'ch', 'roles', 'look'].includes(parts[2]) ? parts[2] : 'q'; }
        else if (act === 'tog' && app) { app.open = !app.open; H.save(); refreshPanel(i.guild); }
        else if (act === 'del' && app) {
            if (!s.confirm) s.confirm = true;
            else { a.apps = a.apps.filter(x => x.id !== app.id); s.sel = ''; s.confirm = false; H.save(); refreshPanel(i.guild); }
        }
        else if (act === 'publish') {
            const r = await publishPanel(i.guild);
            await i.editReply(buildPanel(i));
            return i.followUp({ content: r.msg, flags: EPH });
        }
        return i.editReply(buildPanel(i));
    }

    await i.deferUpdate();
    if (i.isStringSelectMenu() && act === 'app') { s.sel = i.values[0]; s.page = 'apps'; s.sub = 'q'; }
    else if (i.isChannelSelectMenu()) {
        const v = i.values[0] || '';
        if (act === 'pch') { p.channelId = v; if (!v) p.messageId = ''; }
        else if (act === 'prul') p.rulesChannelId = v;
        else if (act === 'arul' && app) app.rulesChannelId = v;
        else if (act === 'rch') a.logChannelId = v;
        else if (act === 'ralog') a.acceptLogId = v;
        else if (act === 'rrlog') a.rejectLogId = v;
        else if (act === 'ach' && app) app.channelId = v;
        else if (act === 'aalog' && app) app.acceptLogId = v;
        else if (act === 'arlog' && app) app.rejectLogId = v;
    } else if (i.isRoleSelectMenu()) {
        if (act === 'rev') a.reviewerRoles = i.values.slice(0, 10);
        else if (act === 'arole' && app) app.acceptRole = i.values[0] || '';
        else if (act === 'mrole' && app) app.mentionRole = i.values[0] || '';
        else if (act === 'qrole' && app) app.reqRole = i.values[0] || '';
    }
    H.save();
    return i.editReply(buildPanel(i));
}

// "2,4,7-9" → مجموعة أرقام
function parseNums(raw, max) {
    const out = new Set();
    for (const part of String(raw).split(/[,\s،]+/).filter(Boolean)) {
        const m = /^(\d+)\s*[-–]\s*(\d+)$/.exec(part);
        if (m) { const x = parseInt(m[1], 10), y = parseInt(m[2], 10); for (let n = Math.min(x, y); n <= Math.max(x, y); n++) if (n >= 1 && n <= max) out.add(n); }
        else { const n = parseInt(part, 10); if (n >= 1 && n <= max) out.add(n); }
    }
    return out;
}

async function modalSubmit(i) {
    const parts = i.customId.split(':'); const act = parts[1];
    // مسار الأعضاء والمراجعين
    if (act === 'p') return submitPage(i, parts[2], parseInt(parts[3], 10) || 0);
    if (act === 'acc') return decideSubmit(i, 'accepted', parts[2]);
    if (act === 'rej') return decideSubmit(i, 'rejected', parts[2]);

    if (!(await adminOnly(i))) return;
    const a = A(); const p = a.panel; const s = sess(i);
    const app = a.apps.find(x => x.id === s.sel);
    const val = (n) => { try { return i.fields.getTextInputValue(n).trim(); } catch { return ''; } };
    const bad = (m) => i.reply({ content: '❌ ' + m, flags: EPH });
    const urls = (...u) => u.every(x => !x || isUrl(x));

    if (act === 'panel') {
        const col = val('color');
        if (col && !normColor(col)) return bad('اللون لازم يكون بصيغة #0F2A66');
        const img = val('image');
        if (img && !isUrl(img)) return bad('رابط الصورة غير صحيح.');
        p.title = val('title') || PANEL_DEFAULTS.title; p.description = val('desc') || PANEL_DEFAULTS.description;
        p.color = normColor(col) || '#0F2A66'; p.image = img; p.content = val('content');
    } else if (act === 'media') {
        if (!urls(val('banner'), val('thumb'))) return bad('الروابط لازم تبدأ بـ https://');
        p.banner = val('banner'); p.thumbnail = val('thumb'); p.placeholder = val('ph') || PANEL_DEFAULTS.placeholder;
        p.showList = /^(لا|no|n)$/i.test(val('lst')) ? 'no' : 'yes';
    } else if (act === 'ident') {
        if (!urls(val('ai'), val('fi'))) return bad('الروابط لازم تبدأ بـ https://');
        p.authorName = val('an'); p.authorIcon = val('ai'); p.footer = val('ft'); p.footerIcon = val('fi');
    } else if (act === 'add') {
        if (a.apps.length >= MAX_APPS) return bad('وصلت الحد الأقصى (' + MAX_APPS + ').');
        const name = val('name'); if (!name) return bad('اكتب اسم التقديم.');
        let id; do { id = rid(); } while (a.apps.some(x => x.id === id));
        a.apps.push({ id, name, emoji: okEmoji(val('emoji')), description: val('desc'), questions: [], perPage: 5, cooldownH: 0, minDays: 0,
            channelId: '', acceptLogId: '', rejectLogId: '', rulesChannelId: '', acceptRole: '', mentionRole: '', reqRole: '', image: '', color: '', logoAccept: '', logoReject: '',
            open: true, acceptMsg: '', rejectMsg: '' });
        s.sel = id; s.page = 'apps'; s.sub = 'q';
    } else if (act === 'edit' && app) {
        app.name = val('name') || app.name; app.emoji = okEmoji(val('emoji')); app.description = val('desc');
    } else if (act === 'img' && app) {
        const col = val('color');
        if (col && !normColor(col)) return bad('اللون لازم يكون بصيغة #ff8800');
        if (!urls(val('image'), val('la'), val('lr'))) return bad('الروابط لازم تبدأ بـ https://');
        app.image = val('image'); app.color = normColor(col) || ''; app.logoAccept = val('la'); app.logoReject = val('lr');
    } else if (act === 'msgs' && app) {
        app.acceptMsg = val('okmsg'); app.rejectMsg = val('nomsg');
    } else if (act === 'qadd' && app) {
        const room = MAX_Q - app.questions.length;
        const qs = val('qs').split(/\r?\n/).map(x => cut(x.trim(), QLEN)).filter(x => x && x !== '~').slice(0, room);
        if (!qs.length) return bad('ما كتبت أي سؤال.');
        app.questions.push(...qs);
    } else if (act === 'qdel' && app) {
        const raw = val('nums');
        if (/^(الكل|all)$/i.test(raw)) app.questions = [];
        else {
            const nums = parseNums(raw, app.questions.length);
            if (!nums.size) return bad('أرقام غير صحيحة. مثال: 1,3 أو 5-10');
            app.questions = app.questions.filter((_, k) => !nums.has(k + 1));
        }
    } else if (act === 'qedit' && app) {
        const n = parseInt(val('num'), 10);
        if (!(n >= 1 && n <= app.questions.length)) return bad('رقم السؤال غير صحيح (1 – ' + app.questions.length + ').');
        const t = cut(val('text'), QLEN);
        if (t) app.questions[n - 1] = t;
        const pos = parseInt(val('pos'), 10);
        if (pos >= 1 && pos <= app.questions.length && pos !== n) { const [q] = app.questions.splice(n - 1, 1); app.questions.splice(pos - 1, 0, q); }
    } else if (act === 'qset' && app) {
        const pp = parseInt(val('pp'), 10), cd = parseInt(val('cd'), 10), md = parseInt(val('md'), 10);
        if (![pp, cd, md].every(Number.isFinite) || pp < 1 || pp > 5 || cd < -1 || md < 0) return bad('اكتب أرقام صحيحة (الأسئلة بالورقة من 1 إلى 5).');
        app.perPage = pp; app.cooldownH = clamp(cd, -1, 720); app.minDays = clamp(md, 0, 365);
    } else return;
    H.save();
    refreshPanel(i.guild);
    return refresh(i);
}

const commands = [{ name: 'apply', description: 'لوحة إدارة التقديمات (أسئلة، أوراق، رومات القبول والرفض، شكل اللوحة)' }];
return { prefix: 'ap', commands, ephemeral: ['apply'], slash: { apply: slash }, component, modal: modalSubmit, _buildPanel: buildPanel, _panelPayload: panelPayload };
};
