# Moderation Bot PRO

بوت بدون داشبورد — كل شيء بأوامر سلاش.

## الإعداد

كل شيء في ملف واحد: `config.json`

- token = توكن البوت
- clientId = آيدي البوت
- guildId = آيدي السيرفر

## التشغيل

```bash
npm install
npm start
```

ثم في ديسكورد:
```
/setup
```
